<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/layout/html.html.twig */
class __TwigTemplate_ce1aaf9eeaa752e3b26fbe1578c7fa3f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        $context["body_classes"] = [((        // line 28
($context["logged_in"] ?? null)) ? ("user-logged-in") : ("")), (( !        // line 29
($context["root_path"] ?? null)) ? ("path-frontpage") : (("path-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["root_path"] ?? null), 29, $this->source))))), ((        // line 30
($context["node_type"] ?? null)) ? (("page-node-type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["node_type"] ?? null), 30, $this->source)))) : ("")), ((        // line 31
($context["db_offline"] ?? null)) ? ("db-offline") : ("")), (((        // line 32
($context["b5_body_schema"] ?? null) == "light")) ? (" text-dark") : ((((($context["b5_body_schema"] ?? null) == "dark")) ? (" text-light") : (" ")))), (((        // line 33
($context["b5_body_bg_schema"] ?? null) != "none")) ? ((" bg-" . $this->sandbox->ensureToStringAllowed(($context["b5_body_bg_schema"] ?? null), 33, $this->source))) : (" ")), "d-flex flex-column", ((        // line 35
($context["body_class_for_page_404"] ?? null)) ? ("page-404") : (""))];
        // line 38
        yield "<!DOCTYPE html>
<html";
        // line 39
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["html_attributes"] ?? null), "addClass", ["h-100"], "method", false, false, true, 39), 39, $this->source), "html", null, true);
        yield ">
    <head-placeholder token=\"";
        // line 40
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["placeholder_token"] ?? null), 40, $this->source), "html", null, true);
        yield "\">
      <meta charset=\"UTF-8\">
      <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
      <link rel=\"shortcut icon\" href=\"/";
        // line 44
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 44, $this->source) . "/CAP.PA.svg"), "html", null, true);
        yield "\">
      <title>";
        // line 45
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->safeJoin($this->env, $this->sandbox->ensureToStringAllowed(($context["head_title"] ?? null), 45, $this->source), " | "));
        yield "</title>
      <css-placeholder token=\"";
        // line 46
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["placeholder_token"] ?? null), 46, $this->source), "html", null, true);
        yield "\">
      <js-placeholder token=\"";
        // line 47
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["placeholder_token"] ?? null), 47, $this->source), "html", null, true);
        yield "\">
    </head>
    <body";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["body_classes"] ?? null)], "method", false, false, true, 49), 49, $this->source), "html", null, true);
        yield ">
        <div class=\"visually-hidden-focusable skip-link p-3 container\">
          <a href=\"#main-content\" class=\"p-2\">
            ";
        // line 52
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Skip to main content"));
        yield "
          </a>
        </div>
        <div class=\"container-fluid g-0\">
        <div class=\"fixed-header\">
          <header class=\"d-flex gap-2 px-3 py-2 ps-header align-items-center justify-content-between\">
                <div class=\"d-flex gap-3 align-items-center h-100\">
                    <h1><a href=\"/\"><img src=\"/";
        // line 59
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 59, $this->source) . "/logo.svg"), "html", null, true);
        yield "\" alt=\"Capgemini Logo\"/></a></h1>
                    <div class=\"vertical-divider\"></div>
                    <a href=\"/\" class=\" d-flex flex-row align-items-center gap-1 ps-logo\">
                        <h2 class=\"h3 mb-0\">PRISM</h2>
                        <span>-</span>
                        <span>Kaleidoscope to Knowledge</span>
                    </a>
                </div>
                ";
        // line 67
        if (( !($context["is_front"] ?? null) && ($context["logged_in"] ?? null))) {
            // line 68
            yield "                <div class=\"d-flex flex-fill justify-content-end ps-search gap-3\">
                  <div class=\"d-flex standardsearchbox-nonfront\">
                    <div class=\"d-flex align-items-center\">
                      ";
            // line 71
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Drupal\twig_tweak\TwigTweakExtension::drupalBlock("custom_standard_search_form_block"), "html", null, true);
            yield "
                    </div>
                  </div>
                </div>
                ";
        }
        // line 76
        yield "                ";
        if (($context["logged_in"] ?? null)) {
            // line 77
            yield "                  ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["custom_picture"] ?? null))) {
                // line 78
                yield "                  <div class=\"user-profile\">
                    <a href=\"/user/";
                // line 79
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, true, 79), 79, $this->source), "html", null, true);
                yield "/profile\" class=\"page-trigger\" title=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["current_userName"] ?? null), 79, $this->source), "html", null, true);
                yield "\"><img width=\"32\" height=\"32\" class=\"img-fluid\" src=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["custom_picture"] ?? null), 79, $this->source), "html", null, true);
                yield "\" alt=\"user photo\" /></a>
                  </div>
                  ";
            } else {
                // line 82
                yield "                  <div class=\"\">
                    <a href=\"/user/";
                // line 83
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
                yield "/profile\" class=\"page-trigger\" title=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["current_userName"] ?? null), 83, $this->source), "html", null, true);
                yield "\"><img width=\"32\" height=\"32\" class=\"img-fluid\" src=\"/";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 83, $this->source) . "/images/Avatar.svg"), "html", null, true);
                yield "\" alt=\"user photo\" /></a>
                  </div>
                  ";
            }
            // line 86
            yield "                ";
        }
        // line 87
        yield "            </header>
          ";
        // line 89
        yield "          ";
        $context["items"] = $this->env->getFunction('simplify_menu')->getCallable()("main");
        // line 90
        yield "          <div class=\"d-flex sub-header align-items-center px-4 gap-5\">
            <div class=\"d-flex flex-fill gap-1 align-items-center announcement\">
                    <img src=\"/";
        // line 92
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 92, $this->source) . "/images/notification.svg"), "html", null, true);
        yield "\" alt=\"announcement\" />
                    <!--<div class=\"marquee position-relative overflow-hidden w-100\">
                        <p> PRISM offers YOU a diverse range of knowledge, connecting all aspects of our business.</p>
                    </div> -->
                    <marquee scrollamount = \"8\" onmouseover=\"this.stop();\" onmouseout=\"this.start();\" class=\"marquee-text\">
                      PRISM offers YOU a diverse range of knowledge, connecting all aspects of our business.
                  </marquee>
                </div>          
                ";
        // line 100
        if (($context["logged_in"] ?? null)) {
            // line 101
            yield "                <ul class=\"nav justify-content-end nav-list\">
                  ";
            // line 102
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "menu_tree", [], "any", false, false, true, 102));
            foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
                // line 103
                yield "                  ";
                $context["cart_class"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 103) == "Cart")) ? ("view-reference-cart") : (""));
                // line 104
                yield "                  <li class=\"nav-item gap-2 ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 104), 104, $this->source), "html", null, true);
                yield " ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["cart_class"] ?? null), 104, $this->source), "html", null, true);
                yield "\">
                      ";
                // line 105
                $context["menu_itemText"] = CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 105);
                // line 106
                yield "                      ";
                if ((($context["menu_itemText"] ?? null) == "Home")) {
                    // line 107
                    yield "                      <a class=\"nav-link d-flex align-items-center gap-2 px-0 ";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 107), 107, $this->source), "html", null, true);
                    yield "\" href=\"";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 107), 107, $this->source), "html", null, true);
                    yield "\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">home</i>
                      ";
                } elseif ((                // line 109
($context["menu_itemText"] ?? null) == "Cart")) {
                    // line 110
                    yield "                      <a id=\"cartLink\" class=\"nav-link d-flex align-items-center gap-2 px-0 ";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 110), 110, $this->source), "html", null, true);
                    yield "\" href=\"";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 110), 110, $this->source), "html", null, true);
                    yield "\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">shopping_cart</i>
                      ";
                } else {
                    // line 113
                    yield "                      <a class=\"nav-link d-flex align-items-center gap-2 px-0 ";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 113), 113, $this->source), "html", null, true);
                    yield "\" href=\"";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 113), 113, $this->source), "html", null, true);
                    yield "\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">notifications</i>
                      ";
                }
                // line 116
                yield "                      ";
                if ((($context["menu_itemText"] ?? null) == "Cart")) {
                    // line 117
                    yield "                      <span>";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 117), 117, $this->source), "html", null, true);
                    yield "</span>                     
                       <a href=\"/crp-init-cart\" class=\"use-ajax\" id=\"crp-init-cart\">Check the cart count</a>                   
                        <a class=\"";
                    // line 119
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 119), 119, $this->source), "html", null, true);
                    yield "\" href=\"";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 119), 119, $this->source), "html", null, true);
                    yield "\">
                        <span class=\"counter-cls count unread-message badge warning px-2\"><span class=\"cart-item\">";
                    // line 120
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["cart_num"] ?? null), 120, $this->source), "html", null, true);
                    yield "</span></span>
                     </a>
                     ";
                } else {
                    // line 123
                    yield "                        <span>";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 123), 123, $this->source), "html", null, true);
                    yield "</span>
                        ";
                    // line 124
                    if ((($context["menu_itemText"] ?? null) == "Notifications")) {
                        yield " 
                        <span data-count=\"";
                        // line 125
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["unread"] ?? null), 125, $this->source), "html", null, true);
                        yield "\" class=\"notification-icon badge warning\">";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["unread"] ?? null), 125, $this->source), "html", null, true);
                        yield "</span>
                        ";
                    }
                    // line 127
                    yield "                      ";
                }
                // line 128
                yield "                    </a>
                  </li>
                  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['menu_item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 131
            yield "                </ul>
                ";
        }
        // line 133
        yield "            </div> 
          </div>                    
          ";
        // line 135
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["page_top"] ?? null), 135, $this->source), "html", null, true);
        yield "
          ";
        // line 136
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["page"] ?? null), 136, $this->source), "html", null, true);
        yield "
          ";
        // line 137
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["page_bottom"] ?? null), 137, $this->source), "html", null, true);
        yield "
        </div>
        <js-bottom-placeholder token=\"";
        // line 139
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["placeholder_token"] ?? null), 139, $this->source), "html", null, true);
        yield "\">
        <footer class=\"d-flex gap-3 flex-column px-4 py-3 footer\">
            <div class=\"d-flex gap-3 align-items-center\">
                <div class=\"d-flex gap-3 flex-fill align-items-center\">
                ";
        // line 143
        $context["footerMenu"] = $this->env->getFunction('simplify_menu')->getCallable()("footer");
        // line 144
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["footerMenu"] ?? null), "menu_tree", [], "any", false, false, true, 144));
        foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
            // line 145
            yield "                  ";
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 145) == "/form/feedback")) {
                // line 146
                yield "                    <a id='footer-feedback-link' class=\"link-primary\" href=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 146), 146, $this->source), "html", null, true);
                yield "\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 146), 146, $this->source), "html", null, true);
                yield "</a>
                  ";
            } else {
                // line 148
                yield "                    <a class=\"link-primary\" href=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 148), 148, $this->source), "html", null, true);
                yield "\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 148), 148, $this->source), "html", null, true);
                yield "</a>
                  ";
            }
            // line 150
            yield "                    <div class=\"vertical-divider\"></div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['menu_item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        yield "                </div>
                <div class=\"d-flex gap-3 flex-fill justify-content-end align-items-center\">
                ";
        // line 154
        $context["footerMenu2"] = $this->env->getFunction('simplify_menu')->getCallable()("social-footer");
        // line 155
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["footerMenu2"] ?? null), "menu_tree", [], "any", false, false, true, 155));
        foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
            // line 156
            yield "                    <a class=\"link-primary d-flex gap-1 align-items-center\" href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "url", [], "any", false, false, true, 156), 156, $this->source), "html", null, true);
            yield "\">
                        <div class=\"sitemap-icon\">
                        ";
            // line 158
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 158) == "Capgemini")) {
                // line 159
                yield "                          <img src=\"/themes/custom/capgemini_b5/images/spade.svg\" alt=\"Capgemini icon\" />
                        ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source,             // line 160
$context["menu_item"], "text", [], "any", false, false, true, 160) == "DAILY.connect")) {
                // line 161
                yield "                        <img src=\"/themes/custom/capgemini_b5/images/viva.png\" alt=\"DAILY.connect icon\" />
                        ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source,             // line 162
$context["menu_item"], "text", [], "any", false, false, true, 162) == "Talent")) {
                // line 163
                yield "                        <img src=\"/themes/custom/capgemini_b5/images/talent-favico.png\" alt=\"Talent icon\" />
                        ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source,             // line 164
$context["menu_item"], "text", [], "any", false, false, true, 164) == "X-PORT")) {
                // line 165
                yield "                        <img src=\"/themes/custom/capgemini_b5/images/xport.png\" alt=\"X-Port icon\" />
                        ";
            }
            // line 167
            yield "                      </div>
                        <span>";
            // line 168
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, $context["menu_item"], "text", [], "any", false, false, true, 168), 168, $this->source), "html", null, true);
            yield "</span>
                    </a>
                    <div class=\"vertical-divider\"></div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['menu_item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 171
        yield "                
                </div>
            </div>
            <p class=\"d-flex gap-1 align-items-center\">© 2025 Capgemini Company Confidential. Powered by Drupal <img
                    src=\"/themes/custom/capgemini_b5/images/drupal-logo.svg\" alt=\"Drupal icon\" /></p>
      </footer>          
    </body>
</html>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["logged_in", "root_path", "node_type", "db_offline", "b5_body_schema", "b5_body_bg_schema", "body_class_for_page_404", "html_attributes", "placeholder_token", "directory", "head_title", "attributes", "is_front", "custom_picture", "user", "current_userName", "cart_num", "unread", "page_top", "page", "page_bottom"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/layout/html.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  394 => 171,  384 => 168,  381 => 167,  377 => 165,  375 => 164,  372 => 163,  370 => 162,  367 => 161,  365 => 160,  362 => 159,  360 => 158,  354 => 156,  349 => 155,  347 => 154,  343 => 152,  336 => 150,  328 => 148,  320 => 146,  317 => 145,  312 => 144,  310 => 143,  303 => 139,  298 => 137,  294 => 136,  290 => 135,  286 => 133,  282 => 131,  274 => 128,  271 => 127,  264 => 125,  260 => 124,  255 => 123,  249 => 120,  243 => 119,  237 => 117,  234 => 116,  225 => 113,  216 => 110,  214 => 109,  206 => 107,  203 => 106,  201 => 105,  194 => 104,  191 => 103,  187 => 102,  184 => 101,  182 => 100,  171 => 92,  167 => 90,  164 => 89,  161 => 87,  158 => 86,  148 => 83,  145 => 82,  135 => 79,  132 => 78,  129 => 77,  126 => 76,  118 => 71,  113 => 68,  111 => 67,  100 => 59,  90 => 52,  84 => 49,  79 => 47,  75 => 46,  71 => 45,  67 => 44,  60 => 40,  56 => 39,  53 => 38,  51 => 35,  50 => 33,  49 => 32,  48 => 31,  47 => 30,  46 => 29,  45 => 28,  44 => 27,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override for the basic structure of a single Drupal page.
 *
 * Variables:
 * - logged_in: A flag indicating if user is logged in.
 * - root_path: The root path of the current page (e.g., node, admin, user).
 * - node_type: The content type for the current node, if the page is a node.
 * - head_title: List of text elements that make up the head_title variable.
 *   May contain one or more of the following:
 *   - title: The title of the page.
 *   - name: The name of the site.
 *   - slogan: The slogan of the site.
 * - page_top: Initial rendered markup. This should be printed before 'page'.
 * - page: The rendered page markup.
 * - page_bottom: Closing rendered markup. This variable should be printed after
 *   'page'.
 * - db_offline: A flag indicating if the database is offline.
 * - placeholder_token: The token for generating head, css, js and js-bottom
 *   placeholders.
 *
 * @see template_preprocess_html()
 */
#}
{%
  set body_classes = [
    logged_in ? 'user-logged-in',
    not root_path ? 'path-frontpage' : 'path-' ~ root_path|clean_class,
    node_type ? 'page-node-type-' ~ node_type|clean_class,
    db_offline ? 'db-offline',
    (b5_body_schema == 'light' ? ' text-dark' : (b5_body_schema == 'dark' ? ' text-light' :  ' ')),
    (b5_body_bg_schema != 'none' ? \" bg-#{b5_body_bg_schema}\" : ' '),
    'd-flex flex-column',
    body_class_for_page_404 ? 'page-404': '',
  ]
%}
<!DOCTYPE html>
<html{{ html_attributes.addClass('h-100') }}>
    <head-placeholder token=\"{{ placeholder_token }}\">
      <meta charset=\"UTF-8\">
      <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
      <link rel=\"shortcut icon\" href=\"/{{ directory ~ '/CAP.PA.svg' }}\">
      <title>{{ head_title|safe_join(' | ') }}</title>
      <css-placeholder token=\"{{ placeholder_token }}\">
      <js-placeholder token=\"{{ placeholder_token }}\">
    </head>
    <body{{ attributes.addClass(body_classes) }}>
        <div class=\"visually-hidden-focusable skip-link p-3 container\">
          <a href=\"#main-content\" class=\"p-2\">
            {{ 'Skip to main content'|t }}
          </a>
        </div>
        <div class=\"container-fluid g-0\">
        <div class=\"fixed-header\">
          <header class=\"d-flex gap-2 px-3 py-2 ps-header align-items-center justify-content-between\">
                <div class=\"d-flex gap-3 align-items-center h-100\">
                    <h1><a href=\"/\"><img src=\"/{{ directory ~ '/logo.svg' }}\" alt=\"Capgemini Logo\"/></a></h1>
                    <div class=\"vertical-divider\"></div>
                    <a href=\"/\" class=\" d-flex flex-row align-items-center gap-1 ps-logo\">
                        <h2 class=\"h3 mb-0\">PRISM</h2>
                        <span>-</span>
                        <span>Kaleidoscope to Knowledge</span>
                    </a>
                </div>
                {% if not is_front and logged_in %}
                <div class=\"d-flex flex-fill justify-content-end ps-search gap-3\">
                  <div class=\"d-flex standardsearchbox-nonfront\">
                    <div class=\"d-flex align-items-center\">
                      {{ drupal_block('custom_standard_search_form_block') }}
                    </div>
                  </div>
                </div>
                {% endif %}
                {% if logged_in %}
                  {% if custom_picture is not empty  %}
                  <div class=\"user-profile\">
                    <a href=\"/user/{{ user.id }}/profile\" class=\"page-trigger\" title=\"{{current_userName}}\"><img width=\"32\" height=\"32\" class=\"img-fluid\" src=\"{{ custom_picture }}\" alt=\"user photo\" /></a>
                  </div>
                  {% else %}
                  <div class=\"\">
                    <a href=\"/user/{{ user.id }}/profile\" class=\"page-trigger\" title=\"{{current_userName}}\"><img width=\"32\" height=\"32\" class=\"img-fluid\" src=\"/{{ directory ~ '/images/Avatar.svg' }}\" alt=\"user photo\" /></a>
                  </div>
                  {% endif %}
                {% endif %}
            </header>
          {# Get menu items #}
          {% set items = simplify_menu('main') %}
          <div class=\"d-flex sub-header align-items-center px-4 gap-5\">
            <div class=\"d-flex flex-fill gap-1 align-items-center announcement\">
                    <img src=\"/{{ directory ~ '/images/notification.svg' }}\" alt=\"announcement\" />
                    <!--<div class=\"marquee position-relative overflow-hidden w-100\">
                        <p> PRISM offers YOU a diverse range of knowledge, connecting all aspects of our business.</p>
                    </div> -->
                    <marquee scrollamount = \"8\" onmouseover=\"this.stop();\" onmouseout=\"this.start();\" class=\"marquee-text\">
                      PRISM offers YOU a diverse range of knowledge, connecting all aspects of our business.
                  </marquee>
                </div>          
                {% if logged_in %}
                <ul class=\"nav justify-content-end nav-list\">
                  {% for menu_item in items.menu_tree %}
                  {% set cart_class = (menu_item.text == \"Cart\") ? \"view-reference-cart\" : \"\" %}
                  <li class=\"nav-item gap-2 {{menu_item.text}} {{cart_class}}\">
                      {% set menu_itemText = menu_item.text %}
                      {% if menu_itemText == 'Home' %}
                      <a class=\"nav-link d-flex align-items-center gap-2 px-0 {{menu_item.text}}\" href=\"{{ menu_item.url }}\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">home</i>
                      {% elseif menu_itemText == 'Cart' %}
                      <a id=\"cartLink\" class=\"nav-link d-flex align-items-center gap-2 px-0 {{menu_item.text}}\" href=\"{{ menu_item.url }}\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">shopping_cart</i>
                      {% else %}
                      <a class=\"nav-link d-flex align-items-center gap-2 px-0 {{menu_item.text}}\" href=\"{{ menu_item.url }}\" aria-current=\"page\">
                      <i class=\"material-symbols-outlined md-5\">notifications</i>
                      {% endif %}
                      {% if menu_itemText == 'Cart' %}
                      <span>{{ menu_item.text }}</span>                     
                       <a href=\"/crp-init-cart\" class=\"use-ajax\" id=\"crp-init-cart\">Check the cart count</a>                   
                        <a class=\"{{menu_item.text}}\" href=\"{{ menu_item.url }}\">
                        <span class=\"counter-cls count unread-message badge warning px-2\"><span class=\"cart-item\">{{ cart_num }}</span></span>
                     </a>
                     {% else %}
                        <span>{{ menu_item.text }}</span>
                        {% if menu_itemText == 'Notifications' %} 
                        <span data-count=\"{{ unread }}\" class=\"notification-icon badge warning\">{{unread}}</span>
                        {% endif %}
                      {% endif %}
                    </a>
                  </li>
                  {% endfor %}
                </ul>
                {% endif %}
            </div> 
          </div>                    
          {{ page_top }}
          {{ page }}
          {{ page_bottom }}
        </div>
        <js-bottom-placeholder token=\"{{ placeholder_token }}\">
        <footer class=\"d-flex gap-3 flex-column px-4 py-3 footer\">
            <div class=\"d-flex gap-3 align-items-center\">
                <div class=\"d-flex gap-3 flex-fill align-items-center\">
                {% set footerMenu = simplify_menu('footer') %}
                {% for menu_item in footerMenu.menu_tree %}
                  {% if menu_item.url == '/form/feedback' %}
                    <a id='footer-feedback-link' class=\"link-primary\" href=\"{{ menu_item.url }}\">{{ menu_item.text }}</a>
                  {% else %}
                    <a class=\"link-primary\" href=\"{{ menu_item.url }}\">{{ menu_item.text }}</a>
                  {% endif %}
                    <div class=\"vertical-divider\"></div>
                {% endfor %}
                </div>
                <div class=\"d-flex gap-3 flex-fill justify-content-end align-items-center\">
                {% set footerMenu2 = simplify_menu('social-footer') %}
                {% for menu_item in footerMenu2.menu_tree %}
                    <a class=\"link-primary d-flex gap-1 align-items-center\" href=\"{{ menu_item.url }}\">
                        <div class=\"sitemap-icon\">
                        {% if(menu_item.text == 'Capgemini') %}
                          <img src=\"/themes/custom/capgemini_b5/images/spade.svg\" alt=\"Capgemini icon\" />
                        {% elseif (menu_item.text == 'DAILY.connect') %}
                        <img src=\"/themes/custom/capgemini_b5/images/viva.png\" alt=\"DAILY.connect icon\" />
                        {% elseif (menu_item.text == 'Talent') %}
                        <img src=\"/themes/custom/capgemini_b5/images/talent-favico.png\" alt=\"Talent icon\" />
                        {% elseif (menu_item.text == 'X-PORT') %}
                        <img src=\"/themes/custom/capgemini_b5/images/xport.png\" alt=\"X-Port icon\" />
                        {% endif %}
                      </div>
                        <span>{{ menu_item.text }}</span>
                    </a>
                    <div class=\"vertical-divider\"></div>
                {% endfor %}                
                </div>
            </div>
            <p class=\"d-flex gap-1 align-items-center\">© 2025 Capgemini Company Confidential. Powered by Drupal <img
                    src=\"/themes/custom/capgemini_b5/images/drupal-logo.svg\" alt=\"Drupal icon\" /></p>
      </footer>          
    </body>
</html>", "themes/custom/capgemini_b5/templates/layout/html.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\layout\\html.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 27, "if" => 67, "for" => 102);
        static $filters = array("clean_class" => 29, "escape" => 39, "safe_join" => 45, "t" => 52);
        static $functions = array("drupal_block" => 71, "simplify_menu" => 89);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'for'],
                ['clean_class', 'escape', 'safe_join', 't'],
                ['drupal_block', 'simplify_menu'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
