<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/form/input.html.twig */
class __TwigTemplate_62d10b5837f60c576009f2c1e5ba6526 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        $context["field_community_def"] = (($__internal_compile_0 = CoreExtension::getAttribute($this->env, $this->source, (($__internal_compile_1 = (($__internal_compile_2 = ($context["element"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess && in_array($__internal_compile_2::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_2["#selection_settings"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#selection_settings", [], "array", false, false, true, 13))) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess && in_array($__internal_compile_1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_1["entity"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, (($__internal_compile_3 = ($context["element"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess && in_array($__internal_compile_3::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_3["#selection_settings"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#selection_settings", [], "array", false, false, true, 13)), "entity", [], "array", false, false, true, 13)), "fieldDefinitions", [], "any", false, false, true, 13)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess && in_array($__internal_compile_0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_0["field_community"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($__internal_compile_4 = (($__internal_compile_5 = ($context["element"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess && in_array($__internal_compile_5::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_5["#selection_settings"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#selection_settings", [], "array", false, false, true, 13))) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess && in_array($__internal_compile_4::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_4["entity"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, (($__internal_compile_6 = ($context["element"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess && in_array($__internal_compile_6::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_6["#selection_settings"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#selection_settings", [], "array", false, false, true, 13)), "entity", [], "array", false, false, true, 13)), "fieldDefinitions", [], "any", false, false, true, 13), "field_community", [], "array", false, false, true, 13));
        // line 14
        yield "
";
        // line 15
        if (((CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "hasClass", ["button"], "method", false, false, true, 15) &&  !CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "hasClass", ["field-add-more-submit"], "method", false, false, true, 15)) &&  !CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "hasClass", ["btn"], "method", false, false, true, 15))) {
            // line 16
            yield "  ";
            if (((($__internal_compile_7 = ($context["element"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess && in_array($__internal_compile_7::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_7["#id"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#id", [], "array", false, false, true, 16)) == "edit-submit-all-communities")) {
                // line 17
                yield "    ";
                // line 18
                $context["classes"] = ["btn", "btn-ghost", "regular"];
                // line 24
                yield "  ";
            } else {
                // line 25
                yield "    ";
                // line 26
                $context["classes"] = ["btn", ((CoreExtension::getAttribute($this->env, $this->source,                 // line 28
($context["attributes"] ?? null), "hasClass", ["button--danger"], "method", false, false, true, 28)) ? ("btn-danger") : ("")), ((( !CoreExtension::getAttribute($this->env, $this->source,                 // line 29
($context["attributes"] ?? null), "hasClass", ["media-library-item__remove"], "method", false, false, true, 29) &&  !CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "hasClass", ["button--danger"], "method", false, false, true, 29))) ? ("btn-primary") : (""))];
                // line 32
                yield "  ";
            }
            // line 33
            yield "  <input";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 33), 33, $this->source), "html", null, true);
            yield " />
";
        } elseif ((((($__internal_compile_8 =         // line 34
($context["element"] ?? null)) && is_array($__internal_compile_8) || $__internal_compile_8 instanceof ArrayAccess && in_array($__internal_compile_8::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_8["#id"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#id", [], "array", false, false, true, 34)) == "edit-field-community-0-target-id") && (CoreExtension::getAttribute($this->env, $this->source, ($context["field_community_def"] ?? null), "get", ["bundle"], "method", false, false, true, 34) == "news"))) {
            // line 35
            yield "  <div class='input-group'>
    <div class='input-group mb-3 select2-wrap'>
      <input";
            // line 37
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 37), 37, $this->source), "html", null, true);
            yield " />
    </div>
  </div>
";
        } elseif (((((($__internal_compile_9 =         // line 40
($context["element"] ?? null)) && is_array($__internal_compile_9) || $__internal_compile_9 instanceof ArrayAccess && in_array($__internal_compile_9::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_9["#id"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#id", [], "array", false, false, true, 40)) == "edit-field-author") || ((($__internal_compile_10 = ($context["element"] ?? null)) && is_array($__internal_compile_10) || $__internal_compile_10 instanceof ArrayAccess && in_array($__internal_compile_10::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_10["#id"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#id", [], "array", false, false, true, 40)) == "edit-field-tags-target-id")) || ((($__internal_compile_11 = ($context["element"] ?? null)) && is_array($__internal_compile_11) || $__internal_compile_11 instanceof ArrayAccess && in_array($__internal_compile_11::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_11["#id"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#id", [], "array", false, false, true, 40)) == "edit-field-community-0-target-id"))) {
            // line 41
            yield "  <div class='input-group mb-3 select2-wrap'>
    <input";
            // line 42
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 42), 42, $this->source), "html", null, true);
            yield " />
  </div>
";
        } elseif (($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((($__internal_compile_12 =         // line 44
($context["element"] ?? null)) && is_array($__internal_compile_12) || $__internal_compile_12 instanceof ArrayAccess && in_array($__internal_compile_12::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_12["#title"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["element"] ?? null), "#title", [], "array", false, false, true, 44))) == "Date")) {
            // line 45
            yield "  ";
            // line 46
            $context["classes"] = ["form-control", "bg-surface-primary", "br-2", "border-moderate"];
            // line 53
            yield "  <input";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 53), 53, $this->source), "html", null, true);
            yield " />
";
        } else {
            // line 55
            yield "  <input";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attributes"] ?? null), 55, $this->source), "html", null, true);
            yield " />
";
        }
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["children"] ?? null), 57, $this->source), "html", null, true);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["element", "attributes", "children"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/form/input.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  115 => 57,  109 => 55,  103 => 53,  101 => 46,  99 => 45,  97 => 44,  92 => 42,  89 => 41,  87 => 40,  81 => 37,  77 => 35,  75 => 34,  70 => 33,  67 => 32,  65 => 29,  64 => 28,  63 => 26,  61 => 25,  58 => 24,  56 => 18,  54 => 17,  51 => 16,  49 => 15,  46 => 14,  44 => 13,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override for an 'input' #type form element.
 *
 * Available variables:
 * - attributes: A list of HTML attributes for the input element.
 * - children: Optional additional rendered elements.
 *
 * @see template_preprocess_input()
 */
#}
{% set field_community_def = element['#selection_settings']['entity'].fieldDefinitions['field_community'] %}

{% if attributes.hasClass('button') and not attributes.hasClass('field-add-more-submit') and not attributes.hasClass('btn') %}
  {% if element['#id'] == 'edit-submit-all-communities' %}
    {%
      set classes = [
        'btn',
        'btn-ghost',
        'regular',
      ]
    %}
  {% else %}
    {%
      set classes = [
        'btn',
        attributes.hasClass('button--danger') ? 'btn-danger' : '',
        (not attributes.hasClass('media-library-item__remove') and not attributes.hasClass('button--danger')) ? 'btn-primary' : ''
      ]
    %}
  {% endif %}
  <input{{ attributes.addClass(classes) }} />
{% elseif element['#id'] == 'edit-field-community-0-target-id' and field_community_def.get('bundle') == 'news' %}
  <div class='input-group'>
    <div class='input-group mb-3 select2-wrap'>
      <input{{ attributes.addClass(classes) }} />
    </div>
  </div>
{% elseif element['#id'] == 'edit-field-author' or element['#id'] == 'edit-field-tags-target-id' or element['#id'] == 'edit-field-community-0-target-id' %}
  <div class='input-group mb-3 select2-wrap'>
    <input{{ attributes.addClass(classes) }} />
  </div>
{% elseif element['#title']|render == 'Date' %}
  {%
    set classes = [
      'form-control',
      'bg-surface-primary',
      'br-2',
      'border-moderate'
    ]
  %}
  <input{{ attributes.addClass(classes) }} />
{% else %}
  <input{{ attributes }} />
{% endif %}
{{ children }}", "themes/custom/capgemini_b5/templates/form/input.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\form\\input.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 13, "if" => 15);
        static $filters = array("escape" => 33, "render" => 44);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'render'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
