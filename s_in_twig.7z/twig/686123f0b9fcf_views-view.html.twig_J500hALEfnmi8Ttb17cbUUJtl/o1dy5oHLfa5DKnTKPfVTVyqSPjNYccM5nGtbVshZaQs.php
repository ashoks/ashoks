<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/views/views-view.html.twig */
class __TwigTemplate_dca4d157f670606cfad2a72ed0560a61 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        $context["classes"] = ["view", ("view-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 36
($context["id"] ?? null), 36, $this->source))), ("view-id-" . $this->sandbox->ensureToStringAllowed(        // line 37
($context["id"] ?? null), 37, $this->source)), ("view-display-id-" . $this->sandbox->ensureToStringAllowed(        // line 38
($context["display_id"] ?? null), 38, $this->source)), ((        // line 39
($context["dom_id"] ?? null)) ? (("js-view-dom-id-" . $this->sandbox->ensureToStringAllowed(($context["dom_id"] ?? null), 39, $this->source))) : (""))];
        // line 42
        if (((($context["id"] ?? null) == "my_communities") && (($context["display_id"] ?? null) == "page_1"))) {
            // line 43
            yield "<div class=\"js-view-dom-id-my_communities__page_1\">
";
        }
        // line 45
        yield "<div";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 45), 45, $this->source), "html", null, true);
        yield ">
  ";
        // line 46
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 46, $this->source), "html", null, true);
        yield "
  ";
        // line 47
        if (($context["title"] ?? null)) {
            // line 48
            yield "    ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title"] ?? null), 48, $this->source), "html", null, true);
            yield "
  ";
        }
        // line 50
        yield "  ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 50, $this->source), "html", null, true);
        yield "
  ";
        // line 51
        if (($context["header"] ?? null)) {
            // line 52
            yield "    <div class=\"view-header\">
      ";
            // line 53
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["header"] ?? null), 53, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 56
        yield "  ";
        if (($context["exposed"] ?? null)) {
            // line 57
            yield "    <div class=\"view-filters\">
      ";
            // line 58
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["exposed"] ?? null), 58, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 61
        yield "  ";
        if (($context["attachment_before"] ?? null)) {
            // line 62
            yield "    <div class=\"attachment attachment-before\">
      ";
            // line 63
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attachment_before"] ?? null), 63, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 66
        yield "  ";
        if (($context["pager"] ?? null)) {
            // line 67
            yield "    <div class=\"pager-first\">
      ";
            // line 68
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["pager"] ?? null), 68, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 71
        yield "  ";
        if (($context["rows"] ?? null)) {
            // line 72
            yield "    <div class=\"view-content\">
      ";
            // line 73
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["rows"] ?? null), 73, $this->source), "html", null, true);
            yield "
    </div>
  ";
        } elseif (        // line 75
($context["empty"] ?? null)) {
            // line 76
            yield "    <div class=\"view-empty\">
      ";
            // line 77
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["empty"] ?? null), 77, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 80
        yield "
  ";
        // line 81
        if (($context["pager"] ?? null)) {
            // line 82
            yield "    ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["pager"] ?? null), 82, $this->source), "html", null, true);
            yield "
  ";
        }
        // line 84
        yield "  ";
        if (($context["attachment_after"] ?? null)) {
            // line 85
            yield "    <div class=\"attachment attachment-after\">
      ";
            // line 86
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attachment_after"] ?? null), 86, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 89
        yield "  ";
        if (($context["more"] ?? null)) {
            // line 90
            yield "    ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["more"] ?? null), 90, $this->source), "html", null, true);
            yield "
  ";
        }
        // line 92
        yield "  ";
        if (($context["footer"] ?? null)) {
            // line 93
            yield "    <div class=\"view-footer\">
      ";
            // line 94
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["footer"] ?? null), 94, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 97
        yield "  ";
        if (($context["feed_icons"] ?? null)) {
            // line 98
            yield "    <div class=\"feed-icons\">
      ";
            // line 99
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["feed_icons"] ?? null), 99, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 102
        yield "</div>
";
        // line 103
        if (((($context["id"] ?? null) == "my_communities") && (($context["display_id"] ?? null) == "page_1"))) {
            // line 104
            yield "</div>
";
        }
        // line 106
        yield "
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["id", "display_id", "dom_id", "attributes", "title_prefix", "title", "title_suffix", "header", "exposed", "attachment_before", "pager", "rows", "empty", "attachment_after", "more", "footer", "feed_icons"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/views/views-view.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  212 => 106,  208 => 104,  206 => 103,  203 => 102,  197 => 99,  194 => 98,  191 => 97,  185 => 94,  182 => 93,  179 => 92,  173 => 90,  170 => 89,  164 => 86,  161 => 85,  158 => 84,  152 => 82,  150 => 81,  147 => 80,  141 => 77,  138 => 76,  136 => 75,  131 => 73,  128 => 72,  125 => 71,  119 => 68,  116 => 67,  113 => 66,  107 => 63,  104 => 62,  101 => 61,  95 => 58,  92 => 57,  89 => 56,  83 => 53,  80 => 52,  78 => 51,  73 => 50,  67 => 48,  65 => 47,  61 => 46,  56 => 45,  52 => 43,  50 => 42,  48 => 39,  47 => 38,  46 => 37,  45 => 36,  44 => 34,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override for a main view template.
 *
 * Available variables:
 * - attributes: Remaining HTML attributes for the element.
 * - css_name: A CSS-safe version of the view name.
 * - css_class: The user-specified classes names, if any.
 * - header: The optional header.
 * - footer: The optional footer.
 * - rows: The results of the view query, if any.
 * - empty: The content to display if there are no rows.
 * - pager: The optional pager next/prev links to display.
 * - exposed: Exposed widget form/info to display.
 * - feed_icons: Optional feed icons to display.
 * - more: An optional link to the next page of results.
 * - title: Title of the view, only used when displaying in the admin preview.
 * - title_prefix: Additional output populated by modules, intended to be
 *   displayed in front of the view title.
 * - title_suffix: Additional output populated by modules, intended to be
 *   displayed after the view title.
 * - attachment_before: An optional attachment view to be displayed before the
 *   view content.
 * - attachment_after: An optional attachment view to be displayed after the
 *   view content.
 * - dom_id: Unique id for every view being printed to give unique class for
 *   JavaScript.
 *
 * @see template_preprocess_views_view()
 */
#}
{%
  set classes = [
    'view',
    'view-' ~ id|clean_class,
    'view-id-' ~ id,
    'view-display-id-' ~ display_id,
    dom_id ? 'js-view-dom-id-' ~ dom_id,
  ]
%}
{% if id == \"my_communities\" and display_id == \"page_1\" %}
<div class=\"js-view-dom-id-my_communities__page_1\">
{% endif %}
<div{{ attributes.addClass(classes) }}>
  {{ title_prefix }}
  {% if title %}
    {{ title }}
  {% endif %}
  {{ title_suffix }}
  {% if header %}
    <div class=\"view-header\">
      {{ header }}
    </div>
  {% endif %}
  {% if exposed %}
    <div class=\"view-filters\">
      {{ exposed }}
    </div>
  {% endif %}
  {% if attachment_before %}
    <div class=\"attachment attachment-before\">
      {{ attachment_before }}
    </div>
  {% endif %}
  {% if pager %}
    <div class=\"pager-first\">
      {{ pager }}
    </div>
  {% endif %}
  {% if rows %}
    <div class=\"view-content\">
      {{ rows }}
    </div>
  {% elseif empty %}
    <div class=\"view-empty\">
      {{ empty }}
    </div>
  {% endif %}

  {% if pager %}
    {{ pager }}
  {% endif %}
  {% if attachment_after %}
    <div class=\"attachment attachment-after\">
      {{ attachment_after }}
    </div>
  {% endif %}
  {% if more %}
    {{ more }}
  {% endif %}
  {% if footer %}
    <div class=\"view-footer\">
      {{ footer }}
    </div>
  {% endif %}
  {% if feed_icons %}
    <div class=\"feed-icons\">
      {{ feed_icons }}
    </div>
  {% endif %}
</div>
{% if id == \"my_communities\" and display_id == \"page_1\" %}
</div>
{% endif %}

", "themes/custom/capgemini_b5/templates/views/views-view.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\views\\views-view.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 34, "if" => 42);
        static $filters = array("clean_class" => 36, "escape" => 45);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['clean_class', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
