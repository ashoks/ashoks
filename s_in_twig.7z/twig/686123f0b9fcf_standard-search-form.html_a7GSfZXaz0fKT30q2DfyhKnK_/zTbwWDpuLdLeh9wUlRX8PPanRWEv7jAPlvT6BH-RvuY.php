<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* modules/custom/custom_search/templates/standard-search-form.html.twig */
class __TwigTemplate_ae5bbdede23f90bcd285bd9c4ce8c411 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"d-flex justify-content-center gap-2 ps-search standardsearchform\">
\t<div class=\"d-flex justify-content-center bg-surface-primary br-100 flex-fill\">        
\t  <div class=\"flex-fill d-flex\">
\t    <label id=\"searchContentLabel\" class=\"visually-hidden-focusable\" for=\"edit-standard-search-keyword\">search</label>
\t\t  ";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["data"] ?? null), 5, $this->source), "html", null, true);
        yield "
\t\t</div>
\t  </div>
\t";
        // line 8
        if ((($context["group_id"] ?? null) && (($context["community_type"] ?? null) != 3))) {
            // line 9
            yield "    ";
            $context["href"] = ("/advanced_search_asset_form?adv_gid=" . $this->sandbox->ensureToStringAllowed(($context["group_id"] ?? null), 9, $this->source));
            yield "\t
\t";
        } elseif ((        // line 10
($context["group_id"] ?? null) && (($context["community_type"] ?? null) == 3))) {
            yield "\t
\t  ";
            // line 11
            $context["href"] = ("/advanced_search_reference_form?adv_gid=" . $this->sandbox->ensureToStringAllowed(($context["group_id"] ?? null), 11, $this->source));
            yield "\t 
\t";
        } else {
            // line 13
            yield "    ";
            $context["href"] = "/advanced_search_asset_form";
            // line 14
            yield "  ";
        }
        yield "\t
  <div class=\"d-flex search-button gap-2\">
\t<a name=\"\" id=\"advSearch\" class=\"btn btn-ghost medium d-flex align-items-center gap-2 page-trigger\" href=\"";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["href"] ?? null), 16, $this->source), "html", null, true);
        yield "\"
\trole=\"button\">
\t\t<span>Advanced Search</span>
\t</a>
  \t<a name=\"\" id=\"help\" class=\"btn btn-ghost medium d-flex align-items-center gap-2\" href=\"/files/alias/asset/1138365/781581\" role=\"button\">
\t\t<span>Search Help</span>
\t</a>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["data", "group_id", "community_type"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "modules/custom/custom_search/templates/standard-search-form.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  81 => 16,  75 => 14,  72 => 13,  67 => 11,  63 => 10,  58 => 9,  56 => 8,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"d-flex justify-content-center gap-2 ps-search standardsearchform\">
\t<div class=\"d-flex justify-content-center bg-surface-primary br-100 flex-fill\">        
\t  <div class=\"flex-fill d-flex\">
\t    <label id=\"searchContentLabel\" class=\"visually-hidden-focusable\" for=\"edit-standard-search-keyword\">search</label>
\t\t  {{ data }}
\t\t</div>
\t  </div>
\t{% if group_id and community_type != 3 %}
    {% set href = '/advanced_search_asset_form?adv_gid=' ~ group_id  %}\t
\t{% elseif group_id and community_type == 3 %}\t
\t  {% set href = '/advanced_search_reference_form?adv_gid=' ~ group_id %}\t 
\t{% else %}
    {% set href = '/advanced_search_asset_form' %}
  {% endif %}\t
  <div class=\"d-flex search-button gap-2\">
\t<a name=\"\" id=\"advSearch\" class=\"btn btn-ghost medium d-flex align-items-center gap-2 page-trigger\" href=\"{{ href }}\"
\trole=\"button\">
\t\t<span>Advanced Search</span>
\t</a>
  \t<a name=\"\" id=\"help\" class=\"btn btn-ghost medium d-flex align-items-center gap-2\" href=\"/files/alias/asset/1138365/781581\" role=\"button\">
\t\t<span>Search Help</span>
\t</a>
  </div>
</div>
", "modules/custom/custom_search/templates/standard-search-form.html.twig", "C:\\xampp\\htdocs\\prismlive\\modules\\custom\\custom_search\\templates\\standard-search-form.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 8, "set" => 9);
        static $filters = array("escape" => 5);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
