<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/layout/page--front.html.twig */
class __TwigTemplate_8f39ef379b7856d33aa63f309dd3f925 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        $context["nav_classes"] = ((("navbar navbar-expand-lg" . (((        // line 47
($context["b5_navbar_schema"] ?? null) != "none")) ? ((" navbar-" . $this->sandbox->ensureToStringAllowed(($context["b5_navbar_schema"] ?? null), 47, $this->source))) : (" "))) . (((        // line 48
($context["b5_navbar_schema"] ?? null) != "none")) ? ((((($context["b5_navbar_schema"] ?? null) == "dark")) ? (" text-light") : (" text-dark"))) : (" "))) . (((        // line 49
($context["b5_navbar_bg_schema"] ?? null) != "none")) ? ((" bg-" . $this->sandbox->ensureToStringAllowed(($context["b5_navbar_bg_schema"] ?? null), 49, $this->source))) : (" ")));
        // line 51
        yield "
";
        // line 53
        $context["footer_classes"] = (((" " . (((        // line 54
($context["b5_footer_schema"] ?? null) != "none")) ? ((" footer-" . $this->sandbox->ensureToStringAllowed(($context["b5_footer_schema"] ?? null), 54, $this->source))) : (" "))) . (((        // line 55
($context["b5_footer_schema"] ?? null) != "none")) ? ((((($context["b5_footer_schema"] ?? null) == "dark")) ? (" text-light") : (" text-dark"))) : (" "))) . (((        // line 56
($context["b5_footer_bg_schema"] ?? null) != "none")) ? ((" bg-" . $this->sandbox->ensureToStringAllowed(($context["b5_footer_bg_schema"] ?? null), 56, $this->source))) : (" ")));
        // line 58
        yield "  ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_left", [], "any", false, false, true, 58)) {
            // line 59
            yield "  <div class=\"d-flex gap-3 align-items-center h-100 12345ashish\">
    ";
            // line 60
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_left", [], "any", false, false, true, 60), 60, $this->source), "html", null, true);
            yield "
  </div>
  ";
        }
        // line 63
        yield "  ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_center", [], "any", false, false, true, 63)) {
            // line 64
            yield "  <div class=\"d-flex flex-fill justify-content-end ps-search gap-3\">
    ";
            // line 65
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_center", [], "any", false, false, true, 65), 65, $this->source), "html", null, true);
            yield "
  </div>
  ";
        }
        // line 68
        yield "  ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_right", [], "any", false, false, true, 68)) {
            // line 69
            yield "  <div class=\"\">
    ";
            // line 70
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_right", [], "any", false, false, true, 70), 70, $this->source), "html", null, true);
            yield "
  </div>
  ";
        }
        // line 73
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_bottom", [], "any", false, false, true, 73)) {
            // line 74
            yield "<div class=\"header-bottom\">
  ";
            // line 75
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_bottom", [], "any", false, false, true, 75), 75, $this->source), "html", null, true);
            yield "
</div>
";
        }
        // line 78
        $context["roles"] = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "getroles", [true], "method", false, false, true, 78);
        // line 79
        yield "<main role=\"main\" class=\"home\"> 
<div class=\"home bg-surface-tertiary\">
                <div class=\"banner position-relative\">
                    <div class=\"banner-bg overflow-hidden\">
                        <img src=\"";
        // line 83
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 83, $this->source) . "/images/bg-image.png"), "html", null, true);
        yield "\" alt=\"banner\" class=\"img-fluid\" />
                    </div>  
                    <div class=\"position-relative z-1\">
                        <div class=\"d-flex justify-content-center ps-search p-32 gap-32\">
                            <div class=\"d-flex justify-content-center bg-surface-primary br-100 flex-fill\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t  ";
        // line 88
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Drupal\twig_tweak\TwigTweakExtension::drupalBlock("custom_standard_search_form_block"), "html", null, true);
        yield "
                            </div>
                        </div>
                        <div class=\"d-flex flex-column px-32 carousel-wrap\">                           
                            <div id=\"carouselId\" class=\"carousel slide\" data-bs-ride=\"carousel\">    
                                <div class=\"carousel-inner\" role=\"listbox\">
                                    <div class=\"carousel-item active\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\"> 
                                                <img class=\"br-top-left-16\" src=\"";
        // line 97
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 97, $this->source) . "/images/banner-img.jpg"), "html", null, true);
        yield "\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                                <h3 class=\"h3\">Welcome to PRISM</h3>
                                                <p>
                                                   PRISM serves as a dynamic hub of knowledge integrating insights from sourced content that supports sales, learning, delivery, contacts, and everything in between. With PRISM, users can access a rich repository of content, essential resources, and links to vital tools and platforms, all designed to elevate performance across Capgemini.
                                                </p>
                                            </div>                    
                                        </div>
                                    </div>
                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"";
        // line 110
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 110, $this->source) . "/images/home-page-2.jpeg"), "html", null, true);
        yield "\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                                <h3 class=\"h3\">Communities in PRISM</h3>
                                                <p>
                                                   Communities are dedicated sites within PRISM where information on specific topics are organized and stored, supporting collaboration and knowledge sharing within Capgemini. 

                                                </p>

                                            </div>                    
                                        </div>
                                    </div>
                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"";
        // line 125
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 125, $this->source) . "/images/home-page-3.jpg"), "html", null, true);
        yield "\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                            <h3 class=\"h3\">Asset Communities:</h3>
                                                <p>                                               
                                                   Asset Communities are repositories of content including sales content, deliverables, key contacts, trainings, lessons learned, overviews and much more.

                                                </p>
                                            <h3 class=\"h3\">Reference Communities:</h3>
                                                <p>
                                                   Reference Communities are repositories of content related to client stories/case studies managed by dedicated Reference Managers.


                                                </p>


                                            </div>                    
                                        </div>
                                    </div>

                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"";
        // line 148
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["directory"] ?? null), 148, $this->source) . "/images/home-page-4.jpg"), "html", null, true);
        yield "\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                            <h3 class=\"h3\">News:</h3>    
                                               <p>                                               
                                                   Stay abreast of the latest news, key announcements, notable achievements, other updates and more.. 


                                                </p>
                                            <h3 class=\"h3\">Events:</h3>
                                                <p>
                                                    Be informed about upcoming conferences, webinars, workshops, and other networking events


                                                </p>

                                            </div>                    
                                        </div>
                                    </div>
                                </div>                            
                                <div class=\"position-relative green d-flex justify-content-center\">
                                    <div class=\"d-flex position-absolute carousal-footer align-items-center justify-content-center\">                                    
                                        <button class=\"carousel-control-prev position-relative\" type=\"button\" data-bs-target=\"#carouselId\" data-bs-slide=\"prev\">
                                            <span class=\"carousel-control-prev-icon material-symbols-outlined\" aria-hidden=\"true\">chevron_left</span>
                                            <span class=\"visually-hidden\">Previous</span>
                                        </button>
                                        <ol class=\"carousel-indicators position-relative d-flex gap-2\">
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"0\" class=\"active\" aria-current=\"true\" aria-label=\"First slide\"></li> </li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"1\" aria-label=\"Second slide\"></li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"2\" aria-label=\"Third slide\"></li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"3\" aria-label=\"Fourth slide\"></li>
                                        </ol>
                                        <button class=\"carousel-control-next position-relative\" type=\"button\" data-bs-target=\"#carouselId\" data-bs-slide=\"next\">
                                            <span class=\"carousel-control-next-icon material-symbols-outlined\" aria-hidden=\"true\">chevron_right</span>
                                            <span class=\"visually-hidden\">Next</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class=\"d-flex gap-3 align-items-center justify-content-between quick-links px-32 py-3 br-bottom-left-16 br-bottom-right-16\">
                                <h4 class=\"h4 mb-0 font-white\">Quick Access Links</h4>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/communities/all\">All Communities</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/asset-listing\">All Assets</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/reference-listing\">All References</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/news-listing\">All News</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/event-listing\">All Events</a>
                               ";
        // line 194
        if (((CoreExtension::inFilter("administrator", ($context["roles"] ?? null)) || CoreExtension::inFilter("global_qc", ($context["roles"] ?? null))) || CoreExtension::inFilter("normal_qc", ($context["roles"] ?? null)))) {
            // line 195
            yield "                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/references-quality-control\">QC of References</a>
                                ";
        }
        // line 197
        yield "                            </div>
                        </div>
                    </div>                                                          
                </div>
                <div class=\"p-32 recent-activity\">
                    <div class=\"d-flex p-32 elevation-02 bg-surface-primary gap-32 flex-column br-16\">        
                        <h4 class=\"h4 mb-0\">My Recent Activities</h4>
                            <div class=\"d-flex flex-column gap-32\">
                                <div class=\"card-group d-flex flex-wrap gap-3\">
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Communities Joined</span>
                                            ";
        // line 209
        $context["homepage_communities"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("home_page_my_communities", "block_1"));
        // line 210
        yield "                                            ";
        if ((($context["homepage_communities"] ?? null) > 10)) {
            // line 211
            yield "                                            <a class=\"link-deep-blue custom-front-link\" href=\"/";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["my_communities_base_url"] ?? null), 211, $this->source), "html", null, true);
            yield "\">View All</a>
                                            ";
        }
        // line 213
        yield "                                        </h5>
                                        <div class=\"card-body py-1\">
                                        ";
        // line 215
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("home_page_my_communities", "home_page_my_communities"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">References from Communities Joined</span>
                                            ";
        // line 221
        $context["homepage_ref_comm_joined"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("homepage_block_references", "block_1"));
        // line 222
        yield "                                            ";
        if ((($context["homepage_ref_comm_joined"] ?? null) > 10)) {
            // line 223
            yield "                                            <a class=\"link-deep-blue custom-front-link\" href=\"/communities-joined-reference-list\">View All</a>
                                            ";
        }
        // line 225
        yield "                                        </h5>
                                        <div class=\"card-body py-1\">
                                        ";
        // line 227
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("homepage_block_references", "home_page_my_references"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Assets from Communities Joined</span>
                                            ";
        // line 233
        $context["homepage_asset_comm_joined"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("home_page_my_assets", "block_1"));
        // line 234
        yield "                                            ";
        if ((($context["homepage_asset_comm_joined"] ?? null) > 10)) {
            // line 235
            yield "                                            <a class=\"link-deep-blue custom-front-link\" href=\"/communities-joined-asset-list\">View All</a>
                                            ";
        }
        // line 237
        yield "                                        </h5>
                                        <div class=\"card-body  py-1\">
                                        ";
        // line 239
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("home_page_my_assets", "home_page_my_assets"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">My Favorites</span>
                                            ";
        // line 245
        $context["homepage_fav"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("profile_my_favorites", "block_1"));
        // line 246
        yield "                                            ";
        if ((($context["homepage_fav"] ?? null) > 10)) {
            // line 247
            yield "                                                <a class=\"link-deep-blue custom-front-link\" href=\"/my-favorites\">View All</a>
                                            ";
        }
        // line 249
        yield "                                        </h5>
                                        <div class=\"card-body py-1\">
                                        ";
        // line 251
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("profile_my_favorites", "home_page_my_favorites"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">References I Follow</span>
                                            ";
        // line 257
        $context["homepage_ref_follow"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("homepage_ref_follow", "block_1"));
        // line 258
        yield "                                            ";
        if ((($context["homepage_ref_follow"] ?? null) > 10)) {
            // line 259
            yield "                                            <a class=\"link-deep-blue custom-front-link\" href=\"/references-i-follow\">View All</a>
                                            ";
        }
        // line 261
        yield "                                        </h5>
                                        <div class=\"card-body py-1\">
                                        ";
        // line 263
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("homepage_ref_follow", "homepage_ref_follow"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Assets I Follow</span>
                                            ";
        // line 269
        $context["homepage_asset_i_follow"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), views_get_view_result("homepage_assets_i_follow", "block_1"));
        // line 270
        yield "                                            ";
        if ((($context["homepage_asset_i_follow"] ?? null) > 10)) {
            // line 271
            yield "                                                <a class=\"link-deep-blue custom-front-link\" href=\"/assets-i-follow\">View All</a>
                                            ";
        }
        // line 273
        yield "                                        </h5>
                                        <div class=\"card-body py-1\">
                                        ";
        // line 275
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("homepage_assets_i_follow", "home_page_asset_follow"), "html", null, true);
        yield "
                                        </div>
                                    </section>
                                </div>
                            </div>
                    </div>
                </div> 


  <a id=\"main-content\" tabindex=\"-1\"></a>";
        // line 285
        yield "  ";
        // line 286
        $context["sidebar_first_classes"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 286) && CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 286))) ? ("col-12 col-sm-6 col-lg-3") : ("col-12 col-lg-3"));
        // line 288
        yield "
  ";
        // line 290
        $context["sidebar_second_classes"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 290) && CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 290))) ? ("col-12 col-sm-6 col-lg-3") : ("col-12 col-lg-3"));
        // line 292
        yield "
  ";
        // line 294
        $context["content_classes"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 294) && CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 294))) ? ("col-12 col-lg-6") : ((((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 294) || CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 294))) ? ("col-12 col-lg-9") : ("col-12"))));
        // line 296
        yield "
   <div class=\"";
        // line 297
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["b5_top_container"] ?? null), 297, $this->source), "html", null, true);
        yield "\">
    ";
        // line 298
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "nav_main", [], "any", false, false, true, 298)) {
            // line 299
            yield "      <div class=\"main-nav\">  
        ";
            // line 300
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "nav_main", [], "any", false, false, true, 300), 300, $this->source), "html", null, true);
            yield "
      </div>
    ";
        }
        // line 303
        yield "    ";
        // line 318
        yield "  </div>
</main>  
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["b5_navbar_schema", "b5_navbar_bg_schema", "b5_footer_schema", "b5_footer_bg_schema", "page", "user", "directory", "my_communities_base_url", "b5_top_container"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/layout/page--front.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  432 => 318,  430 => 303,  424 => 300,  421 => 299,  419 => 298,  415 => 297,  412 => 296,  410 => 294,  407 => 292,  405 => 290,  402 => 288,  400 => 286,  398 => 285,  386 => 275,  382 => 273,  378 => 271,  375 => 270,  373 => 269,  364 => 263,  360 => 261,  356 => 259,  353 => 258,  351 => 257,  342 => 251,  338 => 249,  334 => 247,  331 => 246,  329 => 245,  320 => 239,  316 => 237,  312 => 235,  309 => 234,  307 => 233,  298 => 227,  294 => 225,  290 => 223,  287 => 222,  285 => 221,  276 => 215,  272 => 213,  266 => 211,  263 => 210,  261 => 209,  247 => 197,  243 => 195,  241 => 194,  192 => 148,  166 => 125,  148 => 110,  132 => 97,  120 => 88,  112 => 83,  106 => 79,  104 => 78,  98 => 75,  95 => 74,  93 => 73,  87 => 70,  84 => 69,  81 => 68,  75 => 65,  72 => 64,  69 => 63,  63 => 60,  60 => 59,  57 => 58,  55 => 56,  54 => 55,  53 => 54,  52 => 53,  49 => 51,  47 => 49,  46 => 48,  45 => 47,  44 => 46,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override to display a single page.
 *
 * The doctype, html, head and body tags are not in this template. Instead they
 * can be found in the html.html.twig template in this directory.
 *
 * Available variables:
 *
 * General utility variables:
 * - base_path: The base URL path of the Drupal installation. Will usually be
 *   \"/\" unless you have installed Drupal in a sub-directory.
 * - is_front: A flag indicating if the current page is the front page.
 * - logged_in: A flag indicating if the user is registered and signed in.
 * - is_admin: A flag indicating if the user has permission to access
 *   administration pages.
 *
 * Site identity:
 * - front_page: The URL of the front page. Use this instead of base_path when
 *   linking to the front page. This includes the language domain or prefix.
 *
 * Page content (in order of occurrence in the default page.html.twig):
 * - node: Fully loaded node, if there is an automatically-loaded node
 *   associated with the page and the node ID is the second argument in the
 *   page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - page.header: Items for the header region.
 * - page.primary_menu: Items for the primary menu region.
 * - page.secondary_menu: Items for the secondary menu region.
 * - page.highlighted: Items for the highlighted content region.
 * - page.help: Dynamic help text, mostly for admin pages.
 * - page.content: The main content of the current page.
 * - page.sidebar_first: Items for the first sidebar.
 * - page.sidebar_second: Items for the second sidebar.
 * - page.footer: Items for the footer region.
 * - page.breadcrumb: Items for the breadcrumb region.
 *
 * @see template_preprocess_page()
 * @see html.html.twig
 */
#}
{%
set nav_classes = 'navbar navbar-expand-lg' ~
  (b5_navbar_schema != 'none' ? \" navbar-#{b5_navbar_schema}\" : ' ') ~
  (b5_navbar_schema != 'none' ? (b5_navbar_schema == 'dark' ? ' text-light' : ' text-dark' ) : ' ') ~
  (b5_navbar_bg_schema != 'none' ? \" bg-#{b5_navbar_bg_schema}\" : ' ')
%}

{%
set footer_classes = ' ' ~
  (b5_footer_schema != 'none' ? \" footer-#{b5_footer_schema}\" : ' ') ~
  (b5_footer_schema != 'none' ? (b5_footer_schema == 'dark' ? ' text-light' : ' text-dark' ) : ' ') ~
  (b5_footer_bg_schema != 'none' ? \" bg-#{b5_footer_bg_schema}\" : ' ')
%}
  {% if page.header_left %}
  <div class=\"d-flex gap-3 align-items-center h-100 12345ashish\">
    {{ page.header_left }}
  </div>
  {% endif %}
  {% if page.header_center %}
  <div class=\"d-flex flex-fill justify-content-end ps-search gap-3\">
    {{ page.header_center }}
  </div>
  {% endif %}
  {% if page.header_right %}
  <div class=\"\">
    {{ page.header_right }}
  </div>
  {% endif %}
{% if page.header_bottom %}
<div class=\"header-bottom\">
  {{ page.header_bottom }}
</div>
{% endif %}
{% set roles = user.getroles(TRUE) %}
<main role=\"main\" class=\"home\"> 
<div class=\"home bg-surface-tertiary\">
                <div class=\"banner position-relative\">
                    <div class=\"banner-bg overflow-hidden\">
                        <img src=\"{{ directory ~ '/images/bg-image.png' }}\" alt=\"banner\" class=\"img-fluid\" />
                    </div>  
                    <div class=\"position-relative z-1\">
                        <div class=\"d-flex justify-content-center ps-search p-32 gap-32\">
                            <div class=\"d-flex justify-content-center bg-surface-primary br-100 flex-fill\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t  {{ drupal_block('custom_standard_search_form_block') }}
                            </div>
                        </div>
                        <div class=\"d-flex flex-column px-32 carousel-wrap\">                           
                            <div id=\"carouselId\" class=\"carousel slide\" data-bs-ride=\"carousel\">    
                                <div class=\"carousel-inner\" role=\"listbox\">
                                    <div class=\"carousel-item active\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\"> 
                                                <img class=\"br-top-left-16\" src=\"{{ directory ~ '/images/banner-img.jpg' }}\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                                <h3 class=\"h3\">Welcome to PRISM</h3>
                                                <p>
                                                   PRISM serves as a dynamic hub of knowledge integrating insights from sourced content that supports sales, learning, delivery, contacts, and everything in between. With PRISM, users can access a rich repository of content, essential resources, and links to vital tools and platforms, all designed to elevate performance across Capgemini.
                                                </p>
                                            </div>                    
                                        </div>
                                    </div>
                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"{{ directory ~ '/images/home-page-2.jpeg' }}\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                                <h3 class=\"h3\">Communities in PRISM</h3>
                                                <p>
                                                   Communities are dedicated sites within PRISM where information on specific topics are organized and stored, supporting collaboration and knowledge sharing within Capgemini. 

                                                </p>

                                            </div>                    
                                        </div>
                                    </div>
                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"{{ directory ~ '/images/home-page-3.jpg' }}\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                            <h3 class=\"h3\">Asset Communities:</h3>
                                                <p>                                               
                                                   Asset Communities are repositories of content including sales content, deliverables, key contacts, trainings, lessons learned, overviews and much more.

                                                </p>
                                            <h3 class=\"h3\">Reference Communities:</h3>
                                                <p>
                                                   Reference Communities are repositories of content related to client stories/case studies managed by dedicated Reference Managers.


                                                </p>


                                            </div>                    
                                        </div>
                                    </div>

                                    <div class=\"carousel-item\">
                                        <div class=\"d-flex carousal-wrap\">
                                            <div class=\"w-50 overflow-hidden\">
                                                <img class=\"br-top-left-16\" src=\"{{ directory ~ '/images/home-page-4.jpg' }}\" alt=\"\">
                                            </div>
                                            <div class=\"d-flex flex-column p-4 banner-text w-50 br-top-right-16\">
                                            <h3 class=\"h3\">News:</h3>    
                                               <p>                                               
                                                   Stay abreast of the latest news, key announcements, notable achievements, other updates and more.. 


                                                </p>
                                            <h3 class=\"h3\">Events:</h3>
                                                <p>
                                                    Be informed about upcoming conferences, webinars, workshops, and other networking events


                                                </p>

                                            </div>                    
                                        </div>
                                    </div>
                                </div>                            
                                <div class=\"position-relative green d-flex justify-content-center\">
                                    <div class=\"d-flex position-absolute carousal-footer align-items-center justify-content-center\">                                    
                                        <button class=\"carousel-control-prev position-relative\" type=\"button\" data-bs-target=\"#carouselId\" data-bs-slide=\"prev\">
                                            <span class=\"carousel-control-prev-icon material-symbols-outlined\" aria-hidden=\"true\">chevron_left</span>
                                            <span class=\"visually-hidden\">Previous</span>
                                        </button>
                                        <ol class=\"carousel-indicators position-relative d-flex gap-2\">
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"0\" class=\"active\" aria-current=\"true\" aria-label=\"First slide\"></li> </li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"1\" aria-label=\"Second slide\"></li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"2\" aria-label=\"Third slide\"></li>
                                            <li data-bs-target=\"#carouselId\" data-bs-slide-to=\"3\" aria-label=\"Fourth slide\"></li>
                                        </ol>
                                        <button class=\"carousel-control-next position-relative\" type=\"button\" data-bs-target=\"#carouselId\" data-bs-slide=\"next\">
                                            <span class=\"carousel-control-next-icon material-symbols-outlined\" aria-hidden=\"true\">chevron_right</span>
                                            <span class=\"visually-hidden\">Next</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class=\"d-flex gap-3 align-items-center justify-content-between quick-links px-32 py-3 br-bottom-left-16 br-bottom-right-16\">
                                <h4 class=\"h4 mb-0 font-white\">Quick Access Links</h4>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/communities/all\">All Communities</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/asset-listing\">All Assets</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/reference-listing\">All References</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/news-listing\">All News</a>
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/event-listing\">All Events</a>
                               {% if ('administrator' in roles) or ('global_qc' in roles) or ('normal_qc' in roles) %}
                                <a class=\"btn btn-ghost medium page-trigger flex-fill\" href=\"/references-quality-control\">QC of References</a>
                                {% endif %}
                            </div>
                        </div>
                    </div>                                                          
                </div>
                <div class=\"p-32 recent-activity\">
                    <div class=\"d-flex p-32 elevation-02 bg-surface-primary gap-32 flex-column br-16\">        
                        <h4 class=\"h4 mb-0\">My Recent Activities</h4>
                            <div class=\"d-flex flex-column gap-32\">
                                <div class=\"card-group d-flex flex-wrap gap-3\">
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Communities Joined</span>
                                            {% set homepage_communities = drupal_view_result('home_page_my_communities', 'block_1')|length %}
                                            {% if (homepage_communities > 10) %}
                                            <a class=\"link-deep-blue custom-front-link\" href=\"/{{ my_communities_base_url }}\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body py-1\">
                                        {{ drupal_view('home_page_my_communities', 'home_page_my_communities') }}
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">References from Communities Joined</span>
                                            {% set homepage_ref_comm_joined = drupal_view_result('homepage_block_references', 'block_1')|length %}
                                            {% if (homepage_ref_comm_joined > 10) %}
                                            <a class=\"link-deep-blue custom-front-link\" href=\"/communities-joined-reference-list\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body py-1\">
                                        {{ drupal_view('homepage_block_references', 'home_page_my_references') }}
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Assets from Communities Joined</span>
                                            {% set homepage_asset_comm_joined = drupal_view_result('home_page_my_assets', 'block_1')|length %}
                                            {% if (homepage_asset_comm_joined > 10) %}
                                            <a class=\"link-deep-blue custom-front-link\" href=\"/communities-joined-asset-list\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body  py-1\">
                                        {{ drupal_view('home_page_my_assets', 'home_page_my_assets') }}
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">My Favorites</span>
                                            {% set homepage_fav = drupal_view_result('profile_my_favorites', 'block_1')|length %}
                                            {% if (homepage_fav > 10) %}
                                                <a class=\"link-deep-blue custom-front-link\" href=\"/my-favorites\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body py-1\">
                                        {{ drupal_view('profile_my_favorites', 'home_page_my_favorites') }}
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">References I Follow</span>
                                            {% set homepage_ref_follow = drupal_view_result('homepage_ref_follow', 'block_1')|length %}
                                            {% if (homepage_ref_follow > 10) %}
                                            <a class=\"link-deep-blue custom-front-link\" href=\"/references-i-follow\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body py-1\">
                                        {{ drupal_view('homepage_ref_follow', 'homepage_ref_follow') }}
                                        </div>
                                    </section>
                                    <section class=\"card flex-fill activity-card\">
                                        <h5 class=\"card-title h5 d-flex mb-0\">
                                            <span class=\"flex-fill\">Assets I Follow</span>
                                            {% set homepage_asset_i_follow = drupal_view_result('homepage_assets_i_follow', 'block_1')|length %}
                                            {% if (homepage_asset_i_follow > 10) %}
                                                <a class=\"link-deep-blue custom-front-link\" href=\"/assets-i-follow\">View All</a>
                                            {% endif %}
                                        </h5>
                                        <div class=\"card-body py-1\">
                                        {{ drupal_view('homepage_assets_i_follow', 'home_page_asset_follow') }}
                                        </div>
                                    </section>
                                </div>
                            </div>
                    </div>
                </div> 


  <a id=\"main-content\" tabindex=\"-1\"></a>{# link is in html.html.twig #}
  {%
  set sidebar_first_classes = (page.sidebar_first and page.sidebar_second) ? 'col-12 col-sm-6 col-lg-3' : 'col-12 col-lg-3'
  %}

  {%
  set sidebar_second_classes = (page.sidebar_first and page.sidebar_second) ? 'col-12 col-sm-6 col-lg-3' : 'col-12 col-lg-3'
  %}

  {%
  set content_classes = (page.sidebar_first and page.sidebar_second) ? 'col-12 col-lg-6' : ((page.sidebar_first or page.sidebar_second) ? 'col-12 col-lg-9' : 'col-12' )
   %}

   <div class=\"{{ b5_top_container }}\">
    {% if page.nav_main %}
      <div class=\"main-nav\">  
        {{ page.nav_main }}
      </div>
    {% endif %}
    {# <div class=\"row g-0\">
      {% if page.sidebar_first %}
        <div class=\"order-2 order-lg-1 {{ sidebar_first_classes }}\">
          {{ page.sidebar_first }}
        </div>
      {% endif %}
      <div class=\"order-1 order-lg-2 {{ content_classes }}\">
        {{ page.content }}
      </div>
      {% if page.sidebar_second %}
        <div class=\"order-3 {{ sidebar_second_classes }}\">
          {{ page.sidebar_second }}
        </div>
      {% endif %}
    </div> #}
  </div>
</main>  
", "themes/custom/capgemini_b5/templates/layout/page--front.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\layout\\page--front.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 46, "if" => 58);
        static $filters = array("escape" => 60, "length" => 209);
        static $functions = array("drupal_block" => 88, "drupal_view_result" => 209, "drupal_view" => 215);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'length'],
                ['drupal_block', 'drupal_view_result', 'drupal_view'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
