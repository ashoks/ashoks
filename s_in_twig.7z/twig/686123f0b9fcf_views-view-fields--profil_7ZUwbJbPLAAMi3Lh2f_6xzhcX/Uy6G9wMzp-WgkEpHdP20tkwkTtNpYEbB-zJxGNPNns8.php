<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/views/views-view-fields--profile-my-favorites--home-page-my-favorites.html.twig */
class __TwigTemplate_6afd6d089495b1adfac36d5f381dfdeb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "    ";
        $context["title"] = Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "title", [], "any", false, false, true, 42), "content", [], "any", false, false, true, 42), 42, $this->source)));
        // line 43
        yield "    ";
        $context["nodeid"] = Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "nid", [], "any", false, false, true, 43), "content", [], "any", false, false, true, 43), 43, $this->source)));
        // line 44
        yield "    ";
        $context["type"] = Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "type", [], "any", false, false, true, 44), "content", [], "any", false, false, true, 44), 44, $this->source)));
        // line 45
        yield "    ";
        if ((($context["type"] ?? null) == "Asset")) {
            // line 46
            yield "      ";
            $context["node_type"] = "asset";
            // line 47
            yield "    ";
        } elseif ((($context["type"] ?? null) == "Reference")) {
            // line 48
            yield "      ";
            $context["node_type"] = "reference";
            // line 49
            yield "    ";
        } elseif ((($context["type"] ?? null) == "News")) {
            // line 50
            yield "      ";
            $context["node_type"] = "news";
            // line 51
            yield "    ";
        } else {
            // line 52
            yield "      ";
            $context["node_type"] = "node";
            // line 53
            yield "    ";
        }
        // line 54
        yield "    <ul class=\"d-flex flex-column gap-1\">
        <li class=\"py-2 border-bottom-subtel\">
            <a href=\"/";
        // line 56
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["node_type"] ?? null), 56, $this->source), "html", null, true);
        yield "/";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["nodeid"] ?? null), 56, $this->source), "html", null, true);
        yield "\" class=\"link-primary\">";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["title"] ?? null), 56, $this->source));
        yield "</a>
        </li>
    </ul>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["fields"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/views/views-view-fields--profile-my-favorites--home-page-my-favorites.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  84 => 56,  80 => 54,  77 => 53,  74 => 52,  71 => 51,  68 => 50,  65 => 49,  62 => 48,  59 => 47,  56 => 46,  53 => 45,  50 => 44,  47 => 43,  44 => 42,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Default view template to display all the fields in a row.
 *
 * Available variables:
 * - view: The view in use.
 * - fields: A list of fields, each one contains:
 *   - content: The output of the field.
 *   - raw: The raw data for the field, if it exists. This is NOT output safe.
 *   - class: The safe class ID to use.
 *   - handler: The Views field handler controlling this field.
 *   - inline: Whether or not the field should be inline.
 *   - wrapper_element: An HTML element for a wrapper.
 *   - wrapper_attributes: List of attributes for wrapper element.
 *   - separator: An optional separator that may appear before a field.
 *   - label: The field's label text.
 *   - label_element: An HTML element for a label wrapper.
 *   - label_attributes: List of attributes for label wrapper.
 *   - label_suffix: Colon after the label.
 *   - element_type: An HTML element for the field content.
 *   - element_attributes: List of attributes for HTML element for field content.
 *   - has_label_colon: A boolean indicating whether to display a colon after
 *     the label.
 *   - element_type: An HTML element for the field content.
 *   - element_attributes: List of attributes for HTML element for field content.
 * - row: The raw result from the query, with all data it fetched.
 *
 * @see template_preprocess_views_view_fields()
 *
 * @ingroup themeable
 */
#}
{# 
 {% set nid = result.nid %}
{% set node = drupal_entity('node', nid) %}
{{node['#node'].title.value}}
{% for result in viewres %}
{% set viewres = view.result %}
{% endfor %}
#}
    {% set title = fields.title.content |striptags|trim %}
    {% set nodeid = fields.nid.content |striptags|trim %}
    {% set type = fields.type.content |striptags|trim %}
    {% if type == 'Asset' %}
      {% set node_type = 'asset' %}
    {% elseif type == 'Reference' %}
      {% set node_type = 'reference' %}
    {% elseif type == 'News' %}
      {% set node_type = 'news' %}
    {% else %}
      {% set node_type = 'node' %}
    {% endif %}
    <ul class=\"d-flex flex-column gap-1\">
        <li class=\"py-2 border-bottom-subtel\">
            <a href=\"/{{node_type}}/{{nodeid}}\" class=\"link-primary\">{{title|raw}}</a>
        </li>
    </ul>
", "themes/custom/capgemini_b5/templates/views/views-view-fields--profile-my-favorites--home-page-my-favorites.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\views\\views-view-fields--profile-my-favorites--home-page-my-favorites.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 42, "if" => 45);
        static $filters = array("trim" => 42, "striptags" => 42, "escape" => 56, "raw" => 56);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['trim', 'striptags', 'escape', 'raw'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
