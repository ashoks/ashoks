<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @help_topics/dynamic_entity_reference.overview.html.twig */
class __TwigTemplate_648260580356a3e609835a80c0ea6dc4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "<h2>";
        yield t("Overview", array());
        yield "</h2>
<p>
  <a href=\"https://www.drupal.org/project/dynamic_entity_reference\" rel=\"nofollow\">
    ";
        // line 8
        yield t("Dynamic Entity Reference", array());
        // line 9
        yield "  </a>
  ";
        // line 10
        yield t("provides a field type/widget/formatter combination for Drupal 8 that allows an entity-reference field to reference more than one entity type.", array());
        // line 11
        yield "</p>
<a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\">
  <img src=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\" alt=\"Dynamic Entity Reference\" data-canonical-src=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\" style=\"max-width: 100%;\">
</a>

<h2>";
        // line 16
        yield t("Features", array());
        yield "</h2>

<p>
  ";
        // line 19
        yield t("Create a single field to hold references to Users and Nodes. Or Terms and Nodes, or all three.", array());
        // line 20
        yield "</p>

<h2>";
        // line 22
        yield t("Requirements", array());
        yield "</h2>

<p>
  ";
        // line 25
        yield t("Core field module.", array());
        // line 26
        yield "</p>

<h2>";
        // line 28
        yield t("Known problems", array());
        yield "</h2>

<p>
  ";
        // line 31
        yield t("Please use the", array());
        yield " <a href=\"https://www.drupal.org/project/issues/dynamic_entity_reference\" rel=\"nofollow\">";
        yield t("issue queue", array());
        yield "</a> ";
        yield t("to report problems.", array());
        // line 32
        yield "</p>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@help_topics/dynamic_entity_reference.overview.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  101 => 32,  95 => 31,  89 => 28,  85 => 26,  83 => 25,  77 => 22,  73 => 20,  71 => 19,  65 => 16,  58 => 11,  56 => 10,  53 => 9,  51 => 8,  44 => 5,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% line 5 %}<h2>{% trans %}Overview{% endtrans %}</h2>
<p>
  <a href=\"https://www.drupal.org/project/dynamic_entity_reference\" rel=\"nofollow\">
    {% trans %}Dynamic Entity Reference{% endtrans %}
  </a>
  {% trans %} provides a field type/widget/formatter combination for Drupal 8 that allows an entity-reference field to reference more than one entity type.{% endtrans %}
</p>
<a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\">
  <img src=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\" alt=\"Dynamic Entity Reference\" data-canonical-src=\"https://www.drupal.org/files/project-images/Screen%20Shot%202014-06-11%20at%208.00.21%20am.png\" style=\"max-width: 100%;\">
</a>

<h2>{% trans %}Features{% endtrans %}</h2>

<p>
  {% trans %}Create a single field to hold references to Users and Nodes. Or Terms and Nodes, or all three.{% endtrans %}
</p>

<h2>{% trans %}Requirements{% endtrans %}</h2>

<p>
  {% trans %}Core field module.{% endtrans %}
</p>

<h2>{% trans %}Known problems{% endtrans %}</h2>

<p>
  {% trans %}Please use the{% endtrans %} <a href=\"https://www.drupal.org/project/issues/dynamic_entity_reference\" rel=\"nofollow\">{% trans %}issue queue{% endtrans %}</a> {% trans %}to report problems.{% endtrans %}
</p>", "@help_topics/dynamic_entity_reference.overview.html.twig", "C:\\xampp\\htdocs\\prismlive\\modules\\contrib\\dynamic_entity_reference\\help_topics\\dynamic_entity_reference.overview.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("trans" => 5);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['trans'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
