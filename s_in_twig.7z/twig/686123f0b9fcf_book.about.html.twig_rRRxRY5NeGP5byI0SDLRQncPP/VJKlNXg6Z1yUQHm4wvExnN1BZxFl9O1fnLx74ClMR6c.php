<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @help_topics/book.about.html.twig */
class __TwigTemplate_698c88563d0a5d447a0313c7e5fb36dd extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        $context["user_overview_topic"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\help\HelpTwigExtension']->getTopicLink("user.overview"));
        // line 6
        yield "<h2>";
        yield t("What is a book?", array());
        yield "</h2>
<p>";
        // line 7
        yield t("A book is a structured group of content pages, arranged in a hierarchical structure called a <em>book outline</em>. A book hierarchy can be up to nine levels deep, and a book can include <em>Book page</em> content items or other content items. Every book has a default book-specific navigation block, which contains links that lead to the previous and next pages in the book and to the level above the current page in the book's structure.", array());
        yield "</p>
<h2>";
        // line 8
        yield t("What are the permissions for books?", array());
        yield "</h2>
<p>";
        // line 9
        yield t("The following permissions are needed to create and manage books; see @user_overview_topic and its related topics for more about permissions.", array("@user_overview_topic" => ($context["user_overview_topic"] ?? null), ));
        yield "</p>
<dl>
  <dt>";
        // line 11
        yield t("Create new books", array());
        yield "</dt>
  <dd>";
        // line 12
        yield t("Allows users to add new books to the site.", array());
        yield "</dd>
  <dt>";
        // line 13
        yield t("Add content and child pages to books and manage their hierarchies", array());
        yield "</dt>
  <dd>";
        // line 14
        yield t("Allows users to add configured types of content to existing books.", array());
        yield "</dd>
  <dt>";
        // line 15
        yield t("Administer book outlines", array());
        yield "</dt>
  <dd>";
        // line 16
        yield t("Allows users to add <em>any</em> type of content to a book, use the book overview administration page, and rearrange the pages of a book from the book outline page.", array());
        yield "</dd>
  <dt>";
        // line 17
        yield t("Administer site configuration (in the System module section)", array());
        yield "</dt>
  <dd>";
        // line 18
        yield t("Allows users to do many site configuration tasks, including configuring books. This permission has security implications.", array());
        yield "</dd>
  <dt>";
        // line 19
        yield t("View printer-friendly books", array());
        yield "</dt>
  <dd>";
        // line 20
        yield t("Allows users to click the <em>printer-friendly version</em> link to generate a printer-friendly display of the page, which includes pages below it in the book outline.", array());
        yield "</dd>
  <dt>";
        // line 21
        yield t("<em>Book page</em> content permissions (in the Node module section)", array());
        yield "</dt>
  <dd>";
        // line 22
        yield t("Like other content types, the <em>Book page</em> content type has separate permissions for creating, editing, and deleting a user's own and any content items of this type.", array());
        yield "</dd>
</dl>
<h2>";
        // line 24
        yield t("Managing books", array());
        yield "</h2>
<p>";
        // line 25
        yield t("Book management is handled by the core Book module. The topics listed below will help you create, edit, and configure books.", array());
        yield "</p>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@help_topics/book.about.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  117 => 25,  113 => 24,  108 => 22,  104 => 21,  100 => 20,  96 => 19,  92 => 18,  88 => 17,  84 => 16,  80 => 15,  76 => 14,  72 => 13,  68 => 12,  64 => 11,  59 => 9,  55 => 8,  51 => 7,  46 => 6,  44 => 5,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% line 5 %}{% set user_overview_topic = render_var(help_topic_link('user.overview')) %}
<h2>{% trans %}What is a book?{% endtrans %}</h2>
<p>{% trans %}A book is a structured group of content pages, arranged in a hierarchical structure called a <em>book outline</em>. A book hierarchy can be up to nine levels deep, and a book can include <em>Book page</em> content items or other content items. Every book has a default book-specific navigation block, which contains links that lead to the previous and next pages in the book and to the level above the current page in the book's structure.{% endtrans %}</p>
<h2>{% trans %}What are the permissions for books?{% endtrans %}</h2>
<p>{% trans %}The following permissions are needed to create and manage books; see {{ user_overview_topic }} and its related topics for more about permissions.{% endtrans %}</p>
<dl>
  <dt>{% trans %}Create new books{% endtrans %}</dt>
  <dd>{% trans %}Allows users to add new books to the site.{% endtrans %}</dd>
  <dt>{% trans %}Add content and child pages to books and manage their hierarchies{% endtrans %}</dt>
  <dd>{% trans %}Allows users to add configured types of content to existing books.{% endtrans %}</dd>
  <dt>{% trans %}Administer book outlines{% endtrans %}</dt>
  <dd>{% trans %}Allows users to add <em>any</em> type of content to a book, use the book overview administration page, and rearrange the pages of a book from the book outline page.{% endtrans %}</dd>
  <dt>{% trans %}Administer site configuration (in the System module section){% endtrans %}</dt>
  <dd>{% trans %}Allows users to do many site configuration tasks, including configuring books. This permission has security implications.{% endtrans %}</dd>
  <dt>{% trans %}View printer-friendly books{% endtrans %}</dt>
  <dd>{% trans %}Allows users to click the <em>printer-friendly version</em> link to generate a printer-friendly display of the page, which includes pages below it in the book outline.{% endtrans %}</dd>
  <dt>{% trans %}<em>Book page</em> content permissions (in the Node module section){% endtrans %}</dt>
  <dd>{% trans %}Like other content types, the <em>Book page</em> content type has separate permissions for creating, editing, and deleting a user's own and any content items of this type.{% endtrans %}</dd>
</dl>
<h2>{% trans %}Managing books{% endtrans %}</h2>
<p>{% trans %}Book management is handled by the core Book module. The topics listed below will help you create, edit, and configure books.{% endtrans %}</p>", "@help_topics/book.about.html.twig", "C:\\xampp\\htdocs\\prismlive\\core\\modules\\book\\help_topics\\book.about.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 5, "trans" => 6);
        static $filters = array("escape" => 9);
        static $functions = array("render_var" => 5, "help_topic_link" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'trans'],
                ['escape'],
                ['render_var', 'help_topic_link'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
