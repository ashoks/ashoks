<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/capgemini_b5/templates/form/form.html.twig */
class __TwigTemplate_7b70b1abe24d7fa3971f5b2acda5bd5f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        $context["varForKOForm"] = 0;
        // line 14
        $context["form_array"] = ["node-news-form", "node-event-form", "node-asset-form", "node-reference-form", "node-news-edit-form", "node-event-edit-form", "node-asset-edit-form", "node-reference-edit-form", "node-pages-form", "node-pages-edit-form", "comment-comment-form", "comment-comment-delete-form", "node-revision-revert-confirm", "node-revision-delete-confirm"];
        // line 15
        $context["curr_form"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "storage", [], "any", false, false, true, 15), "class", [], "any", false, false, true, 15), ($context["varForKOForm"] ?? null), [], "any", false, false, true, 15);
        // line 16
        if ((($context["curr_form"] ?? null) == "node-news-form")) {
            // line 17
            yield "  ";
            $context["create_edit_ko_title"] = "Create News";
        } elseif ((        // line 18
($context["curr_form"] ?? null) == "node-news-edit-form")) {
            // line 19
            yield "  ";
            $context["create_edit_ko_title"] = "Edit News";
        } elseif ((        // line 20
($context["curr_form"] ?? null) == "node-event-form")) {
            // line 21
            yield "  ";
            $context["create_edit_ko_title"] = "Create Event";
        } elseif ((        // line 22
($context["curr_form"] ?? null) == "node-event-edit-form")) {
            // line 23
            yield "  ";
            $context["create_edit_ko_title"] = "Edit Event";
        } elseif ((        // line 24
($context["curr_form"] ?? null) == "node-asset-form")) {
            // line 25
            yield "  ";
            $context["create_edit_ko_title"] = "Create Asset";
        } elseif ((        // line 26
($context["curr_form"] ?? null) == "node-asset-edit-form")) {
            // line 27
            yield "  ";
            $context["create_edit_ko_title"] = "Edit Asset";
        } elseif ((        // line 28
($context["curr_form"] ?? null) == "node-reference-form")) {
            // line 29
            yield "  ";
            $context["create_edit_ko_title"] = "Create Reference";
        } elseif ((        // line 30
($context["curr_form"] ?? null) == "node-reference-edit-form")) {
            // line 31
            yield "  ";
            $context["create_edit_ko_title"] = "Edit Reference";
            yield "    
";
        } elseif ((        // line 32
($context["curr_form"] ?? null) == "node-pages-form")) {
            // line 33
            yield "  ";
            $context["create_edit_ko_title"] = "Create Community Page";
        } elseif ((        // line 34
($context["curr_form"] ?? null) == "node-pages-edit-form")) {
            // line 35
            yield "  ";
            $context["create_edit_ko_title"] = "Edit Community Page";
        }
        // line 37
        $context["currentPath"] = (($__internal_compile_0 = $this->extensions['Drupal\Core\Template\TwigExtension']->getUrl("<current>")) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess && in_array($__internal_compile_0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_0["#markup"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $this->extensions['Drupal\Core\Template\TwigExtension']->getUrl("<current>"), "#markup", [], "array", false, false, true, 37));
        // line 38
        $context["urlsegment"] = Twig\Extension\CoreExtension::split($this->env->getCharset(), $this->sandbox->ensureToStringAllowed(($context["currentPath"] ?? null), 38, $this->source), "/");
        // line 39
        $context["pathArgs"] = (($__internal_compile_1 = ($context["urlsegment"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess && in_array($__internal_compile_1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_1[5] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["urlsegment"] ?? null), 5, [], "array", false, false, true, 39));
        // line 40
        $context["pathArgsRevert"] = (($__internal_compile_2 = ($context["urlsegment"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess && in_array($__internal_compile_2::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($__internal_compile_2[7] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["urlsegment"] ?? null), 7, [], "array", false, false, true, 40));
        // line 41
        yield "
";
        // line 42
        if (CoreExtension::inFilter(($context["curr_form"] ?? null), ($context["form_array"] ?? null))) {
            // line 43
            yield "  ";
            if (($context["com_details_block_output"] ?? null)) {
                // line 44
                yield "    <div class=\"d-flex flex-column\">
      ";
                // line 45
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["com_details_block_output"] ?? null), 45, $this->source), "html", null, true);
                yield "
    </div>
  ";
            }
            // line 48
            yield "  <div class=\"d-flex flex-column\">
    ";
            // line 49
            if (((($context["pathArgs"] ?? null) == "revisions") && (($context["pathArgsRevert"] ?? null) == "revert"))) {
                // line 50
                yield "    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
      <h5 class=\"revision-header\">  Are you sure you want to revert? </h5>
    </div>
    ";
            } elseif (((            // line 53
($context["pathArgs"] ?? null) == "revisions") && (($context["pathArgsRevert"] ?? null) == "delete"))) {
                // line 54
                yield "    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
      <h5 class=\"revision-header\">  Are you sure you want to delete? </h5>
    </div>
    ";
            } else {
                // line 58
                yield "    ";
                if (($context["create_edit_ko_title"] ?? null)) {
                    // line 59
                    yield "    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
        <h3 class=\"h4 mb-0\">";
                    // line 60
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["create_edit_ko_title"] ?? null), 60, $this->source), "html", null, true);
                    yield "</h3>
    </div>
    ";
                }
                // line 63
                yield "    ";
            }
        }
        // line 65
        yield "  <form";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attributes"] ?? null), 65, $this->source), "html", null, true);
        yield ">
    ";
        // line 66
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["children"] ?? null), 66, $this->source), "html", null, true);
        yield "
  </form>
";
        // line 68
        if (CoreExtension::inFilter(($context["curr_form"] ?? null), ($context["form_array"] ?? null))) {
            // line 69
            yield "  </div>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["attributes", "com_details_block_output", "children"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/capgemini_b5/templates/form/form.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  174 => 69,  172 => 68,  167 => 66,  162 => 65,  158 => 63,  152 => 60,  149 => 59,  146 => 58,  140 => 54,  138 => 53,  133 => 50,  131 => 49,  128 => 48,  122 => 45,  119 => 44,  116 => 43,  114 => 42,  111 => 41,  109 => 40,  107 => 39,  105 => 38,  103 => 37,  99 => 35,  97 => 34,  94 => 33,  92 => 32,  87 => 31,  85 => 30,  82 => 29,  80 => 28,  77 => 27,  75 => 26,  72 => 25,  70 => 24,  67 => 23,  65 => 22,  62 => 21,  60 => 20,  57 => 19,  55 => 18,  52 => 17,  50 => 16,  48 => 15,  46 => 14,  44 => 13,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override for a 'form' element.
 *
 * Available variables
 * - attributes: A list of HTML attributes for the wrapper element.
 * - children: The child elements of the form.
 *
 * @see template_preprocess_form()
 */
#}
{% set varForKOForm = 0 %}
{% set form_array = ['node-news-form','node-event-form','node-asset-form','node-reference-form','node-news-edit-form','node-event-edit-form','node-asset-edit-form','node-reference-edit-form','node-pages-form','node-pages-edit-form','comment-comment-form','comment-comment-delete-form','node-revision-revert-confirm','node-revision-delete-confirm'] %}
{% set curr_form = attribute(attributes.storage.class, varForKOForm) %}
{% if curr_form == 'node-news-form' %}
  {% set create_edit_ko_title = 'Create News' %}
{% elseif curr_form == 'node-news-edit-form' %}
  {% set create_edit_ko_title = 'Edit News' %}
{% elseif curr_form == 'node-event-form' %}
  {% set create_edit_ko_title = 'Create Event' %}
{% elseif curr_form == 'node-event-edit-form' %}
  {% set create_edit_ko_title = 'Edit Event' %}
{% elseif curr_form == 'node-asset-form' %}
  {% set create_edit_ko_title = 'Create Asset' %}
{% elseif curr_form == 'node-asset-edit-form' %}
  {% set create_edit_ko_title = 'Edit Asset' %}
{% elseif curr_form == 'node-reference-form' %}
  {% set create_edit_ko_title = 'Create Reference' %}
{% elseif curr_form == 'node-reference-edit-form' %}
  {% set create_edit_ko_title = 'Edit Reference' %}    
{% elseif curr_form == 'node-pages-form' %}
  {% set create_edit_ko_title = 'Create Community Page' %}
{% elseif curr_form == 'node-pages-edit-form' %}
  {% set create_edit_ko_title = 'Edit Community Page' %}
{% endif %}
{% set currentPath = url('<current>')['#markup'] %}
{% set urlsegment = currentPath | split('/') %}
{% set pathArgs = urlsegment[5] %}
{% set pathArgsRevert = urlsegment[7] %}

{% if curr_form in form_array %}
  {% if com_details_block_output %}
    <div class=\"d-flex flex-column\">
      {{ com_details_block_output }}
    </div>
  {% endif %}
  <div class=\"d-flex flex-column\">
    {% if pathArgs == 'revisions' and pathArgsRevert == 'revert' %}
    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
      <h5 class=\"revision-header\">  Are you sure you want to revert? </h5>
    </div>
    {% elseif pathArgs == 'revisions' and pathArgsRevert == 'delete' %}
    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
      <h5 class=\"revision-header\">  Are you sure you want to delete? </h5>
    </div>
    {% else %}
    {% if create_edit_ko_title %}
    <div class=\"ko-header bg-surface-secondary border-bottom-subtel p-3\">
        <h3 class=\"h4 mb-0\">{{ create_edit_ko_title }}</h3>
    </div>
    {% endif %}
    {% endif %}
{% endif %}
  <form{{ attributes }}>
    {{ children }}
  </form>
{% if curr_form in form_array %}
  </div>
{% endif %}
", "themes/custom/capgemini_b5/templates/form/form.html.twig", "C:\\xampp\\htdocs\\prismlive\\themes\\custom\\capgemini_b5\\templates\\form\\form.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 13, "if" => 16);
        static $filters = array("split" => 38, "escape" => 45);
        static $functions = array("url" => 37);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['split', 'escape'],
                ['url'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
