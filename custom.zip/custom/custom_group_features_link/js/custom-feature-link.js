jQuery(document).ready(function () {
    if (jQuery(".rows-content-status")[0]) {
        jQuery("[data-view-id=manage_status]").css("display", "none");
        jQuery(".form-item-action").css("display", "none");
        jQuery("#edit-submit--2").css("display", "none");
    }

    if (jQuery(".rows-mass-operation")[0]) {
        jQuery("[data-view-id=mass_operation]").css("display", "none");
        jQuery("#edit-submit--2").css("display", "none");
    }
/*
    jQuery(".pop").popover({
        trigger: "manual",
        html: true,
        animation: false
    })
    .on("mouseenter", function () {
        var _this = this;
        jQuery(this).popover("show");
        jQuery(".popover").on("mouseleave", function () {
            jQuery(_this).popover('hide');
        });
    }).on("mouseleave", function () {
        var _this = this;
        setTimeout(function () {
            if (!jQuery(".popover:hover").length) {
                jQuery(_this).popover("hide");
            }
        }, 300);
    });
*/
});


jQuery(window).on("load", function () {
  // Here code for appending checkbox with nodeid
    jQuery('.rows-content-status').each(function (i, obj) {
        var nodeid = jQuery(this).find("div.row-nid").text();
        jQuery(this).find("input").val(nodeid);
      // jQuery(this).find("input").attr('name', 'customstatus[]');
        jQuery(this).find("div.row-nid").hide();
    });

    jQuery('.rows-mass-operation').each(function (i, obj) {
        var nodeid = jQuery(this).find("div.row-nid").text();
        jQuery(this).find("input").val(nodeid);
      // jQuery(this).find("input").attr('name', 'customstatus[]');
        jQuery(this).find("div.row-nid").hide();
    });

});
