<?php

namespace Drupal\custom_group_features_link_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\user\Entity\User;

/**
 * Provides a 'CustomGroupFeaturesLinkBlock' block.
 *
 * @Block(
 *  id = "custom_group_features_link_block",
 *  admin_label = @Translation("Custom Group Features Link Block"),
 * )
 */
class CustomGroupFeaturesLinkBlock extends BlockBase {

  /**
   * Implements \Drupal\block\BlockBase::blockBuild().
   *
   * {@inheritdoc}
   */
  public function build() {
    // Clear cache for the block.
    \Drupal::service('cache.render')->invalidateAll();
    $status_value = NULL;
    $user_id = \Drupal::currentUser()->id();
    $parameters = \Drupal::routeMatch()->getParameters()->all();
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
      if ($group instanceof GroupInterface) {
        $gid = $group->id();
        $group_type = $group->getGroupType()->id();
        $field_community_type = $group->get('field_community_type')->value;
        $leader_id = $group->getOwnerId();
        $group_publish_check = $group->isPublished();
        $parameters = \Drupal::routeMatch()->getParameters('gid');
        $group_url_gid = $parameters->get('gid');
        if (!empty($group_url_gid)) {
          $group = Group::load($group_url_gid);
          $status_value = $group->get('status')->getValue()[0]['value'];
          $field_community_type = $group->get('field_community_type')->value;
        }
        $community_id = \Drupal::request()->get('community_id');
        if (!empty($community_id)) {
          $group = Group::load($community_id);
          $status_value = $group->get('status')->getValue()[0]['value'];
          $field_community_type = $group->get('field_community_type')->value;
        }
      }
    }
    else {
      $group = \Drupal::routeMatch()->getParameter('group');
      if ($group instanceof GroupInterface) {
        /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
        $field_community_type = $group->get('field_community_type')->value;
        $leader_id = $group->getOwnerId();
        $group_publish_check = $group->isPublished();
      }

      $parameters = \Drupal::routeMatch()->getParameters('gid');
      $group_url_gid = $parameters->get('gid');
      if (!empty($group_url_gid)) {

        $group = Group::load($group_url_gid);
        $status_value = $group->get('status')->getValue()[0]['value'];
        $field_community_type = $group->get('field_community_type')->value;
      }
      $community_id = \Drupal::request()->get('community_id');
      if (!empty($community_id)) {
        $group = Group::load($community_id);
        $status_value = ($group instanceof GroupInterface)?$group->get('status')->getValue()[0]['value']:null;
        $field_community_type = ($group instanceof GroupInterface)?$group->get('field_community_type')->value:null;
      }
    }

    if (empty($gid)) {
      $current_path = \Drupal::service('path.current')->getPath();
      if (strpos($current_path, "/admin/taxonomy/community_taxonomy")) {
        $path = explode('/', $current_path);
        if (isset($path[2]) && !empty($path[2])) {
          $gid = $path[2];
        }
      }
    }

    // Removing warning from the manage member role section.
    if (!isset($group_type)) {
      $group_type = NULL;
    }
    if (!isset($group_publish_check)) {
      $group_publish_check = NULL;
    }
    if (!isset($field_community_type)) {
      $field_community_type = NULL;
    }
    if (!isset($reference_manager)) {
      $reference_manager = NULL;
    }
    $current_path = \Drupal::service('path.current')->getPath();
    if($current_path == '/group/views-bulk-operations/configure/mass_operation/page_1') {
      $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
      $store->get('old_gid');
      if (empty($gid)) {
        if ( $store->get('old_gid') > 0) {
          $group = Group::load($store->get('old_gid'));
          if ($group instanceof GroupInterface) {
            $gid = $group->id();
          }
        }
      }
    }
    elseif($current_path == '/group/views-bulk-operations/confirm/mass_operation/page_1') {
      $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
      $store->get('old_gid');
      if (empty($gid)) {
        if ( $store->get('old_gid') > 0) {
          $group = Group::load($store->get('old_gid'));
          if ($group instanceof GroupInterface) {
            $gid = $group->id();
          }
        }
      }
    }
    if (empty($gid)) {
      $nid = \Drupal::routeMatch()->getRawParameter('node');
      $route_name = \Drupal::routeMatch()->getRouteName();
      $node = ($nid)?Node::load($nid):null;
      $groupSocialId = (($node) && $node->hasField('field_community') && is_array($node->get('field_community')->getValue()) && array_key_exists(0, $node->get('field_community')->getValue())) ? $node->get('field_community')->getValue()[0]['target_id'] : "";
      if ($groupSocialId) {
        $group = Group::load($groupSocialId);
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
        $field_community_type = $group->get('field_community_type')->value;
        $group_type = $group->getGroupType()->id();
        $group_publish_check = $group->isPublished();
       }
      $parameters = \Drupal::routeMatch()->getParameters('gid');
      $group_url_gid = $parameters->get('gid');
      if (!empty($group_url_gid)) {

        $group = Group::load($group_url_gid);
        $status_value = $group->get('status')->getValue()[0]['value'];
        $field_community_type = $group->get('field_community_type')->value;
      }
      $community_id = \Drupal::request()->get('community_id');
      if (!empty($community_id)) {
        $group = Group::load($community_id);
        $status_value = ($group instanceof GroupInterface)?$group->get('status')->getValue()[0]['value']:null;
        $field_community_type = ($group instanceof GroupInterface)?$group->get('field_community_type')->value:null;
      }
      if($route_name == 'view.publish_references.page_1'){
          $current_path = \Drupal::service('path.current')->getPath();
          $gid = explode("/",$current_path)[3];
          if(is_numeric($gid)){
          $group = Group::load($gid);
          $status_value = $group->get('status')->getValue()[0]['value'];
          $field_community_type = $group->get('field_community_type')->value;
          }
      }  
    }

    if (empty($gid)) {
      $gid = $this->getCustomGroupId();
    }
    $group = ($gid)?Group::load($gid):null;

    // Write the code to restrict the block access based on roles.
    $user = User::load(\Drupal::currentUser()->id());
    $roles = $user->getRoles();
    $rolLabel;
    // $group = \Drupal::routeMatch()->getParameter('group');
    if ($group instanceof GroupInterface) {
      $account = \Drupal::currentUser();
      $account_id = \Drupal::currentUser()->id();
      $member = $group->getMember($account);
      $rol = ($member) ? $member->getRoles() : [];
      $reference_manager = 0;
      $owner = $group->getOwner();
      $uid = ($owner) ? $owner->uid->getValue()[0]['value'] : NULL;
      if ($group_publish_check == true || $uid == $account_id) {
        if ((isset($rol[$group->bundle() . '-group_manager']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-moderator']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-group_manager'])) || (isset($rol[$group->bundle() . '-moderator']))) {
          $reference_manager = 1;
          $rolLabelPublic =  isset($rol) && (count($rol)>0) &&  array_key_exists("public_group-moderator", $rol)? $rol['public_group-moderator']->label() : NULL;
          $rolLabelClosed =  isset($rol) && (count($rol)>0) &&  array_key_exists("closed_group-moderator", $rol)? $rol['closed_group-moderator']->label() : NULL;
          $rolLabelSecret =  isset($rol) && (count($rol)>0) &&  array_key_exists("secret_group-moderator", $rol)? $rol['secret_group-moderator']->label() : NULL;
        }
      }
    }

    // Get the leader if the user is the creator of the group.
    $approved_roles = ['reference_manager_overall', 'can_log_in_admin'];
    $admin_roles = ['administrator'];

    // In some cases gid is still blank then check group id from route.
    if (empty($gid)) {
      $current_path = \Drupal::service('path.current')->getPath();
      $path_args = explode('/', $current_path);
      $gid = $path_args[2];
    }

    if ($gid == "edit" || $gid == "add") {
      $gid = "";
    }

    $group = \Drupal::routeMatch()->getParameter('group');
    if (is_null($group)) {
      $path = \Drupal::service('path.current')->getPath();
      $parts = explode('/', $path);
      if ($parts[1] == 'group' && is_numeric($parts[2])) {
        $gid = $parts[2];
        $group = \Drupal::entitytypeManager()->getStorage('group')->load($gid);
      }
    }
    
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;
    } 

    if (empty($gid)) {
      $gid = \Drupal::request()->get('community_id');
    }

    if (empty($gid)) {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node instanceof NodeInterface) {
        $group = $node->get('field_community')->getValue();
        $gid = $group[0]['target_id'];
      }
    }
    $group = ($gid)?Group::load($gid):null;
    if ($group instanceof GroupInterface) {
      $group_publish_check = $group->isPublished();
      $status_value = $group->get('status')->getValue()[0]['value'];
      $group_type = $group->getGroupType()->id();
      $account = \Drupal::currentUser();
      $account_id = \Drupal::currentUser()->id();
      $member = $group->getMember($account);
      $rol = ($member) ? $member->getRoles() : [];
      $reference_manager = 0;
      $owner = $group->getOwner();
      $uid = ($owner) ? $owner->uid->getValue()[0]['value'] : NULL;
      if ($group_publish_check == true || $uid == $account_id) {
        if ((isset($rol[$group->bundle() . '-group_manager']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-moderator']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-group_manager'])) || (isset($rol[$group->bundle() . '-moderator']))) {
          $reference_manager = 1;
          $rolLabelPublic =  isset($rol) && (count($rol)>0) &&  array_key_exists("public_group-moderator", $rol)? $rol['public_group-moderator']->label() : NULL;
          $rolLabelClosed =  isset($rol) && (count($rol)>0) &&  array_key_exists("closed_group-moderator", $rol)? $rol['closed_group-moderator']->label() : NULL;
          $rolLabelSecret =  isset($rol) && (count($rol)>0) &&  array_key_exists("secret_group-moderator", $rol)? $rol['secret_group-moderator']->label() : NULL;
        }
      }
    }
    if (is_array($roles)) {
      if ($field_community_type == 3) {
        // Reference condition.
        if (in_array("administrator", $roles) || ((count(array_intersect($roles, $approved_roles)) > 0) && ($reference_manager == 1))) {
          return [
            '#theme' => 'custom_group_features_link_block',
            '#data' => $gid,
            '#user_id' => $user_id,
            '#feature_type' => $field_community_type,
            '#reference_manager' => $reference_manager,
            '#publish_check' => $group_publish_check,
            '#status_value' => $status_value,
            '#group_type' => $group_type,
            '#cache' => [
              'max-age' => 0,
            ],
          ];
        }
      }
      elseif ($field_community_type == 0 || $field_community_type == 1 || $field_community_type == 2) {
        // Asset condition.
        if (in_array("administrator", $roles) || ($reference_manager == 1)) {
          return [
            '#theme' => 'custom_group_features_link_block',
            '#data' => $gid,
            '#user_id' => $user_id,
            '#feature_type' => $field_community_type,
            '#reference_manager' => $reference_manager,
            '#publish_check' => $group_publish_check,
            '#status_value' => $status_value,
            '#group_type' => $group_type,
            '#cache' => [
              'max-age' => 0,
            ],
          ];
        }
        else{ 
          if($rolLabelPublic == 'Moderator' || $rolLabelClosed == 'Moderator' || $rolLabelSecret == 'Moderator'){
          return [
            '#theme' => 'custom_group_features_link_block',
            '#data' => $gid,
            '#user_id' => $user_id,
            '#feature_type' => $field_community_type,
            '#reference_manager' => $reference_manager,
            '#publish_check' => $group_publish_check,
            '#status_value' => $status_value,
            '#group_type' => $group_type,
            '#cache' => [
              'max-age' => 0,
            ],
          ]; 
          }      
        }
      }
    }
    return [];
  }

  /**
   * Prepares variables for group global id.
   */
  public function getCustomGroupId() {
    $current_path = \Drupal::service('path.current')->getPath();
    $route_name = \Drupal::routeMatch()->getRouteName();

    $group = \Drupal::routeMatch()->getParameter('group');
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;
    }

    $group = \Drupal::routeMatch()->getParameter('gid');
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;

    }

    if ($route_name == "custom_block.custom_yammer_display") {
      // $node = \Drupal::routeMatch()->getParameter('node');
      $current_path = \Drupal::service('path.current')->getPath();
      $gid = explode("/", $current_path)[2];
    }

    if (empty($gid)) {
      $gid = \Drupal::request()->get('community_id');
    }

    if (empty($gid)) {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node instanceof NodeInterface) {
        $group = ($node->hasField('field_community')) ? $node->get('field_community')->getValue() : NULL;
        $gid = ($group) ? $group[0]['target_id'] : NULL;
      }
    }

    if (empty($gid)) {
      // $node = \Drupal::routeMatch()->getParameter('node');
      $current_path = \Drupal::service('path.current')->getPath();
      $nid = explode("/", $current_path)[2];
      $node = Node::load($nid);
      if (($node instanceof NodeInterface) && $route_name == "entity.node.canonical") {
        $group = ($node->hasField('field_community')) ? $node->get('field_community')->getValue() : NULL;
        $gid = ($group) ? $group[0]['target_id'] : NULL;
      }
    }

    if ($gid == NULL) {
      $current_uri = \Drupal::request()->getRequestUri();
      preg_match_all('!\d+!', $current_uri, $matches);
      $gid = (array_key_exists(0, $matches) && isset($matches[0]) && count($matches[0]) > 0) ? $matches[0][0] : NULL;
    }

    return $gid;
  }

  /**
   *
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
