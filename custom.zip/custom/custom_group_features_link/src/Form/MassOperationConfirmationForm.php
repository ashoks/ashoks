<?php

namespace Drupal\custom_group_features_link_block\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Implementing a ajax form.
 */
class MassOperationConfirmationForm extends ConfirmFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mass_operation_confirmation_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    // Collection of all nodes which are selected.
    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];

    switch ($action_item) {
      case "Delete Content":
        // Render Table here which has the listing of all the nodes.
        $form['table_head'] = [
          '#markup' => '<div>Following items will be permanently deleted</div>
            <table class="vbo-table table table-hover table-striped">
            <thead>
            <tr>
            <th class="views-field views-field-title">Content Title</th>
            <th class="views-field views-field-type-1">Content Type</th>
            <th class="views-field views-field-field-author">Author</th>
            <th class="views-field views-field-created">Created on</th>
            </tr>
            </thead>
                                  <tbody>',
        ];

        foreach ($content_id as $nid) {
          $node = Node::load($nid);
          $user = User::load($node->get('field_author')->getValue()[0]['target_id']);
          $dateFormat = date('d M Y', $node->getCreatedTime());
          $author = ($user->getDisplayName()) ? $user->getDisplayName() : "Anonymous";
          $form['table_row'][$nid] = [
            '#markup' => '<tr class="odd views-row-first">
                                        <td class="views-field views-field-title">' . $node->getTitle() . '</td>
                                        <td class="views-field views-field-type">' . strtoupper($node->bundle()) . '</td>
                                        <td class="views-field views-field-author">' . $author . '</td>
                                        <td class="views-field views-field-created">' . $dateFormat . '</td>
                                      </tr>',
          ];
        }
        $form['table_footer'] = [
          '#markup' => '</tbody>
                                   </table>',
        ];

        break;
    }

    return parent::buildForm($form, $form_state);
  }

  /**
   * Returns the question to ask the user.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup
   *   The form question. The page title will be set to this value.
   */
  public function getQuestion() {
    return t('Do you want to delete this node?');
  }

  /**
   * Returns the route to go to if the user cancels the action.
   *
   * @return \Drupal\Core\Url
   *   A URL object.
   */
  public function getCancelUrl() {
    $gid = $_SESSION['gid'];
    return Url::fromRoute('view.mass_operation.page_group_manage_content', ['group' => $gid]);

    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    unset($_SESSION['gid']);
  }

  /**
   * Submitting the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $context['message'] = t('Deleting contents');

    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];

    if (isset($content_id) && $action_item = "Delete Content") {
      $context['message'] = t('Performing mass operation Delete Content');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      foreach ($content_id as $nid) {
        $node = Node::load($nid);
        $node->delete();
      }
    }

    $gid = $_SESSION['gid'];
    \Drupal::messenger()->addStatus('Performed action Delete Content on ' . count($content_id) . ' item(s).', TRUE);
    $gid = $_SESSION['gid'];
    $response = new RedirectResponse("/group/" . $gid . "/manage-content");
    $response->send();
    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    unset($_SESSION['gid']);
  }

}
