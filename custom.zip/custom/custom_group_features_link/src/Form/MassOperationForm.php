<?php

namespace Drupal\custom_group_features_link_block\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupContent;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Implementing a ajax form.
 */
class MassOperationForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mass_operation_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    // Collection of all nodes which are selected.
    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];

    $form['content_id'] = [
      '#type' => 'hidden',
      '#value' => $content_id,
      '#prefix' => '',
    ];

    switch ($action_item) {
      case "Add Tags":
        $form['field_tags'] = [
          '#type' => 'textfield',
          '#title' => $this->t('Enter the tags you want to add to selected items.'),
          '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
          '#suffix' => '</div>',
          '#description' => t('* Use comma as a separator between values'),
          '#autocomplete_route_name' => 'custom_group_features_link_block.autocomplete',
        ];
        break;

      case "Move Content":
        $form['communities_list'] = [
          '#type' => 'textfield',
          '#title' => $this->t('Enter name of community to which you want to move selected items.'),
          '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
          '#suffix' => '</div>',
          '#description' => t('* Please note that the items will actually be moved to the new community. They will not show up anymore in the original community.'),
          '#autocomplete_route_name' => 'custom_group_features_link_block.community_list_autocomplete',
        ];
        break;

      case "Change Submitter":
        $form['field_author'] = [
          '#type' => 'textfield',
          '#title' => $this->t('Enter new submitter\'s name for selected items.'),
          '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
          '#suffix' => '</div>',
          '#description' => t('Help text for Foo field'),
          '#autocomplete_route_name' => 'custom_group_features_link_block.get_submitter_autocomplete',
        ];

        break;

      case "Delete Content":
        $form['field_author'] = [
          '#type' => 'hidden',
          '#title' => $this->t('Enter new submitter\'s name for selected items.'),
          '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
          '#suffix' => '</div>',
          '#description' => t('Help text for field'),
          '#autocomplete_route_name' => 'custom_group_features_link_block.get_submitter_autocomplete',
        ];

        break;
    }

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  /**
   *
   */
  public function string_between_two_string($str, $starting_word, $ending_word) {
    $subtring_start = strpos($str, $starting_word);
    // Adding the starting index of the starting word to
    // its length would give its ending index.
    $subtring_start += strlen($starting_word);
    // Length of our required sub string.
    $size = strpos($str, $ending_word, $subtring_start) - $subtring_start;
    // Return the substring from the index substring_start of length size.
    return substr($str, $subtring_start, $size);
  }

  /**
   * Change Submitter Content Method.
   */
  public function changeSubmitterContent($content_id, $action_item, $form_state) {

    $author_id = $this->string_between_two_string($form_state->getValue('field_author'), '(', ')');

    if (isset($content_id) && $action_item = "Change Submitter") {
      $context['message'] = t('Performed action on Change Submitter');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      foreach ($content_id as $nid) {
        $node = Node::load($nid);
        $node->set('field_author', $author_id);
        $node->save();
      }

      $context['results']['node'] = $node;
    }

    \Drupal::messenger()->addStatus('Performed action Change Submitter on ' . count($content_id) . ' item(s).', TRUE);
  }

  /**
   * Add Tags Batch Method.
   */
  public function addTagsBatch($content_id, $action_item, $form_state) {

    if (isset($content_id) && $action_item = "Add Tags") {
      $context['message'] = t('Performing mass operation on Add Tags');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      foreach ($content_id as $nid) {
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);

        $term_objects = $node->get('field_tags')->referencedEntities();
        $term_labels = [];
        $multiple_tids = [];
        $tags = '';
        foreach ($term_objects as $term_object) {
          // The id of the term.
          $term_object->id();
          // The term title.
          $term_object->label();
          // Build an array of term labels.
          $term_labels[] = $term_object->label();
          $tags .= $term_object->label() . ',';
        }
        $tags .= trim($form_state->getValue('field_tags'));
        $arrayTags = explode(",", $tags);

        $existingTags = \Drupal::service('entity_type.manager')
          ->getStorage("taxonomy_term")
          ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);

        $termTagsId = [];
        $termTagsName = [];
        foreach ($existingTags as $key => $term) {
          $termTagsName[$term->tid] = $term->name;
        }

        foreach ($arrayTags as $tag) {
          $categories_vocabulary = 'tags';
          if (!in_array($tag, $termTagsName)) {
            $term = Term::create([
              'vid' => $categories_vocabulary,
              'langcode' => 'en',
              'name' => trim($tag),
              'weight' => -1,
              'parent' => [0],
            ]);

            $inserted_or_updated = $term->save();
            $multiple_tids[] = $term->id();

            // Now relate the user as author of the term.
            $conn = Database::getConnection();
            $conn->insert('taxonomy_term__field_author')
              ->fields([
                'bundle' => $categories_vocabulary,
                'deleted' => 0,
                'entity_id' => $term->id(),
                'revision_id' => $term->id(),
                'langcode' => "en",
                'delta' => 0,
                'field_author_target_id' => \Drupal::currentUser()->id(),
              ])->execute();
          }
          else {
            $multiple_tids[] = array_search($tag, $termTagsName);
          }
        }

        $node->set('field_tags', array_unique($multiple_tids));
        $node->save();
      }

      $context['results']['node'] = $node;
    }

    \Drupal::messenger()->addStatus('Performed action Add Tag on ' . count($content_id) . ' item(s).', TRUE);
  }

  /**
   * Add Move Content Method.
   */
  public function addMoveContent($content_id, $action_item, $form_state) {

    $context['message'] = t('Moving contents');
    $from_community_id = $_SESSION['gid'];
    $to_community_id = $this->string_between_two_string($form_state->getValue('communities_list'), '(', ')');

    $group = Group::load($to_community_id);

    if (isset($content_id) && $action_item = "Move Content") {
      $context['message'] = t('Performing mass operation on Move Content to Other Community');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      foreach ($content_id as $nid) {
        // If (str_contains($nid->type, 'group_node')) {
        // addGroupContent(NodeInterface $node, Group $group)
        $node = Node::load($nid);
        // @todo Check if group plugin id exists.
        $plugin_id = 'group_node:' . ($node) ? $node->bundle() : NULL;
        // Checking if content exist in community 1.
        $group_contents = GroupContent::loadByEntity($node);

        if (($group_contents = GroupContent::loadByEntity($node)) && !empty($group_contents)) {
          $group->addContent($node, $plugin_id, ['uid' => $node->getOwnerId()]);
        }

        // removeGroupContent(NodeInterface $node, Group $group)
        $removeFromGroup = Group::load($from_community_id);
        // Try to load group content from entity.
        if (($group_contents = GroupContent::loadByEntity($node)) && !empty($group_contents)) {
          /** @var @param \Drupal\group\Entity\GroupContent $group_content */
          foreach ($group_contents as $group_content) {
            if ($removeFromGroup->id() === $group_content->getGroup()->id()) {
              $group_content->delete();
            }
          }
        }

        // }
      }
    }

    $gid = $_SESSION['gid'];

    \Drupal::messenger()->addStatus('Performed action Move To Other Community on ' . count($content_id) . ' item(s).', TRUE);
  }

  /**
   * Merge communities finished.
   */
  public function mass_operation_finished($success, $results, $operations) {

    // $results['node']->save();
    $response = new RedirectResponse("/");
    $response->send();
    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    \Drupal::messenger()->addStatus('Performed action Add Tag on ' . count($results['content_id']) . ' item(s).', TRUE);
    \Drupal::logger('custom_group_features_link_block')->error('Performing mass operation has been completed.');
  }

  /**
   * Submitting the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $operations = [];

    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];

    if ($action_item == "Add Tags") {
      $this->addTagsBatch($content_id, $action_item, $form_state);
    }

    if ($action_item == "Move Content") {
      $this->addMoveContent($content_id, $action_item, $form_state);
    }

    if ($action_item == "Change Submitter") {
      $this->changeSubmitterContent($content_id, $action_item, $form_state);
    }

    // $this->addTagsBatch($content_id, $action_item, $form_state);
    // $batch_builder = new BatchBuilder();
    // $batch_builder->setTitle(t('Mass Operations'))
    // ->addOperation($this->addTagsBatch($this->content_id, $this->action_item), [])
    // ->setFinishCallback($this->mass_operation_finished());
    // batch_set($batch_builder->toArray());
    // print_r($content_id);
    // print_r($action_item);
    // echo "<pre/>";
    // print_r($content_id);
    // die();
    $gid = $_SESSION['gid'];

    $response = new RedirectResponse("/group/" . $gid . "/manage-content");
    $response->send();
    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    unset($_SESSION['gid']);
  }

}
