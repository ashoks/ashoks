<?php

namespace Drupal\custom_group_features_link_block\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 *
 */
class CustomCommConfirmationForm extends ConfigFormBase {

  protected $step = 1;

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
  }

  /**
   * {@inheritdoc}
   */
  public function getFormID() {
    return 'group_contet_public_group-group_membership_edit_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);

    $config = $this->config('multi_step.multi_step_form_config');

    if ($this->step == 1) {
      $form['group_roles']['widget']['#title'] = t('Community Roles');
      $form['group_roles']['public_group-group_admin'] = [
        '#type' => 'checkboxes',
        '#title' => $this->t('Body Style'),
        '#description' => $this->t(''),
        '#options' => ['Coupe', 'Sedan', 'Convertible', 'Hatchbac', 'Station wagon', 'SUV', 'Minivan', 'Full-size van', 'Pick-up'],
        '#default_value' => $config->get('body_style'),
      ];
    }

    if ($this->step == 2) {
      $form['body_style'] = [
        '#type' => 'checkboxes',
        '#title' => $this->t('Body Style'),
        '#description' => $this->t(''),
        '#options' => ['Coupe', 'Sedan', 'Convertible', 'Hatchbac', 'Station wagon', 'SUV', 'Minivan', 'Full-size van', 'Pick-up'],
        '#default_value' => $config->get('body_style'),
      ];
    }

    if ($this->step == 3) {
      $form['gas_mileage'] = [
        '#type' => 'radios',
        '#title' => $this->t('Gas Mileage'),
        '#description' => $this->t(''),
        '#options' => ['20 mpg or less', '21 mpg or more', '26 mpg or more', '31 mpg or more', '36 mpg or more', '41 mpg or more'],
        '#default_value' => $config->get('gas_mileage'),
      ];
    }

    if ($this->step < 3) {
      $button_label = $this->t('Next');
    }
    else {
      $button_label = $this->t('Find a Car');
    }
    $form['actions']['submit']['#value'] = $button_label;

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    return parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    if ($this->step < 3) {
      $form_state->setRebuild();
      $this->step++;
    }
    else {
      parent::submitForm($form, $form_state);

      /*$this->config('multi_step.multi_step_form_config')
      ->set('model', $form_state->getValue('model'))
      ->set('body_style', $form_state->getValue('body_style'))
      ->set('gas_mileage', $form_state->getValue('gas_mileage'))
      ->save();*/
    }
  }

}
