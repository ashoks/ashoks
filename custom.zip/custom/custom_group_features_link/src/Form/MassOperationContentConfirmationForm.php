<?php

namespace Drupal\custom_group_features_link_block\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupContent;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Implementing a ajax form.
 */
class MassOperationContentConfirmationForm extends ConfigFormBase {

  protected $step = 1;

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mass_operation_add_tags_confirmation_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    // Collection of all nodes which are selected.
    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];
    $form = parent::buildForm($form, $form_state);

    $form['content_id'] = [
      '#type' => 'hidden',
      '#value' => $content_id,
      '#prefix' => '',
    ];

    switch ($action_item) {
      case "Add Tags":
        if ($this->step == 1) {
          $form['field_tags'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Enter the tags you want to add to selected items.'),
            '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
            '#suffix' => '</div>',
            '#description' => t('* Use comma as a separator between values'),
            '#autocomplete_route_name' => 'custom_group_features_link_block.autocomplete',
          ];
        }
        if ($this->step == 2) {
          $field_tags = $form_state->getValue('field_tags');

          $form['table_head'] = [
            '#markup' => '<div>Tag(s) ' . $field_tags . ' will be added to following items.</div>
          <table class="vbo-table table table-hover table-striped">
          <thead>
          <tr>
          <th class="views-field views-field-title">Content Title</th>
          </tr>
          </thead>
                                <tbody>',
          ];

          foreach ($content_id as $nid) {
            $node = Node::load($nid);
            // $node_url = Url::fromRoute('entity.node.canonical', ['node' => $this->nid]);
            $user = User::load($node->get('field_author')->getValue()[0]['target_id']);
            $dateFormat = date('d F Y', $node->getCreatedTime());
            $author = ($user->getDisplayName()) ? $user->getDisplayName() : "Anonymous";
            $form['table_row'][$nid] = [
              '#markup' => '<tr class="odd views-row-first">
                                      <td class="views-field views-field-title">' . $node->getTitle() . '</td>
                                    </tr>',
            ];
          }
          $form['table_footer'] = [
            '#markup' => '</tbody>
                                 </table>',
          ];
        }
        break;

      case "Move Content":
        if ($this->step == 1) {
          $form['communities_list'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Enter name of community to which you want to move selected items.'),
            '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
            '#suffix' => '</div>',
            '#description' => t('* Please note that the items will actually be moved to the new community. They will not show up anymore in the original community.'),
            '#autocomplete_route_name' => 'custom_group_features_link_block.community_list_autocomplete',
          ];
        }
        if ($this->step == 2) {
          $communities_list = $form_state->getValue('communities_list');

          $form['table_head'] = [
            '#markup' => '<div>Following items will be moved to community ' . $communities_list . '</div>
              <table class="vbo-table table table-hover table-striped">
              <thead>
              <tr>
              <th class="views-field views-field-title">Content Title</th>
              </tr>
              </thead>
                                        <tbody>',
          ];

          foreach ($content_id as $nid) {
            $node = Node::load($nid);
            // $node_url = Url::fromRoute('entity.node.canonical', ['node' => $this->nid]);
            $user = User::load($node->get('field_author')->getValue()[0]['target_id']);
            $dateFormat = date('d F Y', $node->getCreatedTime());
            $author = ($user->getDisplayName()) ? $user->getDisplayName() : "Anonymous";
            $form['table_row'][$nid] = [
              '#markup' => '<tr class="odd views-row-first">
                                              <td class="views-field views-field-title">' . $node->getTitle() . '</td>
                                            </tr>',
            ];
          }
          $form['table_footer'] = [
            '#markup' => '</tbody>
                                         </table>',
          ];
        }
        break;

      case "Change Submitter":
        if ($this->step == 1) {

          $form['field_author'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Enter new submitter\'s name for selected items.'),
            '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
            '#suffix' => '</div>',
            '#autocomplete_route_name' => 'custom_group_features_link_block.get_submitter_autocomplete',
          ];
        }
        if ($this->step == 2) {
          $field_author = $form_state->getValue('field_author');

          $form['table_head'] = [
            '#markup' => '<div>User ' . $field_author . ' will become submitter for following items</div>
              <table class="vbo-table table table-hover table-striped">
              <thead>
              <tr>
              <th class="views-field views-field-title">Content Title</th>
              </tr>
              </thead>
                                        <tbody>',
          ];

          foreach ($content_id as $nid) {
            $node = Node::load($nid);
            // $node_url = Url::fromRoute('entity.node.canonical', ['node' => $this->nid]);
            $user = User::load($node->get('field_author')->getValue()[0]['target_id']);
            $dateFormat = date('d F Y', $node->getCreatedTime());
            $author = ($user->getDisplayName()) ? $user->getDisplayName() : "Anonymous";
            $form['table_row'][$nid] = [
              '#markup' => '<tr class="odd views-row-first">
                                              <td class="views-field views-field-title">' . $node->getTitle() . '</td>
                                            </tr>',
            ];
          }
          $form['table_footer'] = [
            '#markup' => '</tbody>
                                        </table>',
          ];
        }

        break;
    }

    $form['actions']['#type'] = 'actions';

    if ($this->step == 1) {
      $button_label = $this->t('Next');
      $form['actions']['cancel'] = [
        '#type' => 'link',
        '#title' => $this->t('Cancel'),
        '#attributes' => [
          'class' => ['btn btn-md pull-left'],
        ],
        '#weight' => 0,
        '#url' => Url::fromRoute('view.mass_operation.page_group_manage_content', ['group' => $_SESSION['gid']]),
      ];
    }
    if ($this->step == 2) {
      $button_label = $this->t('Confirm');
      $form['actions']['cancel'] = [
        '#type' => 'link',
        '#title' => $this->t('Cancel'),
        '#attributes' => [
          'class' => ['btn btn-md  pull-left'],
        ],
        '#weight' => 0,
        '#url' => Url::fromRoute('view.mass_operation.page_group_manage_content', ['group' => $_SESSION['gid']]),
      ];
    }

    $form['actions']['submit']['#value'] = $button_label;

    return $form;
  }

  /**
   *
   */
  public function string_between_two_string($str, $starting_word, $ending_word) {
    $subtring_start = strpos($str, $starting_word);
    // Adding the starting index of the starting word to
    // its length would give its ending index.
    $subtring_start += strlen($starting_word);
    // Length of our required sub string.
    $size = strpos($str, $ending_word, $subtring_start) - $subtring_start;
    // Return the substring from the index substring_start of length size.
    return substr($str, $subtring_start, $size);
  }

  /**
   * Change Submitter Content Method.
   */
  public function changeSubmitterContent($content_id, $action_item, $form_state) {

    $author = $form_state->getValue('field_author');
    $explode_author = explode("[", $author);
    $author_id = rtrim($explode_author[2], "]");
    if (isset($content_id) && $action_item = "Change Submitter") {
      $context['message'] = t('Performed action on Change Submitter');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      $account = User::load($author_id);
      $user_id = \Drupal::currentUser()->id();
      $email = $account->getEmail();
      $firstname = $account->field_name_first->getValue()[0]['value'];
      $lastname = $account->field_name_last->getValue()[0]['value'];
      $realname = $firstname . ' ' . strtoupper($lastname);
      $default_value = $realname . '[' . $email . '][' . $author_id . ']';

      foreach ($content_id as $nid) {
        $node = Node::load($nid);
        $node->set('field_dummy_submitter', $default_value);
        $node->save();
      }

      $context['results']['node'] = $node;
    }

    $_SESSION['message'] = 'Performed action Change Submitter on ' . count($content_id) . ' item(s).';
  }

  /**
   * Add Tags Batch Method.
   */
  public function addTagsBatch($content_id, $action_item, $form_state) {

    if (isset($content_id) && $action_item = "Add Tags") {
      $context['message'] = t('Performing mass operation on Add Tags');
      $context['results']['content_id'] = $content_id;
      $context['results']['action_item'] = $action_item;

      foreach ($content_id as $nid) {

        $specialCheck = explode(",", trim($form_state->getValue('field_tags')));
        $specialCheckTrimmed = array_map('trim', $specialCheck);
        $term_value_exp = array_filter($specialCheckTrimmed);

        if (count($term_value_exp) > 0) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
          $term_objects = $node->get('field_tags')->referencedEntities();

          $term_labels = [];
          $multiple_tids = [];
          $tags = '';
          foreach ($term_objects as $term_object) {
            // The id of the term.
            $term_object->id();
            // The term title.
            $term_object->label();
            // Build an array of term labels.
            $term_labels[] = $term_object->label();
            $tags .= $term_object->label() . ',';
          }

          $arrayTags = explode(",", $tags);

          // New code starts here.
          $vid = 'tags';
          // $term_value_exp = explode(",", $form_state->getValue('field_tags'));
          $multiple_tids = [];
          foreach ($term_value_exp as $key => $term_value) {

            if (in_array(strtolower($term_value), array_map("strtolower", $term_labels))) {
              // Do something.
              unset($term_value_exp[$key]);
            }

            $storage = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
            $terms = $storage->loadByProperties([
              'name' => $term_value,
              'vid' => $vid,
            ]);

            if ($terms) {
              // Only use the first term returned; there should only be one anyways if we do this right.
              $term = reset($terms);
            }
            else {
              $term = Term::create([
                'name' => $term_value,
                'vid' => $vid,
              ]);
              $term->save();
            }
            $tid = $term->id();

            // All the term id which is created or which has tid should be added in author table.
            $query = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
            $query->fields('gcf', ['field_author_target_id', 'deleted']);
            $query->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
            $query->condition('gcf.entity_id', $tid);
            $query->condition('gcf.node_id', $nid);
            $query->condition('gcf.deleted', 0);
            $result = $query->execute()->fetchAll();

            if (!$result) {
              // Now relate the user as author of the term.
              $conn = Database::getConnection();
              $conn->insert('taxonomy_term__field_author')
                ->fields([
                  'bundle' => $vid,
                  'deleted' => 0,
                  'entity_id' => $tid,
                  'revision_id' => $tid,
                  'langcode' => "en",
                  'delta' => 0,
                  'field_author_target_id' => \Drupal::currentUser()->id(),
                  'node_id' => $nid,
                ])->execute();

            }

            // Handling comma seperated case ends here.
            $existingTags = \Drupal::service('entity_type.manager')
              ->getStorage("taxonomy_term")
              ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);

            $termTagsId = [];
            $termTagsName = [];
            foreach ($existingTags as $key => $term) {
              $termTagsName[$term->tid] = $term->name;
            }

            // New code ends here.
            foreach ($arrayTags as $tag) {

              $categories_vocabulary = 'tags';
              // print_r(!in_array($tag, $termTagsName));.
              if (!in_array($tag, $termTagsName)) {
                $multiple_tids[] = $tid;
              }
              else {
                $multiple_tids[] = array_search($tag, $termTagsName);
              }
            }

          }

          $node->set('field_tags', array_unique($multiple_tids));
          $node->save();

        }
      }
      $context['results']['node'] = $node;
    }

    $_SESSION['message'] = 'Performed action Add Tag on ' . count($content_id) . ' item(s).';

  }

  /**
   * Add Move Content Method.
   */
  public function addMoveContent($content_id, $action_item, $form_state) {

    $context['message'] = t('Moving contents');
    $from_community_id = $_SESSION['gid'];
    $to_community_id = $this->string_between_two_string($form_state->getValue('communities_list'), '(', ')');

    $group = Group::load($to_community_id);

    if ($from_community_id == $to_community_id) {
      $_SESSION['message'] = 'Performed action Move To Other Community on ' . count($content_id) . ' item(s)';
    }
    else {
      if (isset($content_id) && $action_item = "Move Content") {
        $context['message'] = t('Performing mass operation on Move Content to Other Community');
        $context['results']['content_id'] = $content_id;
        $context['results']['action_item'] = $action_item;

        foreach ($content_id as $nid) {
          // If (str_contains($nid->type, 'group_node')) {
          // addGroupContent(NodeInterface $node, Group $group)
          $node = Node::load($nid);
          // @todo Check if group plugin id exists.
          $plugin_id = "";
          if ($node instanceof NodeInterface) {
            $plugin_id = 'group_node:' . $node->bundle();
          }
          // Checking if content exist in community 1.
          $group_contents = GroupContent::loadByEntity($node);

          if (($group_contents = GroupContent::loadByEntity($node)) && !empty($group_contents)) {
            $group->addContent($node, $plugin_id, ['uid' => $node->getOwnerId()]);
            $node->set('changed', time());
            $node->save();
          }

          // removeGroupContent(NodeInterface $node, Group $group)
          $removeFromGroup = Group::load($from_community_id);
          // Try to load group content from entity.
          if (($group_contents = GroupContent::loadByEntity($node)) && !empty($group_contents)) {
            /** @var @param \Drupal\group\Entity\GroupContent $group_content */
            foreach ($group_contents as $group_content) {
              if ($removeFromGroup->id() === $group_content->getGroup()->id()) {
                $group_content->delete();
              }
            }
          }

          // }
        }
      }
    }

    $gid = $_SESSION['gid'];

    $_SESSION['message'] = 'Performed action Move To Other Community on ' . count($content_id) . ' item(s)';
  }

  /**
   * Merge communities finished.
   */
  public function mass_operation_finished($success, $results, $operations) {

    // $results['node']->save();
    $response = new RedirectResponse("/");
    $response->send();
    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    \Drupal::messenger()->addStatus('Performed action Add Tag on ' . count($results['content_id']) . ' item(s).', TRUE);
    \Drupal::logger('custom_group_features_link_block')->error('Performing mass operation has been completed.');
  }

  /**
   * Submitting the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $content_id = unserialize($_SESSION['content_id']);
    $action_item = $_SESSION['action_item'];

    if ($this->step < 2) {
      $form_state->setRebuild();
      $this->step++;

      $operations = [];

      if ($action_item == "Add Tags") {
        $this->addTagsBatch($content_id, $action_item, $form_state);
      }

      if ($action_item == "Move Content") {
        $this->addMoveContent($content_id, $action_item, $form_state);
      }

      if ($action_item == "Change Submitter") {
        $this->changeSubmitterContent($content_id, $action_item, $form_state);
      }
    }
    else {
      parent::submitForm($form, $form_state);
      $gid = $_SESSION['gid'];

      \Drupal::messenger()->addStatus($_SESSION['message'], TRUE);
      $response = new RedirectResponse("/group/" . $gid . "/manage-content");
      $response->send();
      unset($_SESSION['content_id']);
      unset($_SESSION['action_item']);
      unset($_SESSION['gid']);
      unset($_SESSION['message']);
    }

    // $this->addTagsBatch($content_id, $action_item, $form_state);
    // $batch_builder = new BatchBuilder();
    // $batch_builder->setTitle(t('Mass Operations'))
    // ->addOperation($this->addTagsBatch($this->content_id, $this->action_item), [])
    // ->setFinishCallback($this->mass_operation_finished());
    // batch_set($batch_builder->toArray());
  }

}
