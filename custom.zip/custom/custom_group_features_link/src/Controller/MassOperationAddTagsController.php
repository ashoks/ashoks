<?php

namespace Drupal\custom_group_features_link_block\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\group\Entity\Group;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Defines a route controller for watches autocomplete form elements.
 */
class MassOperationAddTagsController extends ControllerBase {

  /**
   * The node storage.
   *
   * @var \Drupal\node\NodeStorage
   */
  protected $nodeStorage;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->nodeStroage = $entity_type_manager->getStorage('node');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
          $container->get('entity_type.manager')
      );
  }

  /**
   * Handler for autocomplete request.
   */
  public function renderTags(Request $request) {

    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    // $existingTags = \Drupal::service('entity_type.manager')
    // ->getStorage("taxonomy_term")
    // ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);
    $query = \Drupal::database()->select('taxonomy_term_field_data', 'ttfd');
    $query->addField('ttfd', 'name', 'name');
    $query->addField('ttfd', 'tid', 'tid');
    $query->condition('ttfd.vid', 'tags');
    $query->condition('ttfd.name', '%' . $input . '%', 'LIKE');
    $query->groupBy('ttfd.name');
    $query->range(0, 10);
    $existingTags = $query->execute()->fetchAll();

    // $existingTags = ($existingTags) ? $existingTags : [];
    $termTagsName = [];

    foreach ($existingTags as $key => $term) {
      $termTagsName = [$term->name];
      $values[] = [
        'label' => implode(' ', $termTagsName),
      ];
    }

    return new JsonResponse($values);
  }

  /**
   * Handler for autocomplete request.
   */
  public function renderCommunityList(Request $request) {
    $gid = $_SESSION['gid'];
    $group = Group::load($gid);
    $com_type = $group->get('field_community_type')->value;
    $current_user = \Drupal::currentUser()->id();
    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    // $existingTags = \Drupal::service('entity_type.manager')
    // ->getStorage("taxonomy_term")
    // ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);
    $query = \Drupal::database()->select('groups_field_data', 'ttfd');
    $query->join('group_content_field_data', 'gc', 'ttfd.id = gc.gid');
    $query->join('group__field_community_type', 'ct', 'ttfd.id = ct.entity_id');
    $query->addField('ttfd', 'label', 'label');
    $query->addField('ttfd', 'id', 'id');
    $query->condition('ttfd.label', '%' . $input . '%', 'LIKE');
    $query->condition('gc.uid', $current_user);
    $query->condition('ct.field_community_type_value', $com_type);
    $query->groupBy('ttfd.label');
    $query->range(0, 10);
    $existingGroups = $query->execute()->fetchAll();

    // $existingTags = ($existingTags) ? $existingTags : [];
    $values = [];
    foreach ($existingGroups as $result) {
      $label = [
        $result->label, '(' . $result->id . ')',
      ];
      $values[] = [
        'label' => implode(' ', $label),
      ];
    }

    return new JsonResponse($values);
    unset($_SESSION['gid']);
  }

  /**
   * Handler for autocomplete request.
   */
  public function renderSubmitterList(Request $request) {
    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);

    $query = \Drupal::database()->select('users_field_data', 'ufd');
    $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
    $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
    $query->addField('f', 'field_name_first_value', 'firstname');
    $query->addField('l', 'field_name_last_value', 'lastname');
    $query->addField('ufd', 'uid', 'id');
    $query->addField('ufd', 'mail', 'email');
    $query->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q OR ufd.mail LIKE :q", [':q' => '%' . $input . '%']);
    $results = $query->execute()->fetchAll();
    $values = [];
    foreach ($results as $result) {
      $label = [
        $result->firstname . ' ' . strtoupper($result->lastname), '[' . $result->email . ']', '[' . $result->id . ']',
      ];
      $values[] = [
        'label' => implode(' ', $label),
      ];
    }

    return new JsonResponse($values);
  }

  /**
   *
   */
  public function removeTags($term_id, $entity_id) {

    // If ($term = Term::load($term_id)) {
    //     $term->delete();
    // }
    $deletedTerm = \Drupal::database()->delete('node__field_tags')
      ->condition('field_tags_target_id ', $term_id)
      ->condition('entity_id ', $entity_id)
      ->execute();

    $deletedTermRev = \Drupal::database()->delete('node_revision__field_tags')
      ->condition('field_tags_target_id ', $term_id)
      ->condition('entity_id ', $entity_id)
      ->execute();

    if ($deletedTerm && $deletedTermRev) {
      \Drupal::service('cache.data')->invalidateAll();
      \Drupal::service('cache.entity')->invalidateAll();
    }

    $response = new AjaxResponse();
    $response->addCommand(
          new HtmlCommand(
              '#alltag-' . $term_id,
              ''
          ),
      );
    $response->addCommand(
          new HtmlCommand(
              '#mytag-' . $term_id,
              ''
          ),
      );
    return $response;
  }

}
