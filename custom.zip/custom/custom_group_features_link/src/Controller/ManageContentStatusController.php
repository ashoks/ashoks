<?php

namespace Drupal\custom_group_features_link_block\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Manage Content Status Controller class.
 */
class ManageContentStatusController extends ControllerBase {

  /**
   * Callback for changing the content status.
   */
  public function changeStatus($gid, $content_status) {

    // print_r($gid);
    // print_r($content_status);
    return [
      '#theme' => 'manage_content_status',
      '#gid' => $gid,
      '#content_status' => $content_status,
    ];
  }

}
