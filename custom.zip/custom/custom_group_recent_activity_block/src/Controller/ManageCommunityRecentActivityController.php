<?php

namespace Drupal\custom_group_recent_activity_block\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\NodeInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\GroupInterface;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\content_moderation\Entity\ContentModerationState;

/**
 * Manage Content Status Controller class.
 */
class ManageCommunityRecentActivityController extends ControllerBase
{

  /**
   * Callback for changing the Recent Activities.
   */
  public function getRecentCommunityActivity($group) {
    // Clear cache for the block.
    \Drupal::service('cache.render')->invalidateAll();
    
    $gid = $group;
    if(empty($gid)){
      $route_name = \Drupal::routeMatch()->getRouteName();
      if($route_name == 'node.add'){
          $gid = \Drupal::request()->get('community_id');
      }
    }
    $group = \Drupal\group\Entity\Group::load($gid);
    if ($group instanceof GroupInterface) {
      $commtype = $group->getGroupType()->id();
      $field_community_type = $group->get('field_community_type')->value;
    }


    if($field_community_type == 3){
	    $type_ko = "reference";
      $gnode_type = 'group_node:reference';
      $gnode_type_news = 'group_node:news';
      $gnode_type_event = 'group_node:event';
      $gnode_type_page = 'group_node:pages';

      $gnode_types = [
      $gnode_type,
      $gnode_type_news,
      $gnode_type_event,
      $gnode_type_page
      ];
    // Only data related to reference will be fetched here
      $query_ref = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
      FROM (
      SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
      FROM {node_field_data} 
      UNION ALL 
      SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
      FROM {comment_field_data}
      ) c 
      WHERE entity_id IN (
      SELECT entity_id 
      FROM {group_relationship_field_data} 
      WHERE gid = :gid AND plugin_id IN (:gnode_types[])
      ) 
      GROUP BY id 
      ORDER BY changed DESC 
      LIMIT 100";

      $result = \Drupal::database()->query($query_ref, [
      ':gid' => $gid,
      ':gnode_types[]' => $gnode_types,
      ])->fetchAll();
      
 
    } else {      
      $type_ko = "asset";
      $gnode_type = 'group_node:asset';
      $gnode_type_news = 'group_node:news';
      $gnode_type_event = 'group_node:event';
      $gnode_type_page = 'group_node:pages';

      $gnode_types = [
      $gnode_type,
      $gnode_type_news,
      $gnode_type_event,
      $gnode_type_page
      ];
      // Only data related to asset will be fetched here
      $query_asset = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
      FROM (
      SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
      FROM {node_field_data} 
      UNION ALL 
      SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
      FROM {comment_field_data}
      ) c 
      WHERE entity_id IN (
      SELECT entity_id 
      FROM {group_relationship_field_data} 
      WHERE gid = :gid AND plugin_id IN (:gnode_types[])
      ) 
      GROUP BY id 
      ORDER BY changed DESC 
      LIMIT 100";

    $result = \Drupal::database()->query($query_asset, [
    ':gid' => $gid,
    ':gnode_types[]' => $gnode_types,
    ])->fetchAll();         
    }

    $merged_array_data = [];
    foreach($result as $key => $value){
      $node_type = $value->ntype;
      $node_comment_id = $value->id;
      if($node_type == "asset" || $node_type == "reference" || $node_type == "news" || $node_type == "event" || $node_type == "pages")
      {

        $query = \Drupal::database()->select('node_field_data', 'nfd');
        $query->fields('nfd', array('nid', 'title', 'type', 'uid', 'changed'));
        $query->fields('gcfd', array('gid', 'label'));
        $query->innerJoin('group_relationship_field_data', 'gcfd', 'nfd.nid = gcfd.entity_id');
        $query->condition('nfd.nid', $node_comment_id);
        $query->condition('gcfd.gid', $gid);
        $merged_array_data[] = $query->execute()->fetchObject();

      }

      if($node_type == "comment")
      {

        $query_c = \Drupal::database()->select('comment_field_data', 'cfd');
        $query_c->fields('cfd', array('cid', 'comment_type', 'uid', 'entity_id', 'changed'));
        $query_c->fields('gcfd', array('gid', 'label'));
        $query_c->fields('nfd', array('nid', 'title', 'type', 'uid', 'changed'));
        $query_c->innerJoin('group_relationship_field_data', 'gcfd', 'cfd.entity_id = gcfd.entity_id');
        $query_c->innerJoin('node_field_data', 'nfd', 'cfd.entity_id = nfd.nid');
        $query_c->condition('cfd.cid', $node_comment_id);
        $query_c->condition('gcfd.gid', $gid);
        $merged_array_data[] = $query_c->execute()->fetchObject();
      }
    }

    // $merged_array_data = array_merge($result_node, $result_comment);

    $html_array_markup = [];    
    $uid = $user_email = $file_uri = $full_name = $group_label = $merged_array_rev_data_uid = $merged_array_comment_data_uid = '';
    // Lets catch the first 5 data
    $merged_array_data = array_filter($merged_array_data);
    foreach($merged_array_data as $key => $data){
      switch($data->type){
        case 'asset':
          $merged_array_data[$key]->type_ko = 'asset';
          break;
        case 'reference':
          $merged_array_data[$key]->type_ko = 'reference';
          break;
        case 'news':
          $merged_array_data[$key]->type_ko = 'news';
          break;
        case 'pages':
          $merged_array_data[$key]->type_ko = 'page';
          break;
        case 'event':
          $merged_array_data[$key]->type_ko = 'event';
          break;
      }

      if($data->nid){
        if(isset($data->cid) && !empty($data->cid)){
          $comment_query = \Drupal::database()->select('comment_field_data', 'cfd');
          $comment_query->fields('cfd', array('uid'));
          $comment_query->condition('cfd.cid', $data->cid);
          $merged_array_comment_data_uid = $comment_query->execute()->fetchObject();
        }
        else{
          $rev_query = \Drupal::database()->select('node_field_revision', 'nfr');
          $rev_query->fields('nfr', array('nid'));
          $rev_query->condition('nfr.nid', $data->nid);
          $merged_array_rev_data = $rev_query->countQuery()->execute()->fetchField();
          if($merged_array_rev_data != NULL){
            $merged_array_data[$key]->node_created_or_updated_status = $merged_array_rev_data;
            if($merged_array_rev_data > 1){
              $rev_query = \Drupal::database()->select('node_field_revision', 'nfr');
              $rev_query->fields('nfr', array('uid'));
              $rev_query->condition('nfr.nid', $data->nid);
              $rev_query->addExpression('MAX("changed")', 'changed');
              $merged_array_rev_data_uid = $rev_query->execute()->fetchObject();
            }
          }
        }
        if(is_object($merged_array_rev_data_uid)){
          $node_obj = \Drupal::entityTypeManager()->getStorage('node')->load($data->nid);
          $uid = ($node_obj->revision_uid->getValue()[0]['target_id']) ? $node_obj->revision_uid->getValue()[0]['target_id'] : '';
        }
        elseif(is_object($merged_array_comment_data_uid)) {
          $uid = $merged_array_comment_data_uid->uid;
        }
        else{
          $uid = $data->uid;
        }
      }

      if($uid) {
        $user = User::load($uid);
        $user_email = ($user instanceof \Drupal\user\UserInterface) ? $user->getEmail() : null;
        $merged_array_data[$key]->user_email = $user_email;

        $uid_picture_id_query = \Drupal::database()->select('user__user_picture', 'ufp');
        $uid_picture_id_query->fields('ufp', array('entity_id', 'user_picture_target_id'));
        $uid_picture_id_query->condition('ufp.entity_id', $uid, '=');
        $uid_picture_id_result = $uid_picture_id_query->execute()->fetchObject();

        // get the file path from user_picture_target_id
        if(isset($uid_picture_id_result->user_picture_target_id)){
          $query = \Drupal::database()->select('file_managed', 't')
          ->fields('t', ['fid', 'uri'])
          ->condition('t.fid', $uid_picture_id_result->user_picture_target_id);
          $result = $query->execute()->fetchObject();
          $file_uri = isset($result->uri) ? $result->uri : null;
          $merged_array_data[$key]->file_uri = $file_uri;
        }

        $user_name_query = \Drupal::database()->select('user__field_name_first', 'f');
        $user_name_query->innerJoin('user__field_name_last', 'l', 'l.entity_id = f.entity_id');
        $user_name_query->fields('f', ['field_name_first_value']);
        $user_name_query->fields('l', ['field_name_last_value']);
        $user_name_query->condition('f.entity_id', $uid);
        $result_uid = $user_name_query->execute()->fetchAll();
  
        if($result_uid != NULL && isset($result_uid[0])){
        $full_name = $result_uid[0]->field_name_first_value . ' ' .  $result_uid[0]->field_name_last_value;

        $merged_array_data[$key]->full_name = $full_name;
        }
        else{
          $merged_array_data[$key]->full_name = 'Anonymous';
        }
      }

      // Fetch group id and label
      $group = Group::load($gid);
      if ($group instanceof GroupInterface) {
        $group_label = $group->label();
      }
      $merged_array_data[$key]->group_label = $group_label;

      // Handle KO create / update case here
      if(isset($data->nid) && ($data->type == "asset" || $data->type == "news" || $data->type == "event" || $data->type == "pages" || $data->type == "reference" )){
        $node_id = $data->nid;
      }

      // Handle Comment create / update case here for all KOs
      if(isset($data->cid) && $data->comment_type == "comment" ){
        $node_id = $data->entity_id;

      }
      $node = Node::load($node_id);
      if ($node instanceof NodeInterface) {
        $node_label = $node->label();
      }
      $merged_array_data[$key]->node_id = $node_id;
      $merged_array_data[$key]->node_label = $node_label;
    }

    $build['page'] = [
      '#theme' => 'manage_recent_activity',
      '#merged_array_data' => $this->buildPager($merged_array_data, 20),
      '#cache' => [
        'max-age' => 0,
      ],
    ];

    // Create pager
    $build['pager'] = [
      '#type' => 'pager',
    ];
    return $build;
  }

    /**
   * Build custom pager.
   */
  private function buildPager($result, $limit = 20) {
    $total = count($result);
    // Initialize pager and gets current page.
    /* @var $pager_manager \Drupal\Core\Pager\PagerManagerInterface */
    $pager_manager = \Drupal::service('pager.manager');
    $current_page = $pager_manager->createPager($total, $limit)->getCurrentPage();
    // Split the items up into chunks:
    $chunks = array_chunk($result, $limit);
    // Get the items for our current page:
    return $chunks[$current_page];
  }

 
    public function getCacheMaxAge() {
      return 0;
    }
}
