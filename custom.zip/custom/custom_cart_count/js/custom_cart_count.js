(function ($, Drupal, once) {
  Drupal.behaviors.customCartCount = {

    attach: function (context, settings) {
      // Use jQuery's once function scoped to the context to ensure execution on every page and AJAX refresh.
      if ($('.counter-cls .cart-item', context).length) {
        // Start timing when the request begins
        
        // Perform the AJAX request when the cart count element is available in the DOM.
        $.ajax({
          url: '/cart/count',
          type: 'GET',
          success: function (data) {
            // Update the cart count in the HTML element.
            $('.counter-cls .cart-item', context).text(data.count);
            $('.path-view-cart .counter-cls', context).text(data.count);
            
            // End timing and log the total time taken for the request to complete.
          },
          error: function (error) {
            console.log('Error fetching cart count:', error);
            
            // End timing even if there's an error.
          }
        });
      }
    }
  };
})(jQuery, Drupal, once);
