<?php

namespace Drupal\custom_cart_count\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;

class CartController extends ControllerBase {
  
  public function getCartCount() {
    $user_id = \Drupal::currentUser()->id();
    $cart_count = 0;
    if (isset($_SESSION['reference_cart'])) {
      $cart_count = count($_SESSION['reference_cart']);
    }
    else {
    // Query to fetch cart data from the database.
      $cartData = \Drupal::database()->select('custom_cart_info', 'c')
        ->fields('c', ['cart_id'])
        ->condition('c.user_id', $user_id)
        ->condition('c.status', 0)
        ->range(0,200)//0  is offset and 200 is limit
        ->execute();
      
      $cart_db = [];
      foreach ($cartData as $data) {
        $cart_db[] = $data->cart_id;
      }      
      // Return the count of items in the cart.
      $cart_count = count($cart_db);
    }
    if ($cart_count > 200) {
      $cart_count = 200;
    }
    return new JsonResponse(['count' => $cart_count]);
  }
}
