<?php

namespace Drupal\custom_group_link_block\Plugin\Block;

use Drupal\node\NodeInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\GroupInterface;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\content_moderation\Entity\ContentModerationState;

/**
 * Provides a 'CustomGroupLinkBlock' block.
 *
 * @Block(
 *  id = "custom_group_link_block",
 *  admin_label = @Translation("User Features"),
 * )
 */
class CustomGroupLinkBlock extends BlockBase
{

  /**
   * Implements \Drupal\block\BlockBase::blockBuild().
   *
   * {@inheritdoc}
   */
    public function build()
    {

        $group = \Drupal::routeMatch()->getParameter('group');
        $group_publish_check = false;
        $account = \Drupal::currentUser();
        $state_name = $group_publish_check = $group_type = $state_name = $field_community_type = $is_published = '';
        if ($group instanceof GroupInterface) {
          /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
            $group_type = $group->getGroupType()->id();
            $gid = $group->id();
            $field_community_type = $group->get('field_community_type')->value;
            $group_type = $group->getGroupType()->id();
          // $group_publish_check = $group->isPublished();
          $mquery = \Drupal::database()->select('content_moderation_state_field_data', 'cmd');
          $mquery->fields('cmd', ['moderation_state']);
          $mquery->condition('cmd.content_entity_id', $gid);
          $mquery->condition('cmd.content_entity_type_id', 'group');
          $mresult = $mquery->execute()->fetchAll();
          if($mresult){
            $state_name = $mresult[0]->moderation_state;
            $group_publish_check = ($state_name == "unpublished") ? "Unpublished" : "Published";
          }
        }
        elseif(!empty($group)){
          $gid = $group;
          $query = \Drupal::database()->select('groups_field_data', 'gf');
          $query->join('content_moderation_state_field_data', 'cms', 'gf.id = cms.content_entity_id');
          $query->join('group__field_community_type', 'gct', 'gf.id = gct.entity_id');
          $query->fields('gf', ['type']);
          $query->fields('cms', ['moderation_state']);
          $query->fields('gct', ['field_community_type_value']);
          $query->condition('gf.id', $group);
          $result = $query->execute()->fetchAll();
          if($result){
            $group_type =  $result[0]->type;
            $state_name = $result[0]->moderation_state;
            $field_community_type = $result[0]->field_community_type_value;
          }

          $mquery = \Drupal::database()->select('content_moderation_state_field_data', 'cmd');
          $mquery->fields('cmd', ['moderation_state']);
          $mquery->condition('cmd.content_entity_id', $gid);
          $mquery->condition('cmd.content_entity_type_id', 'group');
          $mresult = $mquery->execute()->fetchAll();
          if($mresult){
            $state_name = $mresult[0]->moderation_state;
            $group_publish_check = ($state_name == "unpublished") ? "Unpublished" : "Published"; 
          }   
        }
         else {
            $nid = \Drupal::routeMatch()->getRawParameter('node');
            $route_name = \Drupal::routeMatch()->getRouteName();
            $node = ($nid)?Node::load($nid): null;

            $groupSocialId = (($node instanceof NodeInterface) && $node->hasField('field_community')) ? $node->get('field_community')->getValue()[0]['target_id'] : "";
            if ($groupSocialId) {
                $group = Group::load($groupSocialId);
                $group_type = ($group instanceof GroupInterface)?$group->getGroupType()->id():null;
                $gid = ($group instanceof GroupInterface)?$group->id():null;
                $field_community_type = ($group instanceof GroupInterface)?$group->get('field_community_type')->value:null;
                $group_type = ($group instanceof GroupInterface)?$group->getGroupType()->id():null;
								
              // $group_publish_check = $group->isPublished();
              $query = \Drupal::database()->select('content_moderation_state_field_data', 'cmd');
              $query->fields('cmd', ['moderation_state']);
              $query->condition('cmd.content_entity_id', $gid);
              $query->condition('cmd.content_entity_type_id', 'group');
              $result = $query->execute()->fetchAll();
              if($result){
                $state_name = $result[0]->moderation_state;
                $group_publish_check = ($state_name == "unpublished") ? "Unpublished" : "Published";  
              }   
            }
            if($route_name == 'view.publish_references.page_1'){
                $current_path = \Drupal::service('path.current')->getPath();
                $grp_id = explode("/",$current_path)[3];
                if(is_numeric($grp_id)){
                  $group = Group::load($grp_id);
                  $group_type = $group->getGroupType()->id();
                  $gid = $group->id();
                }
            }             
        }
        $user_id = \Drupal::currentUser()->id();

        $user = User::load(\Drupal::currentUser()->id());
        $roles = $user->getRoles();

      // Get the leader if the user is the creator of the group
      // In some cases gid is still blank then check group id from route.
        if (empty($gid)) {
            $current_path = \Drupal::service('path.current')->getPath();
            $path_args = explode('/', $current_path);
          // Array ( [0] => [1] => group [2] => 10 [3] => admin [4] => taxonomy [5] => community_taxonomy [6] => add )
          // Entity type = group $variables['build_info']['args'][0];.
            $gid = isset($path_args[2]) ? $path_args[2] : '';
        }

        if ($gid == "edit" || $gid == "add") {
            $gid = "";
        }
        if (empty($gid)) {
            $gid = $this->getCustomGroupId();
        }
        $request = \Drupal::service('request_stack')->getCurrentRequest();
        $current_url = $request->getRequestUri();
        if (strpos($current_url, '/views-bulk-operations/configure/mass_operation/page_1') !== FALSE || strpos($current_url, '/views-bulk-operations/confirm/mass_operation/page_1') !== FALSE) {
          $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
          $gid = $_SESSION['ccid'];
        }

        $group = ($gid)?Group::load($gid):null;
        // $group = \Drupal::routeMatch()->getParameter('group');
        if ($group instanceof GroupInterface) {
          /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
            $group_type = $group->getGroupType()->id();
            $gid = $group->id();
            $field_community_type = $group->get('field_community_type')->value;
        }
        if (empty($gid)) {
            $gid = \Drupal::request()->get('community_id');
        }

        if (empty($gid)) {
            $node = \Drupal::routeMatch()->getParameter('node');
            if ($node instanceof NodeInterface) {
                $group = ($node->hasField('field_community'))?$node->get('field_community')->getValue():null;
                $gid = $group[0]['target_id'];
            }
        }

      // $approved_roles = array('reference_manager_overall', 'moderator', 'can_log_in_admin');
        $attributes_user_feature = 0;
        if ($group instanceof Group) {
            $group_type = $group->getGroupType()->id();
						$is_published = $group->isPublished();
            $gid = $group->id();
            $field_community_type = $group->get('field_community_type')->value;
            $roles = $account->getRoles();
            $membergroup = $group->getMember($account);
            if ((($group->getGroupType()->id() == "secret_group") || ($group->getGroupType()->id() == "closed_group")) && (!$group->getMember($account) || $account->isAnonymous()) && !in_array("administrator", $roles)) {
              $attributes_user_feature = 1;
            }
        }

        // $group = \Drupal::routeMatch()->getParameter('group');
        $reference_manager = null;
        if ($group instanceof GroupInterface) {
            $account_id = \Drupal::currentUser()->id();
						$is_published = $group->isPublished();
            $member = $group->getMember($account);
            $rol = ($member) ? $member->getRoles() : [];
            $role_detail = array_keys($rol);
            $grp_type = $group->getGroupType()->id();
            $reference_manager = 0;
            $owner = $group->getOwner();
            if(isset($owner)){
              $uid = ($owner)?$owner->uid->getValue()[0]['value']:null;  
            }
            
           if($group_publish_check != 'Unpublished' || $uid == $account_id){
            if ((isset($rol[$group->bundle() . '-group_manager']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-moderator']) && isset($rol[$group->bundle() . '-group_admin'])) || (isset($rol[$group->bundle() . '-group_manager'])) || (isset($rol[$group->bundle() . '-moderator']))) {
                $reference_manager = 1;
            }
          }
        }

        // Get the leader if the user is the creator of the group.
        $approved_roles = ['reference_manager_overall', 'can_log_in_admin'];
        $route_name = \Drupal::routeMatch()->getRouteName();
        
        if (is_array($roles)) {
            if (in_array('administrator', $roles)) {
                return [
                '#theme' => 'custom_group_link_block',
                '#data' => $gid,
                '#user_id' => $user_id,
                '#feature_type' => $field_community_type,
                '#status' => $group_publish_check,
								'#is_published' => $is_published,
                '#cache' => [
                'max-age' => 0,
                ],
                ];
            } elseif (in_array("administrator", $roles) || ((count(array_intersect($roles, $approved_roles)) > 0) && ($reference_manager == 1))|| ($reference_manager == 1)) {
              return [
                '#theme' => 'custom_group_link_block',
                '#data' => $gid,
                '#user_id' => $user_id,
                '#feature_type' => $field_community_type,
                '#status' => $group_publish_check,
								'#is_published' => $is_published,
                '#cache' => [
                'max-age' => 0,
                ],
              ];
            } elseif ((($group_publish_check == "Published")  && ($group_type === "public_group"))) {
                return [
                '#theme' => 'custom_group_link_block',
                '#data' => $gid,
                '#user_id' => $user_id,
                '#feature_type' => $field_community_type,
                '#status' => $group_publish_check,
								'#is_published' => $is_published,
                '#cache' => [
                'max-age' => 0,
                ],
                ];
            } elseif (($group_publish_check == "Published") && ($attributes_user_feature == 0) && $membergroup) {
                return [
                '#theme' => 'custom_group_link_block',
                '#data' => $gid,
                '#user_id' => $user_id,
                '#feature_type' => $field_community_type,
                '#status' => $group_publish_check,
								'#is_published' => $is_published,
                '#cache' => [
                'max-age' => 0,
                ],
                ];
            }elseif (isset($rol) && $role_detail[0] == $group_type . '-member') {
            return [
            '#theme' => 'custom_group_link_block',
            '#data' => $gid,
            '#user_id' => $user_id,
            '#feature_type' => $field_community_type,
            '#status' => $group_publish_check,
						'#is_published' => $is_published,
            '#cache' => [
            'max-age' => 0,
            ],
            ];
        }elseif (isset($grp_type) && empty($member) && ($grp_type == 'public_group')) {
          return [
          '#theme' => 'custom_group_link_block',
          '#data' => $gid,
          '#user_id' => $user_id,
          '#feature_type' => $field_community_type,
          '#status' => $group_publish_check,
					'#is_published' => $is_published,
          '#cache' => [
          'max-age' => 0,
          ],
          ];
      } elseif ($route_name == 'node.add') {
              return [
              '#theme' => 'custom_group_link_block',
              '#data' => $gid,
              '#user_id' => $user_id,
              '#feature_type' => $field_community_type,
              '#status' => $group_publish_check,
							'#is_published' => $is_published,
              '#cache' => [
              'max-age' => 0,
              ],
              ];
          }else {
                return [];
            }
        }
    }

    /**
 * Prepares variables for group global id.
 */
public function getCustomGroupId(){
    $current_path = \Drupal::service('path.current')->getPath();
    $route_name = \Drupal::routeMatch()->getRouteName();
     
    $group = \Drupal::routeMatch()->getParameter('group');
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;
     
    }
    
  
     $group = \Drupal::routeMatch()->getParameter('gid');
     if ($group instanceof GroupInterface) {
       /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
       $group_type = $group->getGroupType()->id();
       $gid = $group->id();
       $field_community_type = $group->get('field_community_type')->value;
      
     }
  
    if($route_name == "custom_block.custom_yammer_display"){
      // $node = \Drupal::routeMatch()->getParameter('node');
      $current_path = \Drupal::service('path.current')->getPath();
      $gid = explode("/",$current_path)[2];
    }
  
     if(empty($gid)){
       $gid = \Drupal::request()->get('community_id');
     }
  
     
     if(empty($gid)){
     $node = \Drupal::routeMatch()->getParameter('node');
     if ($node instanceof \Drupal\node\NodeInterface) {
       $group = ($node->hasField('field_community'))?$node->get('field_community')->getValue():null;
       $gid = $group[0]['target_id'];
     }
    }
  
    if(empty($gid)){
      // $node = \Drupal::routeMatch()->getParameter('node');
      $current_path = \Drupal::service('path.current')->getPath();
      $nid = explode("/",$current_path)[2];
      $node = Node::load($nid);
      if ($node instanceof \Drupal\node\NodeInterface) {
        $group = ($node->hasField('field_community'))?$node->get('field_community')->getValue():null;
        $gid = $group[0]['target_id'];
      }
     }
  
    return $gid;
  }

  /**
   * check if member of group.
   */
    public function isMember($gid, $user_id)
    {

        $string = "group_membership";
        $query = \Drupal::database()->select('group_content_field_data', 'gcf');
        $query->fields('gcf', ['entity_id']);
        $query->condition('gcf.gid', $gid);
        $query->condition('gcf.entity_id', $user_id);
        $query->condition('gcf.type', "%" . $query->escapeLike($string) . "%", 'LIKE');
        $isMember = $query->execute()->fetchAll();

        return !empty($isMember) ? true : false;
    }
}
