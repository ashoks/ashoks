function export_content(groupid, type) {
    if (typeof groupid === 'undefined' || typeof type === 'undefined' ||
        (typeof groupid === 'string' && groupid != 'all')) {
        var message = '<div class="messages error"> <h2 class="element-invisible">Status message</h2> <ul>  <li class="message-item">Sorry, something goes wrong. Please contact site administrator.</li> </ul></div>';
        jQuery('#columns').prepend(message);
        window.scrollTo(0, 0);
    } else {
        console.log(drupalSettings.custom_export.base_url + 'export-content');

        jQuery.ajax({
            url: drupalSettings.custom_export.base_url + 'export-content',
            type: 'post',
            data: {
                gid: groupid,
                type: type,
            },
            success: function (data) {
                if(data.result !== 0) {
                    if(type == 'crp') {
                        sessionStorage.setItem('clear_cart_after_export', 1);
                        window.location.reload();
                    } else {
                        var message = '<div class="messages status"> <h2 class="element-invisible">Status message</h2> <ul>  <li class="message-item">It will take few minutes to export the file, based upon the amount of data to be exported. We will send the export file to you via mail as soon as the export is complete.</li> </ul></div>';
                    }
                }
                else { var message = '<div class="messages status"> <h2 class="element-invisible">Status message</h2> <ul>  <li class="message-item">Data is out of date. Please reload the page.</li> </ul></div>';
                }
                jQuery('#columns div.messages').each(function () {this.remove()});
                jQuery('#columns').prepend(message);
                jQuery("html, body").animate(
                  {
                    scrollTop: jQuery("#exportsuccess").offset().top - 50
                  },
                  2000 // Animation duration in milliseconds
                );
            },
            fail: function () {
                var message = '<div class="messages error"> <h2 class="element-invisible">Status message</h2> <ul>  <li class="message-item">Sorry, this feature is not working. Please contact site administrator.</li> </ul></div>';
                jQuery('#columns div.messages').each(function () {this.remove()});
                jQuery('#columns').prepend(message);
                jQuery("html, body").animate(
                    {
                      scrollTop: jQuery("#exportsuccess").offset().top - 50
                    },
                    2000 // Animation duration in milliseconds
                  );
            }
        });
    }
}
(function ($) {
  $(document).ready(function () {
		$('.export-link').on('click', function(){
			$("html, body").animate({ scrollTop: 0 }, "slow");
		});
        $('.export-link').on('contextmenu', function(e) {
            e.preventDefault(); // Prevents the default right-click context menu
        });
    
  });
})(jQuery);	