<?php

namespace Drupal\custom_export\Controller;

use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\ScrollTopCommand;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\user\Entity\User;
use Drupal\Core\Mail\MailManagerInterface;
use Drupal\Component\Utility\SafeMarkup;
use Drupal\Component\Utility\Html;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Session\AccountSwitcherInterface;
use Drupal\Core\Entity\EntityFieldManager;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\UserSession;

/**
 * Defines a route controller.
 */
class ExportController extends ControllerBase {
  /**
   * Retrieves the entity type manager.
   *
   * @return \Drupal\Core\Entity\EntityTypeManagerInterface
   *   The entity type manager.
   */
  public function getEntityTypeManager(): EntityTypeManagerInterface {
    if (!isset($this->entityTypeManager)) {
      $this->entityTypeManager = \Drupal::service('entity_type.manager');
    }
    return $this->entityTypeManager;
  }
  /**
   * Get the account switcher service.
   *
   * @return \Drupal\Core\Session\AccountSwitcherInterface
   *   The account switcher service.
   */
  public function getAccountSwitcher(): AccountSwitcherInterface {
    if (!isset($this->accountSwitcher)) {
      $this->accountSwitcher = \Drupal::service('account_switcher');
    }
    return $this->accountSwitcher;
  }
  /**
   * Database entry for KO exports.
   */
  public function content($gid, $type) {
    $user = User::load(\Drupal::currentUser()->id());
    $uid = $user->get('uid')->value;
    if ($gid && $type) {
      $connection = \Drupal::service('database');
      $query = $connection->insert('export_feature_log')
        ->fields(['uid', 'gid', 'type', 'timestamp', 'state'])
        ->values([
          'uid' => $uid,
          'gid' => $gid,
          'type' => $type,
          'timestamp' => \Drupal::time()->getRequestTime(),
          'state' => 0,
        ])
        ->execute();

      if ($query != 0 && !empty($query)) {
        $message = '<div class="alert alert-sm alert-success">It will take few minutes to export the file, based upon the amount of data to be exported. We will send the export file to you via mail as soon as the export is complete.</div>';
      }
      else {
        $message = '<div class="alert alert-sm alert-warning">Sorry, this feature is not working. Please contact site administrator.</div>';
      }

      $response = new AjaxResponse();
      $response->addCommand(
        new HtmlCommand(
          '#exportsuccess',
          $message),
      );
      $response->addCommand(new ScrollTopCommand('.sub-header'));
      return $response;
    }
  }

  /**
   * Database entry for Reference exports.
   */
  public function contentreference($gid, $type) {
    $user = User::load(\Drupal::currentUser()->id());
    $uid = $user->get('uid')->value;
    if ($gid && $type) {
      $connection = \Drupal::service('database');
      $query = $connection->insert('export_primary_secondary_log')
        ->fields(['state', 'uid', 'gid', 'timestamp'])
        ->values([
          'state' => 0,
          'uid' => $uid,
          'gid' => $gid,
          'timestamp' => \Drupal::time()->getRequestTime(),
        ])
        ->execute();
      if ($query != 0 && !empty($query)) {
        $message = '<div class="alert alert-sm alert-success">It will take few minutes to export the file, based upon the amount of data to be exported. We will send the export file to you via mail as soon as the export is complete.</div>';
      }
      else {
        $message = '<div class="alert alert-sm alert-warning">Sorry, this feature is not working. Please contact site administrator.</div>';
      }

      $response = new AjaxResponse();
      $response->addCommand(
        new HtmlCommand(
          '#exportsuccess',
          $message),
      );
      $response->addCommand(new ScrollTopCommand('.sub-header'));
      return $response;
    }
  }

  /**
   * Database entry for Attachments exports.
   */
  public function contentattachments($gid, $type) {
    $user = User::load(\Drupal::currentUser()->id());
    $uid = $user->get('uid')->value;
    $random = uniqid();
    if ($gid && $type) {

      $connection = \Drupal::service('database');

      $query = $connection->select('group_relationship_field_data', 'c');
      $query->join('node_field_data', 'n', 'c.entity_id = n.nid');
      $query->addField('c', 'entity_id', 'entity_id');
      $query->addField('n', 'type', 'type');
      $query->condition('n.status', 1);
      $query->condition('c.gid', $gid);
			$query->condition('c.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('c.plugin_id', '%group_invitation%' , 'NOT LIKE');
      $results = $query->execute()->fetchAllkeyed();
      
      $results_ref = $results_ref2 = $results_ko = $results_ko2 = '';
      if (count(array_keys($results)) >= 1) {
        foreach ($results as $nid => $ntype) {
          if ($ntype == 'reference' || $ntype == 'asset') {
            $query_ref = $connection->select('node__field_files', 'ff');
            $query_ref->join('paragraph__field_attachment', 'fa', 'ff.field_files_target_id = fa.entity_id');
            $query_ref->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
            $query_ref->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
            $query_ref->addField('ff', 'entity_id', 'entity_id');
            $query_ref->addField('fa', 'field_attachment_target_id', 'field_attachment_target_id');
            $query_ref->condition('o.gid', $gid);
            $query_ref->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
						$query_ref->condition('o.plugin_id', '%group_invitation%' , 'NOT LIKE');
            $query_ref->condition('pd.field_type_of_document_value', 0);
            $query_ref->condition('ff.bundle', $ntype, 'IN');
            $results_ref = $query_ref->execute()->fetchAll();
                 
            $query_ref2 = $connection->select('node__field_files', 'ff');
            $query_ref2->join('paragraph__field_link', 'fa', 'ff.field_files_target_id = fa.entity_id');
            $query_ref2->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
            $query_ref2->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
            $query_ref2->addField('ff', 'entity_id', 'entity_id');
            $query_ref2->addField('fa', 'entity_id', 'entity_id');
            $query_ref2->condition('o.gid', $gid);
            $query_ref2->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
						$query_ref2->condition('o.plugin_id', '%group_invitation%' , 'NOT LIKE');
            $query_ref2->condition('pd.field_type_of_document_value', 1);
            $query_ref2->condition('ff.bundle', $ntype, 'IN');
            $results_ref2 = $query_ref2->execute()->fetchAll();
      
             
                }
                else {
                  $query_ko = $connection->select('node__field_content_files', 'n');
                  $query_ko->join('paragraph__field_attachment', 'a', 'n.field_content_files_target_id = a.entity_id');
                  $query_ko->join('group_relationship_field_data', 'g', 'n.entity_id = g.entity_id');
                  $query_ko->addField('n', 'entity_id', 'entity_id');
                  $query_ko->addField('a', 'field_attachment_target_id', 'field_attachment_target_id');
                  $query_ko->condition('g.gid', $gid);
                  $query_ko->condition('g.plugin_id', '%group_membership%' , 'NOT LIKE');
									$query_ko->condition('g.plugin_id', '%group_invitation%' , 'NOT LIKE');
                  $results_ko = $query_ko->execute()->fetchAll();
      
                  $query_ko2 = $connection->select('paragraph__field_link', 'l');
                  $query_ko2->join('node__field_content_files', 'n', 'l.entity_id = n.field_content_files_target_id');
                  $query_ko2->join('group_relationship_field_data', 'g', 'n.entity_id = g.entity_id');
                  $query_ko2->addField('n', 'entity_id', 'entity_id');
                  $query_ko2->addField('l', 'entity_id', 'entity_id');
                  $query_ko2->condition('g.gid', $gid);
									$query_ko2->condition('g.plugin_id', '%group_membership%' , 'NOT LIKE');
									$query_ko2->condition('g.plugin_id', '%group_invitation%' , 'NOT LIKE');
                  $results_ko2 = $query_ko2->execute()->fetchAll();
                }
              }
              $files_array = $links_array = $ref_attachments = $ko_files_array = $ko_links_array = $ko_attachments = $filelist = [];
                foreach ($results_ref as $key => $value) {
                $entity_id = $value->entity_id;
                $file_id =   $value->field_attachment_target_id;
                $files_array[] = $entity_id . '-' . $file_id . 'R';
              }
              foreach ($results_ref2 as $key => $value) {
                 $entity_id = $value->entity_id;
                $file_id =   $value->fa_entity_id;
                $links_array[] = $entity_id . '-' . $file_id . 'RL';
              }
              $ref_attachments = array_merge($files_array, $links_array);
      
              foreach ($results_ko as $key => $value) {
                $entity_id = $value->entity_id;
                $file_id =   $value->field_attachment_target_id;
                $ko_files_array[] = $entity_id . '-' . $file_id;
              }
              foreach ($results_ko2 as $nid => $value) {
                $entity_id = $value->entity_id;
                $file_id =   $value->l_entity_id;
                $ko_links_array[] = $entity_id . '-' . $file_id . 'AL';
              }
              $ko_attachments = array_merge($ko_files_array, $ko_links_array);
            }
      
            $filelist = array_merge($ref_attachments, $ko_attachments);
            $filelist = implode(',', $filelist);
      
      

      $query = $connection->insert('export_cart_file_log')
        ->fields(['state', 'uid', 'gid', 'type', 'feature', 'nids', 'timestamp'])
        ->values([
          'state' => 0,
          'uid' => $uid,
          'gid' => $gid,
          'type' => $type,
          'feature' => $random,
          'nids' => $filelist,
          'timestamp' => \Drupal::time()->getRequestTime(),
        ])
        ->execute();
      if ($query != 0 && !empty($query)) {
        $message = '<div class="alert alert-sm alert-success">It will take few minutes to export the file, based upon the amount of data to be exported. We will send the export file to you via mail as soon as the export is complete.</div>';
      }
      else {
        $message = '<div class="alert alert-sm alert-warning">Sorry, this feature is not working. Please contact site administrator.</div>';
      }

      $response = new AjaxResponse();
      $response->addCommand(
        new HtmlCommand(
          '#exportsuccess',
          $message),
      );
      $response->addCommand(new ScrollTopCommand('.sub-header'));
      return $response;
    }
  }

  /**
   * Database entry for Cart exports.
   */
  public function contentcart() {
    $gid = null;
    $type = 'crp';
    $user = User::load(\Drupal::currentUser()->id());
    $uid = $user->get('uid')->value;
    $random = uniqid();
    $nids = $_SESSION['reference_cart'] ? implode(',',$_SESSION['reference_cart']) : '';
    //$nids = '65,66,29-608R';
    if ($nids != '') {
      $explode_nids = explode(',', $nids);
      foreach ($explode_nids as $nid) {
        $check_for_files = strpos($nid, '-');
        if ($check_for_files !== FALSE) {
          $file_nids .= $nid . ',';
        }
        else {
          $asset_or_reference_nid .= $nid . ',';
        }
      }
      $nids = rtrim($asset_or_reference_nid, ',');
      $file_nid = rtrim($file_nids, ',');
      $random = uniqid();
      $connection = \Drupal::service('database');

      if ($nids != '') {
        $query = $connection->insert('export_cart_log')
          ->fields(['state', 'uid', 'gid', 'type', 'feature', 'nids', 'timestamp'])
          ->values([
            'state' => 0,
            'uid' => $uid,
            'gid' => $gid,
            'type' => $type,
            'feature' => $random,
            'nids' => $nids,
            'timestamp' => \Drupal::time()->getRequestTime(),
          ])
          ->execute();
      }
      if ($file_nid != '') {
        $query = $connection->insert('export_cart_file_log')
          ->fields(['state', 'uid', 'gid', 'type', 'feature', 'nids', 'timestamp'])
          ->values([
            'state' => 0,
            'uid' => $uid,
            'gid' => $gid,
            'type' => $type,
            'feature' => $random,
            'nids' => $file_nid,
            'timestamp' => \Drupal::time()->getRequestTime(),
          ])
          ->execute();
      }

      if ($query != 0 && !empty($query)) {
        $message = '<div class="alert alert-sm alert-success">It will take few minutes to export the file, based upon the amount of data to be exported. We will send the export file to you via mail as soon as the export is complete.</div>';
      }
      else {
        $message = '<div class="alert alert-sm alert-warning">Sorry, this feature is not working. Please contact site administrator.</div>';
      }

      $response = new AjaxResponse();
      $response->addCommand(
        new HtmlCommand(
          '#exportcartsuccess',
          $message),
      );
      
      return $response;
    }
  }

  /**
   *
   */
  public function exporttoexcel() {
	global $base_url;
    $view = [
      'asset' => 'capgemini_browsing_widget_asset',
      'reference' => 'capgemini_browsing_widget_reference_secondary',
      'pages' => 'cap_group_books',
      'member' => 'export_cap_members',
    ];
    $object = [
      'asset' => 'Assets',
      'reference' => 'References',
      'pages' => 'Community Pages',
      'member' => 'Members',
    ];
    try {

      $db = \Drupal::service('database');
      $check_available_query = $db->query("SELECT state FROM {export_feature_log} WHERE state = 1 ORDER BY timestamp ASC LIMIT 1");
      $in_progress = $check_available_query->fetchField();
      if (!$in_progress) {
        $query = $db->query('SELECT gid, type, group_concat(uid) as uids, group_concat(timestamp) as export_time FROM {export_feature_log} WHERE state=0 GROUP BY gid, type ORDER BY timestamp ASC LIMIT 2');
        $items = $query->fetchAll();
        $type = $items[0]->type;
        $view_name = $view[$type];
        $display_id = 'data_export_3';
        $gid = $items[0]->gid;
        $uids = $items[0]->uids;
        $time = explode(',', $items[0]->export_time);
        $body = '';
        if(isset($gid) && $gid == 1){
					$subject = 'Export from PRISM - Capgemini Global community';
					$body = 'You requested an export  for Capgemini Global community. However, due to the very large size of this community, export file cannot be automatically generated. If you have good reason for requesting this export, please contact the KM3.0 moderation team (km3.0moderationteam.in@capgemini.com) and we will generate the export for you.</br> Thanks for your understanding.';
					$query = $db->query('SELECT uid, mail FROM {users_field_data} WHERE uid IN (' . $uids . ')');
					$target_users = $query->fetchAllKeyed();
					$mailManager = \Drupal::service('plugin.manager.mail');
					$module = 'custom_export';
					$key = 'community_export';
					$to = $target_users;
					$params['message'] = $body;
					$params['subject'] = $subject;
					$langcode = 'en';
					$send = true;
        
		      if(isset($receivers)){
            $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
          }
          if ($result['result'] != true) {
						$message = t('There was a problem sending your email notification to @email.', array('@email' => $to));
						\Drupal::messenger()->addError($message);
						//\Drupal::logger('mail-log')->error($message);
          }
					$message = t('An email notification has been sent to @email ', array('@email' => $to));
					\Drupal::messenger()->addStatus($message);
					//\Drupal::logger('mail-log')->notice($message);
					foreach ($target_users as $target_uid => $target_mail) {
						$message['to'] = $target_mail;
						$message = $system->format($message);
						$message_check = $system->mail($message);
						$state = 3;
						//update the state
						$num_updated = $db->update('export_feature_log')
							->fields([
                'state' => 3,
              ])
							->condition('gid', $gid, '=')
							->condition('type', $type, '=')
							->condition('uid', $target_uid, 'IN')
							->execute();
					}
				}
				else{
        $userids = explode(',', $uids);
        foreach ($userids as $key => $userid) {
          $num_updated = $db->update('export_feature_log')
          ->fields([
          'state' => 1, //1 make this 1
          ])
          ->condition('gid', $gid, '=')
          ->condition('type', $type, '=')
          ->condition('uid', $userid, 'IN')
          ->condition('state', 0, '=')
          ->condition('timestamp', $time[$key], '=')
          ->execute();
		  if(isset($userid) && $userid != '' && $userid != null){
            $target_users_query = $db->query('SELECT uid, mail FROM {users_field_data} WHERE uid=' . $userid);
            $target_users = $target_users_query->fetchAllKeyed(0, 1);
            $target_mail[] = $target_users[$userid];
          }
        }
        
        //dump($object[$type]);die;

     
        if ($object[$type] == 'Assets') {
		$url = $base_url.'/asset/';
		$query = $db->query("SELECT
        n.nid,
        concat('$url', n.nid) as url,
        grd.label as primary_community,
		n.title as asset_name
		FROM `node_field_data` n
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		LEFT JOIN groups_field_data grd on grd.id = gd.gid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		
		$records = $query->fetchAllAssoc('nid');

		$query2 = $db->query("SELECT
		n.nid,
    concat(fn.field_name_first_value, ' ', ln.field_name_last_value) as submitter
		FROM `node_field_data` n
		LEFT JOIN node__field_author sb ON sb.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
    LEFT JOIN user__field_name_first fn on fn.entity_id = gd.uid
    LEFT JOIN user__field_name_last ln on ln.entity_id = gd.uid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        AND gd.type LIKE '%group_node%'
        group by n.nid;");
		$records2 = $query2->fetchAllAssoc('nid');
		foreach($records2 as $key=>$refrecord2){
		  if(array_key_exists($key,$records)){
			$records[$key]->submitter = $refrecord2->submitter;
		  }
		}
		$query3 = $db->query("SELECT
		n.nid,
        cli.field_client_value as account
		FROM `node_field_data` n
		LEFT JOIN node__field_client cli ON cli.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records3 = $query3->fetchAllAssoc('nid');
		foreach($records3 as $key=>$refrecord3){
		  if(array_key_exists($key,$records)){
			$records[$key]->account = $refrecord3->account;
		  }
		}
		
		$query4 = $db->query("SELECT
		n.nid,
        CONCAT(fn.field_name_first_value,' ',ln.field_name_last_value) as other_contributor
		FROM `node_field_data` n
		LEFT JOIN node__field_other_contributor oc ON oc.entity_id = n.nid
        LEFT JOIN user__field_name_first fn ON fn.entity_id = oc.field_other_contributor_target_id
        LEFT JOIN user__field_name_last ln ON ln.entity_id = oc.field_other_contributor_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records4 = $query4->fetchAllAssoc('nid');
		foreach($records4 as $key=>$refrecord4){
		  if(array_key_exists($key,$records)){
			$records[$key]->other_contributor = $refrecord4->other_contributor;
		  }
		}
		
		$query5 = $db->query("SELECT
		n.nid,
        (CASE
          WHEN st.field_status_value = 0 THEN 'Live - Not reviewed by Community Leaders/Moderators'
          WHEN st.field_status_value = 1 THEN 'Live Gold - Validated by Community Leaders/Moderators'
          WHEN st.field_status_value = 2 THEN 'Archived'
          ELSE ''
        END) as status
		FROM `node_field_data` n
		LEFT JOIN node__field_status st ON n.nid = st.entity_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records5 = $query5->fetchAllAssoc('nid');
		foreach($records5 as $key=>$refrecord5){
		  if(array_key_exists($key,$records)){
			$records[$key]->status = $refrecord5->status;
		  }
		}
		
		$query6 = $db->query("SELECT
		n.nid,
        au.field_archive_date_value as actual_untill
		FROM `node_field_data` n
		LEFT JOIN node__field_archive_date au ON au.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records6 = $query6->fetchAllAssoc('nid');
		foreach($records6 as $key=>$refrecord6){
		  if(array_key_exists($key,$records)){
			$records[$key]->actual_untill = $refrecord6->actual_untill;
		  }
		}
		
		$query7 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT cat_tax.name) as category
		FROM `node_field_data` n
		LEFT JOIN node__field_entity_category cat ON cat.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data cat_tax ON cat_tax.tid = cat.field_entity_category_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records7 = $query7->fetchAllAssoc('nid');
		foreach($records7 as $key=>$refrecord7){
		  if(array_key_exists($key,$records)){
			$records[$key]->category = $refrecord7->category;
		  }
		}
		
		$query8 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT sbu_tax.name) as strategic_business_unit
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_strategic_business sbu ON sbu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sbu_tax ON sbu_tax.tid = sbu.field_selling_strategic_business_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records8 = $query8->fetchAllAssoc('nid');
		foreach($records8 as $key=>$refrecord8){
		  if(array_key_exists($key,$records)){
			$records[$key]->strategic_business_unit = $refrecord8->strategic_business_unit;
		  }
		}
		
		$query9 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT orc_tax.name) as originating_country
		FROM `node_field_data` n
		LEFT JOIN node__field_entity_country orc ON orc.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data orc_tax ON orc_tax.tid = orc.field_entity_country_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records9 = $query9->fetchAllAssoc('nid');
		foreach($records9 as $key=>$refrecord9){
		  if(array_key_exists($key,$records)){
			$records[$key]->originating_country = $refrecord9->originating_country;
		  }
		}
		
		$query10 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT sec_tax.name) as sector
		FROM `node_field_data` n
		LEFT JOIN node__field_sector sec ON sec.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sec_tax ON sec_tax.tid = sec.field_sector_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records10 = $query10->fetchAllAssoc('nid');
		foreach($records10 as $key=>$refrecord10){
		  if(array_key_exists($key,$records)){
			$records[$key]->sector = $refrecord10->sector;
		  }
		}
		
		$query11 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT seg_tax.name) as industry
		FROM `node_field_data` n
		LEFT JOIN node__field_segment seg ON seg.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data seg_tax ON seg_tax.tid = seg.field_segment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records11 = $query11->fetchAllAssoc('nid');
		foreach($records11 as $key=>$refrecord11){
		  if(array_key_exists($key,$records)){
			$records[$key]->industry = $refrecord11->industry;
		  }
		}
		
		$query12 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT sseg_tax.name) as industry_segment
		FROM `node_field_data` n
		LEFT JOIN node__field_subsegment sseg ON sseg.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sseg_tax ON sseg_tax.tid = sseg.field_subsegment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records12 = $query12->fetchAllAssoc('nid');
		foreach($records12 as $key=>$refrecord12){
		  if(array_key_exists($key,$records)){
			$records[$key]->industry_segment = $refrecord12->industry_segment;
		  }
		}
		
		$query13 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT secin_tax.name) as sector_initiative
		FROM `node_field_data` n
		LEFT JOIN node__field_sector_initiative secin ON secin.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data secin_tax ON secin_tax.tid = secin.field_sector_initiative_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records13 = $query13->fetchAllAssoc('nid');
		foreach($records13 as $key=>$refrecord13){
		  if(array_key_exists($key,$records)){
			$records[$key]->sector_initiative = $refrecord13->sector_initiative;
		  }
		}
		
		$query14 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT lsbu_tax.name) as legacy_sbu
		FROM `node_field_data` n
		LEFT JOIN node__field_entity_sbu lsbu ON lsbu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data lsbu_tax ON lsbu_tax.tid = lsbu.field_entity_sbu_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records14 = $query14->fetchAllAssoc('nid');
		foreach($records14 as $key=>$refrecord14){
		  if(array_key_exists($key,$records)){
			$records[$key]->legacy_sbu = $refrecord14->legacy_sbu;
		  }
		}
		
		$query15 = $db->query("SELECT
		n.nid,
        (CASE
          WHEN ms.field_managed_services_am_im__value = 0 THEN 'False'
          ELSE 'TRUE'
        END) as managed_services
		FROM `node_field_data` n
		LEFT JOIN node__field_managed_services_am_im_ ms ON ms.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records15 = $query15->fetchAllAssoc('nid');
		foreach($records15 as $key=>$refrecord15){
		  if(array_key_exists($key,$records)){
			$records[$key]->managed_services = $refrecord15->managed_services;
		  }
		}
		
		$query16 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT ep_tax.name) as entry_portfolio
		FROM `node_field_data` n
		LEFT JOIN node__field_entry_portfolio ep ON ep.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data ep_tax ON ep_tax.tid = ep.field_entry_portfolio_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records16 = $query16->fetchAllAssoc('nid');
		foreach($records16 as $key=>$refrecord16){
		  if(array_key_exists($key,$records)){
			$records[$key]->entry_portfolio = $refrecord16->entry_portfolio;
		  }
		}
		
		$query17 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT off_tax.name) as offer
		FROM `node_field_data` n
		LEFT JOIN node__field_offer off ON off.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data off_tax ON off_tax.tid = off.field_offer_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records17 = $query17->fetchAllAssoc('nid');
		foreach($records17 as $key=>$refrecord17){
		  if(array_key_exists($key,$records)){
			$records[$key]->offer = $refrecord17->offer;
		  }
		}
		
		$query18 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT bus_tax.name) as business_unit
		FROM `node_field_data` n
		LEFT JOIN node__field_business_unit bus ON bus.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data bus_tax ON bus_tax.tid = bus.field_business_unit_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records18 = $query18->fetchAllAssoc('nid');
		foreach($records18 as $key=>$refrecord18){
		  if(array_key_exists($key,$records)){
			$records[$key]->business_unit = $refrecord18->business_unit;
		  }
		}
		
		$query19 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT par_tax.name) as alliance_partner
		FROM `node_field_data` n
		LEFT JOIN node__field_partner par ON par.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data par_tax ON par_tax.tid = par.field_partner_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records19 = $query19->fetchAllAssoc('nid');
		foreach($records19 as $key=>$refrecord19){
		  if(array_key_exists($key,$records)){
			$records[$key]->alliance_partner = $refrecord19->alliance_partner;
		  }
		}
		
		$query20 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT tec_tax.name) as technologies
		FROM `node_field_data` n
		LEFT JOIN node__field_technologies tec ON tec.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data tec_tax ON tec_tax.tid = tec.field_technologies_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records20 = $query20->fetchAllAssoc('nid');
		foreach($records20 as $key=>$refrecord20){
		  if(array_key_exists($key,$records)){
			$records[$key]->technologies = $refrecord20->technologies;
		  }
		}
		
		$query21 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT comtax_tax.name) as community_taxonomy
		FROM `node_field_data` n
		LEFT JOIN node__field_community_taxonomy_id comtax ON comtax.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data comtax_tax ON comtax_tax.tid = comtax.field_community_taxonomy_id_value
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records21 = $query21->fetchAllAssoc('nid');
		foreach($records21 as $key=>$refrecord21){
		  if(array_key_exists($key,$records)){
			$records[$key]->community_taxonomy = $refrecord21->community_taxonomy;
		  }
		}
		
		$query22 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT comfol_tax.name) as community_folders
		FROM `node_field_data` n
		LEFT JOIN node__field_community_folders comfol ON comfol.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data comfol_tax ON comfol_tax.tid = comfol.field_community_folders_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records22 = $query22->fetchAllAssoc('nid');
		foreach($records22 as $key=>$refrecord22){
		  if(array_key_exists($key,$records)){
			$records[$key]->community_folders = $refrecord22->community_folders;
		  }
		}
		
		$query23 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT utag_tax.name) as users_tags
		FROM `node_field_data` n
		LEFT JOIN node__field_tags utag ON utag.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data utag_tax ON utag_tax.tid = utag.field_tags_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records23 = $query23->fetchAllAssoc('nid');
		foreach($records23 as $key=>$refrecord23){
		  if(array_key_exists($key,$records)){
			$records[$key]->users_tags = $refrecord23->users_tags;
		  }
		}
		
		$query24 = $db->query("SELECT
		n.nid,
        DATE_FORMAT(FROM_UNIXTIME(nfr.created), '%d-%M-%Y') as created
		FROM `node_field_data` n
        LEFT JOIN node_field_revision nfr on nfr.nid = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records24 = $query24->fetchAllAssoc('nid');
		foreach($records24 as $key=>$refrecord24){
		  if(array_key_exists($key,$records)){
			$records[$key]->created = $refrecord24->created;
		  }
		}
		
		$query25 = $db->query("SELECT
		n.nid,
        DATE_FORMAT(FROM_UNIXTIME(n.changed), '%d-%M-%Y') as changed
		FROM `node_field_data` n
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'asset'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records25 = $query25->fetchAllAssoc('nid');
		foreach($records25 as $key=>$refrecord25){
		  if(array_key_exists($key,$records)){
			$records[$key]->changed = $refrecord25->changed;
		  }
		}
    
        $file_query = $db->query("SELECT
          n.nid,
          CONCAT('Kind of attachment: File','>>','Attachment(s):',fm.filename,'>>','Date:',da.field_file_date_value) as Attachement 

          FROM `node_field_data` n
          LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
          LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
          LEFT JOIN paragraph__field_attachment att ON att.entity_id = par_con.id
          LEFT JOIN file_managed fm ON fm.fid = att.field_attachment_target_id
          LEFT JOIN paragraph__field_entity_language lan ON lan.entity_id = par_con.id
          LEFT JOIN taxonomy_term_field_data lan_tax ON lan_tax.tid = lan.field_entity_language_target_id
          LEFT JOIN paragraph__field_file_date da ON da.entity_id = par_con.id

          LEFT JOIN paragraph__field_type_asset ta ON ta.entity_id = par_con.id
          WHERE n.type = 'asset' AND gd.type LIKE '%group_node%' AND gd.gid = '$gid' GROUP BY n.nid;");

          $assetfilerecords = $file_query->fetchAllAssoc('nid');
          foreach($assetfilerecords as $key=>$assetfile){
            if(array_key_exists($key,$records)){
              $records[$key]->Attachement = str_replace('>>',';;',$assetfile->Attachement);
            }
          }

          $link_query = $db->query("SELECT
          n.nid,
          CONCAT('Kind of attachment: Link','>>','Attachment(s):',lin.field_link_uri,'>>','Date:',da.field_file_date_value) as Links

          FROM `node_field_data` n
          LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
          LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
          LEFT JOIN paragraph__field_entity_language lan ON lan.entity_id = par_con.id
          LEFT JOIN taxonomy_term_field_data lan_tax ON lan_tax.tid = lan.field_entity_language_target_id
          LEFT JOIN paragraph__field_file_date da ON da.entity_id = par_con.id
          LEFT JOIN paragraph__field_link lin ON lin.entity_id = par_con.id 
          LEFT JOIN paragraph__field_type_asset ta ON ta.entity_id = par_con.id
          WHERE n.type = 'asset' AND par_con.parent_field_name = 'field_files' AND gd.type LIKE '%group_node%' AND gd.gid = '$gid' AND lin.bundle = 'files' GROUP BY n.nid;");

          $assetlinkrecords = $link_query->fetchAllAssoc('nid');
          
          foreach($assetlinkrecords as $key=>$assetlink){
            if(array_key_exists($key,$records)){
              $records[$key]->Attachement .= ';;'.str_replace('>>',';;',$assetlink->Links);
            }
          }

          $contact_query = $db->query("SELECT
          n.nid,
          (CASE
          WHEN top.field_contact_topics_value IS NULL THEN
          CONCAT('Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value)))
          ELSE
          CONCAT(CONCAT('TOPIC : ',GROUP_CONCAT(distinct top.field_contact_topics_value),'>','Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value))))
          END) as contact
          FROM `node_field_data` n
          LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
          LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
          LEFT JOIN paragraph__field_contact_name con ON con.entity_id = par_con.id
          LEFT JOIN paragraph__field_contact_topics top ON top.entity_id = par_con.id
          LEFT JOIN user__field_name_first con_fn ON con_fn.entity_id = con.field_contact_name_target_id
          LEFT JOIN user__field_name_last con_ln ON con_ln.entity_id = con.field_contact_name_target_id
          WHERE n.type = 'asset' AND gd.gid = '$gid' GROUP BY n.nid;");
          $assetcontactrecords = $contact_query->fetchAllAssoc('nid');

          foreach($assetcontactrecords as $key=>$assetcontact){
            if(array_key_exists($key,$records)){
              $records[$key]->contact = str_replace('>',';',$assetcontact->contact);
            }
          }
          
        // CSV FILE WRITING CODE
        $fields_mapping = array(
          'url' => 'URL',
          'primary_community' => 'Primary community',
          'asset_name' => 'Asset Name',
          'submitter' => 'Submitter',
          'contact' => 'Contacts',
          'other_contributor' => 'Other Contributer',
          'account' => 'Account',
          'status' => 'Status',
          'actual_untill' => 'Actual Until',
          'category' => 'Category',
          'strategic_business_unit' => 'Strategic Business Unit / Global Business Line',
          'originating_country' => 'Orginating Country(ies)',
          'sector' => 'Sector',
          'industry' => 'Industry',
          'industry_segment' => 'Industry Segment',
          'sector_initiative' => 'Sector Initiative (Marketing)',
          'legacy_sbu' => 'Legacy SBU/OU',
          'managed_services' => 'Managed Services (AM/IM)',
          'entry_portfolio' => 'Entry Portfolio',
          'offer' => 'Offer',
          'business_unit' => 'Business Unit',
          'alliance_partner' => 'Alliance Partner',
          'technologies' => 'Technologies',
          'community_taxonomy' => 'Community taxonomy',
          'community_folders' => 'Community Folders',
          'users_tags' => 'User tags',
          'Attachement' => 'Attachment(s)',
          'created' => 'Created',
          'changed' => 'Changed'
        );
        $headers = array_values($fields_mapping);

        $directory = 'files/export/community/' . $gid;
        if (!file_exists($directory)) {
          mkdir($directory, 0777, TRUE);
        }
        $link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.csv';
        fopen($link,'w');
        $converted_link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.xlsx';
        $list = array(
          $headers,
        );
        foreach($records as $i => $values) {
          foreach(array_keys($fields_mapping) as $key){
            $list[$i][] =  $values->$key;
          }
        }

        $fp = fopen($link, 'w');
        foreach ($list as $fields) {
          fputcsv($fp, $fields);
        }
        fclose($fp);
        $spreadsheet = IOFactory::load($link);
        $sheetData = $spreadsheet->getActiveSheet();

        $rows = [];
        $high = $sheetData->getHighestRow();
        
          // Column for actual date.
          $range_actualdate = 'I2:I' . $high;
          // Column for creation date and update date.
          $range_creation_updatedate = 'AB2:AC' . $high;
          $nid_range = 'A2:A' . $high;
          $actual_date_data = $sheetData->rangeToArray($range_actualdate);
          $creation_update_date_data = $sheetData->rangeToArray($range_creation_updatedate);
          $nid_range_data = $sheetData->rangeToArray($nid_range);
          

          foreach($nid_range_data as $nid){
            $nodeid = '';
            $nodeid = explode('/',$nid[0]);
            $n_id = $nodeid[4];
            if(isset($n_id) && !empty($n_id)){
              $node_data = \Drupal::entityTypeManager()->getStorage('node')->load($n_id);
              //dump($node_data);
            }
          }//die;

          // Date format change for Actual Date column values.
		  $rownum = 2;
          foreach ($actual_date_data as $data1) {
            $actualdate_array = [];
            $actualdate_day = '';
            $actualdate_month = '';
            $actualdate_year = '';

            if (isset($data1[0]) && !empty($data1[0])) {
              $actualdatetime = strtotime($data1[0]);
              $actualdatenewformat = date('Y-m-d', $actualdatetime);
              $actualdate_array = explode('-', $actualdatenewformat);
              $actualdate_day = $actualdate_array[2];
              $actualdate_month = $actualdate_array[1];
              $actualdate_year = $actualdate_array[0];
            }
            if ($actualdate_day != '' && $actualdate_month != '' && $actualdate_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('I' . $rownum, '=DATE(' . $actualdate_year . ',' . $actualdate_month . ',' . $actualdate_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('I' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum++;
          }

          // Date format change for Creation and Update Date columns values.
          $rownum2 = 2;
          foreach ($creation_update_date_data as $data2) {
            $creation_array = [];
            $update_array = [];
            $creation_day = '';
            $creation_month = '';
            $creation_year = '';
            $update_day = '';
            $update_month = '';
            $update_year = '';

            if (isset($data2[0]) && !empty($data2[0])) {
              $creationtime = strtotime($data2[0]);
              $creationnewformat = date('Y-m-d', $creationtime);
              $creation_array = explode('-', $creationnewformat);
              $creation_day = $creation_array[2];
              $creation_month = $creation_array[1];
              $creation_year = $creation_array[0];
            }
            if (isset($data2[1]) && !empty($data2[1])) {
              $updatetime = strtotime($data2[1]);
              $updatenewformat = date('Y-m-d', $updatetime);
              $update_array = explode('-', $updatenewformat);
              $update_day = $update_array[2];
              $update_month = $update_array[1];
              $update_year = $update_array[0];
            }

            if ($creation_day != '' && $creation_month != '' && $creation_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('AB' . $rownum2, '=DATE(' . $creation_year . ',' . $creation_month . ',' . $creation_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('AB' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            if ($update_day != '' && $update_month != '' && $update_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('AC' . $rownum2, '=DATE(' . $update_year . ',' . $update_month . ',' . $update_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('AC' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum2++;
          }
          $writer = new Xlsx($spreadsheet);
        $writer->save($converted_link);
        chmod($converted_link, 0777);
        }
        
        if ($object[$type] == 'Community Pages') {
		      $url = $base_url.'/pages/';
          $pagesquery = $db->query("SELECT
          n.nid,
          concat('$url', n.nid) as url,
          n.title as page_name,
          concat(fn.field_name_first_value, ' ', ln.field_name_last_value) as submitter,
          np.title as parent,
          GROUP_CONCAT(DISTINCT utag_tax.name) as users_tags,
          DATE_FORMAT(FROM_UNIXTIME(nfr.created), '%d-%M-%Y') as created,
          DATE_FORMAT(FROM_UNIXTIME(n.changed), '%d-%M-%Y') as changed,
          GROUP_CONCAT(CONCAT('Attachment(s):',fm.filename)) as Attachement
          FROM `node_field_data` n
          LEFT JOIN node_field_revision nfr on nfr.nid = n.nid
          LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
          LEFT JOIN user__field_name_first fn on fn.entity_id = gd.uid
          LEFT JOIN user__field_name_last ln on ln.entity_id = gd.uid
          LEFT JOIN book as pn on pn.nid = n.nid
          LEFT JOIN node_field_data np on np.nid = pn.pid
          LEFT JOIN node__field_tags utag ON utag.entity_id = n.nid
          LEFT JOIN taxonomy_term_field_data utag_tax ON utag_tax.tid = utag.field_tags_target_id
          LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid AND par_con.parent_field_name = 'field_content_files'
          LEFT JOIN paragraph__field_attachment att ON att.entity_id = par_con.id
          LEFT JOIN file_managed fm ON fm.fid = att.field_attachment_target_id
          WHERE n.type = 'pages'
          AND gd.type = 'public_group-group_node-pages'
          AND gd.gid = '$gid' group by n.nid,utag.entity_id;");

          $pagesrecords = $pagesquery->fetchAllAssoc('nid');

          // CSV FILE WRITING CODE
          $fields_mapping = array(
          'url' => 'URL',
          'page_name' => 'Title',
          'submitter' => 'Submitter',
          'parent' => 'Parent',
          'users_tags' => 'User tags',
          'Attachement' => 'Attachment(s)',
          'created' => 'Created',
          'changed' => 'Changed'
          );
          $headers = array_values($fields_mapping);

          $directory = 'files/export/community/' . $gid;
          if (!file_exists($directory)) {
            mkdir($directory, 0777, TRUE);
          }
          $link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.csv';
          fopen($link,'w');
          $converted_link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.xlsx';
          $list = array(
            $headers,
          );
          foreach($pagesrecords as $i => $values) {
            foreach(array_keys($fields_mapping) as $key){
              $list[$i][] =  $values->$key;
            }
          }

          $fp = fopen($link, 'w');
          foreach ($list as $fields) {
            fputcsv($fp, $fields);
          }
          fclose($fp);
          $spreadsheet = IOFactory::load($link);
        $sheetData = $spreadsheet->getActiveSheet();

        $rows = [];
        $high = $sheetData->getHighestRow();
        $rowsub = 2;
		$rownum = 2;
        //Submitter column.
        $range_submitter = 'C2:C' . $high;
        $submitter_data = $sheetData->rangeToArray($range_submitter);
        foreach ($submitter_data as $sub) {
          if (isset($sub[0]) && !empty($sub[0])) {
            $submitter = explode('[',$sub[0]);
            $submittername = trim($submitter[0]);
            $spreadsheet->getActiveSheet()->setCellValue('C' . $rowsub, $submittername);
          }
          $rowsub++;
        }
          $range = 'G2:H' . $high;
          $data = $sheetData->rangeToArray($range);

          foreach ($data as $row) {
            $creation_array = [];
            $update_array = [];
            $creation_day = '';
            $creation_month = '';
            $creation_year = '';
            $update_day = '';
            $update_month = '';
            $update_year = '';

            if (isset($row[0]) && !empty($row[0])) {
              $creationtime = strtotime($row[0]);
              $creationnewformat = date('Y-m-d', $creationtime);
              $creation_array = explode('-', $creationnewformat);
              $creation_day = $creation_array[2];
              $creation_month = $creation_array[1];
              $creation_year = $creation_array[0];
            }
            if (isset($row[1]) && !empty($row[1])) {
              $updatetime = strtotime($row[1]);
              $updatenewformat = date('Y-m-d', $updatetime);
              $update_array = explode('-', $updatenewformat);
              $update_day = $update_array[2];
              $update_month = $update_array[1];
              $update_year = $update_array[0];
            }

            if ($creation_day != '' && $creation_month != '' && $creation_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('G' . $rownum, '=DATE(' . $creation_year . ',' . $creation_month . ',' . $creation_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('G' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            if ($update_day != '' && $update_month != '' && $update_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('H' . $rownum, '=DATE(' . $update_year . ',' . $update_month . ',' . $update_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('H' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum++;
          }
          $writer = new Xlsx($spreadsheet);
        $writer->save($converted_link);
        chmod($converted_link, 0777);
        }

        if ($object[$type] == 'Members') {
          $query = $db->query("SELECT
          gd.entity_id,
          fn.field_name_first_value as firstname,
          ln.field_name_last_value as lastname,
          u.mail as email,
          uc_tax.name as country
          from group_relationship_field_data gd
          LEFT JOIN user__field_name_first fn ON fn.entity_id = gd.entity_id
          LEFT JOIN user__field_name_last ln ON ln.entity_id = gd.entity_id
          LEFT JOIN users_field_data u on u.uid = gd.entity_id
          LEFT JOIN user__field_country_user uc on uc.entity_id = gd.entity_id
          LEFT JOIN taxonomy_term_field_data uc_tax ON uc_tax.tid = uc.field_country_user_target_id
          where gd.type LIKE '%_membership%'
          AND gd.gid = '$gid' GROUP BY gd.entity_id;");
          $records = $query->fetchAllAssoc('entity_id');
          // CSV FILE WRITING CODE
          $fields_mapping = array(
          'firstname' => 'First Name',
          'lastname' => 'Last Name',
          'email' => 'Email',
          'country' => 'Country'
          );
          $headers = array_values($fields_mapping);

          $directory = 'files/export/community/' . $gid;
          if (!file_exists($directory)) {
            mkdir($directory, 0777, TRUE);
          }
          $link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.csv';
          fopen($link,'w');
          $converted_link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.xlsx';
          $list = array(
            $headers,
          );
          foreach($records as $i => $values) {
            foreach(array_keys($fields_mapping) as $key){
              $list[$i][] =  $values->$key;
            }
          }

          $fp = fopen($link, 'w');
          foreach ($list as $fields) {
            fputcsv($fp, $fields);
          }
          fclose($fp);
          $spreadsheet = IOFactory::load($link);
          $sheetData = $spreadsheet->getActiveSheet();
          $writer = new Xlsx($spreadsheet);
          $writer->save($converted_link);
          chmod($converted_link, 0777);
        }
        
		    $subject = 'Export from PRISM - Community ID: ' . $gid . ' - ' . $object[$type];
		    if(isset($gid) && $gid != '' && $gid != null){	
          $groupname_query = $db->query('SELECT label FROM {groups_field_data} WHERE id=' . $gid);
          $groupname = $groupname_query->fetchAll();
		    }
        
        //success message
        if (file_exists($converted_link)) {
          $file_create = \Drupal::service('file_url_generator')->generateAbsoluteString($converted_link);
          
          $file_link = str_replace('http://','https://', $file_create); 
          $file_link .= "?".time();

          $body = 'You have requested to export ' . $object[$type] . ' from "' . $groupname[0]->label . '" community.<br />Please download the export file from <a href="' . $file_link . '">here</a>. Thank you.';
          
        } else {
          $body = 'You have requested to export ' . $object[$type] . ' from "' . $groupname[0]->label . '" community.<br />However, there were some issues preventing the export file to be generated.<br />Please try again, and contact the support team if you get the same error again.<br />Thank you.';  
        }

        $receivers = implode(';',$target_mail);
        $mailManager = \Drupal::service('plugin.manager.mail');
        $module = 'custom_export';
        $key = 'community_export';
        $to = $receivers;
        $params['message'] = $body;
        $params['subject'] = $subject;
        $langcode = 'en';
        $send = true;
		    if(isset($receivers)){
          $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
        }
        if ($result['result'] != true) {
          $message = t('There was a problem sending your email notification to @email.', array('@email' => $to));
          \Drupal::messenger()->addError($message);
          //\Drupal::logger('mail-log')->error($message);
        }

        $message = t('An email notification has been sent to @email ', array('@email' => $to));
        \Drupal::messenger()->addStatus($message);
        //\Drupal::logger('mail-log')->notice($message);

        foreach ($userids as $key => $userid) {
          $num_updated = $db->update('export_feature_log')
          ->fields([
          'state' => 2,
          ])
          ->condition('gid', $gid, '=')
          ->condition('type', $type, '=')
          ->condition('uid', $userid, 'IN')
          ->condition('state', 1, '=')
          ->condition('timestamp', $time[$key], '=')
          ->execute();
        }
				}
      }
      else {
        echo 'Report not generated. Please try again later.';
        die;
      }
			
    }
    catch (Exception $e) {
      \Drupal::logger('widget')->error($e->getMessage());
      // dump($e->getMessage());die;
    }
    $response = new AjaxResponse();
    return $response;
  }

  /**
   *
   */
  public function exporttoexcelref() {
	  global $base_url;
    $view = [
      'reference' => 'capgemini_browsing_widget_reference_secondary',
    ];
    $object = [
      'reference' => 'References',
    ];
    try {

      $db = \Drupal::service('database');
      $check_available_query = $db->query("SELECT state FROM {export_primary_secondary_log} WHERE state = 1 ORDER BY timestamp ASC LIMIT 1");
      $in_progress = $check_available_query->fetchField();
      if (!$in_progress) {
        $query = $db->query('SELECT gid, group_concat(uid) as uids, group_concat(timestamp) as export_time FROM {export_primary_secondary_log} WHERE state=0 GROUP BY gid ORDER BY timestamp ASC LIMIT 2');
        $items = $query->fetchAll();

        $type = 'reference';
        $view_name = $view[$type];
        $display_id = 'data_export_1';
        $gid = $items[0]->gid;
        $uids = $items[0]->uids;
        $time = explode(',', $items[0]->export_time);
        $body = '';

        $userids = explode(',', $uids);
        foreach ($userids as $key => $userid) {
          $num_updated = $db->update('export_primary_secondary_log')
          ->fields([
          'state' => 1,
          ])
          ->condition('gid', $gid, '=')
          ->condition('uid', $userid, 'IN')
          ->condition('state', 0, '=')
          ->condition('timestamp', $time[$key], '=')
          ->execute();
		  if(isset($userid) && $userid != '' && $userid != null){
            $target_users_query = $db->query('SELECT uid, mail FROM {users_field_data} WHERE uid=' . $userid);
            $target_users = $target_users_query->fetchAllKeyed(0, 1);
            $target_mail[] = $target_users[$userid];
		  }
        }
        
		$url = $base_url.'/reference/';
		$query = $db->query("SELECT
        n.nid,
        concat('$url', n.nid) as url,
        grd.label as primary_community,
		n.title as referece_title
		FROM `node_field_data` n
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		LEFT JOIN groups_field_data grd on grd.id = gd.gid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		
		$records = $query->fetchAllAssoc('nid');
		
		$query2 = $db->query("SELECT
		n.nid,
        op.field_opportunity_id_value as opp_id
		FROM `node_field_data` n
		LEFT JOIN node__field_opportunity_id op on op.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records2 = $query2->fetchAllAssoc('nid');
		foreach($records2 as $key=>$refrecord2){
		  if(array_key_exists($key,$records)){
			$records[$key]->opp_id = $refrecord2->opp_id;
		  }
		}
		
		$query3 = $db->query("SELECT
		n.nid,
    concat(fn.field_name_first_value, ' ', ln.field_name_last_value) as submitter
		FROM `node_field_data` n
		LEFT JOIN node__field_author sb ON sb.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
    LEFT JOIN user__field_name_first fn on fn.entity_id = gd.uid
    LEFT JOIN user__field_name_last ln on ln.entity_id = gd.uid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records3 = $query3->fetchAllAssoc('nid');
		foreach($records3 as $key=>$refrecord3){
		  if(array_key_exists($key,$records)){
			$records[$key]->submitter = $refrecord3->submitter;
		  }
		}
    
		$query4 = $db->query("SELECT
		n.nid,
        cli.field_client_account_value as account
		FROM `node_field_data` n
		LEFT JOIN node__field_client_account cli ON cli.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records4 = $query4->fetchAllAssoc('nid');
		foreach($records4 as $key=>$refrecord4){
		  if(array_key_exists($key,$records)){
			$records[$key]->account = $refrecord4->account;
		  }
		}
		
		$query5 = $db->query("SELECT
		n.nid,
        CONCAT(fn.field_name_first_value,' ',ln.field_name_last_value) as other_contributor
		FROM `node_field_data` n
		LEFT JOIN node__field_other_contributor oc ON oc.entity_id = n.nid
        LEFT JOIN user__field_name_first fn ON fn.entity_id = oc.field_other_contributor_target_id
        LEFT JOIN user__field_name_last ln ON ln.entity_id = oc.field_other_contributor_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records5 = $query5->fetchAllAssoc('nid');
		foreach($records5 as $key=>$refrecord5){
		  if(array_key_exists($key,$records)){
			$records[$key]->other_contributor = $refrecord5->other_contributor;
		  }
		}
		
		$query6 = $db->query("SELECT
		n.nid,
        mc.field_migrated_contact_value as migrated_contact
		FROM `node_field_data` n
		LEFT JOIN node__field_migrated_contact mc on mc.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records6 = $query6->fetchAllAssoc('nid');
		foreach($records6 as $key=>$refrecord6){
		  if(array_key_exists($key,$records)){
			$records[$key]->migrated_contact = $refrecord6->migrated_contact;
		  }
		}
		
		$query7 = $db->query("SELECT
		n.nid,
        upa.field_ultimate_parent_account_value as upa
		FROM `node_field_data` n
		LEFT JOIN node__field_ultimate_parent_account upa on upa.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records7 = $query7->fetchAllAssoc('nid');
		foreach($records7 as $key=>$refrecord7){
		  if(array_key_exists($key,$records)){
			$records[$key]->upa = $refrecord7->upa;
		  }
		}
		
		$query8 = $db->query("SELECT
		n.nid,
        aan.field_masking_client_names_value as masking_client
		FROM `node_field_data` n
		LEFT JOIN node__field_masking_client_names aan on aan.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records8 = $query8->fetchAllAssoc('nid');
		foreach($records8 as $key=>$refrecord8){
		  if(array_key_exists($key,$records)){
			$records[$key]->masking_client = $refrecord8->masking_client;
		  }
		}
		
		$query9 = $db->query("SELECT
		n.nid,
        if(em.field_enable_masking_value = 0, 'No', 'Yes') as masking_val
		FROM `node_field_data` n
		LEFT JOIN node__field_enable_masking em on em.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records9 = $query9->fetchAllAssoc('nid');
		foreach($records9 as $key=>$refrecord9){
		  if(array_key_exists($key,$records)){
			$records[$key]->masking_val = $refrecord9->masking_val;
		  }
		}
		
		$query10 = $db->query("SELECT
		n.nid,
        at.field_account_category_value as acc_type
		FROM `node_field_data` n
		LEFT JOIN node__field_account_category at on at.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records10 = $query10->fetchAllAssoc('nid');
		foreach($records10 as $key=>$refrecord10){
		  if(array_key_exists($key,$records)){
			$records[$key]->acc_type = $refrecord10->acc_type;
		  }
		}
		
		$query11 = $db->query("SELECT
		n.nid,
        ac_tax.name as account_country
		FROM `node_field_data` n
		LEFT JOIN node__field_account_country ac ON ac.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data ac_tax ON ac_tax.tid = ac.field_account_country_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records11 = $query11->fetchAllAssoc('nid');
		foreach($records11 as $key=>$refrecord11){
		  if(array_key_exists($key,$records)){
			$records[$key]->account_country = $refrecord11->account_country;
		  }
		}
		
		
		$query12 = $db->query("SELECT
		n.nid,
        act.field_account_city_value as acc_city
		FROM `node_field_data` n
		LEFT JOIN node__field_account_city act ON act.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records12 = $query12->fetchAllAssoc('nid');
		foreach($records12 as $key=>$refrecord12){
		  if(array_key_exists($key,$records)){
			$records[$key]->acc_city = $refrecord12->acc_city;
		  }
		}
		
		$query13 = $db->query("SELECT
		n.nid,
        CONCAT(ofn.field_name_first_value,' ',oln.field_name_last_value) as opp_lead
		FROM `node_field_data` n
		LEFT JOIN node__field_opportunity_lead ol ON ol.entity_id = n.nid
		LEFT JOIN user__field_name_first ofn ON ofn.entity_id = ol.field_opportunity_lead_target_id
        LEFT JOIN user__field_name_last oln ON oln.entity_id = ol.field_opportunity_lead_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records13 = $query13->fetchAllAssoc('nid');
		foreach($records13 as $key=>$refrecord13){
		  if(array_key_exists($key,$records)){
			$records[$key]->opp_lead = $refrecord13->opp_lead;
		  }
		}
		
		$query14 = $db->query("SELECT
		n.nid,
        ps.field_permission_status_value as confidentiality
		FROM `node_field_data` n
		LEFT JOIN node__field_permission_status ps ON ps.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records14 = $query14->fetchAllAssoc('nid');
		foreach($records14 as $key=>$refrecord14){
		  if(array_key_exists($key,$records)){
			$records[$key]->confidentiality = $refrecord14->confidentiality;
		  }
		}
		
		
		$query15 = $db->query("SELECT
		n.nid,
        group_concat(distinct ru.field_reference_usage_value) as reference_usage
		FROM `node_field_data` n
		LEFT JOIN node__field_reference_usage ru ON ru.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records15 = $query15->fetchAllAssoc('nid');
		foreach($records15 as $key=>$refrecord15){
		  if(array_key_exists($key,$records)){
			$records[$key]->reference_usage = $refrecord15->reference_usage;
		  }
		}

		$query16 = $db->query("SELECT
		n.nid,
        (CASE
          WHEN st.field_status_rf_value = 0 THEN 'Live - Not reviewed by Community Leaders/Moderators'
          WHEN st.field_status_rf_value = 1 THEN 'Live Gold - Validated by Community Leaders/Moderators'
          WHEN st.field_status_rf_value = 2 THEN 'Archived'
          ELSE ''
        END) as status
		FROM `node_field_data` n
		LEFT JOIN node__field_status_rf st ON n.nid = st.entity_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records16 = $query16->fetchAllAssoc('nid');
		foreach($records16 as $key=>$refrecord16){
		  if(array_key_exists($key,$records)){
			$records[$key]->status = $refrecord16->status;
		  }
		}
    
		$query17 = $db->query("SELECT
		n.nid,
        group_concat(distinct ssbu_tax.name) as selling_strategic_bu
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_strategic_unit ssbu ON ssbu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data ssbu_tax ON ssbu_tax.tid = ssbu.field_selling_strategic_unit_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records17 = $query17->fetchAllAssoc('nid');
		foreach($records17 as $key=>$refrecord17){
		  if(array_key_exists($key,$records)){
			$records[$key]->selling_strategic_bu = $refrecord17->selling_strategic_bu;
		  }
		}
		
		$query18 = $db->query("SELECT
		n.nid,
        group_concat(distinct sbu_tax.name) as selling_bu
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_business_unit sbu ON sbu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sbu_tax ON sbu_tax.tid = sbu.field_selling_business_unit_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records18 = $query18->fetchAllAssoc('nid');
		foreach($records18 as $key=>$refrecord18){
		  if(array_key_exists($key,$records)){
			$records[$key]->selling_bu = $refrecord18->selling_bu;
		  }
		}
		
		$query19 = $db->query("SELECT
		n.nid,
        group_concat(distinct smu_tax.name) as selling_mu
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_market_unit smu ON smu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data smu_tax ON smu_tax.tid = smu.field_selling_market_unit_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records19 = $query19->fetchAllAssoc('nid');
		foreach($records19 as $key=>$refrecord19){
		  if(array_key_exists($key,$records)){
			$records[$key]->selling_mu = $refrecord19->selling_mu;
		  }
		}
		
		$query20 = $db->query("SELECT
		n.nid,
        group_concat(distinct sms_tax.name) as selling_ms
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_market_segment sms ON sms.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sms_tax ON sms_tax.tid = sms.field_selling_market_segment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records20 = $query20->fetchAllAssoc('nid');
		foreach($records20 as $key=>$refrecord20){
		  if(array_key_exists($key,$records)){
			$records[$key]->selling_ms = $refrecord20->selling_ms;
		  }
		}
		
		$query21 = $db->query("SELECT
		n.nid,
        group_concat(distinct sru_tax.name) as selling_ru
		FROM `node_field_data` n
		LEFT JOIN node__field_selling_reporting_unit sru ON sru.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sru_tax ON sru_tax.tid = sru.field_selling_reporting_unit_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records21 = $query21->fetchAllAssoc('nid');
		foreach($records21 as $key=>$refrecord21){
		  if(array_key_exists($key,$records)){
			$records[$key]->selling_ru = $refrecord21->selling_ru;
		  }
		}
		
		$query22 = $db->query("SELECT
		n.nid,
        group_concat(distinct dms_tax.name) as delivery_ms
		FROM `node_field_data` n
		LEFT JOIN node__field_delivery_market_segment dms ON dms.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data dms_tax ON dms_tax.tid = dms.field_delivery_market_segment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records22 = $query22->fetchAllAssoc('nid');
		foreach($records22 as $key=>$refrecord22){
		  if(array_key_exists($key,$records)){
			$records[$key]->delivery_ms = $refrecord22->delivery_ms;
		  }
		}
		
		$query23 = $db->query("SELECT
		n.nid,
        group_concat(distinct gblsb_tax.name) as gbl_sbu
		FROM `node_field_data` n
		LEFT JOIN node__field_delivery_gbl_sbu gblsb ON gblsb.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data gblsb_tax ON gblsb_tax.tid = gblsb.field_delivery_gbl_sbu_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records23 = $query23->fetchAllAssoc('nid');
		foreach($records23 as $key=>$refrecord23){
		  if(array_key_exists($key,$records)){
			$records[$key]->gbl_sbu = $refrecord23->gbl_sbu;
		  }
		}
		
		$query24 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT sec_tax.name) as sector
		FROM `node_field_data` n
		LEFT JOIN node__field_sector sec ON sec.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sec_tax ON sec_tax.tid = sec.field_sector_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records24 = $query24->fetchAllAssoc('nid');
		foreach($records24 as $key=>$refrecord24){
		  if(array_key_exists($key,$records)){
			$records[$key]->sector = $refrecord24->sector;
		  }
		}
		
		$query25 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT seg_tax.name) as industry
		FROM `node_field_data` n
		LEFT JOIN node__field_segment seg ON seg.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data seg_tax ON seg_tax.tid = seg.field_segment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records25 = $query25->fetchAllAssoc('nid');
		foreach($records25 as $key=>$refrecord25){
		  if(array_key_exists($key,$records)){
			$records[$key]->industry = $refrecord25->industry;
		  }
		}
		
		$query26 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT sseg_tax.name) as industry_segment
		FROM `node_field_data` n
		LEFT JOIN node__field_subsegment sseg ON sseg.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data sseg_tax ON sseg_tax.tid = sseg.field_subsegment_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records26 = $query26->fetchAllAssoc('nid');
		foreach($records26 as $key=>$refrecord26){
		  if(array_key_exists($key,$records)){
			$records[$key]->industry_segment = $refrecord26->industry_segment;
		  }
		}
		
		$query27 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT si_tax.name) as sector_initiative
		FROM `node_field_data` n
		LEFT JOIN node__field_sector_initiative si ON si.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data si_tax ON si_tax.tid = si.field_sector_initiative_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records27 = $query27->fetchAllAssoc('nid');
		foreach($records27 as $key=>$refrecord27){
		  if(array_key_exists($key,$records)){
			$records[$key]->sector_initiative = $refrecord27->sector_initiative;
		  }
		}
		
		$query28 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT lsbu_tax.name) as legacy_sbu
		FROM `node_field_data` n
		LEFT JOIN node__field_entity_sbu lsbu ON lsbu.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data lsbu_tax ON lsbu_tax.tid = lsbu.field_entity_sbu_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records28 = $query28->fetchAllAssoc('nid');
		foreach($records28 as $key=>$refrecord28){
		  if(array_key_exists($key,$records)){
			$records[$key]->legacy_sbu = $refrecord28->legacy_sbu;
		  }
		}
		
		$query29 = $db->query("SELECT
		n.nid,
        if(ms.field_managed_services_am_im__value = 0, 'False', 'True') as manages_services
		FROM `node_field_data` n
		LEFT JOIN node__field_managed_services_am_im_ ms ON ms.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records29 = $query29->fetchAllAssoc('nid');
		foreach($records29 as $key=>$refrecord29){
		  if(array_key_exists($key,$records)){
			$records[$key]->manages_services = $refrecord29->manages_services;
		  }
		}
		
		$query30 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT ep_tax.name) as entry_portfolio
		FROM `node_field_data` n
		LEFT JOIN node__field_entry_portfolio ep ON ep.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data ep_tax ON ep_tax.tid = ep.field_entry_portfolio_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records30 = $query30->fetchAllAssoc('nid');
		foreach($records30 as $key=>$refrecord30){
		  if(array_key_exists($key,$records)){
			$records[$key]->entry_portfolio = $refrecord30->entry_portfolio;
		  }
		}
		
		$query31 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT of_tax.name) as offer
		FROM `node_field_data` n
		LEFT JOIN node__field_offer of ON of.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data of_tax ON of_tax.tid = of.field_offer_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records31 = $query31->fetchAllAssoc('nid');
		foreach($records31 as $key=>$refrecord31){
		  if(array_key_exists($key,$records)){
			$records[$key]->offer = $refrecord31->offer;
		  }
		}
		
		
		$query32 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT par_tax.name) as alliance_partner
		FROM `node_field_data` n
		LEFT JOIN node__field_partner par ON par.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data par_tax ON par_tax.tid = par.field_partner_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records32 = $query32->fetchAllAssoc('nid');
		foreach($records32 as $key=>$refrecord32){
		  if(array_key_exists($key,$records)){
			$records[$key]->alliance_partner = $refrecord32->alliance_partner;
		  }
		}
		
		$query33 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT tec_tax.name) as technologies
		FROM `node_field_data` n
		LEFT JOIN node__field_technologies tec ON tec.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data tec_tax ON tec_tax.tid = tec.field_technologies_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records33 = $query33->fetchAllAssoc('nid');
		foreach($records33 as $key=>$refrecord33){
		  if(array_key_exists($key,$records)){
			$records[$key]->technologies = $refrecord33->technologies;
		  }
		}
		
		$query34 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT utag_tax.name) as users_tags
		FROM `node_field_data` n
		LEFT JOIN node__field_tags utag ON utag.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data utag_tax ON utag_tax.tid = utag.field_tags_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records34 = $query34->fetchAllAssoc('nid');
		foreach($records34 as $key=>$refrecord34){
		  if(array_key_exists($key,$records)){
			$records[$key]->users_tags = $refrecord34->users_tags;
		  }
		}
		
		$query35 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT gfdd.label) as secondary_communities
		FROM `node_field_data` n
		LEFT JOIN node__field_second_communities sc ON sc.entity_id = n.nid
        LEFT JOIN groups_field_data gfdd on gfdd.id = sc.field_second_communities_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records35 = $query35->fetchAllAssoc('nid');
		foreach($records35 as $key=>$refrecord35){
		  if(array_key_exists($key,$records)){
			$records[$key]->secondary_communities = $refrecord35->secondary_communities;
		  }
		}
		
		$query36 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT comfol_tax.name) as community_folders
		FROM `node_field_data` n
		LEFT JOIN node__field_community_folders comfol ON comfol.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data comfol_tax ON comfol_tax.tid = comfol.field_community_folders_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records36 = $query36->fetchAllAssoc('nid');
		foreach($records36 as $key=>$refrecord36){
		  if(array_key_exists($key,$records)){
			$records[$key]->community_folders = $refrecord36->community_folders;
		  }
		}
		
		
		$query37 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT ct.field_contract_type_value) as contract_type
		FROM `node_field_data` n
		LEFT JOIN node__field_contract_type ct ON ct.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records37 = $query37->fetchAllAssoc('nid');
		foreach($records37 as $key=>$refrecord37){
		  if(array_key_exists($key,$records)){
			$records[$key]->contract_type = $refrecord37->contract_type;
		  }
		}
		
		$query38 = $db->query("SELECT
		n.nid,
        cr.field_currency_value as currency
		FROM `node_field_data` n
		LEFT JOIN node__field_currency cr ON cr.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records38 = $query38->fetchAllAssoc('nid');
		foreach($records38 as $key=>$refrecord38){
		  if(array_key_exists($key,$records)){
			$records[$key]->currency = $refrecord38->currency;
		  }
		}
		
		$query39 = $db->query("SELECT
		n.nid,
        tcv.field_contract_value_value as tcv
		FROM `node_field_data` n
		LEFT JOIN node__field_contract_value tcv ON tcv.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records39 = $query39->fetchAllAssoc('nid');
		foreach($records39 as $key=>$refrecord39){
		  if(array_key_exists($key,$records)){
			$records[$key]->tcv = $refrecord39->tcv;
		  }
		}
		
		$query40 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT compt_tax.name) as competitors
		FROM `node_field_data` n
		LEFT JOIN node__field_competitors_rf compt ON compt.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data compt_tax ON compt_tax.tid = compt.field_competitors_rf_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records40 = $query40->fetchAllAssoc('nid');
		foreach($records40 as $key=>$refrecord40){
		  if(array_key_exists($key,$records)){
			$records[$key]->competitors = $refrecord40->competitors;
		  }
		}
		
		$query41 = $db->query("SELECT
		n.nid,
        strd.field_engagement_start_date_value as start_date
		FROM `node_field_data` n
		LEFT JOIN node__field_engagement_start_date strd ON strd.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records41 = $query41->fetchAllAssoc('nid');
		foreach($records41 as $key=>$refrecord41){
		  if(array_key_exists($key,$records)){
			$records[$key]->start_date = $refrecord41->start_date;
		  }
		}
		
		$query42 = $db->query("SELECT
		n.nid,
        endt.field_engagement_end_date_value as end_date
		FROM `node_field_data` n
		LEFT JOIN node__field_engagement_end_date endt ON endt.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records42 = $query42->fetchAllAssoc('nid');
		foreach($records42 as $key=>$refrecord42){
		  if(array_key_exists($key,$records)){
			$records[$key]->end_date = $refrecord42->end_date;
		  }
		}
		
		$query43 = $db->query("SELECT
		n.nid,
        nmd.field_milestone_date_value as next_milestone_date
		FROM `node_field_data` n
		LEFT JOIN node__field_milestone_date nmd ON nmd.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records43 = $query43->fetchAllAssoc('nid');
		foreach($records43 as $key=>$refrecord43){
		  if(array_key_exists($key,$records)){
			$records[$key]->next_milestone_date = $refrecord43->next_milestone_date;
		  }
		}
		
		$query44 = $db->query("SELECT
		n.nid,
        rsm.field_rightshore_model_value as righshore_model
		FROM `node_field_data` n
		LEFT JOIN node__field_rightshore_model rsm ON rsm.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records44 = $query44->fetchAllAssoc('nid');
		foreach($records44 as $key=>$refrecord44){
		  if(array_key_exists($key,$records)){
			$records[$key]->righshore_model = $refrecord44->righshore_model;
		  }
		}
		
		$query45 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT ctd_tax.name) as contries_that_deliver
		FROM `node_field_data` n
		LEFT JOIN node__field_capgemini_country_ies_that ctd ON ctd.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data ctd_tax ON ctd_tax.tid = ctd.field_capgemini_country_ies_that_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records45 = $query45->fetchAllAssoc('nid');
		foreach($records45 as $key=>$refrecord45){
		  if(array_key_exists($key,$records)){
			$records[$key]->contries_that_deliver = $refrecord45->contries_that_deliver;
		  }
		}
		
		$query46 = $db->query("SELECT
		n.nid,
        GROUP_CONCAT(DISTINCT cwd_tax.name) as contries_where_deliver
		FROM `node_field_data` n
		LEFT JOIN node__field_entity_country cwd ON cwd.entity_id = n.nid
        LEFT JOIN taxonomy_term_field_data cwd_tax ON cwd_tax.tid = cwd.field_entity_country_target_id
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records46 = $query46->fetchAllAssoc('nid');
		foreach($records46 as $key=>$refrecord46){
		  if(array_key_exists($key,$records)){
			$records[$key]->contries_that_deliver = $refrecord46->contries_that_deliver;
		  }
		}
		
		$query47 = $db->query("SELECT
		n.nid,
        DATE_FORMAT(FROM_UNIXTIME(nfr.created), '%d-%M-%Y') as created
		FROM `node_field_data` n
		LEFT JOIN node_field_revision nfr on nfr.nid = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records47 = $query47->fetchAllAssoc('nid');
		foreach($records47 as $key=>$refrecord47){
		  if(array_key_exists($key,$records)){
			$records[$key]->created = $refrecord47->created;
		  }
		}
		
		$query48 = $db->query("SELECT
		n.nid,
        DATE_FORMAT(FROM_UNIXTIME(n.changed), '%d-%M-%Y') as changed
		FROM `node_field_data` n
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records48 = $query48->fetchAllAssoc('nid');
		foreach($records48 as $key=>$refrecord48){
		  if(array_key_exists($key,$records)){
			$records[$key]->changed = $refrecord48->changed;
		  }
		}
		
		$query49 = $db->query("SELECT
		n.nid,
        if(sb.field_sustainability_benefit_value = 0, 'False', 'True') as sus_benefit
		FROM `node_field_data` n
		LEFT JOIN node__field_sustainability_benefit sb ON sb.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records49 = $query49->fetchAllAssoc('nid');
		foreach($records49 as $key=>$refrecord49){
		  if(array_key_exists($key,$records)){
			$records[$key]->sus_benefit = $refrecord49->sus_benefit;
		  }
		}
		
		$query50 = $db->query("SELECT
		n.nid,
        ccb.field_client_carbon_benefit_value as carbon_benefit
		FROM `node_field_data` n
		LEFT JOIN node__field_client_carbon_benefit ccb ON ccb.entity_id = n.nid
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records50 = $query50->fetchAllAssoc('nid');
		foreach($records50 as $key=>$refrecord50){
		  if(array_key_exists($key,$records)){
			$records[$key]->carbon_benefit = $refrecord50->carbon_benefit;
		  }
		}
		
		$query51 = $db->query("SELECT
		n.nid,
        if(n.status = 0, 'Unpublished', 'Published') as published
		FROM `node_field_data` n
		LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
		WHERE n.type = 'reference'
        AND gd.gid = '$gid'
        group by n.nid;");
		$records51 = $query51->fetchAllAssoc('nid');
		foreach($records51 as $key=>$refrecord51){
		  if(array_key_exists($key,$records)){
			$records[$key]->published = $refrecord51->published;
		  }
		}
		
		$contact_query = $db->query("SELECT
        n.nid,
        (CASE
        WHEN top.field_contact_topics_value IS NULL THEN
        CONCAT('Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value)))
        ELSE
        CONCAT(CONCAT('TOPIC : ',GROUP_CONCAT(distinct top.field_contact_topics_value),'>','Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value))))
        END) as contact
        FROM `node_field_data` n
        LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
        LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
        LEFT JOIN paragraph__field_contact_name con ON con.entity_id = par_con.id
        LEFT JOIN paragraph__field_contact_topics top ON top.entity_id = par_con.id
        LEFT JOIN user__field_name_first con_fn ON con_fn.entity_id = con.field_contact_name_target_id
        LEFT JOIN user__field_name_last con_ln ON con_ln.entity_id = con.field_contact_name_target_id
        WHERE n.type = 'reference' AND gd.gid = '$gid' GROUP BY n.nid;");
        $referencecontactrecords = $contact_query->fetchAllAssoc('nid');

        foreach($referencecontactrecords as $key=>$assetcontact){
          if(array_key_exists($key,$records)){
            $records[$key]->contact = str_replace('>',';',$assetcontact->contact);
          }
        }
        
		$file_query = $db->query("SELECT
        n.nid,
        GROUP_CONCAT(CASE
          WHEN lin.field_link_uri IS NULL THEN 
          CONCAT('Kind of attachment: File','>>','Attachment(s):',fm.filename,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
          ELSE 
          CONCAT('Kind of attachment: Link','>>','Attachment(s):',lin.field_link_uri,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
        END) as Attachement
        FROM `node_field_data` n
        LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
        JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid AND par_con.parent_field_name = 'field_files'
        LEFT JOIN paragraph__field_attachment att ON att.entity_id = par_con.id
        LEFT JOIN file_managed fm ON fm.fid = att.field_attachment_target_id
        LEFT JOIN paragraph__field_entity_language lan ON lan.entity_id = par_con.id
        LEFT JOIN taxonomy_term_field_data lan_tax ON lan_tax.tid = lan.field_entity_language_target_id
        LEFT JOIN paragraph__field_file_date da ON da.entity_id = par_con.id
        LEFT JOIN paragraph__field_link lin ON lin.entity_id = par_con.id 
        LEFT JOIN paragraph__field_type_asset ta ON ta.entity_id = par_con.id
        WHERE n.type = 'reference' AND gd.gid = '$gid' GROUP BY n.nid;");

        $referencefilerecords = $file_query->fetchAllAssoc('nid');

       
        foreach($referencefilerecords as $key=>$referencefile){
          if(array_key_exists($key,$records)){
            $records[$key]->Attachement = str_replace('>>',';;',$referencefile->Attachement);
          }
        }
       
        
        // CSV FILE WRITING CODE
        $fields_mapping = array(
          'url' => 'URL',
          'primary_community' => 'Primary community',
          'referece_title' => 'Reference Name',
          'opp_id' => 'Opportunity ID',
          'submitter' => 'Submitter',
          'contact' => 'Contacts',
          'other_contributor' => 'Other Contributer',
          'Migrated contact' => 'Migrated contact',
          'account' => 'Account',
          'upa' => 'Ultimate Parent Account',
          'masking_client' => 'Alias Account Name',
          'masking_val' => 'Masked Account Name (Yes/ No)',
          'acc_type' => 'Account Type',
          'account_country' => 'Account Country',
          'acc_city' => 'Account City',
          'opp_lead' => 'Opportunity Lead',
          'confidentiality' => 'Confidentiality Level',
          'reference_usage' => 'Reference Usage',
          'status' => 'Status',
          'secondary_communities' => 'Secondary Communities',
          'selling_strategic_bu' => 'Selling Strategic Business Unit',
          'selling_bu' => 'Selling Business Unit',
          'selling_mu' => 'Selling Market Unit',
          'selling_ms' => 'Selling Market Segment',
          'selling_ru' => 'Selling Reporting Unit',
          'delivery_ms' => 'Delivery Market Segment',
          'gbl_sbu' => 'Delivery GBL/SBU',
          'sector' => 'Sector',
          'industry' => 'Industry',
          'industry_segment' => 'Industry Segment',
          'sector_initiative' => 'Sector Initiative (Marketing)',
          'legacy_sbu' => 'Legacy SBU/OU',
          'managed_services' => 'Managed Services (AM/IM)',
          'entry_portfolio' => 'Entry Portfolio',
          'offer' => 'Offer',
          'business_unit' => 'Business Unit',
          'alliance_partner' => 'Alliance/Partner',
          'technologies' => 'Technologies',
          //'community_taxonomy' => 'Community taxonomy',
          'community_folders' => 'Community Folders',
          'users_tags' => 'User tags',
          'contract_type' => 'Contract Type',
          'currency' => 'Currency',
          'tcv' => 'Total Contract Value',
          'deal_size' => 'Deal Size',
          'competitors' => 'Competitors',
          'start_date' => 'Start Date',
          'end_date' => 'End Date',
          'project_status' => 'Project Status',
          'next_milestone_date' => 'Next Milestone Date',
          'righshore_model'=>'Rightshore Model',
          'contries_that_deliver'=>'Capgemini Country(ies) that Delivered',
          'contries_where_deliver'=>'Client Country(ies) where Delivered',
          'Attachement' => 'Attachment(s)',
          'created' => 'Created',
          'changed' => 'Changed',
          'sus_benefit'=>'Sustainability Benefit',
          'carbon_benefit'=>'Client Carbon Benefit',
          'published'=>'Published'
        );
        $headers = array_values($fields_mapping);

        $directory = 'files/export/community/' . $gid;
        if (!file_exists($directory)) {
          mkdir($directory, 0777, TRUE);
        }
        $link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.csv';
        fopen($link,'w');
        $converted_link = $directory . '/PRISM_Export_CommID' . $gid . '_' . str_replace(' ', '_', $object[$type]) . '.xlsx';
        $list = array(
          $headers,
        );
        foreach($records as $i => $values) {
          foreach(array_keys($fields_mapping) as $key){
            $list[$i][] =  $values->$key;
          }
        }
        $fp = fopen($link, 'w');
        foreach ($list as $fields) {
          fputcsv($fp, $fields);
        }
        fclose($fp);
        $spreadsheet = IOFactory::load($link);

        $sheetData = $spreadsheet->getActiveSheet();

        $rows = [];
        $high = $sheetData->getHighestRow();

        if ($object[$type] == 'References') {
          $range_startenddate = 'AT2:AU' . $high;
          $range_milestonedate = 'AW2:AW' . $high;
          $range_creationdate = 'BB2:BB' . $high;
          $range_updatedate = 'BC2:BC' . $high;
          //Submitter column.
          $subrow = 2;
          $range_submitter = 'E2:E' . $high;
          $submitter_data = $sheetData->rangeToArray($range_submitter);
          foreach ($submitter_data as $sub) {
            if (isset($sub[0]) && !empty($sub[0])) {
              $submitter = explode('[',$sub[0]);
              $submittername = trim($submitter[0]);
              $spreadsheet->getActiveSheet()->setCellValue('E' . $subrow, $submittername);
            }
            $subrow++;
          }

          $startend_date_data = $sheetData->rangeToArray($range_startenddate);
          $milestone_date_data = $sheetData->rangeToArray($range_milestonedate);
          $creation_date_data = $sheetData->rangeToArray($range_creationdate);
          $update_date_data = $sheetData->rangeToArray($range_updatedate);

          $rownum = 2;
          // Date format change for Start and End Date column values.
          foreach ($startend_date_data as $data1) {
            $startdate_array = [];
            $enddate_array = [];
            $startdate_day = '';
            $startdate_month = '';
            $startdate_year = '';
            $enddate_day = '';
            $enddate_month = '';
            $enddate_year = '';

            if (isset($data1[0]) && !empty($data1[0])) {
              $startdatetime = strtotime($data1[0]);
              $startdatenewformat = date('Y-m-d', $startdatetime);
              $startdate_array = explode('-', $startdatenewformat);
              $startdate_day = $startdate_array[2];
              $startdate_month = $startdate_array[1];
              $startdate_year = $startdate_array[0];
            }
            if (isset($data1[1]) && !empty($data1[1])) {
              $enddatetime = strtotime($data1[1]);
              $enddatenewformat = date('Y-m-d', $enddatetime);
              $enddate_array = explode('-', $enddatenewformat);
              $enddate_day = $enddate_array[2];
              $enddate_month = $enddate_array[1];
              $enddate_year = $enddate_array[0];
            }

            if ($startdate_day != '' && $startdate_month != '' && $startdate_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('AT' . $rownum, '=DATE(' . $startdate_year . ',' . $startdate_month . ',' . $startdate_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('AT' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            if ($enddate_day != '' && $enddate_month != '' && $enddate_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('AU' . $rownum, '=DATE(' . $enddate_year . ',' . $enddate_month . ',' . $enddate_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('AU' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum++;
          }

          // Date format change for Milestone Date columns values.
          $rownum2 = 2;
          foreach ($milestone_date_data as $data2) {
            $milestone_array = [];
            $milestone_day = '';
            $milestone_month = '';
            $milestone_year = '';

            if (isset($data2[0]) && !empty($data2[0])) {
              $milestonetime = strtotime($data2[0]);
              $milestonenewformat = date('Y-m-d', $milestonetime);
              $milestone_array = explode('-', $milestonenewformat);
              $milestone_day = $milestone_array[2];
              $milestone_month = $milestone_array[1];
              $milestone_year = $milestone_array[0];
            }
            if ($milestone_day != '' && $milestone_month != '' && $milestone_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('AW' . $rownum2, '=DATE(' . $milestone_year . ',' . $milestone_month . ',' . $milestone_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('AW' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum2++;
          }

          // Date format change for Creation Date columns values.
          $rownum3 = 2;
          foreach ($creation_date_data as $data3) {
            $creation_array = [];
            $creation_day = '';
            $creation_month = '';
            $creation_year = '';

            if (isset($data3[0]) && !empty($data3[0])) {
              $creationtime = strtotime($data3[0]);
              $creationnewformat = date('Y-m-d', $creationtime);
              $creation_array = explode('-', $creationnewformat);
              $creation_day = $creation_array[2];
              $creation_month = $creation_array[1];
              $creation_year = $creation_array[0];
            }
            if ($creation_day != '' && $creation_month != '' && $creation_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('BB' . $rownum3, '=DATE(' . $creation_year . ',' . $creation_month . ',' . $creation_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('BB' . $rownum3)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum3++;
          }

          // Date format change for Update Date columns values.
          $rownum4 = 2;
          foreach ($update_date_data as $updatedata) {
            $update_array = [];
            $update_day = '';
            $update_month = '';
            $update_year = '';

            if (isset($updatedata[0]) && !empty($updatedata[0])) {
              $updatetime = strtotime($updatedata[0]);
              $updatenewformat = date('Y-m-d', $updatetime);
              $update_array = explode('-', $updatenewformat);
              $update_day = $update_array[2];
              $update_month = $update_array[1];
              $update_year = $update_array[0];
            }
            if ($update_day != '' && $update_month != '' && $update_year != '') {
              $spreadsheet->getActiveSheet()->setCellValue('BC' . $rownum4, '=DATE(' . $update_year . ',' . $update_month . ',' . $update_day . ')');
              $spreadsheet->getActiveSheet()->getStyle('BC' . $rownum4)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
            }
            $rownum4++;
          }

          // Dealsize field computation.
          $contract_currency_value = 'AP2:AQ' . $high;
          $contract_currency_value_data = $sheetData->rangeToArray($contract_currency_value);
          $currency_sign = [
            'AUD' => 'AU$',
            'BRL' => 'R$',
            'CNY' => '¥',
            'EUR' => '€',
            'GBP' => '£',
            'USD' => '$',
            'MXN' => 'Mex$',
          ];
          $row = '';
          foreach ($contract_currency_value_data as $id => $data4) {
            if (isset($data4[1]) && $data4[1] != 'null' && isset($data4[0]) && $data4[0] != 'null') {
              if (($data4[1] > 0 ||  $data4[1] == 0) && $data4[1] < 500001) {
                $dealsize = '0 ' . $currency_sign[$data4[0]] . ' - 0.5 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 500000 && $data4[1] < 1000001) {
                $dealsize = '0.5 M ' . $currency_sign[$data4[0]] . ' - 1 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 100000 && $data4[1] < 5000001) {
                $dealsize = '1 M ' . $currency_sign[$data4[0]] . ' - 5 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 500000 && $data4[1] < 10000001) {
                $dealsize = '5 M ' . $currency_sign[$data4[0]] . ' - 10 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 1000000 && $data4[1] < 20000001) {
                $dealsize = '10 M ' . $currency_sign[$data4[0]] . ' - 20 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 20000000 && $data4[1] < 50000001) {
                $dealsize = '20 M ' . $currency_sign[$data4[0]] . ' - 50 M' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
              elseif ($data4[1] > 50000000) {
                $dealsize = 'more than 50 M ' . $currency_sign[$data4[0]];
                $row = $id + 2;
                $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
              }
            }
          }

          // Project status field computation.
          $project_status_value = 'AT2:AU' . $high;
          $project_status_data = $sheetData->rangeToArray($project_status_value);
          $statusrow = '';
          foreach ($project_status_data as $psid => $data5) {
            if (isset($data5[1]) && $data5[1] != 'null' && isset($data5[0]) && $data5[0] != 'null') {
              $project_status = ' ';
              $date = new DrupalDateTime();
              $date->setTime(0, 0, 0);
              $current_date = $date->getTimestamp();
              $start_date = strtotime($data5[0]);
              $end_date = strtotime($data5[1]);

              if ($start_date < $end_date) {
                if ($current_date > $end_date) {
                  $project_status = t('Project Completion');
                  $statusrow = $psid + 2;
                  $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                }
                elseif ($current_date > $start_date) {
                  $project_status = t('Delivery');
                  $statusrow = $psid + 2;
                  $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                }
                else {
                  $project_status = t('New Win');
                  $statusrow = $psid + 2;
                  $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                }
              }
              else {
                if ((!empty($start_date) && !empty($end_date)) && ($start_date == $end_date) && ($current_date > $end_date)) {
                  $project_status = t('Project Completion');
                  $statusrow = $psid + 2;
                  $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                }
              }
            }
          }
        }

        $writer = new Xlsx($spreadsheet);
        $writer->save($converted_link);
        chmod($converted_link, 0777);
		    $subject = 'Export from PRISM - Community ID: ' . $gid . ' - ' . $object[$type];
		if(isset($gid) && $gid != '' && $gid != null){	
          $groupname_query = $db->query('SELECT label FROM {groups_field_data} WHERE id=' . $gid);
          $groupname = $groupname_query->fetchAll();
		}
        
        //success message
        if (file_exists($converted_link)) {
          $file_create = \Drupal::service('file_url_generator')->generateAbsoluteString($converted_link);
          
          $file_link = str_replace('http://','https://', $file_create); 
          $file_link .= "?".time();
          
          $body = 'You have requested to export ' . $object[$type] . ' from "' . $groupname[0]->label . '" community.<br />Please download the export file from <a href="' . $file_link . '">here</a>. Thank you.';
        } else {
          $body = 'You have requested to export ' . $object[$type] . ' from "' . $groupname[0]->label . '" community.<br />However, there were some issues preventing the export file to be generated.<br />Please try again, and contact the support team if you get the same error again.<br />Thank you.';  
        }

        $receivers = implode(';',$target_mail);
        $mailManager = \Drupal::service('plugin.manager.mail');
        $module = 'custom_export';
        $key = 'community_export';
        $to = $receivers;
        $params['message'] = $body;
        $params['subject'] = $subject;
        $langcode = 'en';
        $send = true;
        if(isset($receivers)){
          $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
        }
        if ($result['result'] != true) {
          $message = t('There was a problem sending your email notification to @email.', array('@email' => $to));
          \Drupal::messenger()->addError($message);
          //\Drupal::logger('mail-log')->error($message);
        }

        $message = t('An email notification has been sent to @email ', array('@email' => $to));
        \Drupal::messenger()->addStatus($message);
        //\Drupal::logger('mail-log')->notice($message);

        foreach ($userids as $key => $userid) {
          $num_updated = $db->update('export_primary_secondary_log')
          ->fields([
          'state' => 2,
          ])
          ->condition('gid', $gid, '=')
          ->condition('uid', $userid, 'IN')
          ->condition('state', 1, '=')
          ->condition('timestamp', $time[$key], '=')
          ->execute();
        }
		//dd(date("h:i:sa"));
      }
      else {
        echo 'Report not generated. Please try again later.';
        die;
      }
    }
    catch (Exception $e) {
      \Drupal::logger('widget')->error($e->getMessage());
    }
    $response = new AjaxResponse();
    return $response;
  }

  /**
   *
   */
  public function exportcommumityfiles() {
	  global $base_url;  
    try{
      $db = \Drupal::service('database');
      $check_available_query = $db->query("SELECT state FROM {export_cart_file_log} WHERE state = 1 ORDER BY timestamp ASC LIMIT 1");
      $in_progress = $check_available_query->fetchField();
      if (!$in_progress) {
        $files_query = $db->query("SELECT * FROM {export_cart_file_log} WHERE state = 0 ORDER BY timestamp ASC LIMIT 1");
        $results = $files_query->fetchAll();

        if (!empty($results)) {
          $gid = $results[0]->gid;
          $uid = $results[0]->uid;
          $type = $results[0]->type;
          $feature = $results[0]->feature;
          $timestamp = $results[0]->timestamp;
      
          $num_updated = $db->update('export_cart_file_log')
          ->fields([
          'state' => 1,
          ])
          ->condition('gid', $gid, '=')
          ->condition('type', $type, '=')
          ->condition('uid', $uid, '=')
          ->condition('state', 0, '=')
          ->condition('timestamp', $timestamp, '=')
          ->condition('feature', $feature, '=')
          ->execute();
          if(isset($uid) && $uid != '' && $uid != null){
            $target_users_query = $db->query('SELECT uid, mail FROM {users_field_data} WHERE uid=' . $uid);
            $target_users = $target_users_query->fetchAll();
            $target_mail = $target_users[0]->mail;
		  }
          
          $combine_with_file = 0;
          $export_from_community = TRUE;
          $cart_export_id = $results[0]->id;
          $arr = json_decode(json_encode($results), TRUE);
          foreach ($arr as $recordset) {
            $file_db_id = $recordset['id'];
            $results = explode(',', $recordset['nids']);
            foreach ($results as $key => $value) {
              $file_record = explode('-', $results[$key]);
              $fileresult[$recordset['uid']][] = ["nid" => $file_record[0], "fid" => $file_record[1]];
            }
          }
          // Date format CR start.
          $file_date = [];
          $node_records = [];
          foreach ($fileresult as $uid_key => $Fresult) {
            foreach ($Fresult as $value) {
              $result_file_details = get_export_file_details($value['fid']);
              $files_array = json_decode(json_encode($result_file_details), TRUE);
              $file_records[$uid_key][] = $files_array;
            }
          }
          
          foreach ($file_records as $uid_key => $record) {
            $directory = 'files/export/cart_file_export/' . $uid_key;
            if (!file_exists($directory)) {
              mkdir($directory, 0777, TRUE);
            }
            else {
              chmod($directory, 0777);
            }
            if ($export_from_community && $gid != 'all') {
              $filename = 'PRISM_Export_CommID' . $gid . '_Attachments';
            }
            else {
              $filename = 'PRISM_Export_CartID' . $cart_export_id . '_Attachments';
            }
            
            $spreadsheet = new Spreadsheet();
            $spreadsheet->getActiveSheet()->setCellValue('A1', 'File Name');
            $spreadsheet->getActiveSheet()->setCellValue('B1', 'Kind of Attachment');
            $spreadsheet->getActiveSheet()->setCellValue('C1', 'Language');
            $spreadsheet->getActiveSheet()->setCellValue('D1', 'Date');
            $spreadsheet->getActiveSheet()->setCellValue('E1', 'Knowledge Object URL');
            $spreadsheet->getActiveSheet()->setCellValue('F1', 'Knowledge Object Title');
            $spreadsheet->getActiveSheet()->setCellValue('G1', 'Community URL');
            $spreadsheet->getActiveSheet()->setCellValue('H1', 'Community Name');
            $spreadsheet->setActiveSheetIndex(0);
            $rowcount = 2;
            foreach ($record as $result) {
             
              $fileday = '';
              $filemonth = '';
              $fileyear = '';
              if (isset($result[0]['field_file_date_value']) && !empty($result[0]['field_file_date_value'])) {
                $filedate = strtotime($result[0]['field_file_date_value']);
                $filedatenew = date('Y-m-d', $filedate);
                $filedate_array = explode('-', $filedatenew);
                $fileday = $filedate_array[2];
                $filemonth = $filedate_array[1];
                $fileyear = $filedate_array[0];
              }
              // Date format CR start.
              $result[1]['knowledge_ob_url'] = str_replace('http://', 'https://', $result[1]['knowledge_ob_url']);
              $result[1]['community_url'] = str_replace('http://', 'https://', $result[1]['community_url']);

             if(isset($result[0]['filename']) && !empty($result[0]['filename'])){
                $spreadsheet->getActiveSheet()->setCellValue('A' . $rowcount, $result[0]['filename']);
			  }
			  if(isset($result[0]['field_type_of_document_value']) && !empty($result[0]['field_type_of_document_value'])){
                $spreadsheet->getActiveSheet()->setCellValue('B' . $rowcount, $result[0]['field_type_of_document_value']);
			  }
			  if(isset($result[0]['langcode']) && !empty($result[0]['langcode'])){
                $spreadsheet->getActiveSheet()->setCellValue('C' . $rowcount, $result[0]['langcode']);
			  }
			  if(isset($result[0]['field_file_date_value']) && !empty($result[0]['field_file_date_value'])){
                $spreadsheet->getActiveSheet()->setCellValue('D' . $rowcount, $result[0]['field_file_date_value']);
			  }
			  if(isset($result[0]['type']) && !empty($result[0]['type']) && isset($result[0]['nid']) && !empty($result[0]['nid'])){
                $spreadsheet->getActiveSheet()->setCellValue('E' . $rowcount, $base_url . $result[0]['type'] . '/' . $result[0]['nid']);
			  }
			  if(isset($result[0]['title']) && !empty($result[0]['title'])){
                $spreadsheet->getActiveSheet()->setCellValue('F' . $rowcount, $result[0]['title']);
			  }
			  if(isset($result[0]['gid']) && !empty($result[0]['gid'])){
                $spreadsheet->getActiveSheet()->setCellValue('G' . $rowcount, $base_url . $result[0]['gid']);
			  }
			  if(isset($result[0]['label']) && !empty($result[0]['label'])){
                $spreadsheet->getActiveSheet()->setCellValue('H' . $rowcount, $result[0]['label']);
			  }
              $rowcount++;
            }
            $writer = IOFactory::createWriter($spreadsheet, "Xlsx");
            $filesave = $directory . '/' . $filename . '.xlsx';
            $writer->save($filesave);
            chmod($filesave, 0777);
            $spreadsheet = IOFactory::load($filesave);
            $sheetData = $spreadsheet->getActiveSheet();
            $rows = [];
            $high = $sheetData->getHighestRow();
            $range_filedate = 'D2:D' . $high;
            $filedate_data = $sheetData->rangeToArray($range_filedate);
            $filenum = 2;
            foreach ($filedate_data as $data1) {
              $filedate_array = [];
              $filedate_day = '';
              $filedate_month = '';
              $filedate_year = '';

              if (isset($data1[0]) && !empty($data1[0])) {
                $filedatetime = strtotime($data1[0]);
                $filedatenewformat = date('Y-m-d', $filedatetime);
                $filedate_array = explode('-', $filedatenewformat);
                $filedate_day = $filedate_array[2];
                $filedate_month = $filedate_array[1];
                $filedate_year = $filedate_array[0];
              }
              if ($filedate_day != '' && $filedate_month != '' && $filedate_year != '') {
                $spreadsheet->getActiveSheet()->setCellValue('D' . $filenum, '=DATE(' . $filedate_year . ',' . $filedate_month . ',' . $filedate_day . ')');
                $spreadsheet->getActiveSheet()->getStyle('D' . $filenum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
              }
              $filenum++;
            }
            $writer = new Xlsx($spreadsheet);
            $writer->save($filesave);
            chmod($link, 0777);

          
            $num_updated = $db->update('export_cart_file_log')
              ->fields([
              'state' => 2,
              ])
              ->condition('gid', $gid, '=')
              ->condition('type', $type, '=')
              ->condition('uid', $uid, '=')
              ->condition('state', 1, '=')
              ->condition('timestamp', $timestamp, '=')
              ->condition('feature', $feature, '=')
              ->execute();


            $subject = 'Export from PRISM - Community ID: ' . $gid . ' - Attachments';
			if(isset($gid) && $gid != '' && $gid != null){
              $groupname_query = $db->query('SELECT label FROM {groups_field_data} WHERE id=' . $gid);
              $groupname = $groupname_query->fetchAll();
			}
            
            //success message
            if (file_exists($filesave)) {
              $file_create = \Drupal::service('file_url_generator')->generateAbsoluteString($filesave);
              $file_link = str_replace('http://','https://', $file_create); 
              $file_link .= "?".time();
              $body = 'You have requested to export Attachment(s) from "' . $groupname[0]->label . '" community.<br />Please download the export from <a href="' . $file_link . '">here</a>. Thank you.';
            } else {
              $body = 'There were some issues preventing the export file to be generated.<br />Please try again, and contact the support team if you get the same error again.<br />Thank you.';  
            }

            
            

            $mailManager = \Drupal::service('plugin.manager.mail');
            $module = 'custom_export';
            $key = 'community_export';
            $to = $target_mail;
            $params['message'] = $body;
            $params['subject'] = $subject;
            $langcode = 'en';
            $send = true;
			if(isset($target_mail) && $target_mail != '' && $target_mail != null){
              $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
			}
            
            

            $message = t('An email notification has been sent to @email ', array('@email' => $to));
            \Drupal::messenger()->addStatus($message);
            //\Drupal::logger('mail-log')->notice($message);

            
          }
        }
      }
      else {
        echo 'Report not generated. Please try again later.';
        die;
      }
    }
    catch (Exception $e) {
      \Drupal::logger('widget')->error($e->getMessage());
    }
	  $response = new AjaxResponse();
    return $response;
  }

  /**
   * Export from cart function.
   */ 
  public function exportfromcart() {
	  global $base_url;
    $db = \Drupal::service('database');
    $view = [
      'asset' => 'capgemini_browsing_widget_asset',
      'reference' => 'capgemini_browsing_widget_reference_secondary',
    ];
    $object = [
      'asset' => 'Assets',
      'reference' => 'References',
    ];
    $check_available_query = $db->query("SELECT id FROM {export_cart_log} WHERE state=1 ORDER BY timestamp ASC LIMIT 1");
    $available = $check_available_query->fetchAll();

    if (!$available) {
      $query = $db->query("SELECT * FROM {export_cart_log} WHERE state=0 ORDER BY timestamp ASC LIMIT 1");
      $items = $query->fetchAll();

      if (!empty($items)) {
        foreach ($items as $item) {
          $id = $item->id;
          $type = $item->type;
          $nids = $item->nids;
          $display_id = 'data_export_2';
          $gid = $item->gid;
          $uid = $item->uid;
          $feature = $item->feature;
          $timestamp = $item->timestamp;
          $itemid = $id;
          $num_updated = $db->update('export_cart_log')
            ->fields([
            'state' => 1,
            ])
            ->condition('gid', $gid, '=')
            ->condition('type', $type, '=')
            ->condition('uid', $uid, '=')
            ->condition('state', 0, '=')
            ->condition('timestamp', $timestamp, '=')
            ->condition('feature', $feature, '=')
            ->execute();

          $subject = 'Export from PRISM - Cart Items';
          $error = FALSE;
          $nids_array = explode(",", $nids);
          $total_items = count($nids_array);
          $num_of_items_query = $db->query("SELECT type , nid FROM {node_field_data} WHERE nid IN (" . $nids . ")");
          $num_of_items = $num_of_items_query->fetchAll();

          foreach ($num_of_items as $item) {
            $final[$item->type][] = $item->nid;
          }
          
          foreach ($final as $key => $value) {
            $val = implode(',', $value);
            if ($key == 'reference') {
              
				$url = $base_url.'/reference/';
				$query = $db->query("SELECT
				n.nid,
				concat('$url', n.nid) as url,
				grd.label as primary_community,
				n.title as referece_title
				FROM `node_field_data` n
				LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
				LEFT JOIN groups_field_data grd on grd.id = gd.gid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records = $query->fetchAllAssoc('nid');
				
				$query2 = $db->query("SELECT
				n.nid,
				op.field_opportunity_id_value as opp_id
				FROM `node_field_data` n
				LEFT JOIN node__field_opportunity_id op on op.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records2 = $query2->fetchAllAssoc('nid');
				foreach($records2 as $key=>$refrecord2){
				  if(array_key_exists($key,$records)){
					$records[$key]->opp_id = $refrecord2->opp_id;
				  }
				}
				
				$query3 = $db->query("SELECT
				n.nid,
				concat(fn.field_name_first_value, ' ', ln.field_name_last_value) as submitter
				FROM `node_field_data` n
				LEFT JOIN node__field_author sb ON sb.entity_id = n.nid
        LEFT JOIN user__field_name_first fn on fn.entity_id = n.uid
        LEFT JOIN user__field_name_last ln on ln.entity_id = n.uid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records3 = $query3->fetchAllAssoc('nid');
				foreach($records3 as $key=>$refrecord3){
				  if(array_key_exists($key,$records)){
					$records[$key]->submitter = $refrecord3->submitter;
				  }
				}

				$query4 = $db->query("SELECT
				n.nid,
				cli.field_client_account_value as account
				FROM `node_field_data` n
				LEFT JOIN node__field_client_account cli ON cli.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records4 = $query4->fetchAllAssoc('nid');
				foreach($records4 as $key=>$refrecord4){
				  if(array_key_exists($key,$records)){
					$records[$key]->account = $refrecord4->account;
				  }
				}
				
				$query5 = $db->query("SELECT
				n.nid,
				CONCAT(fn.field_name_first_value,' ',ln.field_name_last_value) as other_contributor
				FROM `node_field_data` n
				LEFT JOIN node__field_other_contributor oc ON oc.entity_id = n.nid
				LEFT JOIN user__field_name_first fn ON fn.entity_id = oc.field_other_contributor_target_id
				LEFT JOIN user__field_name_last ln ON ln.entity_id = oc.field_other_contributor_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records5 = $query5->fetchAllAssoc('nid');
				foreach($records5 as $key=>$refrecord5){
				  if(array_key_exists($key,$records)){
					$records[$key]->other_contributor = $refrecord5->other_contributor;
				  }
				}
				
				$query6 = $db->query("SELECT
				n.nid,
				mc.field_migrated_contact_value as migrated_contact
				FROM `node_field_data` n
				LEFT JOIN node__field_migrated_contact mc on mc.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records6 = $query6->fetchAllAssoc('nid');
				foreach($records6 as $key=>$refrecord6){
				  if(array_key_exists($key,$records)){
					$records[$key]->migrated_contact = $refrecord6->migrated_contact;
				  }
				}
				
				$query7 = $db->query("SELECT
				n.nid,
				upa.field_ultimate_parent_account_value as upa
				FROM `node_field_data` n
				LEFT JOIN node__field_ultimate_parent_account upa on upa.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records7 = $query7->fetchAllAssoc('nid');
				foreach($records7 as $key=>$refrecord7){
				  if(array_key_exists($key,$records)){
					$records[$key]->upa = $refrecord7->upa;
				  }
				}
				
				$query8 = $db->query("SELECT
				n.nid,
				aan.field_masking_client_names_value as masking_client
				FROM `node_field_data` n
				LEFT JOIN node__field_masking_client_names aan on aan.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records8 = $query8->fetchAllAssoc('nid');
				foreach($records8 as $key=>$refrecord8){
				  if(array_key_exists($key,$records)){
					$records[$key]->masking_client = $refrecord8->masking_client;
				  }
				}
				
				$query9 = $db->query("SELECT
				n.nid,
				if(em.field_enable_masking_value = 0, 'No', 'Yes') as masking_val
				FROM `node_field_data` n
				LEFT JOIN node__field_enable_masking em on em.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records9 = $query9->fetchAllAssoc('nid');
				foreach($records9 as $key=>$refrecord9){
				  if(array_key_exists($key,$records)){
					$records[$key]->masking_val = $refrecord9->masking_val;
				  }
				}
				
				$query10 = $db->query("SELECT
				n.nid,
				at.field_account_category_value as acc_type
				FROM `node_field_data` n
				LEFT JOIN node__field_account_category at on at.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records10 = $query10->fetchAllAssoc('nid');
				foreach($records10 as $key=>$refrecord10){
				  if(array_key_exists($key,$records)){
					$records[$key]->acc_type = $refrecord10->acc_type;
				  }
				}
				
				$query11 = $db->query("SELECT
				n.nid,
				ac_tax.name as account_country
				FROM `node_field_data` n
				LEFT JOIN node__field_account_country ac ON ac.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data ac_tax ON ac_tax.tid = ac.field_account_country_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records11 = $query11->fetchAllAssoc('nid');
				foreach($records11 as $key=>$refrecord11){
				  if(array_key_exists($key,$records)){
					$records[$key]->account_country = $refrecord11->account_country;
				  }
				}
				
				
				$query12 = $db->query("SELECT
				n.nid,
				act.field_account_city_value as acc_city
				FROM `node_field_data` n
				LEFT JOIN node__field_account_city act ON act.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records12 = $query12->fetchAllAssoc('nid');
				foreach($records12 as $key=>$refrecord12){
				  if(array_key_exists($key,$records)){
					$records[$key]->acc_city = $refrecord12->acc_city;
				  }
				}
				
				$query13 = $db->query("SELECT
				n.nid,
				CONCAT(ofn.field_name_first_value,' ',oln.field_name_last_value) as opp_lead
				FROM `node_field_data` n
				LEFT JOIN node__field_opportunity_lead ol ON ol.entity_id = n.nid
				LEFT JOIN user__field_name_first ofn ON ofn.entity_id = ol.field_opportunity_lead_target_id
				LEFT JOIN user__field_name_last oln ON oln.entity_id = ol.field_opportunity_lead_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records13 = $query13->fetchAllAssoc('nid');
				foreach($records13 as $key=>$refrecord13){
				  if(array_key_exists($key,$records)){
					$records[$key]->opp_lead = $refrecord13->opp_lead;
				  }
				}
				
				$query14 = $db->query("SELECT
				n.nid,
				ps.field_permission_status_value as confidentiality
				FROM `node_field_data` n
				LEFT JOIN node__field_permission_status ps ON ps.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records14 = $query14->fetchAllAssoc('nid');
				foreach($records14 as $key=>$refrecord14){
				  if(array_key_exists($key,$records)){
					$records[$key]->confidentiality = $refrecord14->confidentiality;
				  }
				}
				
				
				$query15 = $db->query("SELECT
				n.nid,
				group_concat(distinct ru.field_reference_usage_value) as reference_usage
				FROM `node_field_data` n
				LEFT JOIN node__field_reference_usage ru ON ru.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records15 = $query15->fetchAllAssoc('nid');
				foreach($records15 as $key=>$refrecord15){
				  if(array_key_exists($key,$records)){
					$records[$key]->reference_usage = $refrecord15->reference_usage;
				  }
				}

				$query16 = $db->query("SELECT
				n.nid,
				(CASE
				  WHEN st.field_status_rf_value = 0 THEN 'Live - Not reviewed by Community Leaders/Moderators'
				  WHEN st.field_status_rf_value = 1 THEN 'Live Gold - Validated by Community Leaders/Moderators'
				  WHEN st.field_status_rf_value = 2 THEN 'Archived'
				  ELSE ''
				END) as status
				FROM `node_field_data` n
				LEFT JOIN node__field_status_rf st ON n.nid = st.entity_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records16 = $query16->fetchAllAssoc('nid');
				foreach($records16 as $key=>$refrecord16){
				  if(array_key_exists($key,$records)){
					$records[$key]->status = $refrecord16->status;
				  }
				}
				
				$query17 = $db->query("SELECT
				n.nid,
				group_concat(distinct ssbu_tax.name) as selling_strategic_bu
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_strategic_unit ssbu ON ssbu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data ssbu_tax ON ssbu_tax.tid = ssbu.field_selling_strategic_unit_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records17 = $query17->fetchAllAssoc('nid');
				foreach($records17 as $key=>$refrecord17){
				  if(array_key_exists($key,$records)){
					$records[$key]->selling_strategic_bu = $refrecord17->selling_strategic_bu;
				  }
				}
				
				$query18 = $db->query("SELECT
				n.nid,
				group_concat(distinct sbu_tax.name) as selling_bu
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_business_unit sbu ON sbu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sbu_tax ON sbu_tax.tid = sbu.field_selling_business_unit_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records18 = $query18->fetchAllAssoc('nid');
				foreach($records18 as $key=>$refrecord18){
				  if(array_key_exists($key,$records)){
					$records[$key]->selling_bu = $refrecord18->selling_bu;
				  }
				}
				
				$query19 = $db->query("SELECT
				n.nid,
				group_concat(distinct smu_tax.name) as selling_mu
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_market_unit smu ON smu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data smu_tax ON smu_tax.tid = smu.field_selling_market_unit_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records19 = $query19->fetchAllAssoc('nid');
				foreach($records19 as $key=>$refrecord19){
				  if(array_key_exists($key,$records)){
					$records[$key]->selling_mu = $refrecord19->selling_mu;
				  }
				}
				
				$query20 = $db->query("SELECT
				n.nid,
				group_concat(distinct sms_tax.name) as selling_ms
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_market_segment sms ON sms.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sms_tax ON sms_tax.tid = sms.field_selling_market_segment_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records20 = $query20->fetchAllAssoc('nid');
				foreach($records20 as $key=>$refrecord20){
				  if(array_key_exists($key,$records)){
					$records[$key]->selling_ms = $refrecord20->selling_ms;
				  }
				}
				
				$query21 = $db->query("SELECT
				n.nid,
				group_concat(distinct sru_tax.name) as selling_ru
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_reporting_unit sru ON sru.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sru_tax ON sru_tax.tid = sru.field_selling_reporting_unit_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records21 = $query21->fetchAllAssoc('nid');
				foreach($records21 as $key=>$refrecord21){
				  if(array_key_exists($key,$records)){
					$records[$key]->selling_ru = $refrecord21->selling_ru;
				  }
				}
				
				$query22 = $db->query("SELECT
				n.nid,
				group_concat(distinct dms_tax.name) as delivery_ms
				FROM `node_field_data` n
				LEFT JOIN node__field_delivery_market_segment dms ON dms.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data dms_tax ON dms_tax.tid = dms.field_delivery_market_segment_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records22 = $query22->fetchAllAssoc('nid');
				foreach($records22 as $key=>$refrecord22){
				  if(array_key_exists($key,$records)){
					$records[$key]->delivery_ms = $refrecord22->delivery_ms;
				  }
				}
				
				$query23 = $db->query("SELECT
				n.nid,
				group_concat(distinct gblsb_tax.name) as gbl_sbu
				FROM `node_field_data` n
				LEFT JOIN node__field_delivery_gbl_sbu gblsb ON gblsb.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data gblsb_tax ON gblsb_tax.tid = gblsb.field_delivery_gbl_sbu_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records23 = $query23->fetchAllAssoc('nid');
				foreach($records23 as $key=>$refrecord23){
				  if(array_key_exists($key,$records)){
					$records[$key]->gbl_sbu = $refrecord23->gbl_sbu;
				  }
				}
				
				$query24 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT sec_tax.name) as sector
				FROM `node_field_data` n
				LEFT JOIN node__field_sector sec ON sec.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sec_tax ON sec_tax.tid = sec.field_sector_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records24 = $query24->fetchAllAssoc('nid');
				foreach($records24 as $key=>$refrecord24){
				  if(array_key_exists($key,$records)){
					$records[$key]->sector = $refrecord24->sector;
				  }
				}
				
				$query25 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT seg_tax.name) as industry
				FROM `node_field_data` n
				LEFT JOIN node__field_segment seg ON seg.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data seg_tax ON seg_tax.tid = seg.field_segment_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records25 = $query25->fetchAllAssoc('nid');
				foreach($records25 as $key=>$refrecord25){
				  if(array_key_exists($key,$records)){
					$records[$key]->industry = $refrecord25->industry;
				  }
				}
				
				$query26 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT sseg_tax.name) as industry_segment
				FROM `node_field_data` n
				LEFT JOIN node__field_subsegment sseg ON sseg.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sseg_tax ON sseg_tax.tid = sseg.field_subsegment_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records26 = $query26->fetchAllAssoc('nid');
				foreach($records26 as $key=>$refrecord26){
				  if(array_key_exists($key,$records)){
					$records[$key]->industry_segment = $refrecord26->industry_segment;
				  }
				}
				
				$query27 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT si_tax.name) as sector_initiative
				FROM `node_field_data` n
				LEFT JOIN node__field_sector_initiative si ON si.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data si_tax ON si_tax.tid = si.field_sector_initiative_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records27 = $query27->fetchAllAssoc('nid');
				foreach($records27 as $key=>$refrecord27){
				  if(array_key_exists($key,$records)){
					$records[$key]->sector_initiative = $refrecord27->sector_initiative;
				  }
				}
				
				$query28 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT lsbu_tax.name) as legacy_sbu
				FROM `node_field_data` n
				LEFT JOIN node__field_entity_sbu lsbu ON lsbu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data lsbu_tax ON lsbu_tax.tid = lsbu.field_entity_sbu_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records28 = $query28->fetchAllAssoc('nid');
				foreach($records28 as $key=>$refrecord28){
				  if(array_key_exists($key,$records)){
					$records[$key]->legacy_sbu = $refrecord28->legacy_sbu;
				  }
				}
				
				$query29 = $db->query("SELECT
				n.nid,
				if(ms.field_managed_services_am_im__value = 0, 'False', 'True') as manages_services
				FROM `node_field_data` n
				LEFT JOIN node__field_managed_services_am_im_ ms ON ms.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records29 = $query29->fetchAllAssoc('nid');
				foreach($records29 as $key=>$refrecord29){
				  if(array_key_exists($key,$records)){
					$records[$key]->manages_services = $refrecord29->manages_services;
				  }
				}
				
				$query30 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT ep_tax.name) as entry_portfolio
				FROM `node_field_data` n
				LEFT JOIN node__field_entry_portfolio ep ON ep.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data ep_tax ON ep_tax.tid = ep.field_entry_portfolio_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records30 = $query30->fetchAllAssoc('nid');
				foreach($records30 as $key=>$refrecord30){
				  if(array_key_exists($key,$records)){
					$records[$key]->entry_portfolio = $refrecord30->entry_portfolio;
				  }
				}
				
				$query31 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT of_tax.name) as offer
				FROM `node_field_data` n
				LEFT JOIN node__field_offer of ON of.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data of_tax ON of_tax.tid = of.field_offer_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records31 = $query31->fetchAllAssoc('nid');
				foreach($records31 as $key=>$refrecord31){
				  if(array_key_exists($key,$records)){
					$records[$key]->offer = $refrecord31->offer;
				  }
				}
				
				
				$query32 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT par_tax.name) as alliance_partner
				FROM `node_field_data` n
				LEFT JOIN node__field_partner par ON par.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data par_tax ON par_tax.tid = par.field_partner_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records32 = $query32->fetchAllAssoc('nid');
				foreach($records32 as $key=>$refrecord32){
				  if(array_key_exists($key,$records)){
					$records[$key]->alliance_partner = $refrecord32->alliance_partner;
				  }
				}
				
				$query33 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT tec_tax.name) as technologies
				FROM `node_field_data` n
				LEFT JOIN node__field_technologies tec ON tec.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data tec_tax ON tec_tax.tid = tec.field_technologies_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records33 = $query33->fetchAllAssoc('nid');
				foreach($records33 as $key=>$refrecord33){
				  if(array_key_exists($key,$records)){
					$records[$key]->technologies = $refrecord33->technologies;
				  }
				}
				
				$query34 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT utag_tax.name) as users_tags
				FROM `node_field_data` n
				LEFT JOIN node__field_tags utag ON utag.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data utag_tax ON utag_tax.tid = utag.field_tags_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records34 = $query34->fetchAllAssoc('nid');
				foreach($records34 as $key=>$refrecord34){
				  if(array_key_exists($key,$records)){
					$records[$key]->users_tags = $refrecord34->users_tags;
				  }
				}
				
				$query35 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT gfdd.label) as secondary_communities
				FROM `node_field_data` n
				LEFT JOIN node__field_second_communities sc ON sc.entity_id = n.nid
				LEFT JOIN groups_field_data gfdd on gfdd.id = sc.field_second_communities_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records35 = $query35->fetchAllAssoc('nid');
				foreach($records35 as $key=>$refrecord35){
				  if(array_key_exists($key,$records)){
					$records[$key]->secondary_communities = $refrecord35->secondary_communities;
				  }
				}
				
				$query36 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT comfol_tax.name) as community_folders
				FROM `node_field_data` n
				LEFT JOIN node__field_community_folders comfol ON comfol.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data comfol_tax ON comfol_tax.tid = comfol.field_community_folders_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records36 = $query36->fetchAllAssoc('nid');
				foreach($records36 as $key=>$refrecord36){
				  if(array_key_exists($key,$records)){
					$records[$key]->community_folders = $refrecord36->community_folders;
				  }
				}
				
				
				$query37 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT ct.field_contract_type_value) as contract_type
				FROM `node_field_data` n
				LEFT JOIN node__field_contract_type ct ON ct.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records37 = $query37->fetchAllAssoc('nid');
				foreach($records37 as $key=>$refrecord37){
				  if(array_key_exists($key,$records)){
					$records[$key]->contract_type = $refrecord37->contract_type;
				  }
				}
				
				$query38 = $db->query("SELECT
				n.nid,
				cr.field_currency_value as currency
				FROM `node_field_data` n
				LEFT JOIN node__field_currency cr ON cr.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records38 = $query38->fetchAllAssoc('nid');
				foreach($records38 as $key=>$refrecord38){
				  if(array_key_exists($key,$records)){
					$records[$key]->currency = $refrecord38->currency;
				  }
				}
				
				$query39 = $db->query("SELECT
				n.nid,
				tcv.field_contract_value_value as tcv
				FROM `node_field_data` n
				LEFT JOIN node__field_contract_value tcv ON tcv.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records39 = $query39->fetchAllAssoc('nid');
				foreach($records39 as $key=>$refrecord39){
				  if(array_key_exists($key,$records)){
					$records[$key]->tcv = $refrecord39->tcv;
				  }
				}
				
				$query40 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT compt_tax.name) as competitors
				FROM `node_field_data` n
				LEFT JOIN node__field_competitors_rf compt ON compt.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data compt_tax ON compt_tax.tid = compt.field_competitors_rf_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records40 = $query40->fetchAllAssoc('nid');
				foreach($records40 as $key=>$refrecord40){
				  if(array_key_exists($key,$records)){
					$records[$key]->competitors = $refrecord40->competitors;
				  }
				}
				
				$query41 = $db->query("SELECT
				n.nid,
				strd.field_engagement_start_date_value as start_date
				FROM `node_field_data` n
				LEFT JOIN node__field_engagement_start_date strd ON strd.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records41 = $query41->fetchAllAssoc('nid');
				foreach($records41 as $key=>$refrecord41){
				  if(array_key_exists($key,$records)){
					$records[$key]->start_date = $refrecord41->start_date;
				  }
				}
				
				$query42 = $db->query("SELECT
				n.nid,
				endt.field_engagement_end_date_value as end_date
				FROM `node_field_data` n
				LEFT JOIN node__field_engagement_end_date endt ON endt.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records42 = $query42->fetchAllAssoc('nid');
				foreach($records42 as $key=>$refrecord42){
				  if(array_key_exists($key,$records)){
					$records[$key]->end_date = $refrecord42->end_date;
				  }
				}
				
				$query43 = $db->query("SELECT
				n.nid,
				nmd.field_milestone_date_value as next_milestone_date
				FROM `node_field_data` n
				LEFT JOIN node__field_milestone_date nmd ON nmd.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records43 = $query43->fetchAllAssoc('nid');
				foreach($records43 as $key=>$refrecord43){
				  if(array_key_exists($key,$records)){
					$records[$key]->next_milestone_date = $refrecord43->next_milestone_date;
				  }
				}
				
				$query44 = $db->query("SELECT
				n.nid,
				rsm.field_rightshore_model_value as righshore_model
				FROM `node_field_data` n
				LEFT JOIN node__field_rightshore_model rsm ON rsm.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records44 = $query44->fetchAllAssoc('nid');
				foreach($records44 as $key=>$refrecord44){
				  if(array_key_exists($key,$records)){
					$records[$key]->righshore_model = $refrecord44->righshore_model;
				  }
				}
				
				$query45 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT ctd_tax.name) as contries_that_deliver
				FROM `node_field_data` n
				LEFT JOIN node__field_capgemini_country_ies_that ctd ON ctd.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data ctd_tax ON ctd_tax.tid = ctd.field_capgemini_country_ies_that_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records45 = $query45->fetchAllAssoc('nid');
				foreach($records45 as $key=>$refrecord45){
				  if(array_key_exists($key,$records)){
					$records[$key]->contries_that_deliver = $refrecord45->contries_that_deliver;
				  }
				}
				
				$query46 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT cwd_tax.name) as contries_where_deliver
				FROM `node_field_data` n
				LEFT JOIN node__field_entity_country cwd ON cwd.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data cwd_tax ON cwd_tax.tid = cwd.field_entity_country_target_id
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records46 = $query46->fetchAllAssoc('nid');
				foreach($records46 as $key=>$refrecord46){
				  if(array_key_exists($key,$records)){
					$records[$key]->contries_that_deliver = $refrecord46->contries_that_deliver;
				  }
				}
				
				$query47 = $db->query("SELECT
				n.nid,
				DATE_FORMAT(FROM_UNIXTIME(nfr.created), '%d-%M-%Y') as created
				FROM `node_field_data` n
				LEFT JOIN node_field_revision nfr on nfr.nid = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records47 = $query47->fetchAllAssoc('nid');
				foreach($records47 as $key=>$refrecord47){
				  if(array_key_exists($key,$records)){
					$records[$key]->created = $refrecord47->created;
				  }
				}
				
				$query48 = $db->query("SELECT
				n.nid,
				DATE_FORMAT(FROM_UNIXTIME(n.changed), '%d-%M-%Y') as changed
				FROM `node_field_data` n
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records48 = $query48->fetchAllAssoc('nid');
				foreach($records48 as $key=>$refrecord48){
				  if(array_key_exists($key,$records)){
					$records[$key]->changed = $refrecord48->changed;
				  }
				}
				
				$query49 = $db->query("SELECT
				n.nid,
				if(sb.field_sustainability_benefit_value = 0, 'False', 'True') as sus_benefit
				FROM `node_field_data` n
				LEFT JOIN node__field_sustainability_benefit sb ON sb.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records49 = $query49->fetchAllAssoc('nid');
				foreach($records49 as $key=>$refrecord49){
				  if(array_key_exists($key,$records)){
					$records[$key]->sus_benefit = $refrecord49->sus_benefit;
				  }
				}
				
				$query50 = $db->query("SELECT
				n.nid,
				ccb.field_client_carbon_benefit_value as carbon_benefit
				FROM `node_field_data` n
				LEFT JOIN node__field_client_carbon_benefit ccb ON ccb.entity_id = n.nid
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records50 = $query50->fetchAllAssoc('nid');
				foreach($records50 as $key=>$refrecord50){
				  if(array_key_exists($key,$records)){
					$records[$key]->carbon_benefit = $refrecord50->carbon_benefit;
				  }
				}
				
				$query51 = $db->query("SELECT
				n.nid,
				if(n.status = 0, 'Unpublished', 'Published') as published
				FROM `node_field_data` n
				WHERE n.type = 'reference'
				AND n.nid in ($val)
				group by n.nid;");
				$records51 = $query51->fetchAllAssoc('nid');
				foreach($records51 as $key=>$refrecord51){
				  if(array_key_exists($key,$records)){
					$records[$key]->published = $refrecord51->published;
				  }
				}
				

                $contact_query = $db->query("SELECT
                n.nid,
                (CASE
                WHEN top.field_contact_topics_value IS NULL THEN
                CONCAT('Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value)))
                ELSE
                CONCAT(CONCAT('TOPIC : ',GROUP_CONCAT(distinct top.field_contact_topics_value),'>','Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value))))
                END) as contact
                FROM `node_field_data` n
                LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
                LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
                LEFT JOIN paragraph__field_contact_name con ON con.entity_id = par_con.id
                LEFT JOIN paragraph__field_contact_topics top ON top.entity_id = par_con.id
                LEFT JOIN user__field_name_first con_fn ON con_fn.entity_id = con.field_contact_name_target_id
                LEFT JOIN user__field_name_last con_ln ON con_ln.entity_id = con.field_contact_name_target_id
                WHERE n.type = 'reference' AND n.nid in ($val) GROUP BY n.nid;");
                $referencecontactrecords = $contact_query->fetchAllAssoc('nid');

                foreach($referencecontactrecords as $key=>$assetcontact){
                  if(array_key_exists($key,$records)){
                    $records[$key]->contact = str_replace('>',';',$assetcontact->contact);
                  }
                }

                $file_query = $db->query("SELECT
                n.nid,
                GROUP_CONCAT(CASE
                  WHEN lin.field_link_uri IS NULL THEN 
                  CONCAT('Kind of attachment: File','>>','Attachment(s):',fm.filename,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
                  ELSE 
                  CONCAT('Kind of attachment: Link','>>','Attachment(s):',lin.field_link_uri,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
                END) as Attachement
                FROM `node_field_data` n
                LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
                JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid AND par_con.parent_field_name = 'field_files'
                LEFT JOIN paragraph__field_attachment att ON att.entity_id = par_con.id
                LEFT JOIN file_managed fm ON fm.fid = att.field_attachment_target_id
                LEFT JOIN paragraph__field_entity_language lan ON lan.entity_id = par_con.id
                LEFT JOIN taxonomy_term_field_data lan_tax ON lan_tax.tid = lan.field_entity_language_target_id
                LEFT JOIN paragraph__field_file_date da ON da.entity_id = par_con.id
                LEFT JOIN paragraph__field_link lin ON lin.entity_id = par_con.id 
                LEFT JOIN paragraph__field_type_asset ta ON ta.entity_id = par_con.id
                WHERE n.type = 'reference' AND n.nid in ($val) GROUP BY n.nid;");

                $referencefilerecords = $file_query->fetchAllAssoc('nid');

                foreach($referencefilerecords as $key=>$referencefile){
                  if(array_key_exists($key,$records)){
                    $records[$key]->Attachement = str_replace('>>',';;',$referencefile->Attachement);
                  }
                }
                
                // CSV FILE WRITING CODE
                $fields_mapping = array(
                  'url' => 'URL',
                  'primary_community' => 'Primary community',
                  'referece_title' => 'Reference Name',
                  'opp_id' => 'Opportunity ID',
                  'submitter' => 'Submitter',
                  'contact' => 'Contacts',
                  'other_contributor' => 'Other Contributer',
                  'Migrated contact' => 'Migrated contact',
                  'account' => 'Account',
                  'upa' => 'Ultimate Parent Account',
                  'masking_client' => 'Alias Account Name',
                  'masking_val' => 'Masked Account Name (Yes/ No)',
                  'acc_type' => 'Account Type',
                  'account_country' => 'Account Country',
                  'acc_city' => 'Account City',
                  'opp_lead' => 'Opportunity Lead',
                  'confidentiality' => 'Confidentiality Level',
                  'reference_usage' => 'Reference Usage',
                  'status' => 'Status',
                  'secondary_communities' => 'Secondary Communities',
                  'selling_strategic_bu' => 'Selling Strategic Business Unit',
                  'selling_bu' => 'Selling Business Unit',
                  'selling_mu' => 'Selling Market Unit',
                  'selling_ms' => 'Selling Market Segment',
                  'selling_ru' => 'Selling Reporting Unit',
                  'delivery_ms' => 'Delivery Market Segment',
                  'gbl_sbu' => 'Delivery GBL/SBU',
                  'sector' => 'Sector',
                  'industry' => 'Industry',
                  'industry_segment' => 'Industry Segment',
                  'sector_initiative' => 'Sector Initiative (Marketing)',
                  'legacy_sbu' => 'Legacy SBU/OU',
                  'managed_services' => 'Managed Services (AM/IM)',
                  'entry_portfolio' => 'Entry Portfolio',
                  'offer' => 'Offer',
                  'business_unit' => 'Business Unit',
                  'alliance_partner' => 'Alliance/Partner',
                  'technologies' => 'Technologies',
                  //'community_taxonomy' => 'Community taxonomy',
                  'community_folders' => 'Community Folders',
                  'users_tags' => 'User tags',
                  'contract_type' => 'Contract Type',
                  'currency' => 'Currency',
                  'tcv' => 'Total Contract Value',
                  'deal_size' => 'Deal Size',
                  'competitors' => 'Competitors',
                  'start_date' => 'Start Date',
                  'end_date' => 'End Date',
                  'project_status' => 'Project Status',
                  'next_milestone_date' => 'Next Milestone Date',
                  'righshore_model'=>'Rightshore Model',
                  'contries_that_deliver'=>'Capgemini Country(ies) that Delivered',
                  'contries_where_deliver'=>'Client Country(ies) where Delivered',
                  'Attachement' => 'Attachment(s)',
                  'created' => 'Created',
                  'changed' => 'Changed',
                  'sus_benefit'=>'Sustainability Benefit',
                  'carbon_benefit'=>'Client Carbon Benefit',
                  'published'=>'Published'
                );
                $headers = array_values($fields_mapping);

                $directory = 'files/export/cart/' . $uid;
                if (!file_exists($directory)) {
                  mkdir($directory, 0777, TRUE);
                }
                
                $reflink = $directory . '/PRISM_Export_CartID' . $itemid . '_reference.csv';
                fopen($reflink,'w');
                $refconverted_link = $directory . '/PRISM_Export_CartID' . $itemid . '_reference.xlsx';

                $list = array(
                  $headers,
                );
                foreach($records as $i => $values) {
                  foreach(array_keys($fields_mapping) as $key){
                    $list[$i][] =  $values->$key;
                  }
                }
                $fp = fopen($reflink, 'w');
                foreach ($list as $fields) {
                  fputcsv($fp, $fields);
                }
                fclose($fp);
                $spreadsheet = IOFactory::load($reflink);

                $sheetData = $spreadsheet->getActiveSheet();

                $rows = [];
                $high = $sheetData->getHighestRow();

                $range_startenddate = 'AT2:AU' . $high;
                $range_milestonedate = 'AW2:AW' . $high;
				$range_creationdate = 'BB2:BB' . $high;
				$range_updatedate = 'BC2:BC' . $high;
                $subrow = 2;
                $range_submitter = 'E2:E' . $high;
                $submitter_data = $sheetData->rangeToArray($range_submitter);
                foreach ($submitter_data as $sub) {
                  if (isset($sub[0]) && !empty($sub[0])) {
                    $submitter = explode('[',$sub[0]);
                    $submittername = trim($submitter[0]);
                    $spreadsheet->getActiveSheet()->setCellValue('E' . $subrow, $submittername);
                  }
                  $subrow++;
                }
                $startend_date_data = $sheetData->rangeToArray($range_startenddate);
                $milestone_date_data = $sheetData->rangeToArray($range_milestonedate);
                $creation_date_data = $sheetData->rangeToArray($range_creationdate);
                $update_date_data = $sheetData->rangeToArray($range_updatedate);

                $rownum = 2;
                // Date format change for Start and End Date column values.
                foreach ($startend_date_data as $data1) {
                  $startdate_array = [];
                  $enddate_array = [];
                  $startdate_day = '';
                  $startdate_month = '';
                  $startdate_year = '';
                  $enddate_day = '';
                  $enddate_month = '';
                  $enddate_year = '';

                  if (isset($data1[0]) && !empty($data1[0])) {
                    $startdatetime = strtotime($data1[0]);
                    $startdatenewformat = date('Y-m-d', $startdatetime);
                    $startdate_array = explode('-', $startdatenewformat);
                    $startdate_day = $startdate_array[2];
                    $startdate_month = $startdate_array[1];
                    $startdate_year = $startdate_array[0];
                  }
                  if (isset($data1[1]) && !empty($data1[1])) {
                    $enddatetime = strtotime($data1[1]);
                    $enddatenewformat = date('Y-m-d', $enddatetime);
                    $enddate_array = explode('-', $enddatenewformat);
                    $enddate_day = $enddate_array[2];
                    $enddate_month = $enddate_array[1];
                    $enddate_year = $enddate_array[0];
                  }

                  if ($startdate_day != '' && $startdate_month != '' && $startdate_year != '') {
					$spreadsheet->getActiveSheet()->setCellValue('AT' . $rownum, '=DATE(' . $startdate_year . ',' . $startdate_month . ',' . $startdate_day . ')');
					$spreadsheet->getActiveSheet()->getStyle('AT' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
				  }
				  if ($enddate_day != '' && $enddate_month != '' && $enddate_year != '') {
					$spreadsheet->getActiveSheet()->setCellValue('AU' . $rownum, '=DATE(' . $enddate_year . ',' . $enddate_month . ',' . $enddate_day . ')');
					$spreadsheet->getActiveSheet()->getStyle('AU' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
				  }
                  $rownum++;
                }

                // Date format change for Milestone Date columns values.
                $rownum2 = 2;
                foreach ($milestone_date_data as $data2) {
                  $milestone_array = [];
                  $milestone_day = '';
                  $milestone_month = '';
                  $milestone_year = '';

                  if (isset($data2[0]) && !empty($data2[0])) {
                    $milestonetime = strtotime($data2[0]);
                    $milestonenewformat = date('Y-m-d', $milestonetime);
                    $milestone_array = explode('-', $milestonenewformat);
                    $milestone_day = $milestone_array[2];
                    $milestone_month = $milestone_array[1];
                    $milestone_year = $milestone_array[0];
                  }

                  if ($milestone_day != '' && $milestone_month != '' && $milestone_year != '') {
                   $spreadsheet->getActiveSheet()->setCellValue('AW' . $rownum2, '=DATE(' . $milestone_year . ',' . $milestone_month . ',' . $milestone_day . ')');
                   $spreadsheet->getActiveSheet()->getStyle('AW' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  $rownum2++;
                }

                // Date format change for Creation Date columns values.
                $rownum3 = 2;
                foreach ($creation_date_data as $data3) {
                  $creation_array = [];
                  $creation_day = '';
                  $creation_month = '';
                  $creation_year = '';

                  if (isset($data3[0]) && !empty($data3[0])) {
                    $creationtime = strtotime($data3[0]);
                    $creationnewformat = date('Y-m-d', $creationtime);
                    $creation_array = explode('-', $creationnewformat);
                    $creation_day = $creation_array[2];
                    $creation_month = $creation_array[1];
                    $creation_year = $creation_array[0];
                  }
                  if ($creation_day != '' && $creation_month != '' && $creation_year != '') {
                    $spreadsheet->getActiveSheet()->setCellValue('BB' . $rownum3, '=DATE(' . $creation_year . ',' . $creation_month . ',' . $creation_day . ')');
                    $spreadsheet->getActiveSheet()->getStyle('BB' . $rownum3)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  $rownum3++;
                }

                // Date format change for Update Date columns values.
                $rownum4 = 2;
                foreach ($update_date_data as $updatedata) {
                  $update_array = [];
                  $update_day = '';
                  $update_month = '';
                  $update_year = '';

                  if (isset($updatedata[0]) && !empty($updatedata[0])) {
                    $updatetime = strtotime($updatedata[0]);
                    $updatenewformat = date('Y-m-d', $updatetime);
                    $update_array = explode('-', $updatenewformat);
                    $update_day = $update_array[2];
                    $update_month = $update_array[1];
                    $update_year = $update_array[0];
                  }
                  if ($update_day != '' && $update_month != '' && $update_year != '') {
                    $spreadsheet->getActiveSheet()->setCellValue('BC' . $rownum4, '=DATE(' . $update_year . ',' . $update_month . ',' . $update_day . ')');
                    $spreadsheet->getActiveSheet()->getStyle('BC' . $rownum4)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  $rownum4++;
                }

                // Dealsize field computation.
                $contract_currency_value = 'AP2:AQ' . $high;
                $contract_currency_value_data = $sheetData->rangeToArray($contract_currency_value);
                $currency_sign = [
                  'AUD' => 'AU$',
                  'BRL' => 'R$',
                  'CNY' => '¥',
                  'EUR' => '€',
                  'GBP' => '£',
                  'USD' => '$',
                  'MXN' => 'Mex$',
                ];
                $row = '';
                foreach ($contract_currency_value_data as $id => $data4) {
                  if (isset($data4[1]) && $data4[1] != 'null' && isset($data4[0]) && $data4[0] != 'null') {
                    if (($data4[1] > 0 ||  $data4[1] == 0) && $data4[1] < 500001) {
                      $dealsize = '0 ' . $currency_sign[$data4[0]] . ' - 0.5 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 500000 && $data4[1] < 1000001) {
                      $dealsize = '0.5 M ' . $currency_sign[$data4[0]] . ' - 1 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 100000 && $data4[1] < 5000001) {
                      $dealsize = '1 M ' . $currency_sign[$data4[0]] . ' - 5 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 500000 && $data4[1] < 10000001) {
                      $dealsize = '5 M ' . $currency_sign[$data4[0]] . ' - 10 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 1000000 && $data4[1] < 20000001) {
                      $dealsize = '10 M ' . $currency_sign[$data4[0]] . ' - 20 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 20000000 && $data4[1] < 50000001) {
                      $dealsize = '20 M ' . $currency_sign[$data4[0]] . ' - 50 M' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                    elseif ($data4[1] > 50000000) {
                      $dealsize = 'more than 50 M ' . $currency_sign[$data4[0]];
                      $row = $id + 2;
                      $spreadsheet->getActiveSheet()->setCellValue('AR' . $row, $dealsize);
                    }
                  }
                }

                // Project status field computation.
                $project_status_value = 'AT2:AU' . $high;
                $project_status_data = $sheetData->rangeToArray($project_status_value);
                $statusrow = '';
                foreach ($project_status_data as $psid => $data5) {
                  if (isset($data5[1]) && $data5[1] != 'null' && isset($data5[0]) && $data5[0] != 'null') {
                    $project_status = ' ';
                    $date = new DrupalDateTime();
                    $date->setTime(0, 0, 0);
                    $current_date = $date->getTimestamp();
                    $start_date = strtotime($data5[0]);
                    $end_date = strtotime($data5[1]);

                    if ($start_date < $end_date) {
                      if ($current_date > $end_date) {
                        $project_status = t('Project Completion');
                        $statusrow = $psid + 2;
                        $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                      }
                      elseif ($current_date > $start_date) {
                        $project_status = t('Delivery');
                        $statusrow = $psid + 2;
                        $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                      }
                      else {
                        $project_status = t('New Win');
                        $statusrow = $psid + 2;
                        $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                      }
                    }
                    else {
                      if ((!empty($start_date) && !empty($end_date)) && ($start_date == $end_date) && ($current_date > $end_date)) {
                        $project_status = t('Project Completion');
                        $statusrow = $psid + 2;
                        $spreadsheet->getActiveSheet()->setCellValue('AV' . $statusrow, $project_status);
                      }
                    }
                  }
                }
              $writer = new Xlsx($spreadsheet);
              $writer->save($refconverted_link);
              chmod($refconverted_link, 0777);
            }
            if($key == 'asset'){
             
			  $url = $base_url.'/asset/';
			  $query = $db->query("SELECT
				n.nid,
				concat('$url', n.nid) as url,
				grd.label as primary_community,
				n.title as asset_name
				FROM `node_field_data` n
				LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
				LEFT JOIN groups_field_data grd on grd.id = gd.gid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records = $query->fetchAllAssoc('nid');
				
				$query2 = $db->query("SELECT
				n.nid,
				sb.field_dummy_submitter_value as submitter
				FROM `node_field_data` n
				LEFT JOIN node__field_dummy_submitter sb ON sb.entity_id = n.nid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records2 = $query2->fetchAllAssoc('nid');
				foreach($records2 as $key=>$refrecord2){
				  if(array_key_exists($key,$records)){
					$records[$key]->submitter = $refrecord2->submitter;
				  }
				}
				
				$query3 = $db->query("SELECT
				n.nid,
				CONCAT(fn.field_name_first_value,' ',ln.field_name_last_value) as other_contributor
				FROM `node_field_data` n
				LEFT JOIN node__field_other_contributor oc ON oc.entity_id = n.nid
				LEFT JOIN user__field_name_first fn ON fn.entity_id = oc.field_other_contributor_target_id
				LEFT JOIN user__field_name_last ln ON ln.entity_id = oc.field_other_contributor_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records3= $query3->fetchAllAssoc('nid');
				foreach($records3 as $key=>$refrecord3){
				  if(array_key_exists($key,$records)){
					$records[$key]->other_contributor = $refrecord3->other_contributor;
				  }
				}
				
				$query4 = $db->query("SELECT
				n.nid,
				cli.field_client_value as account
				FROM `node_field_data` n
				LEFT JOIN node__field_client cli ON cli.entity_id = n.nid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records4= $query4->fetchAllAssoc('nid');
				foreach($records4 as $key=>$refrecord4){
				  if(array_key_exists($key,$records)){
					$records[$key]->account = $refrecord4->account;
				  }
				}
				
				$query5 = $db->query("SELECT
				n.nid,
				(CASE
						WHEN st.field_status_value = 0 THEN 'Live - Not reviewed by Community Leaders/Moderators'
						WHEN st.field_status_value = 1 THEN 'Live Gold - Validated by Community Leaders/Moderators'
						WHEN st.field_status_value = 2 THEN 'Archived'
						ELSE ''
					  END) as status
				FROM `node_field_data` n
				LEFT JOIN node__field_status st ON n.nid = st.entity_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records5= $query5->fetchAllAssoc('nid');
				foreach($records5 as $key=>$refrecord5){
				  if(array_key_exists($key,$records)){
					$records[$key]->status = $refrecord5->status;
				  }
				}
				
				$query6 = $db->query("SELECT
				n.nid,
				au.field_archive_date_value as actual_untill
				FROM `node_field_data` n
				LEFT JOIN node__field_archive_date au ON au.entity_id = n.nid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records6= $query6->fetchAllAssoc('nid');
				foreach($records6 as $key=>$refrecord6){
				  if(array_key_exists($key,$records)){
					$records[$key]->actual_untill = $refrecord6->actual_untill;
				  }
				}
				
				$query7 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT cat_tax.name) as category
				FROM `node_field_data` n
				LEFT JOIN node__field_entity_category cat ON cat.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data cat_tax ON cat_tax.tid = cat.field_entity_category_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				
				$records7= $query7->fetchAllAssoc('nid');
				foreach($records7 as $key=>$refrecord7){
				  if(array_key_exists($key,$records)){
					$records[$key]->category = $refrecord7->category;
				  }
				}
				
				$query8 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT sbu_tax.name) as strategic_business_unit
				FROM `node_field_data` n
				LEFT JOIN node__field_selling_strategic_business sbu ON sbu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sbu_tax ON sbu_tax.tid = sbu.field_selling_strategic_business_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records8= $query8->fetchAllAssoc('nid');
				foreach($records8 as $key=>$refrecord8){
				  if(array_key_exists($key,$records)){
					$records[$key]->strategic_business_unit = $refrecord8->strategic_business_unit;
				  }
				}
				
				$query9 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT orc_tax.name) as originating_country
				FROM `node_field_data` n
				LEFT JOIN node__field_entity_country orc ON orc.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data orc_tax ON orc_tax.tid = orc.field_entity_country_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records9 = $query9->fetchAllAssoc('nid');
				foreach($records9 as $key=>$refrecord9){
				  if(array_key_exists($key,$records)){
					$records[$key]->originating_country = $refrecord9->originating_country;
				  }
				}
				
				$query10 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT sec_tax.name) as sector
				FROM `node_field_data` n
				LEFT JOIN node__field_sector sec ON sec.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sec_tax ON sec_tax.tid = sec.field_sector_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records10 = $query10->fetchAllAssoc('nid');
				foreach($records10 as $key=>$refrecord10){
				  if(array_key_exists($key,$records)){
					$records[$key]->sector = $refrecord10->sector;
				  }
				}
				
				$query11 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT seg_tax.name) as industry
				FROM `node_field_data` n
				LEFT JOIN node__field_segment seg ON seg.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data seg_tax ON seg_tax.tid = seg.field_segment_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records11 = $query11->fetchAllAssoc('nid');
				foreach($records11 as $key=>$refrecord11){
				  if(array_key_exists($key,$records)){
					$records[$key]->industry = $refrecord11->industry;
				  }
				}
				
				$query12 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT sseg_tax.name) as industry_segment
				FROM `node_field_data` n
				LEFT JOIN node__field_subsegment sseg ON sseg.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data sseg_tax ON sseg_tax.tid = sseg.field_subsegment_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records12 = $query12->fetchAllAssoc('nid');
				foreach($records12 as $key=>$refrecord12){
				  if(array_key_exists($key,$records)){
					$records[$key]->industry_segment = $refrecord12->industry_segment;
				  }
				}
				
				$query13 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT secin_tax.name) as sector_initiative
				FROM `node_field_data` n
				LEFT JOIN node__field_sector_initiative secin ON secin.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data secin_tax ON secin_tax.tid = secin.field_sector_initiative_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records13 = $query13->fetchAllAssoc('nid');
				foreach($records13 as $key=>$refrecord13){
				  if(array_key_exists($key,$records)){
					$records[$key]->sector_initiative = $refrecord13->sector_initiative;
				  }
				}
				
				$query14 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT lsbu_tax.name) as legacy_sbu
				FROM `node_field_data` n
				LEFT JOIN node__field_entity_sbu lsbu ON lsbu.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data lsbu_tax ON lsbu_tax.tid = lsbu.field_entity_sbu_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records14 = $query14->fetchAllAssoc('nid');
				foreach($records14 as $key=>$refrecord14){
				  if(array_key_exists($key,$records)){
					$records[$key]->legacy_sbu = $refrecord14->legacy_sbu;
				  }
				}
				
				$query15 = $db->query("SELECT
				n.nid,
				(CASE
				  WHEN ms.field_managed_services_am_im__value = 0 THEN 'False'
				  ELSE 'TRUE'
				END) as managed_services
				FROM `node_field_data` n
				LEFT JOIN node__field_managed_services_am_im_ ms ON ms.entity_id = n.nid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records15 = $query15->fetchAllAssoc('nid');
				foreach($records15 as $key=>$refrecord15){
				  if(array_key_exists($key,$records)){
					$records[$key]->managed_services = $refrecord15->managed_services;
				  }
				}
				
				$query16 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT ep_tax.name) as entry_portfolio
				FROM `node_field_data` n
				LEFT JOIN node__field_entry_portfolio ep ON ep.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data ep_tax ON ep_tax.tid = ep.field_entry_portfolio_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records16 = $query16->fetchAllAssoc('nid');
				foreach($records16 as $key=>$refrecord16){
				  if(array_key_exists($key,$records)){
					$records[$key]->entry_portfolio = $refrecord16->entry_portfolio;
				  }
				}
				
				$query17 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT off_tax.name) as offer
				FROM `node_field_data` n
				LEFT JOIN node__field_offer off ON off.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data off_tax ON off_tax.tid = off.field_offer_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records17 = $query17->fetchAllAssoc('nid');
				foreach($records17 as $key=>$refrecord17){
				  if(array_key_exists($key,$records)){
					$records[$key]->offer = $refrecord17->offer;
				  }
				}
				
				$query18 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT bus_tax.name) as business_unit
				FROM `node_field_data` n
				LEFT JOIN node__field_business_unit bus ON bus.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data bus_tax ON bus_tax.tid = bus.field_business_unit_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records18 = $query18->fetchAllAssoc('nid');
				foreach($records18 as $key=>$refrecord18){
				  if(array_key_exists($key,$records)){
					$records[$key]->business_unit = $refrecord18->business_unit;
				  }
				}
				
				$query19 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT par_tax.name) as alliance_partner
				FROM `node_field_data` n
				LEFT JOIN node__field_partner par ON par.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data par_tax ON par_tax.tid = par.field_partner_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records19 = $query19->fetchAllAssoc('nid');
				foreach($records19 as $key=>$refrecord19){
				  if(array_key_exists($key,$records)){
					$records[$key]->alliance_partner = $refrecord19->alliance_partner;
				  }
				}
				
				$query20 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT tec_tax.name) as technologies
				FROM `node_field_data` n
				LEFT JOIN node__field_technologies tec ON tec.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data tec_tax ON tec_tax.tid = tec.field_technologies_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records20 = $query20->fetchAllAssoc('nid');
				foreach($records20 as $key=>$refrecord20){
				  if(array_key_exists($key,$records)){
					$records[$key]->technologies = $refrecord20->technologies;
				  }
				}
				
				$query21 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT comtax_tax.name) as community_taxonomy
				FROM `node_field_data` n
				LEFT JOIN node__field_community_taxonomy_id comtax ON comtax.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data comtax_tax ON comtax_tax.tid = comtax.field_community_taxonomy_id_value
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records21 = $query21->fetchAllAssoc('nid');
				foreach($records21 as $key=>$refrecord21){
				  if(array_key_exists($key,$records)){
					$records[$key]->community_taxonomy = $refrecord21->community_taxonomy;
				  }
				}
				
				$query22 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT comfol_tax.name) as community_folders
				FROM `node_field_data` n
				LEFT JOIN node__field_community_folders comfol ON comfol.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data comfol_tax ON comfol_tax.tid = comfol.field_community_folders_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records22 = $query22->fetchAllAssoc('nid');
				foreach($records22 as $key=>$refrecord22){
				  if(array_key_exists($key,$records)){
					$records[$key]->community_folders = $refrecord22->community_folders;
				  }
				}
				
				$query23 = $db->query("SELECT
				n.nid,
				GROUP_CONCAT(DISTINCT utag_tax.name) as users_tags
				FROM `node_field_data` n
				LEFT JOIN node__field_tags utag ON utag.entity_id = n.nid
				LEFT JOIN taxonomy_term_field_data utag_tax ON utag_tax.tid = utag.field_tags_target_id
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records23 = $query23->fetchAllAssoc('nid');
				foreach($records23 as $key=>$refrecord23){
				  if(array_key_exists($key,$records)){
					$records[$key]->users_tags = $refrecord23->users_tags;
				  }
				}
				
				$query24 = $db->query("SELECT
				n.nid,
				DATE_FORMAT(FROM_UNIXTIME(nfr.created), '%d-%M-%Y') as created
				FROM `node_field_data` n
				LEFT JOIN node_field_revision nfr on nfr.nid = n.nid
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records24 = $query24->fetchAllAssoc('nid');
				foreach($records24 as $key=>$refrecord24){
				  if(array_key_exists($key,$records)){
					$records[$key]->created = $refrecord24->created;
				  }
				}
				
				$query25 = $db->query("SELECT
				n.nid,
				DATE_FORMAT(FROM_UNIXTIME(n.changed), '%d-%M-%Y') as changed
				FROM `node_field_data` n
				WHERE n.type = 'asset'
				AND n.nid in ($val)
				group by n.nid;");
				$records25 = $query25->fetchAllAssoc('nid');
				foreach($records25 as $key=>$refrecord25){
				  if(array_key_exists($key,$records)){
					$records[$key]->changed = $refrecord25->changed;
				  }
				}
      
              $file_query = $db->query("SELECT
                n.nid,
                GROUP_CONCAT(CASE
                  WHEN lin.field_link_uri IS NULL THEN 
                  CONCAT('Kind of attachment: File','>>','Attachment(s):',fm.filename,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
                  ELSE 
                  CONCAT('Kind of attachment: Link','>>','Attachment(s):',lin.field_link_uri,'>>','Language:', lan_tax.name,'>>','Date:',da.field_file_date_value)
                END) as Attachement
                FROM `node_field_data` n
                LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
                JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid AND par_con.parent_field_name = 'field_files'
                LEFT JOIN paragraph__field_attachment att ON att.entity_id = par_con.id
                LEFT JOIN file_managed fm ON fm.fid = att.field_attachment_target_id
                LEFT JOIN paragraph__field_entity_language lan ON lan.entity_id = par_con.id
                LEFT JOIN taxonomy_term_field_data lan_tax ON lan_tax.tid = lan.field_entity_language_target_id
                LEFT JOIN paragraph__field_file_date da ON da.entity_id = par_con.id
                LEFT JOIN paragraph__field_link lin ON lin.entity_id = par_con.id 
                LEFT JOIN paragraph__field_type_asset ta ON ta.entity_id = par_con.id
                WHERE n.type = 'asset' AND n.nid in ($val) GROUP BY n.nid;");
      
                $assetfilerecords = $file_query->fetchAllAssoc('nid');
                foreach($assetfilerecords as $key=>$assetfile){
                  if(array_key_exists($key,$records)){
                    $records[$key]->Attachement = str_replace('>>',';;',$assetfile->Attachement);
                  }
                }
      
                $contact_query = $db->query("SELECT
                n.nid,
                (CASE
                WHEN top.field_contact_topics_value IS NULL THEN
                CONCAT('Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value)))
                ELSE
                CONCAT(CONCAT('TOPIC : ',GROUP_CONCAT(distinct top.field_contact_topics_value),'>','Name:',GROUP_CONCAT(CONCAT(con_fn.field_name_first_value,' ',con_ln.field_name_last_value))))
                END) as contact
                FROM `node_field_data` n
                LEFT JOIN group_relationship_field_data gd on gd.entity_id = n.nid
                LEFT JOIN paragraphs_item_field_data par_con ON par_con.parent_id = n.nid
                LEFT JOIN paragraph__field_contact_name con ON con.entity_id = par_con.id
                LEFT JOIN paragraph__field_contact_topics top ON top.entity_id = par_con.id
                LEFT JOIN user__field_name_first con_fn ON con_fn.entity_id = con.field_contact_name_target_id
                LEFT JOIN user__field_name_last con_ln ON con_ln.entity_id = con.field_contact_name_target_id
                WHERE n.type = 'asset' AND n.nid in ($val) GROUP BY n.nid;");
                $assetcontactrecords = $contact_query->fetchAllAssoc('nid');
      
                foreach($assetcontactrecords as $key=>$assetcontact){
                  if(array_key_exists($key,$records)){
                    $records[$key]->contact = str_replace('>',';',$assetcontact->contact);
                  }
                }
      
              // CSV FILE WRITING CODE
              $fields_mapping = array(
                'url' => 'URL',
                'primary_community' => 'Primary community',
                'asset_name' => 'Asset Name',
                'submitter' => 'Submitter',
                'contact' => 'Contacts',
                'other_contributor' => 'Other Contributer',
                'account' => 'Account',
                'status' => 'Status',
                'actual_untill' => 'Actual Until',
                'category' => 'Category',
                'strategic_business_unit' => 'Strategic Business Unit / Global Business Line',
                'originating_country' => 'Orginating Country(ies)',
                'sector' => 'Sector',
                'industry' => 'Industry',
                'industry_segment' => 'Industry Segment',
                'sector_initiative' => 'Sector Initiative (Marketing)',
                'legacy_sbu' => 'Legacy SBU/OU',
                'managed_services' => 'Managed Services (AM/IM)',
                'entry_portfolio' => 'Entry Portfolio',
                'offer' => 'Offer',
                'business_unit' => 'Business Unit',
                'alliance_partner' => 'Alliance Partner',
                'technologies' => 'Technologies',
                'community_taxonomy' => 'Community taxonomy',
                'community_folders' => 'Community Folders',
                'users_tags' => 'User tags',
                'Attachement' => 'Attachment(s)',
                'created' => 'Created',
                'changed' => 'Changed'
              );
              $headers = array_values($fields_mapping);
      
              $directory = 'files/export/cart/' . $uid;
              if (!file_exists($directory)) {
                mkdir($directory, 0777, TRUE);
              }
              $assetlink = $directory . '/PRISM_Export_CartID' . $itemid . '_asset.csv';
              fopen($assetlink,'w');
              $assetconverted_link = $directory . '/PRISM_Export_CartID' . $itemid . '_asset.xlsx';
              $list = array(
                $headers,
              );
              foreach($records as $i => $values) {
                foreach(array_keys($fields_mapping) as $key){
                  $list[$i][] =  $values->$key;
                }
              }
      
              $fp = fopen($assetlink, 'w');
              foreach ($list as $fields) {
                fputcsv($fp, $fields);
              }
              fclose($fp);
              $spreadsheet = IOFactory::load($assetlink);
              $sheetData = $spreadsheet->getActiveSheet();
      
              $rows = [];
              $high = $sheetData->getHighestRow();
      
              $rowsub = 2;
              //Submitter column.
              $range_submitter = 'D2:D' . $high;
              $submitter_data = $sheetData->rangeToArray($range_submitter);
              foreach ($submitter_data as $sub) {
                if (isset($sub[0]) && !empty($sub[0])) {
                  $submitter = explode('[',$sub[0]);
                  $submittername = trim($submitter[0]);
                  $spreadsheet->getActiveSheet()->setCellValue('D' . $rowsub, $submittername);
                }
                $rowsub++;
              }
                // Column for actual date.
                $range_actualdate = 'I2:I' . $high;
                // Column for creation date and update date.
                $range_creation_updatedate = 'AB2:AC' . $high;
                $nid_range = 'A2:A' . $high;
                $actual_date_data = $sheetData->rangeToArray($range_actualdate);
                $creation_update_date_data = $sheetData->rangeToArray($range_creation_updatedate);
                $nid_range_data = $sheetData->rangeToArray($nid_range);
                $rownum = 2;
      
                foreach($nid_range_data as $nid){
                  $nodeid = '';
                  $nodeid = explode('/',$nid[0]);
                  $n_id = $nodeid[4];
                  if(isset($n_id) && !empty($n_id)){
                    $node_data = \Drupal::entityTypeManager()->getStorage('node')->load($n_id);
                    //dump($node_data);
                  }
                }//die;
      
                // Date format change for Actual Date column values.
                foreach ($actual_date_data as $data1) {
                  $actualdate_array = [];
                  $actualdate_day = '';
                  $actualdate_month = '';
                  $actualdate_year = '';
      
                  if (isset($data1[0]) && !empty($data1[0])) {
                    $actualdatetime = strtotime($data1[0]);
                    $actualdatenewformat = date('Y-m-d', $actualdatetime);
                    $actualdate_array = explode('-', $actualdatenewformat);
                    $actualdate_day = $actualdate_array[2];
                    $actualdate_month = $actualdate_array[1];
                    $actualdate_year = $actualdate_array[0];
                  }
      
                  if ($actualdate_day != '' && $actualdate_month != '' && $actualdate_year != '') {
                    $spreadsheet->getActiveSheet()->setCellValue('I' . $rownum, '=DATE(' . $actualdate_year . ',' . $actualdate_month . ',' . $actualdate_day . ')');
                    $spreadsheet->getActiveSheet()->getStyle('I' . $rownum)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  $rownum++;
                }
      
                // Date format change for Creation and Update Date columns values.
                $rownum2 = 2;
                foreach ($creation_update_date_data as $data2) {
                  $creation_array = [];
                  $update_array = [];
                  $creation_day = '';
                  $creation_month = '';
                  $creation_year = '';
                  $update_day = '';
                  $update_month = '';
                  $update_year = '';
      
                  if (isset($data2[0]) && !empty($data2[0])) {
                    $creationtime = strtotime($data2[0]);
                    $creationnewformat = date('Y-m-d', $creationtime);
                    $creation_array = explode('-', $creationnewformat);
                    $creation_day = $creation_array[2];
                    $creation_month = $creation_array[1];
                    $creation_year = $creation_array[0];
                  }
                  if (isset($data2[1]) && !empty($data2[1])) {
                    $updatetime = strtotime($data2[1]);
                    $updatenewformat = date('Y-m-d', $updatetime);
                    $update_array = explode('-', $updatenewformat);
                    $update_day = $update_array[2];
                    $update_month = $update_array[1];
                    $update_year = $update_array[0];
                  }
                  if ($creation_day != '' && $creation_month != '' && $creation_year != '') {
                    $spreadsheet->getActiveSheet()->setCellValue('AB' . $rownum2, '=DATE(' . $creation_year . ',' . $creation_month . ',' . $creation_day . ')');
                    $spreadsheet->getActiveSheet()->getStyle('AB' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  if ($update_day != '' && $update_month != '' && $update_year != '') {
                    $spreadsheet->getActiveSheet()->setCellValue('AC' . $rownum2, '=DATE(' . $update_year . ',' . $update_month . ',' . $update_day . ')');
                    $spreadsheet->getActiveSheet()->getStyle('AC' . $rownum2)->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_DATE_XLSX15);
                  }
                  $rownum2++;
                }
                $writer = new Xlsx($spreadsheet);
                $writer->save($assetconverted_link);
                chmod($assetconverted_link, 0777);
            }
            $reference_url = $asset_url = NULL;
            if (file_exists($assetconverted_link)) {
              $assetfile_create = \Drupal::service('file_url_generator')->generateAbsoluteString($assetconverted_link);
              $assetfile_link = str_replace('http://','https://', $assetfile_create); 
              $assetfile_link .= "?".time();
            }
            if (file_exists($refconverted_link)) {
              $reffile_create = \Drupal::service('file_url_generator')->generateAbsoluteString($refconverted_link);
              $reffile_link = str_replace('http://','https://', $reffile_create); 
              $reffile_link .= "?".time();
            }

            $cart_links['asset_url'] = $assetfile_link;
            $cart_links['reference_url'] = $reffile_link;
            $cart_links['uid'] = $uid;
            $cart_links['timestamp'] = $timestamp;
            $cart_links['feature'] = $feature;

            $num_updated = $db->update('export_cart_log')
              ->fields([
              'state' => 2,
              ])
              ->condition('gid', $gid, '=')
              ->condition('type', $type, '=')
              ->condition('uid', $uid, '=')
              ->condition('state', 1, '=')
              ->condition('timestamp', $timestamp, '=')
              ->condition('feature', $feature, '=')
              ->execute();
          }
        }
      }
      if($cart_links['asset_url'] || $cart_links['reference_url']){
      $query = $db->insert('export_mail_log')
        ->fields(['uid', 'asset_url', 'reference_url', 'file_url', 'status', 'timestamp', 'gid'])
        ->values([
          'uid' => $cart_links['uid'],
          'asset_url' => $cart_links['asset_url'],
          'reference_url' => $cart_links['reference_url'],
          'file_url' => NULL,
          'status' => 0,
          'timestamp' => \Drupal::time()->getRequestTime(),
          'gid' => NULL
        ])
        ->execute();
      }
      
      $check_available_query = $db->query("SELECT id FROM {export_mail_log} WHERE status=1 ORDER BY timestamp ASC LIMIT 1");
      $available = $check_available_query->fetchAll();
  
      if (!$available) {
        $get_cart_email_data = $db->query("SELECT * FROM {export_mail_log} WHERE status = 0 ORDER BY timestamp ASC LIMIT 1");

        $cart_components = $get_cart_email_data->fetchAll();

        $target_users = '';
        if($cart_components[0]->uid){
          $target_users_query = $db->query('SELECT mail FROM {users_field_data} WHERE uid=' . $cart_components[0]->uid);
          $target_users = $target_users_query->fetchField();
        }
        $subject = 'Export from PRISM - Cart Items';
        if(isset($cart_components[0]->asset_url) && $cart_components[0]->asset_url != NULL && !isset($cart_components[0]->reference_url) && $cart_components[0]->reference_url == NULL) {
          $body = 'You have requested to export content from your cart.<br />Please download the export for Asset(s) from <a href="' . $cart_components[0]->asset_url . '">here</a>. Thank you.';
        } else if(isset($cart_components[0]->reference_url) && $cart_components[0]->reference_url != NULL && !isset($cart_components[0]->asset_url) && $cart_components[0]->asset_url == NULL) {
          $body = 'You have requested to export content from your cart.<br />Please download the export for Reference(s) from <a href="' . $cart_components[0]->reference_url . '">here</a>. Thank you.';
        }
        else if(isset($cart_components[0]->asset_url) && $cart_components[0]->asset_url != NULL && isset($cart_components[0]->reference_url) && $cart_components[0]->reference_url != NULL){
          $body = 'You have requested to export content from your cart.<br />Please download the export for Asset(s) from <a href="' . $cart_components[0]->asset_url . '">here</a>. <br />Please download the export for Reference(s) from <a href="' . $cart_components[0]->reference_url . '">here</a>. Thank you.';
        }
        else {
          $body = 'There were some issues preventing the export file to be generated.<br />Please try again, and contact the support team if you get the same error again.<br />Thank you.'; 
        }

        $mailManager = \Drupal::service('plugin.manager.mail');
        $module = 'custom_export';
        $key = 'community_export';
        $to = $target_users;
        $params['message'] = $body;
        $params['subject'] = $subject;
        $langcode = 'en';
        $send = true;

        $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);

        if ($result['result'] != true) {
          $num_updated = $db->update('export_mail_log')
          ->fields([
          'status' => 1,
          ])
          ->condition('uid', $cart_components[0]->uid, '=')
          ->condition('status', 0, '=')
          ->condition('timestamp', $cart_components[0]->timestamp, '=')
          ->execute();

          $message = t('There was a problem sending your email notification to @email.', array('@email' => $to));
          \Drupal::messenger()->addError($message);
          //\Drupal::logger('mail-log')->error($message);
        }

        $message = t('An email notification has been sent to @email ', array('@email' => $to));
        \Drupal::messenger()->addStatus($message);
        //\Drupal::logger('mail-log')->notice($message);
        $num_updated = $db->update('export_mail_log')
          ->fields([
          'status' => 2,
          ])
          ->condition('uid', $cart_components[0]->uid, '=')
          ->condition('status', 0, '=')
          ->condition('timestamp', $cart_components[0]->timestamp, '=')
          ->execute();
      }  
    }
    $response = new AjaxResponse();
    return $response;
  }
}
