<?php
namespace Drupal\custom_search\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Cache\Cache;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Datetime\Element\DateElementBase;
use Drupal\Core\Datetime\Element\Datetime;
use Drupal\Core\Pager\PagerManagerInterface;
use Drupal\Component\Utility\Xss;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\image\Entity\ImageStyle;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupContent;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\RedirectResponse;



/**
 * Default controller for the custom_search module.
 */
class DefaultController extends ControllerBase {
  public function standard_search_sinequa_all_results() {
		$param = \Drupal::request()->query->all();
    $search_results = null;
    $this->_get_search_data_process();
    $search_results = _build_sinequa_query($_SESSION['search']);
    unset($_SESSION['search']['is_new']);
    $rendered = $this->_get_response_renderable_result($search_results);
    $sorting_form = \Drupal::formBuilder()->getForm('\Drupal\custom_search\Form\CustomSearchSortingForm');

    // //Generating Search Link
    $query_url = _build_search_url($_SESSION['search']);
		if(isset($query_url['q_key']) && $query_url['q_key'] != ''){
		  $query_url['q_key'] = urldecode($query_url['q_key']);
		}
    $link = Link::createFromRoute(t('right-clicking here'), 'custom_search.search_sinequa_all_results', $query_url);
    $string = $link->toString();
    
    $alphabet_facet = $_SESSION['search']['alphabet_facet'];
		foreach($alphabet_facet as $key => $alphafacet){
			$filteredURL = preg_replace('~(\?|&)page=[^&]*~', '$1', $alphafacet['url']);
			$alphabet_facet[$key]['url'] = $filteredURL;
		}
    if((isset($_SESSION['search']['group_id']) && !empty($_SESSION['search']['group_id'])) && $_SESSION['search']['scope'] == 2) {
      $group = Group::load($_SESSION['search']['group_id']);
      if ($group instanceof Group) {
        $group_title = $group->get('label')->value;

        $url = Url::fromRoute('entity.group.canonical', array('group' => $group->id()));
        $project_link = Link::fromTextAndUrl(t($group_title), $url);
        $project_link = $project_link->toString();
        $platform = $project_link;
      }
    } else {
      // scope == 0  (standard)
      // scope == 1  (my communities)
      // scope == 2  (this community)
      // scope == 3  (My Communities + Related Communities)
      if($_SESSION['search']['scope'] == 1 || $_SESSION['search']['scope'] == 3){
        $platform = "communities you are a member of";
        // Empty Adv URL for Community Joined and related communities
        $string = "";
      } else {
        $platform = "PRISM Platform";
      }
    }
		global $base_url;
		$scopevar = isset($_SESSION['search']['scope'])?$_SESSION['search']['scope']:'';
		$community_name = isset($group_title)?$group_title:'';
		$community_url = isset($_SESSION['search']['group_id'])?$base_url . '/community/' .  $_SESSION['search']['group_id']:'';
    $search_text = " Results found in the ".$platform." (excluding archived content).";
    $total_count_text = $rendered['total_count'].$search_text;
    $rendered_block = '';
    return [
      '#theme' => 'custom_search_results',
      '#data' => $rendered['rendered'],
      '#total_count_text' => $total_count_text,
      '#advlink' => $string,
			'#scopevar' => $scopevar,
			'#community_name' => $community_name,
			'#community_url' => $community_url,
      '#sort_form' => $sorting_form,
      '#alphabetFacet' => $alphabet_facet,
			'#currentalphabet' => isset($param['alphabet_filter'])?$param['alphabet_filter']:'',
      '#pager' => [
        '#type' => 'pager',
      ],
      '#attached' => [
        'library' => [
          'custom_search/custom_search.custom-search-js',
        ],
      ],
    ];
  }
  public function standard_search_sinequa_content_results() {
		$param = \Drupal::request()->query->all();
    $search_results = null;
    $this->_get_search_data_process();
    $search_results = _build_sinequa_query($_SESSION['search']);

    unset($_SESSION['search']['is_new']);
    $rendered = $this->_get_response_renderable_result($search_results);

    $sorting_form = \Drupal::formBuilder()->getForm('\Drupal\custom_search\Form\CustomSearchSortingForm');

    // //Generating Search Link
    $query_url = _build_search_url($_SESSION['search']);
    $link = Link::createFromRoute(t('right-clicking here'), 'custom_search.search_sinequa_content_results', $query_url);
    $string = $link->toString();
    if((isset($_SESSION['search']['group_id']) && !empty($_SESSION['search']['group_id'])) && $_SESSION['search']['scope'] == 2) {
      $group = Group::load($_SESSION['search']['group_id']);
      if ($group instanceof Group) {
        $group_title = $group->get('label')->value;

        $url = Url::fromRoute('entity.group.canonical', array('group' => $group->id()));
        $project_link = Link::fromTextAndUrl(t($group_title), $url);
        $project_link = $project_link->toString();
        $platform = $project_link;
      }
    } else {
      if($_SESSION['search']['scope'] == 1 || $_SESSION['search']['scope'] == 3){
        $platform = "communities you are a member of";
        // Empty Adv URL for Community Joined and related communities
        $string = "";
      } else {
        $platform = "PRISM Platform";
      }
    }

    switch($_SESSION['search']['form_id']){
      case 'custom_advanced_search_asset_form':
        $search_text = " Assets and/or related files found in the ".$platform.".";
      break;
      case 'custom_advanced_search_reference_form':
        $search_text = " References and/or related files found in the ".$platform.".";
      break;
      case 'custom_advanced_search_asset_reference_form':
        $search_text = " References and/or related files found in the ".$platform.".";
      break;
      case 'custom_advanced_search_people_form':
        $search_text = " People found in the ".$platform.".";
      break;
    }
    $total_count_text = $rendered['total_count'].$search_text;
    $alphabet_facet = $_SESSION['search']['alphabet_facet'];
		foreach($alphabet_facet as $key => $alphafacet){
			$filteredURL = preg_replace('~(\?|&)page=[^&]*~', '$1', $alphafacet['url']);
			$alphabet_facet[$key]['url'] = $filteredURL;
		}
    return [
      '#theme' => 'custom_search_results',
      '#data' => $rendered['rendered'],
      '#total_count_text' => $total_count_text,
      '#advlink' => $string,
      '#sort_form' => $sorting_form,
      '#alphabetFacet' => $alphabet_facet,
			'#currentalphabet' => isset($param['alphabet_filter'])?$param['alphabet_filter']:'',
      '#pager' => [
        '#type' => 'pager',
      ],
      '#attached' => [
        'library' => [
          'custom_search/custom_search.custom-search-js',
        ],
      ],
    ];
  }
  public function advanced_search_sinequa_account_asset_reference_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    $query = \Drupal::database()->select('node__field_client', 'c');
    $query->fields('c', ['entity_id','field_client_value']);
    $query->condition('field_client_value', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result1 = $query->execute()->fetchAllKeyed(0,1);
    foreach($result1 as $id => $value) {
      $result_json[$value] = $value;
    }
    $query = \Drupal::database()->select('node__field_client_account', 'c');
    $query->fields('c', ['entity_id','field_client_account_value']);
    $query->condition('field_client_account_value', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result2 = $query->execute()->fetchAllKeyed(0,1);
    foreach($result2 as $id => $value) {
      $result_json[$value] = $value;
    }
    return new JsonResponse($result_json);
  }
  public function advanced_search_sinequa_account_asset_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }
    $input = Xss::filter($input);
    $query = \Drupal::database()->select('node__field_client', 'c');
    $query->fields('c', ['entity_id','field_client_value']);
    $query->condition('field_client_value', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result = $query->execute()->fetchAllKeyed(0,1);
    foreach($result as $id => $value) {
      $result_json[$value] = $value;
    }
    return new JsonResponse($result_json);
  }
  public function advanced_search_sinequa_account_reference_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }   
    $input = Xss::filter($input);
    $query = \Drupal::database()->select('node__field_client_account', 'c');
    $query->fields('c', ['entity_id','field_client_account_value']);
    $query->condition('field_client_account_value', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result = $query->execute()->fetchAllKeyed(0,1);
    foreach($result as $id => $value) {
      $result_json[$value] = $value;
    }
		
		$query1 = \Drupal::database()->select('node__field_client', 'f');
    $query1->fields('f', ['entity_id','field_client_value']);
    $query1->condition('field_client_value', '%'.$input.'%', 'LIKE');
    $query1->distinct();
    $query1->range(0, 50);
    $result1 = $query1->execute()->fetchAllKeyed(0,1);
    foreach($result1 as $id1 => $value1) {
      $result_json[$value1] = $value1;
    }
    return new JsonResponse($result_json);
  }
  public function advanced_search_sinequa_technologies_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }
    $input = Xss::filter($input);
		$query = \Drupal::database()->select('node__field_technologies', 'c');
		$query->join('taxonomy_term_field_data', 't', 't.tid = c.field_technologies_target_id');
		$query->addField('c', 'field_technologies_target_id');
		$query->addField('t', 'name');
    $query->condition('t.name', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result = $query->execute()->fetchAllKeyed(0,1);
    foreach($result as $id => $value) {
      $result_json[$value] = $value;
    }
    /* $technologies_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('technologies');
    foreach($technologies_terms as $tid => $term_value) {
      if(strpos(strtolower($term_value->name),strtolower($input))) {
        $result_json[$term_value->name] = $term_value->name;
      }
    } */
    return new JsonResponse($result_json);
  }

  public function advanced_search_sinequa_gen_ai_technology_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }
    $input = Xss::filter($input);
		$query = \Drupal::database()->select('node__field_gen_ai_technology', 'c');
		$query->join('taxonomy_term_field_data', 't', 't.tid = c.field_gen_ai_technology_target_id');
		$query->addField('c', 'field_gen_ai_technology_target_id');
		$query->addField('t', 'name');
    $query->condition('t.name', '%'.$input.'%', 'LIKE');
    $query->distinct();
    $query->range(0, 50);
    $result = $query->execute()->fetchAllKeyed(0,1);
    foreach($result as $id => $value) {
      $result_json[$value] = $value;
    }
    return new JsonResponse($result_json);
  }
  
  public function handleSearchParentAutocomplete(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    // node__field_ultimate_parent_account

    $input = Xss::filter($input);
    // $language_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('language');
    // foreach($language_terms as $tid => $term_value) {
    //   if(strpos(strtolower($term_value->name),strtolower($input))) {
    //     $result_json[$term_value->name] = $term_value->name;
    //   }
    // }
    // return new JsonResponse($result_json);
    $query = \Drupal::database()->select('node__field_ultimate_parent_account', 'c');
    $query->fields('c', ['field_ultimate_parent_account_value']);
    $query->condition('c.field_ultimate_parent_account_value', '%' . $input . '%', 'LIKE');
    $query->range(0, 100);
    $results = $query->distinct()->execute()->fetchAll();
    $values = [];
    foreach ($results as $result) {
        $label = [$result->field_ultimate_parent_account_value];
        $values[] = [
        'label' => implode(' ', $label),
        ];
    }

    return new JsonResponse($values);
  }

  public function advanced_search_sinequa_user_language_results(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }
    $input = Xss::filter($input);
    $language_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('language');
    foreach($language_terms as $tid => $term_value) {
      if(strpos(strtolower($term_value->name),strtolower($input)) !== false) {
        $result_json[$term_value->name] = $term_value->name;
      }
    }
    return new JsonResponse($result_json);
  }
  /**
   * Function to set the SESSION variable for Search and get the query string value.
   */
  function _get_search_data_process() {
    // Request Came from URL, Hence Captured = 1
    $captured_fromurl = \Drupal::request()->query->get('captured');
    if(isset($captured_fromurl) && $captured_fromurl == 1){
      unset($_SESSION['search']);
      _capture_query_string_to_session();
      $community_id = \Drupal::request()->query->get('community_id');
      if(isset($community_id)) {
        $_SESSION['search']['scope'] = '2';
        $_SESSION['search']['group_id'] = $community_id;
      } else {
        $_SESSION['search']['scope'] = '0';
      }
    }
    // Setting Default User Detail in Session
    $_SESSION['search']['user'] = \Drupal::currentUser()->id();
    $_SESSION['search']['user_email_id'] = \Drupal::currentUser()->getEmail();
    $_SESSION['search']['user_name'] = \Drupal::currentUser()->getAccountName();
    $_SESSION['search']['class'] = 'item';

    // Handle Sort By in Get Query String
    $sort_by = \Drupal::request()->query->get('sortby');
    if($sort_by){
      $sortvalue = explode('-', $sort_by);
      if(!isset($_SESSION['search']['is_new'])){
        $_SESSION['search']['sort']['search_sorted_order'] = $sortvalue[0];
        $_SESSION['search']['sort']['search_sorted_by'] = $sortvalue[1];
      }
    }

    // Capture User Selected Facets
    $facets = \Drupal::request()->query->all('facets');
    if($facets) {
      $_SESSION['search']['facets'] = $facets;
    } else {
      if(isset($_SESSION['search']['facets']) && !empty($_SESSION['search']['facets'])){
        unset($_SESSION['search']['facets']);
      }
    }

    // Capture User Selected Alphabet Sorting
    $alphabet_filter = \Drupal::request()->query->get('alphabet_filter');
    if(isset($alphabet_filter)) {
      $_SESSION['search']['alphabet_filter'] = $alphabet_filter;
    } else {
      if(isset($_SESSION['search']['alphabet_filter']) && !empty($_SESSION['search']['alphabet_filter'])){
        unset($_SESSION['search']['alphabet_filter']);
      }
    }

    // Paging for search results.
    $page_val = \Drupal::request()->query->get('page');
    $page = isset($page_val) ? ($page_val) : 0;
    $_SESSION['search']['page'] = $page;
  }
  public function _get_response_renderable_result($search_results){
		$sinequa_result_array = [];
		$rendered = '';
		$cache_user_variable = \Drupal::currentUser()->id();
    // Deleting Facet Cache Data for Replacing with New one.
    \Drupal::cache()->delete('search_results_facets-'.$cache_user_variable);
    $style = ImageStyle::load('thumbnail');
    if(isset($search_results) && !empty($search_results)) {
      $xml_data = @simplexml_load_string($search_results);
      #$xml_data = $search_results;
      if($xml_data === false){
        $error = Json::decode($search_results);
        \Drupal::messenger()->addError("CURL ERROR : ".$error['error']['errorCode'] . " - " .$error['error']['description']);
      } else {
        $xml_encoded = Json::encode($xml_data);
        $sinequa_result_array = Json::decode($xml_encoded);
        $alphabetFacet = $sinequa_result_array['FacetValues']['AlphabetDisplay']['e'];
        if(isset($alphabetFacet)) {
          if(!isset($alphabetFacet[0]) || empty($alphabetFacet[0])) {
            $ex_query_string = \Drupal::request()->query->all();
            $query_string = array_merge($ex_query_string,array('alphabet_filter'=>strtolower($alphabetFacet['display'])));
            $url = \Drupal\Core\Url::fromRoute(
              '<current>',
              $query_string,
              ['absolute' => TRUE]
            )->toString();
            $alphabet_facet[0]['facet'] = $alphabetFacet['display'];
            $alphabet_facet[0]['url'] = $url;
          }else{
            foreach($alphabetFacet as $key => $facet) {
              if(is_array($facet) && ctype_alpha($facet['display'])) {
                $ex_query_string = \Drupal::request()->query->all();
                $query_string = array_merge($ex_query_string,array('alphabet_filter'=>strtolower($facet['display'])));
                $url = \Drupal\Core\Url::fromRoute(
                  '<current>',
                  $query_string,
                  ['absolute' => TRUE]
                )->toString();
                $alphabet_facet[$key]['facet'] = $facet['display'];
                $alphabet_facet[$key]['url'] = $url;
              }
            }
          }
          $all_query_string = \Drupal::request()->query->all();
          unset($all_query_string['alphabet_filter']);
          $url = \Drupal\Core\Url::fromRoute(
            '<current>',
            $all_query_string,
            ['absolute' => TRUE]
          )->toString();
          $alphabet_facet[100]['facet'] = 'All';
          $alphabet_facet[100]['url'] = $url;
          $_SESSION['search']['alphabet_facet'] = $alphabet_facet;
        }
        // Setting Facet Data in Cache.
        $cache_user_variable = \Drupal::currentUser()->id();
				\Drupal::cache()->delete('search_results_facets-'.$cache_user_variable);
        \Drupal::cache()->set('search_results_facets-'.$cache_user_variable, $sinequa_result_array['FacetValues'], Cache::PERMANENT);
      }
    }
    if(isset($sinequa_result_array['TotalRowCount']) && $sinequa_result_array['TotalRowCount'] == '1') {
      $new_sinequa_result_array = $sinequa_result_array['RowObjects']['e'];
      unset($sinequa_result_array['RowObjects']['e']);
      $sinequa_result_array['RowObjects']['e'][] = $new_sinequa_result_array;
    }
		if(isset($sinequa_result_array)){
		  if($_SESSION['search']['form_id'] == 'custom_standard_search_form'){
        $sinequa_result_array['RowObjects'] = $this->highlight_processing_sinequa($sinequa_result_array['RowObjects']);
      } else {
				if($_SESSION['search']['form_id'] == 'custom_advanced_search_reference_form' || $_SESSION['search']['form_id'] == 'custom_advanced_search_asset_reference_form'){
					// New Highlight Feature for Sector/Account/Industry/EntryPortfolio
					$sinequa_result_array['RowObjects'] = $this->highlight_references_fields_sinequa($sinequa_result_array['RowObjects']);
				}
        $sinequa_result_array['RowObjects'] = $this->highlight_multi_items_sinequa($sinequa_result_array['RowObjects']);
      }
		}
		$singlerecord = [];
		if(!isset($sinequa_result_array['RowObjects']['e'][0])){
			$singlerecord[0] = $sinequa_result_array['RowObjects']['e']; 
		}
		else{
			$singlerecord = $sinequa_result_array['RowObjects']['e'];
		}
		//dump($singlerecord);
		
    foreach($singlerecord as $result){
			if(empty($result['sourcecsv38']) || $result['sourcecsv38'] == ''){
				$result['sourcecsv38'] = '';
			}
			if(empty($result['sourcecsv39']) || $result['sourcecsv39'] == ''){
				$result['sourcecsv39'] = '';
			}if(empty($result['sourcecsv12']) || $result['sourcecsv12'] == ''){
				$result['sourcecsv12'] = '';
			}
      $datecreate = "";
      $dateupdate = "";
			
			//Temporary solution for creation date issue in Sinequa. Need to remove once Sinequa provides solution. Bug 1467429
			$nodeid = explode('|',$result['id']);
			$nid = $nodeid[1];
			$query = \Drupal::database()->select('node_field_data', 'n');
			$query->addField('n', 'created');
			$query->condition('n.nid', $nid, '=');
			$results = $query->execute()->fetchAll();
			
      if(!is_array($result['sourcedatetime9'])){
				$result['sourcedatetime9'] = $results[0]->created;
        $datecreate = strtotime($result['sourcedatetime9']);
      }
      if(!is_array($result['sourcedatetime10'])) {
        $dateupdate = strtotime($result['sourcedatetime10']);
      }
      $datestartref = (!is_array($result['sourcedatetime14']))?strtotime($result['sourcedatetime14']):'';
      $dateendref = (!is_array($result['sourcedatetime15']))?strtotime($result['sourcedatetime15']):'';
      $date_creation = ($datecreate)?date('d M Y', $datecreate):'';
      $date_update = ($dateupdate)?date('d M Y', $dateupdate):'';
      $date_start_ref = ($datestartref)?date('d M Y', $datestartref):'';
      $date_end_ref = ($dateendref)?date('d M Y', $dateendref):'';
      $result['sourcedatetime11'] = $date_start_ref;
      $result['sourcedatetime12'] = $date_end_ref;
      // Star Rating
      if(is_numeric($result['sourceint2'])) {
        $result['rating'] = $this->_search_create_rating_star($result['sourceint2']);
      } else {
        $result['rating'] = $this->_search_create_rating_star(0);
      }
      // Created by Name
      if(is_numeric($result['sourceint5']) || $result['sourceint5'] == '0') {
        if($result['sourceint5'] != '0') {
          $user_acc = \Drupal\user\Entity\User::load($result['sourceint5']);
          $media_field = isset($user_acc)?$user_acc->get('user_picture')->getValue():'';
          if(!empty($media_field[0]['target_id'])){
            $file = \Drupal\file\Entity\File::load($media_field[0]['target_id']);
            $file_uri = $file->getFileUri();
            $image_path = $style->buildUrl($file_uri);
          }
          else{
            $image_path = '/themes/custom/capgemini_b5/images/Avatar.svg';
          }
          if(isset($user_acc) && isset($user_acc->get('field_name_first')->getValue()[0]['value']) && isset($user_acc->get('field_name_last')->getValue()[0]['value'])) {
            $result['created_by'] = $user_acc->get('field_name_first')->getValue()[0]['value'] . ' ' . $user_acc->get('field_name_last')->getValue()[0]['value'];
          }
		  else {
            $result['created_by'] = "Anonymous";
            $image_path = '/themes/custom/capgemini_b5/images/Avatar.svg';
          }
          $result['content_user_picture'] = $image_path;
        } else {
          $result['created_by'] = "Anonymous";
          $image_path = '/themes/custom/capgemini_b5/images/Avatar.svg';
          $result['content_user_picture'] = $image_path;
        }
      } else {
        $result['created_by'] = "Anonymous";
        $image_path = '/themes/custom/capgemini_b5/images/Avatar.svg';
        $result['content_user_picture'] = $image_path;
      }
      // Updated by Name
      if(is_numeric($result['sourceint8']) || $result['sourceint8'] == '0') {
        if($result['sourceint8'] != '0') {
          $user_acc = \Drupal\user\Entity\User::load($result['sourceint8']);
          if(isset($user_acc) && isset($user_acc->get('field_name_first')->getValue()[0]['value']) && isset($user_acc->get('field_name_last')->getValue()[0]['value'])) {
		    $result['updated_by'] = $user_acc->get('field_name_first')->getValue()[0]['value'] . ' ' . $user_acc->get('field_name_last')->getValue()[0]['value'];
		  }
		  else {
            $result['updated_by'] = "Anonymous";
          }
        } else {
          $result['updated_by'] = "Anonymous";
        }
      } else {
        $result['updated_by'] = "Anonymous";
      }
      
      $user_id = \Drupal::currentUser()->id();

      if(is_numeric($result['sourceint1'])){
        // TEMP Code placed will be replaced after data migration and indexation
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($result['sourceint1']);
        if ($node instanceof \Drupal\node\NodeInterface) {
          $flag_service = \Drupal::service('flag.link_builder');
          $flag_follow_link_var = $flag_service->build($node->getEntityTypeId(), $node->id(), 'follow_content');
          $flag_fav_link_var = $flag_service->build($node->getEntityTypeId(), $node->id(), 'favorite');
          $result['search_follow_action'] = $flag_follow_link_var;
          $result['search_fav_action'] = $flag_fav_link_var;
					if($node->hasField('field_community')){
						if($node->get('type')->getValue()[0]['target_id'] != 'notification_user_preference'){
							$attcount = get_file_count_by_paragraph_id($node);
							$comment_count = isset($node) && !empty($node->get('field_comments')) ? $node->get('field_comments')->comment_count : 0;
						}
					}
				  $result['attachments'] = $attcount;
					$result['comment_count'] = $comment_count;
        }
      }
      
      if(isset($result['sourceint1']) && !empty($result['sourceint1'])){
        if(get_node_hits($result['sourceint1']) != false){
          $result['hits'] = get_node_hits($result['sourceint1']);
		}
        else{
		  $result['hits'] = 0;	
		}
      }
      $status_arr = ['0'=>'Live - Not Reviewed by Community Leaders/Moderators','1'=>'Live Gold - Validated by Community Leaders/Moderators','2'=>'Archived',];
      if(!is_array($result['sourcestr22'])) {
        $result['sourcestr22'] = $status_arr[$result['sourcestr22']];
      }
      if(isset($result['sourceint1']) && !empty($result['sourceint1'])){
        $result['enable_masking'] = get_masking_value($result['sourceint1']);
      } 
      $currency_sign = ['AUD' => 'AU$','BRL' => 'R$','CNY' => '¥','EUR' => '€','GBP' => '£','USD' => '$','MXN' => 'Mex$'];

      if(isset($result['sourcedouble1']) && $result['sourcedouble1'] != 'null' && isset($result['sourcestr9']) && is_string($result['sourcestr9']) && $result['sourcestr9'] != 'null'){
        if(($result['sourcedouble1'] > 0 ||  $result['sourcedouble1'] == 0) && $result['sourcedouble1'] < 500001){
          $result['dealsize'] = '0 ' . $currency_sign[$result['sourcestr9']] . ' - 0.5 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 500000 && $result['sourcedouble1'] < 1000001){
          $result['dealsize'] = '0.5 M ' . $currency_sign[$result['sourcestr9']] . ' - 1 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 100000 && $result['sourcedouble1'] < 5000001){
          $result['dealsize'] = '1 M ' . $currency_sign[$result['sourcestr9']] . ' - 5 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 500000 && $result['sourcedouble1'] < 10000001){
          $result['dealsize'] = '5 M ' . $currency_sign[$result['sourcestr9']] . ' - 10 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 1000000 && $result['sourcedouble1'] < 20000001){
          $result['dealsize'] = '10 M ' . $currency_sign[$result['sourcestr9']] . ' - 20 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 20000000 && $result['sourcedouble1'] < 50000001){
          $result['dealsize'] = '20 M ' . $currency_sign[$result['sourcestr9']] . ' - 50 M' . $currency_sign[$result['sourcestr9']];
        }
        else if($result['sourcedouble1'] > 50000000){
          if(!is_array($result['sourcestr9'])) {
            $result['dealsize'] = 'more than 50 M ' . $currency_sign[$result['sourcestr9']];
          }
        }
      }
      $type = $result['sourcestr23'];

      // Field required for attachment type.
      if($type == 'km file') {
        $url = explode('/', $result['url1']);
        $count = count($url);
        $result['file_node_type'] = $url[$count - 2];
        if($result['file_node_type'] == 'pages') $result['file_node_type'] = 'community page';
        if($result['file_node_type'] == 'wiki') $result['file_node_type'] = 'wiki page';
        if($result['file_node_type'] == 'group') $result['file_node_type'] = 'community';
        if($result['file_node_type'] == 'asset') $result['file_node_type'] = 'asset';
        if($result['file_node_type'] == 'reference') $result['file_node_type'] = 'reference';
        if($result['file_node_type'] == 'news') $result['file_node_type'] = 'news';

        //Node Title
        if(is_numeric($result['sourceint1'])){
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($result['sourceint1']);
          if($node)
          $result['file_node_title'] = $node->get('title')->value;
        }

        //GET EXTENTION 
        if(isset($result['title'])){
          $result['file_ext'] = $this->_get_extension_file($result['title']);
        }

        // Cart Value
        $cartArr[] = $result['sourceint1'].'-'.$result['sourcecsv23']; 
        

      } else {
        // Cart Value
        $cartArr[]= $result['sourceint1'];
      } 
      switch($type){
        case 'asset':
          $renderable = [ '#theme' => 'custom_search_asset','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'reference':
          $renderable = [ '#theme' => 'custom_search_reference','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'pages':
          $renderable = [ '#theme' => 'custom_search_pages','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'news':
          $renderable = [ '#theme' => 'custom_search_news','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'event':
          $renderable = [ '#theme' => 'custom_search_events','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'yammer message':
          $renderable = [ '#theme' => 'custom_search_yammer','#data' => $result];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'km file':
          $renderable = [ '#theme' => 'custom_search_attachments','#data' => $result,];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'user_profile':
		  if(empty($result['url1']) || !isset($result['url1']) || $result['url1'] == null){
            $result['url1'] = '/user/' . $result['sourceint5'] . '/profile';
          }
          if(empty($result['content_user_id']) || !isset($result['content_user_id']) || $result['content_user_id'] == null){
            $result['content_user_id'] = $result['sourceint5'];
          }
          $renderable = [ '#theme' => 'custom_search_user','#data' => $result,];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
        case 'group':
          $renderable = [ '#theme' => 'custom_search_community','#data' => $result,];
          $rendered .= \Drupal::service('renderer')->renderPlain($renderable);
          break;
      }
    }
    // This values is been accessed in Add to All Cart Button
		if(isset($cartArr) && !empty($cartArr)){
      $_SESSION['search']['all_cart_ids'] = implode(",",$cartArr);
		}
    
    if(isset($_SESSION['search']) && !empty($_SESSION['search']) && isset($_SESSION['search']['skipCount'])){
			$limit = $_SESSION['search']['skipCount'];
		}
		else{
			$limit = 50;
		}
		if(isset($sinequa_result_array['TotalRowCount'])){
      $totalItems = $sinequa_result_array['TotalRowCount'];
		}
		if(isset($totalItems)){
      $current_page = \Drupal::service('pager.manager')->createPager($totalItems, $limit)->getCurrentPage();
		}
    $return_array = ['rendered' => isset($rendered)?$rendered:'', 'total_count' => isset($totalItems)?$totalItems:''];
    return $return_array;
  }
  public function _search_create_rating_star($rating) {
		$rating_star = '';
		$starString = '';
    // Created the custom rating as not sure about any theme available for displaying rating using rating module.
    // if any features found need to replace this.
    switch($rating) {
      case '20':
        $rating_star = 1;
      break;
      case '40':
        $rating_star = 2;
      break;
      case '60':
        $rating_star = 3;
      break;
      case '80':
        $rating_star = 4;
      break;
      case '100':
        $rating_star = 5;
      break;
      case '':
        $rating_star = 0;
      break;
    }
    for($i=0;$i<5;$i++){
      $class = '';
      if($i < $rating_star) {
        $class = 'selected';
      }
      $starString.= '<div class="star '.$class.'"></div>';
    }
    return $starString;
  }
  public function _get_extension_file($file_name) {
    #global $base_url;
    $ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $ext = strtolower(trim($ext));
    $ext = ($ext != '0' || strlen($ext) > 10) ? $ext : 'unknown';
    $default_theme_name = \Drupal::config('system.theme')->get('default');
    $theme_path = \Drupal::service('extension.list.theme')->getPath($default_theme_name);
    if($ext == NULL)
      $ext = 'unknown';
    return $base_url . '/'.$theme_path.'/images/extension/' . $ext . '-icon.gif';
  }
  /**
   * Add highlight to text for Advanced Search.
   */
  public function highlight_multi_items_sinequa($RowObjects) {
    ########### Cleaning Content ################.
    $desiredLength = 200;
    if($RowObjects['e'][0] != '') {
      foreach($RowObjects['e'] as $key => $value) {
        foreach($value as $meta_key => $meta_value ) {
          if($meta_key == 'sourcestr4') {
            if(isset($meta_value) && !empty($meta_value) && $meta_value != '' && $meta_value != null){
              $meta_value = strip_tags($meta_value);
              if (mb_strlen($meta_value) <=  $desiredLength) {
                $string = $meta_value;           
              }
              else {       
                $string = mb_substr($meta_value, 0, mb_strpos($meta_value,' ',$desiredLength-1));
              }
						}
            $RowObjects['e'][$key][$meta_key] = $string;
          }
        }
      }
    } else {
      foreach($RowObjects['e'] as $key => $value) {
        if($key == 'sourcestr4') {
          $meta_value = strip_tags($value);
          if (mb_strlen($meta_value) <=  $desiredLength) {
            $string = $meta_value;           
          }
          else {       
            $string = mb_substr($meta_value, 0, mb_strpos($meta_value,' ',$desiredLength-1));
          }
          $RowObjects['e'][$key] = $string;
        }
      }
    }
    ########### Cleaning Content ################
    if(!empty($_SESSION['search']['with_at_least_one_of_the_words'])){
      if($RowObjects['e'][0] != '') {
        foreach($RowObjects['e'] as $key => $value) {
          foreach($value as $meta_key => $meta_value ) {
            if($meta_key == 'title') {
              $string = $meta_value;
              $text_highlight = $this->highlight($string, $_SESSION['search']['with_at_least_one_of_the_words'],1);
                $RowObjects['e'][$key][$meta_key] = $text_highlight;
            }
            if($meta_key == 'sourcestr4') {
              $string = $meta_value;
              $text_highlight = $this->highlight($string, $_SESSION['search']['with_at_least_one_of_the_words'],1);
                $RowObjects['e'][$key][$meta_key] = $text_highlight;
            }
          }
        }
      }
      else{
        foreach($RowObjects['e'] as $key => $value) {
          if($key == 'title') {
            $string = $value;
            $text_highlight = $this->highlight($string, $_SESSION['search']['with_at_least_one_of_the_words'],1);
            $RowObjects['e'][$key] = $text_highlight;
          }
          if($key == 'sourcestr4') {
            $string = $value;
            $text_highlight = $this->highlight($string, $_SESSION['search']['with_at_least_one_of_the_words'],1);
            $RowObjects['e'][$key] = $text_highlight;
          }
        }
      }
    }
    if(!empty($_SESSION['search']['with_all_of_the_words'])){
      if($RowObjects['e'][0] != '') {
        foreach($RowObjects['e'] as $key => $value) {
          foreach($value as $meta_key => $meta_value ) {
              if($meta_key == 'title') {
                $string = $meta_value;
                $text_highlight = $this->highlight($string, $_SESSION['search']['with_all_of_the_words'],1);
                $RowObjects['e'][$key][$meta_key] = $text_highlight;
              }
              if($meta_key == 'sourcestr4') {
                $stringsourcestr4 = $meta_value;
                $text_highlight_sourcestr4 = $this->highlight($stringsourcestr4,$_SESSION['search']['with_all_of_the_words'],1);
                $RowObjects['e'][$key][$meta_key] = $text_highlight_sourcestr4;
              }
          }
        }
      }
      else{
        foreach($RowObjects['e'] as $key => $value) {
          if($key == 'title') {
            $string = $value;
            $text_highlight = $this->highlight($string, $_SESSION['search']['with_all_of_the_words'],1);
            $RowObjects['e'][$key] = $text_highlight;
          }
          if($key == 'sourcestr4') {
            $string = $value;
            $text_highlight_sourcestr4 = $this->highlight($string, $_SESSION['search']['with_all_of_the_words'],1);
            $RowObjects['e'][$key] = $text_highlight_sourcestr4;
          }
        }
      }
    }
    if(!empty($_SESSION['search']['with_the_exact_phrase'])){
      if($RowObjects['e'][0] != '') {
        foreach($RowObjects['e'] as $key => $value) {
          foreach($value as $meta_key => $meta_value ) {
            if($meta_key == 'title') {
              $string = $meta_value;
              $quotes = preg_match_all("/\"[^\"]*\"/", $_SESSION['search']['with_the_exact_phrase'], $exact_words_with_quotes);
              if ($quotes > 1) {
                foreach ($exact_words_with_quotes[0] as $search_string) {
                $text_highlight = $this->highlight($string, $search_string,2);
                $string = $text_highlight;
                }
              } else {
                $text_highlight = $this->highlight($string, $_SESSION['search']['with_the_exact_phrase'],2);
              }

              $RowObjects['e'][$key][$meta_key] = $text_highlight;
            }
            if($meta_key == 'sourcestr4') {
              $string = $meta_value;
              $quotes = preg_match_all("/\"[^\"]*\"/", $_SESSION['search']['with_the_exact_phrase'], $exact_words_with_quotes);
              if ($quotes > 1) {
                foreach ($exact_words_with_quotes[0] as $search_string) {
                $text_highlight_sourcestr4 = $this->highlight($string, $search_string,2);
                $string = $text_highlight_sourcestr4;
                }
              } else {
                $text_highlight_sourcestr4 = $this->highlight($string, $_SESSION['search']['with_the_exact_phrase'],2);
              }
              $RowObjects['e'][$key][$meta_key] = $text_highlight_sourcestr4;
            }
          }
        }
      }
      else{
        foreach($RowObjects['e'] as $key => $value) {
          if($key == 'title') {
            $string = $value;
            $text_highlight = $this->highlight($string,$_SESSION['search']['with_the_exact_phrase'],2);
            $RowObjects['e'][$key] = $text_highlight;
          }
          if($key == 'sourcestr4') {
            $string = $value;
            $text_highlight_sourcestr4 = $this->highlight($string, $_SESSION['search']['with_the_exact_phrase'],2);
            $RowObjects['e'][$key] = $text_highlight_sourcestr4;
          }
        }
      }
    }
    return $RowObjects;
  }

	/**
   * Add highlight to reference fields.
   */
	function highlight_references_fields_sinequa($result) {
		$data = $_SESSION['search'];
		if(isset($data['sector']) && !empty($data['sector'])){
			foreach($data['sector'] as $sec) {
				// strtr in place of str_replace.
			$sec_trans = array('"' => "");
			$sec = strtr($sec, $sec_trans);
				if(isset($result['e'][0])) {
					foreach($result['e'] as $i => $dataset) {
						foreach($dataset as $key => $value){
							if($key == 'sourcecsv38'){
								$result['e'][$i][$key] = $this->highlight($value,$sec,2);
							}
						}
					}
				} else {
					foreach($result['e'] as $key => $value){
						if($key == 'sourcecsv38'){
							$result['e'][$key] = $this->highlight($value,$sec,2);
						}
					}
				}
			}
		}
		if(isset($data['industry']) && !empty($data['industry'])){
			
			foreach($data['industry'] as $ind) {
			 // strtr in place of str_replace.
		 $ind_trans = array('"' => "");
		 $ind = strtr($ind, $ind_trans);
				if(isset($result['e'][0])) {
					foreach($result['e'] as $i => $dataset) {
						foreach($dataset as $key => $value){
							if($key == 'sourcecsv39'){
								$result['e'][$i][$key] = $this->highlight($value,$ind,2);
							}
						}
					}
				} else {
					foreach($result['e'] as $key => $value){
						if($key == 'sourcecsv39'){
							$result['e'][$key] = $this->highlight($value,$ind,2);
						}
					}
				}
			}
		}
		if(isset($data['account']) && !empty($data['account'])){
			foreach($data['account'] as $acc) {
				// strtr in place of str_replace.
			 $acc_trans = array('"' => "");
			 $acc = strtr($acc, $acc_trans);
				if(isset($result['e'][0])) {
					foreach($result['e'] as $i => $dataset) {
						foreach($dataset as $key => $value){
							if($key == 'sourcestr19'){
								$result['e'][$i][$key] = $this->highlight($value,$acc);
							}
						}
					}
				} else {
					foreach($result['e'] as $key => $value){
						if($key == 'sourcestr19'){
							$result['e'][$key] = $this->highlight($value,$acc);
						}
					}
				}
			}
		}

		if(isset($data['entry_portfolio']) && !empty($data['entry_portfolio'])){
			#dd($data['entry_portfolio']);
			foreach($data['entry_portfolio'] as $dep){
				$dep_trans = array('"' => "");
				$dep = strtr($dep, $dep_trans);
				if(isset($result['e'][0])) {
					
					foreach($result['e'] as $i => $dataset) {
						foreach($dataset as $key => $value){

							if($key == 'sourcecsv12'){
								//dump($value);
								$result['e'][$i][$key] = $this->highlight($value,$dep,2);
							}
						}
					}
				} else {
					foreach($result['e'] as $key => $value){
						if($key == 'sourcecsv12'){
							$result['e'][$key] = $this->highlight($value,$dep,2);
						}
					}
				}
			}//die;
		}
	  #echo '<pre>' .print_r($result,'\n'). '</pre>';die;
		return $result;
	}

  /**
   * Add highlight to text for sinequa.
   */
  public function highlight_processing_sinequa($RowObjects) {
    $type_of_search = 1;
    $desiredLength = 200;
    $needle = trim($_SESSION['search']['keyword']);
    if(isset($RowObjects['e'][0])){
      foreach($RowObjects['e'] as $key => $value) {
        foreach($value as $meta_key => $meta_value ) {
          if($meta_key == 'title') {
            $string = $meta_value;
            if(preg_match('/^(["\']).*\1$/m', $needle)){
              $type_of_search = 2;
            }
            $extra_number = strlen($needle);
            if(isset($needle) && !empty($needle)){
              $text_highlight = $this->highlight($string, $needle, $type_of_search);
            } else {
              $text_highlight = $string;
            }
            $RowObjects['e'][$key][$meta_key] = $text_highlight;
          }
          if($meta_key == 'sourcestr4') {
            if(isset($meta_value) && !empty($meta_value)){
              $meta_value = strip_tags($meta_value);
              if (mb_strlen($meta_value) <=  $desiredLength) {
                $string = $meta_value;
              }
              else {
                $string = mb_substr($meta_value, 0, mb_strpos($meta_value,' ',$desiredLength-1));
              }
            }
            if(preg_match('/^(["\']).*\1$/m', $needle)){
              $type_of_search = 2;
            }
            if(isset($needle) && !empty($needle)){
              $text_highlight = $this->highlight($string, $needle, $type_of_search);
            } else {
              $text_highlight = $string;
            }
            $RowObjects['e'][$key][$meta_key] = $text_highlight;
          }
        }
      }
    }
    else{
      foreach($RowObjects['e'] as $meta_key => $meta_value ) {
        if($meta_key == 'title') {
          $string = $meta_value;
          if(preg_match('/^(["\']).*\1$/m', $needle)){
            $type_of_search = 2;
          }
          if(isset($needle) && !empty($needle)){
            $text_highlight = $this->highlight($string, $needle, $type_of_search);
          } else {
            $text_highlight = $string;
          }
          $RowObjects['e'][$meta_key] = $text_highlight;
        }
        if($meta_key == 'sourcestr4') {
          $meta_value = strip_tags($meta_value);
          if (mb_strlen($meta_value) <=  $desiredLength) {
            $string = $meta_value;           
          }
          else {       
            $string = mb_substr($meta_value, 0, mb_strpos($meta_value,' ',$desiredLength-1));
          }
          if(preg_match('/^(["\']).*\1$/m', $needle)){
            $type_of_search = 2;
          }
          if(isset($needle) && !empty($needle)){
            $text_highlight = $this->highlight($string, $needle, $type_of_search);
          } else {
            $text_highlight = $string;
          }
          $RowObjects['e'][$meta_key] = $text_highlight;
        }
      }
    }
    return $RowObjects;
  }
  public function highlight($text, $words, $type=1) {
    // New Highlight Code Implemented.
    // strtr in place of str_replace.
    $trans = array('"' => "",'+'=>" ");
    $words = strtr($words, $trans);
    if($type == 1){
      preg_match_all('~\S+|\d+~', $words, $m);
      if(!$m){
          return $text;
      }
      $search = array('\\','+','#','.','*','?','[','^',']','$','(',')','{','}','=','!','<','>','|',':','-',"'");
      $replace = array("'\/'",'\+','\#','\.','\*','\?','\[','\^','\]','\$','\(','\)','\{','\}','\=','\!','\<','\>','\|','\:','\-',"");
      $m[0] = str_replace($search,$replace,$m[0]);
      #echo'<pre>';print_r($m);echo'</pre>';
      $re = '#'. implode('|',$m[0]) .'#i';
      #echo $re.'<br />';
    } else {
      $search = array('\\','+','#','.','*','?','[','^',']','$','(',')','{','}','=','!','<','>','|',':','-',"'");
      $replace = array("'\/'",'\+','\#','\.','\*','\?','\[','\^','\]','\$','\(','\)','\{','\}','\=','\!','\<','\>','\|','\:','\-',"");
      $words = str_replace($search,$replace,$words);	
      $re = '#'. $words .'#i';
    }
    $text = preg_replace($re, '<span class="highlight">\\0</span>', $text);
    return $text;
  }
  
  /**
   * Handler for advanced search user fields autocomplete request.
   */
  public function handleadvsearchAutocomplete(Request $request) {
    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);

    $query = \Drupal::database()->select('users_field_data', 'ufd');
    $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
    $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
    $query->addField('f', 'field_name_first_value', 'firstname');
    $query->addField('l', 'field_name_last_value', 'lastname');
    $query->addField('ufd', 'uid', 'id');
    $query->addField('ufd', 'mail', 'email');
    $query->range(0, 10);
    $query->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q OR ufd.mail LIKE :q", array(':q'=> '%' . $input . '%'));
    $results = $query->execute()->fetchAll();
    $valuesdelux = [];
    foreach ($results as $result) {
      $val = $result->firstname . ' ' . $result->lastname;
      $lable = $val . ' [' . $result->email . '] [' . $result->id . ']';
      $valuesdelux[$val.' ('.$result->id.')'] = $lable;
    }
    // Check if no results were found.
    if (empty($valuesdelux)) {
        return new JsonResponse([
            'message' => "<div class='suggestion-msg'>There are no more results with '{$input}'. Try others or more input.</div>"
        ]);
    }
    return new JsonResponse($valuesdelux);
  }
  public function standardSearchKeywordAutocomplete(Request $request) {
    $results = [];
    $string = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$string) {
      return new JsonResponse($results);
    }

    $suggestion = array();
    $xml = "<Sinequa>
    <method>search.suggest</method>
    <profile>km3profile</profile>
    <suggestionQuery>km3SuggestQuery</suggestionQuery>
    <text>$string</text>
    <user>SinKm3</user>
    <password>SinKm3@123</password>
    </Sinequa>";
    $data = sinequa_search_request_xml($xml);
    $doc = simplexml_load_string($data);

    if($doc->ErrorCode != 1) {
      $json = Json::encode($doc);
      $entries = Json::decode($json);
      if(isset($entries['Suggests']['e'][0])) {
        foreach($entries['Suggests']['e'] as $item) {
          $value = (string) $item['Display'];
          $suggestion[]['label'] = htmlspecialchars_decode($value);
        }
      }
      else{
        $value = (string) $entries['Suggests']['e']['Display'];
        $suggestion[]['label'] = htmlspecialchars_decode($value);
      }
      if(empty($suggestion[0]['label'])) {
        $suggestion[0]['label'] = 'No results found';
      }
      return new JsonResponse($suggestion);
    }
    else{
      if(empty($suggestion[0]['label'])) {
        $suggestion[0]['label'] = 'No results found';
      }
      return new JsonResponse($suggestion);
    }
  }

  public function standard_search_sinequa_km_all_results(){
    $param = \Drupal::request()->query->all();
    #dump($param);
    $prism_search_url['q_key'] = $param['q_key'];
    if(isset($param['community_id']) && !empty($param['community_id'])){
     $prism_search_url['community_id'] = $param['community_id'];
    }
    if($param['form_id'] == 'exalead_basic_search_form') {
      $prism_search_url['form_id'] = 'custom_standard_search_form';
    }
    // Facets
    if(isset($param['facets']) && !empty($param['facets'])){
      $prism_search_url['facets'] = $param['facets'];
    }

    // Sortby
    if(isset($param['sortby']) && !empty($param['sortby'])){
     $prism_search_url['sortby'] = $param['sortby'];
    }

    // Pagination
    $prism_search_url['page'] = $param['page'];
    // limit
    if(isset($param['per_page']) && !empty($param['per_page'])){
     $prism_search_url['per_page'] = $param['per_page'];
    }
    // Captured 1
    $prism_search_url['captured'] = 1;

    $url = Url::fromRoute('custom_search.search_sinequa_all_results', $prism_search_url);
    #echo $url->toString();
    #dd($prism_search_url);
    return new RedirectResponse($url->toString());
  }

  public function standard_search_sinequa_km_content_results(){
    $param = \Drupal::request()->query->all();
    #dump($param);
    $prism_search_url = array();
    $prism_search_url['q_key'] = $param['q_key'];
    if(isset($param['community_id']) && !empty($param['community_id'])){
     $prism_search_url['community_id'] = $param['community_id'];
    }


    // Track Form ID
    if($param['form_id'] == 'advanced_search_assets_entityform_edit_form') {
      $prism_search_url['form_id'] = 'custom_advanced_search_asset_form';
    } elseif ($param['form_id'] == 'advanced_search_references_entityform_edit_form') {
      $prism_search_url['form_id'] = 'custom_advanced_search_reference_form';
    } elseif ($param['form_id'] == 'advanced_search_ishowcase_entityform_edit_form') {
      $prism_search_url['form_id'] = 'custom_advanced_search_asset_reference_form';
    } elseif ($param['form_id'] == 'advanced_search_people_entityform_edit_form') {
      $prism_search_url['form_id'] = 'custom_advanced_search_people_form';
    }

    // Submitter
    if(isset($param['submitter']) && !empty($param['submitter'])) {
      $param['submitter'] = str_replace(array('"','+'),array('',' '),urldecode($param['submitter']));
      if(strpos($param['submitter'],'OR')) {
        $exp_submitter = explode('OR', $param['submitter']);
        $exp_submitter = array_map('trim',$exp_submitter);
        $prism_search_url['submitter'] = $exp_submitter;
      } else {
        $prism_search_url['submitter'][0] = $param['submitter'];
      }
    }
    // Contact
    if(isset($param['contacts']) && !empty($param['contacts'])) {
      $param['contacts'] = str_replace(array('"','+'),array('',' '),urldecode($param['contacts']));
      if(strpos($param['contacts'],'OR')) {
        $exp_contact = explode('OR', $param['contacts']);
        $exp_contact = array_map('trim',$exp_contact);
        $prism_search_url['contacts'] = $exp_contact;
      } else {
        $prism_search_url['contacts'][0] = $param['contacts'];
      }
    }
    // Other Contributor
    if(isset($param['other_contributors']) && !empty($param['other_contributors'])) {
      $param['other_contributors'] = str_replace(array('"','+'),array('',' '),urldecode($param['other_contributors']));
      if(strpos($param['other_contributors'],'OR')) {
        $exp_other_contributor = explode('OR', $param['other_contributors']);
        $exp_other_contributor = array_map('trim',$exp_other_contributor);
        $prism_search_url['other_contributors'] = $exp_other_contributor;
      } else {
        $prism_search_url['other_contributors'][0] = $param['other_contributors'];
      }
    }
    // Account
    if(isset($param['account']) && !empty($param['account'])) {
      $param['account'] = str_replace(array('"','+'),array('',' '),urldecode($param['account']));
      if(strpos($param['account'],'OR')) {
        $exp_account = explode('OR', $param['account']);
        $exp_account = array_map('trim',$exp_account);
        $prism_search_url['account'] = $exp_account;
      } else {
        $prism_search_url['account'][0] = $param['account'];
      }
    }

    // Status
    if(isset($param['status']) && !empty($param['status'])) {
      $param['status'] = str_replace(array('+'),array(' '),urldecode($param['status']));
      $prism_search_url['status'] = $param['status'];
    }

    // Rating
    if(isset($param['ratings']) && !empty($param['ratings'])){
     $prism_search_url['ratings'] = $param['ratings'];
    }

    // Created Date
    if(isset($param['creation_date']) && !empty($param['creation_date'])){
     $prism_search_url['creation_date'] = $param['creation_date'];
    }

    // Updated Date
    if(isset($param['updated_date']) && !empty($param['updated_date'])){
     $prism_search_url['updated_date'] = $param['updated_date'];
    }


    // Category
    if(isset($param['category']) && !empty($param['category'])) {
      $param['category'] = str_replace(array('"','+'),array('',' '),urldecode($param['category']));
      if(strpos($param['category'],'OR')) {
        $exp_category = explode('OR', $param['category']);
        $exp_category = array_map('trim',$exp_category);
        foreach($exp_category as $category_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($category_val,'category',0,1);
          $exp_category_id[] = $taxo_id;
        }
        $prism_search_url['category'] = array_filter($exp_category_id);
      } else {
        $taxo_id_category = $this->_get_taxonony_name_by_id($param['category'],'category',0,1);
        $prism_search_url['category'][0] = $taxo_id_category;
      }
    }

    // Originating Country
    if(isset($param['originating_countries']) && !empty($param['originating_countries'])) {
      $param['originating_countries'] = str_replace(array('"','+'),array('',' '),urldecode($param['originating_countries']));
      if(strpos($param['originating_countries'],'OR')) {
        $exp_originating_countries = explode('OR', $param['originating_countries']);
        $exp_originating_countries = array_map('trim',$exp_originating_countries);
        $prism_search_url['originating_countries'] = $exp_originating_countries;
      } else {
        $prism_search_url['originating_countries'][0] = $param['originating_countries'];
      }
    }

    // Sector
    if(isset($param['sector']) && !empty($param['sector'])) {
      $param['sector'] = str_replace(array('"','+'),array('',' '),urldecode($param['sector']));
      if(strpos($param['sector'],'OR')) {
        $exp_sector = explode('OR', $param['sector']);
        $exp_sector = array_map('trim',$exp_sector);
        foreach($exp_sector as $sector_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($sector_val,'groupsector',0,1);
          $exp_sector_id[] = $taxo_id;
        }
        $prism_search_url['sector'] = array_filter($exp_sector_id);
      } else {
        $taxo_id_sector = $this->_get_taxonony_name_by_id($param['sector'],'groupsector',0,1);
        $prism_search_url['sector'][0] = $taxo_id_sector;
      }
    }

    // Industry
    if(isset($param['industry']) && !empty($param['industry'])) {
      $param['industry'] = str_replace(array('"','+'),array('',' '),urldecode($param['industry']));
      if(strpos($param['industry'],'OR')) {
        $exp_industry = explode('OR', $param['industry']);
        $exp_industry = array_map('trim',$exp_industry);
        foreach($exp_industry as $industry_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($industry_val,'groupsector',$prism_search_url['sector'],2);
          $exp_industry_id[] = $taxo_id;
        }
        $prism_search_url['industry'] = array_filter($exp_industry_id);
      } else {
        $taxo_id_industry = $this->_get_taxonony_name_by_id($param['industry'],'groupsector',$prism_search_url['sector'],2);
        $prism_search_url['industry'][0] = $taxo_id_industry;
      }
    }

    // Industry Segment
    if(isset($param['industry_segment']) && !empty($param['industry_segment'])) {
      $param['industry_segment'] = str_replace(array('"','+'),array('',' '),urldecode($param['industry_segment']));
      if(strpos($param['industry_segment'],'OR')) {
        $exp_industry_seg = explode('OR', $param['industry_segment']);
        $exp_industry_seg = array_map('trim',$exp_industry_seg);
        foreach($exp_industry_seg as $industry_seg_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($industry_seg_val,'groupsector',$prism_search_url['industry'],3);
          $exp_industry_seg_id[] = $taxo_id;
        }
        $prism_search_url['industry_segment'] = array_filter($exp_industry_seg_id);
      } else {
        $taxo_id_industry_seg = $this->_get_taxonony_name_by_id($param['industry_segment'],'groupsector',$prism_search_url['industry'],3);
        $prism_search_url['industry_segment'][0] = $taxo_id_industry_seg;
      }
    }

    // Entry Portfolio
    if(isset($param['entry_portfolio']) && !empty($param['entry_portfolio'])) {
      $param['entry_portfolio'] = str_replace(array('"','+'),array('',' '),urldecode($param['entry_portfolio']));
      if(strpos($param['entry_portfolio'],'OR')) {
        $exp_entry_portfolio = explode('OR', $param['entry_portfolio']);
        $exp_entry_portfolio = array_map('trim',$exp_entry_portfolio);
        foreach($exp_entry_portfolio as $entry_portfolio_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($entry_portfolio_val,'entry_portfolio',0,1);
          $exp_entry_portfolio_id[] = $taxo_id;
        }
        $prism_search_url['entry_portfolio'] = array_filter($exp_entry_portfolio_id);
      } else {
        $taxo_id_entry_portfolio = $this->_get_taxonony_name_by_id($param['entry_portfolio'],'entry_portfolio',0,1);
        $prism_search_url['entry_portfolio'][0] = $taxo_id_entry_portfolio;
      }
    }

    // Offers
    if(isset($param['offer']) && !empty($param['offer'])) {
      $param['offer'] = str_replace(array('"','+'),array('',' '),urldecode($param['offer']));
      if(strpos($param['offer'],'OR')) {
        $exp_offer = explode('OR', $param['offer']);
        $exp_offer = array_map('trim',$exp_offer);
        foreach($exp_offer as $offer_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($offer_val,'entry_portfolio',$prism_search_url['entry_portfolio'],2);
          $exp_offer_id[] = $taxo_id;
        }
        $prism_search_url['offer'] = array_filter($exp_offer_id);
      } else {
        $taxo_id_offer = $this->_get_taxonony_name_by_id($param['offer'],'entry_portfolio',$prism_search_url['entry_portfolio'],2);
        $prism_search_url['offer'][0] = $taxo_id_offer;
      }
    }

    // Alliance partner
    if(isset($param['alliance_partner']) && !empty($param['alliance_partner'])) {
      $param['alliance_partner'] = str_replace(array('"','+'),array('',' '),urldecode($param['alliance_partner']));
      if(strpos($param['alliance_partner'],'OR')) {
        $exp_alliance_partner = explode('OR', $param['alliance_partner']);
        $exp_alliance_partner = array_map('trim',$exp_alliance_partner);
        foreach($exp_alliance_partner as $alliance_partner_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($alliance_partner_val,'partner',0,1);
          $exp_alliance_partner_id[] = $taxo_id;
        }
        $prism_search_url['alliance_partner'] = array_filter($exp_alliance_partner_id);
      } else {
        $taxo_id_alliance_partner = $this->_get_taxonony_name_by_id($param['alliance_partner'],'partner',0,1);
        $prism_search_url['alliance_partner'][0] = $taxo_id_alliance_partner;
      }
    }

    // Technologies
    if(isset($param['technologies']) && !empty($param['technologies'])) {
      $param['technologies'] = str_replace(array('"','+'),array('',' '),urldecode($param['technologies']));
      if(strpos($param['technologies'],'OR')) {
        $exp_technologies = explode('OR', $param['technologies']);
        $exp_technologies = array_map('trim',$exp_technologies);
        foreach($exp_technologies as $technologies_val) {
          $taxo_id = $this->_get_taxonony_name_by_id($technologies_val,'technologies',0,1);
          $exp_technologies_id[] = $taxo_id;
        }
        $prism_search_url['technologies'] = array_filter($exp_technologies_id);
      } else {
        $exp_technologies_id = $this->_get_taxonony_name_by_id($param['technologies'],'technologies',0,1);
        $prism_search_url['technologies'][0] = $exp_technologies_id;
      }
    }
		
		// community_taxonomy
    if(isset($param['community_taxonomy']) && !empty($param['community_taxonomy'])) {
      $param['community_taxonomy'] = str_replace(array('"','+'),array('',' '),urldecode($param['community_taxonomy']));
      if(strpos($param['community_taxonomy'],'OR')) {
        $exp_community_taxonomy = explode('OR', $param['community_taxonomy']);
        $exp_community_taxonomy = array_map('trim',$exp_community_taxonomy);
        $prism_search_url['community_taxonomy'] = $exp_community_taxonomy;
      } else {
        $prism_search_url['community_taxonomy'][0] = $param['community_taxonomy'];
      }
    }
		
		// community_folders
    if(isset($param['community_folders']) && !empty($param['community_folders'])) {
      $param['community_folders'] = str_replace(array('"','+'),array('',' '),urldecode($param['community_folders']));
      if(strpos($param['community_folders'],'OR')) {
        $exp_community_folders = explode('OR', $param['community_folders']);
        $exp_community_folders = array_map('trim',$exp_community_folders);
        $prism_search_url['community_folders'] = $exp_community_folders;
      } else {
        $prism_search_url['community_folders'][0] = $param['community_folders'];
      }
    }
		
		//user_tags
		if(isset($param['user_tags']) && !empty($param['user_tags'])) {
      $param['user_tags'] = str_replace(array('+'),array(' '),urldecode($param['user_tags']));
      if(strpos($param['user_tags'],',')) {
        $exp_user_tags = explode(',', $param['user_tags']);
        $exp_user_tags = array_map(function($exp_user_tags) { return str_replace('"', '', $exp_user_tags); }, $exp_user_tags);
        $exp_user_tags = array_map('trim',$exp_user_tags);
        $prism_search_url['user_tags'] = $exp_user_tags;
      } if(strpos($param['user_tags'],'" "')) {
        $exp_user_tags = explode('" "', $param['user_tags']);
        $exp_user_tags = array_map(function($exp_user_tags) { return str_replace('"', '', $exp_user_tags); }, $exp_user_tags);
        $exp_user_tags = array_map('trim',$exp_user_tags);
        $prism_search_url['user_tags'] = $exp_user_tags;
      }else {
        $param['user_tags'] = str_replace('"', '', $param['user_tags']);
        $prism_search_url['user_tags'][0] = $param['user_tags'];
      }
    }
		
		// file_format
    if(isset($param['file_format']) && !empty($param['file_format'])) {
      $param['file_format'] = str_replace(array('"','+'),array('',' '),urldecode($param['file_format']));
      if(strpos($param['file_format'],'OR')) {
        $exp_file_format = explode('OR', $param['file_format']);
        $exp_file_format = array_map('trim',$exp_file_format);
        $prism_search_url['file_format'] = implode(' OR ',$exp_file_format);
      } else {
        $prism_search_url['file_format'] = $param['file_format'];
      }
    }
		
		//File Language
		if(isset($param['file_language']) && !empty($param['file_language'])) {
			$prism_search_url['language'] = $param['file_language'];
    }
		
		//File date
		if(isset($param['file_date']) && !empty($param['file_date'])) {
			$today = date('Y/m/d');
			$prism_search_url['file_date'] = $param['file_date'] . '00:00:00 TO ' . $today . ' 23:59:59';
    }
		
    //Managed Services
    if(isset($param['managed_services']) && !isset($param['managed_services'])){
      if($param['managed_services'] == 'True') {
        $prism_search_url['managed_services'] = 1;
      } else {
        $prism_search_url['managed_services'] = 3;
      }
    }

    // Account Country
    if(isset($param['account_country']) && !empty($param['account_country'])){
      $prism_search_url['account_country'] = $param['account_country'];
    }

    // Ultimate Parent Account
    if(isset($param['ultimate_parent_account']) && !empty($param['ultimate_parent_account'])){
      $param['ultimate_parent_account'] = str_replace(array('"','+'),array('',' '),urldecode($param['ultimate_parent_account']));
      $prism_search_url['ultimate_parent_account'] = $param['ultimate_parent_account'];
    }

    // Confidentiality Level
    if(isset($param['confidentiality_level']) && !empty($param['confidentiality_level'])){
      $prism_search_url['confidentiality_level'] = $param['confidentiality_level'];
    }

    // Account Type
    if(isset($param['account_type']) && !empty($param['account_type'])) {
      $param['account_type'] = str_replace(array('"','+'),array('',' '),urldecode($param['account_type']));
      if(strpos($param['account_type'],'OR')) {
        $exp_account_type = explode('OR', $param['account_type']);
        $exp_account_type = array_map('trim',$exp_account_type);
        $prism_search_url['account_type'] = $exp_account_type;
      } else {
        $prism_search_url['account_type'][0] = $param['account_type'];
      }
    }

    //Sustainability Benefit
    if(((isset($param['sustainability_benefit']) && !isset($param['sustainability_benefit']))) || $param['sustainability_benefit']==="False" || $param['sustainability_benefit']==="True"){
      if($param['sustainability_benefit'] == 'True') {
        $prism_search_url['sustainability_benefit'] = "1";
      } else {
        $prism_search_url['sustainability_benefit'] = "3";
      }
    }

    // Contract Type
    if(isset($param['contract_type']) && !empty($param['contract_type'])) {
      $param['contract_type'] = str_replace(array('"','+'),array('',' '),urldecode($param['contract_type']));
      if(strpos($param['contract_type'],'OR')) {
        $exp_contract_type = explode('OR', $param['contract_type']);
        $exp_contract_type = array_map('trim',$exp_contract_type);
        $prism_search_url['contract_type'] = $exp_contract_type;
      } else {
        $prism_search_url['contract_type'][0] = $param['contract_type'];
      }
    }

    // Currency
    if(isset($param['currency']) && !empty($param['currency'])){
      $prism_search_url['currency'] = $param['currency'];
    }
    // Deal Size
    if(isset($param['deal_size']) && !empty($param['deal_size'])){
      $param['deal_size'] = str_replace(array('"','+'),array('',' '),urldecode($param['deal_size']));
      $prism_search_url['deal_size'] = $param['deal_size'];
    }

    // Start Date
    if(isset($param['start_date']) && !empty($param['start_date'])) {
      $param['start_date'] = str_replace(array('"','+'),array('',' '),urldecode($param['start_date']));
      if(strpos($param['start_date'],'TO')) {
        $exp_start_date = explode('TO', $param['start_date']);
        $prism_search_url['reference_start_date'] = $exp_start_date[0] . '00:00:00 TO' . $exp_start_date[1] . ' 23:59:59';
      }
    }

    // End Date
    if(isset($param['end_date']) && !empty($param['end_date'])) {
      $param['end_date'] = str_replace(array('"','+'),array('',' '),urldecode($param['end_date']));
      if(strpos($param['end_date'],'TO')) {
        $exp_end_date = explode('TO', $param['end_date']);
        $prism_search_url['reference_end_date'] = $exp_end_date[0] . '00:00:00 TO' . $exp_end_date[1] . ' 23:59:59';
      }
    }

    // Rightshore model
    if(isset($param['rightshore_model']) && !empty($param['rightshore_model'])){
      $param['rightshore_model'] = str_replace(array('"','+'),array('',' '),urldecode($param['rightshore_model']));
      $prism_search_url['rightshore_model'] = $param['rightshore_model'];
    }

    // capgemini_countries_that_delivered
    if(isset($param['capgemini_countries_that_delivered']) && !empty($param['capgemini_countries_that_delivered'])) {
      $param['capgemini_countries_that_delivered'] = str_replace(array('"','+'),array('',' '),urldecode($param['capgemini_countries_that_delivered']));
      if(strpos($param['capgemini_countries_that_delivered'],'OR')) {
        $exp_cdd = explode('OR', $param['capgemini_countries_that_delivered']);
        $exp_cdd = array_map('trim',$exp_cdd);
        $prism_search_url['capgemini_countries_that_delivered'] = $exp_cdd;
      } else {
        $prism_search_url['capgemini_countries_that_delivered'][0] = $param['capgemini_countries_that_delivered'];
      }
    }

    // client_countries_where_delivered
    if(isset($param['client_countries_where_delivered']) && !empty($param['client_countries_where_delivered'])) {
      $param['client_countries_where_delivered'] = str_replace(array('"','+'),array('',' '),urldecode($param['client_countries_where_delivered']));
      if(strpos($param['client_countries_where_delivered'],'OR')) {
        $exp_ccwd = explode('OR', $param['client_countries_where_delivered']);
        $exp_ccwd = array_map('trim',$exp_ccwd);
        $prism_search_url['originating_countries'] = $exp_ccwd;
      } else {
        $prism_search_url['originating_countries'][0] = $param['client_countries_where_delivered'];
      }
    }

    // Language
    if(isset($param['language']) && !empty($param['language'])){
      $param['language'] = str_replace(array('"','+'),array('',' '),urldecode($param['language']));
      $prism_search_url['language_rf'] = $param['language'];
    }

    // Attachment Type
    if(isset($param['attachment_type']) && !empty($param['attachment_type'])){
      $param['attachment_type'] = str_replace(array('"','+'),array('',' '),urldecode($param['attachment_type']));
      $file_options = [
        "project_snapshot_new" => "Project Snapshot - New Win",
        "project_snapshot_delivery" => "Project Snapshot – Delivery Milestone",
        "project_snapshot" => "Project Snapshot – Project Completion/ Final Project Qualification",
        "case_study" => "Case Study",
        "video" => "Video",
        "press" => "Press Release",
        "article" => "Internal Article",
        "logo" => "Logo",
        "other" => "Other",
      ];
      $prism_search_url['attachment_type'] = array_search($param['attachment_type'],$file_options);
    }

    //job_title_role
    if(isset($param['job_title_role']) && !empty($param['job_title_role'])){
      $prism_search_url['job_title_role'] = $param['job_title_role'];
    }
    //skills_tags
    if(isset($param['skills_tags']) && !empty($param['skills_tags'])){
      $prism_search_url['skills_tags'] = $param['skills_tags'];
    }
    //Languages
    if(isset($param['languages']) && !empty($param['languages'])) {
      $param['languages'] = str_replace(array('"','+'),array('',' '),urldecode($param['languages']));
      if(strpos($param['languages'],'OR')) {
        $exp_ccwd = explode('OR', $param['languages']);
        $exp_ccwd = array_map('trim',$exp_ccwd);
        $prism_search_url['languages'] = $exp_ccwd;
      } else {
        $prism_search_url['languages'][0] = $param['languages'];
      }
    }
    //base_location
    if(isset($param['base_location']) && !empty($param['base_location'])){
      $prism_search_url['base_location'] = $param['base_location'];
    }

    //user_country
    if(isset($param['country']) && !empty($param['country'])){
      $prism_search_url['user_country'] = $param['country'];
    }

    // Facets
    if(isset($param['facets']) && !empty($param['facets'])){
      $prism_search_url['facets'] = $param['facets'];
    }

    // Sortby
    if(isset($param['sortby']) && !empty($param['sortby'])){
     $prism_search_url['sortby'] = $param['sortby'];
    }

    // Pagination
    $prism_search_url['page'] = $param['page'];
    // limit
    if(isset($param['per_page']) && !empty($param['per_page'])){
     $prism_search_url['per_page'] = $param['per_page'];
    }
    // Captured 1
    $prism_search_url['captured'] = 1;


    $url = Url::fromRoute('custom_search.search_sinequa_content_results', $prism_search_url);
    #echo $url->toString();
    #dd($prism_search_url);
    return new RedirectResponse($url->toString());
  }
  public function _get_taxonony_name_by_id($term_name, $vid,$parent_id,$depth) {
    $term_name = html_entity_decode($term_name, ENT_QUOTES, 'UTF-8');
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $tree = $manager->loadTree(
      $vid,
      0,
      $depth,
      TRUE
    );
    $results = [];
    foreach ($tree as $term) {
      $name = str_replace('&',' &',$term->get('name')->value);
      if(($depth == 1 && $vid == 'groupsector' && $name != 'Public & Healthcare')){
        $name = str_replace(' &','&',$term->get('name')->value);
      }
			elseif($vid == 'entry_portfolio'){
				$name = str_replace('  &',' &',$term->get('name')->value);
			}
      if($term_name == $name){
        $term_id = $term->id();
      }
    }
    return $term_id;
  }
}
