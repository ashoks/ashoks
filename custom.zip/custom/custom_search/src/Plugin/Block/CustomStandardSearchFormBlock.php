<?php

namespace Drupal\custom_search\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\NodeInterface;
/**
 * Provides a "Custom Standard Search Form Block".
 *
 * @Block(
 *   id = "custom_standard_search_form_block",
 *   admin_label = @Translation("Standard Search Form Block")
 * )
 */
class CustomStandardSearchFormBlock extends BlockBase {
  public function build() {
    $form = \Drupal::formBuilder()->getForm('\Drupal\custom_search\Form\CustomStandardSearchForm');
		$route_name = \Drupal::routeMatch()->getRouteName();
		$group_id = '';
		$community_type = '';
		$group = \Drupal::routeMatch()->getParameter('group');
		if ($group instanceof Group) {
			$group_id = $group->id();
			$community_type = $group->get('field_community_type')->value;
		}
		$adv_gid = \Drupal::request()->get('adv_gid');
		if (isset($adv_gid) && !empty($adv_gid)) {
			$variables['group_id'] = $adv_gid;
			$group_id = $adv_gid;
			$group = Group::load($adv_gid);
			if ($group instanceof Group) {
				$community_type = $group->get('field_community_type')->value;
			}
		}
		else {
			if ($route_name == 'custom_search.search_sinequa_all_results' || $route_name == 'custom_search.search_sinequa_content_results') {
				if (isset($_SESSION['search']['group_id']) && !empty($_SESSION['search']['group_id'])) {
					$group = Group::load($_SESSION['search']['group_id']);
					if ($group instanceof Group) {
						$group_id = $group->id();
						$community_type = $group->get('field_community_type')->value;
					}
				}
			}
			else {
				
				$current_uri = \Drupal::request()->getRequestUri();
				$path_args = explode('/', $current_uri);
				if ($path_args[1] == 'community') {
					$group = Group::load($path_args[2]);
					if ($group instanceof Group) {
						$group_id = $group->id();
						$community_type = $group->get('field_community_type')->value;
					}
				}
				else {
					$node = \Drupal::routeMatch()->getParameter('node');
					if ($node instanceof NodeInterface) {
						$group = ($node->hasField('field_community'))?$node->get('field_community')->getValue(): null;
						$gid = $group[0]['target_id'];
						$group = Group::load($gid);
						if ($group instanceof Group) {
							$group_id = $group->id();
							$community_type = $group->get('field_community_type')->value;
						}
					}
				}
			}
		}
    return [
      '#theme' => 'standard_search_form',
      '#data' => $form,
	  '#group_id' => $group_id,
	  '#community_type' => $community_type,
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }
}
