<?php

namespace Drupal\custom_search\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a "Custom Search Sorting Form Block".
 *
 * @Block(
 *   id = "custom_search_sorting_form",
 *   admin_label = @Translation("Search Sorting Form")
 * )
 */
class CustomSearchSortingFormBlock extends BlockBase {
  public function build() {
    $form = \Drupal::formBuilder()->getForm('\Drupal\custom_search\Form\CustomSearchSortingForm');
    return $form;
  }
}
