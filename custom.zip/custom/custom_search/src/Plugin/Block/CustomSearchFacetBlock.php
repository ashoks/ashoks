<?php

namespace Drupal\custom_search\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Datetime\Element\DateElementBase;
use Drupal\Core\Datetime\Element\Datetime;
use Drupal\Component\Utility;
use Drupal\Component\Utility\Unicode;

/**
 * Provides a "Custom Search Facet Block".
 *
 * @Block(
 *   id = "custom_search_facet",
 *   admin_label = @Translation("Search Facet Block")
 * )
 */
class CustomSearchFacetBlock extends BlockBase {
  public function build() {
    $facet_output = "";
    $facetCache = "";
    $norecord_message = "";
    $new_general_filters = array();
    $new_additional_filters = array();
    $data = $_SESSION['search'];
    switch($data['form_id']){
      case 'custom_advanced_search_asset_form':
        $current_object = 'asset';
      break;
      case 'custom_advanced_search_reference_form':
        $current_object = 'reference';
      break;
      case 'custom_advanced_search_asset_reference_form':
        $current_object = 'asset_reference';
      break;
      case 'custom_advanced_search_people_form':
        $current_object = 'user_profile';
      break;
      default:
        $current_object = "general";
      break;
    }
    $facets_from_querystring = \Drupal::request()->query->all('facets');
    if(isset($facets_from_querystring) && !empty($facets_from_querystring)) {
      switch($facets_from_querystring['knowledge_object'][0]) {
        case 'user_profile':
          $current_object = 'user_profile';
        break;
        case 'group':
          $current_object = 'group';
        break;
        case 'event':
          $current_object = 'event';
        break;
        case 'news':
          $current_object = 'news';
        break;
        case 'yammer message':
          $current_object = 'yammer message';
        break;
        case 'km file':
          $current_object = 'km file';
        break;
        case 'pages':
          $current_object = 'pages';
        break;
      }
    }
    $sinequa_facets_names = unserialize(CAP_SERVICE_SINEQUA_FACET_NAMES);
    $sinequa_facets_display_per_object = unserialize(CAP_SERVICE_SINEQUA_FACETS_DISPLAY_PER_OBJECT);
    $status_asset = array('0' => 'Live - Not reviewed by community leaders/moderators','1'  => 'Live Gold - Validated by community leaders/moderators','2' => 'Archived');
    $status_reference = array('0' => 'Live - Not reviewed by community leaders/moderators','1'  => 'Live Gold - Validated by community leaders/moderators','2' => 'Archived');
    /**
     * Fetch Facets Data stored in Cache.
     */
		$cache_user_variable = \Drupal::currentUser()->id();
    $facetCache = \Drupal::cache()->get('search_results_facets-'.$cache_user_variable);
    if(isset($facetCache) && !empty($facetCache)) {
      $facets = $facetCache->data;
      // Current Knowledge Object Selection From the Facet List.
      $sinequa_facets_display = $sinequa_facets_display_per_object[$current_object];
      // Changing the order of Knowledge Object's order.
      if(isset($facets['knowledge_object']) && !empty($facets['knowledge_object'])) {
        if(!isset($facets['knowledge_object']['e']['name']) || empty($facets['knowledge_object']['e']['name'])){
          foreach($facets['knowledge_object']['e'] as $ko_values) {
            $temp = Unicode::ucwords($ko_values['display']);
            $ko_array1 = $ko_values;  
            $ko_array2 = array('display' => $temp);  
            $ko_array3 = array_replace($ko_array1,$ko_array2);
            if($ko_values['name'] == 'reference') $kb_sort_array[0]=$ko_array3;
            if($ko_values['name'] == 'asset') $kb_sort_array[1]=$ko_array3;
            if($ko_values['name'] == 'km file') $kb_sort_array[2]=$ko_array3;
            if($ko_values['name'] == 'pages') $kb_sort_array[3]=$ko_array3;
            if($ko_values['name'] == 'yammer message') $kb_sort_array[4]=$ko_array3;
            if($ko_values['name'] == 'group') $kb_sort_array[5]=$ko_array3;
            if($ko_values['name'] == 'user_profile') $kb_sort_array[6]=$ko_array3;
            if($ko_values['name'] == 'news') $kb_sort_array[7]=$ko_array3;
            if($ko_values['name'] == 'event') $kb_sort_array[8]=$ko_array3;
          }
          ksort($kb_sort_array);
          $facets['knowledge_object']['e'] = $kb_sort_array;
        } 
      }
      // Asset and Reference Status Related Change Logic.
      if(!isset($facets['status']['e']['name']) && empty($facets['status']['e']['name'])) {
        foreach($facets['status']['e'] as $key => $value) {
          if($current_object == 'asset') {
            if(array_key_exists($facets['status']['e'][$key]['name'],$status_asset)){
              $facets['status']['e'][$key]['name'] = $status_asset[$facets['status']['e'][$key]['name']];
              $facets['status']['e'][$key]['display'] = $status_asset[$facets['status']['e'][$key]['display']];
            }
          } else {
            if(array_key_exists($facets['status']['e'][$key]['name'],$status_reference)){
              $facets['status']['e'][$key]['name'] = $status_reference[$facets['status']['e'][$key]['name']];
              $facets['status']['e'][$key]['display'] = $status_reference[$facets['status']['e'][$key]['display']];
            }
          }
        }
      } else {
        if($current_object == 'asset') {
          if(array_key_exists($facets['status']['e']['name'],$status_asset)){
            $facets['status']['e']['name'] = $status_asset[$facets['status']['e']['name']];
            $facets['status']['e']['display'] = $status_asset[$facets['status']['e']['display']];
            $facets['status']['e']['count'] = $facets['status']['e']['count'];
          }
        } else {
          if(array_key_exists($facets['status']['e']['name'],$status_reference)){
            $facets['status']['e']['name'] = $status_reference[$facets['status']['e']['name']];
            $facets['status']['e']['display'] = $status_reference[$facets['status']['e']['display']];
            $facets['status']['e']['count'] = $facets['status']['e']['count'];
          }
        }
      }
      // Is Empty is not working as value it holds is 0 & 1,Hence check if the value is string.
      if(isset($facets['showcase']['e']) && is_string($facets['showcase']['e']['name'])) {
        if($facets['showcase']['e']['name'] == "0") {
          $facets['showcase']['e']['name'] =  'No';
          $facets['showcase']['e']['display'] = 'No';
          $facets['showcase']['e']['count'] = $facets['showcase']['e']['count'];
        } elseif($facets['showcase']['e']['name'] == "1") {
          $facets['showcase']['e']['name'] =  'Yes';
          $facets['showcase']['e']['display'] = 'Yes';
          $facets['showcase']['e']['count'] = $facets['showcase']['e']['count'];
        }
      } else {
        if(isset($facets['showcase']['e']) && !empty($facets['showcase']['e'])){
          foreach($facets['showcase']['e'] as $key => $value) {
            if($facets['showcase']['e'][$key]['name'] == "0") {
              $facets['showcase']['e'][$key]['name'] =  'No';
              $facets['showcase']['e'][$key]['display'] = 'No';
              $facets['showcase']['e'][$key]['count'] = $facets['showcase']['e'][$key]['count'];
            } elseif($facets['showcase']['e'][$key]['name'] == "1") {
              $facets['showcase']['e'][$key]['name'] =  'Yes';
              $facets['showcase']['e'][$key]['display'] = 'Yes';
              $facets['showcase']['e'][$key]['count'] = $facets['showcase']['e'][$key]['count'];
            } else {
              unset($facets['showcase']['e'][$key]);
            }
          }
        }
      }
      if(isset($facets['managed_services']['e']['name']) && is_string($facets['managed_services']['e']['name'])) {
        if($facets['managed_services']['e']['name'] == "0"){
          $facets['managed_services']['e']['name'] = 'False';
          $facets['managed_services']['e']['display'] = 'False';
        } elseif($facets['managed_services']['e']['name'] == "1") {
          $facets['managed_services']['e']['name'] = 'True';
          $facets['managed_services']['e']['display'] = 'True';
        }
      } else {
        foreach($facets['managed_services']['e'] as $key => $value) {
          if($facets['managed_services']['e'][$key]['name'] == "0"){
            $facets['managed_services']['e'][$key]['name'] = 'False';
            $facets['managed_services']['e'][$key]['display'] = 'False';
          } elseif($facets['managed_services']['e'][$key]['name'] == "1") {
            $facets['managed_services']['e'][$key]['name'] = 'True';
            $facets['managed_services']['e'][$key]['display'] = 'True';
          } else {
            unset($facets['managed_services']['e'][$key]);
          }
        }
      }
      if(!is_array($facets['sustainability_benefit']['e']) && ($facets['sustainability_benefit']['e']['name'] == "0" || $facets['sustainability_benefit']['e']['name'] == "1")) {
        if($facets['sustainability_benefit']['e']['name'] == 0){
          $facets['sustainability_benefit']['e']['name'] = 'False';
          $facets['sustainability_benefit']['e']['display'] = 'False';
        } elseif($facets['sustainability_benefit']['e'][$key]['name'] == 1) {
          $facets['sustainability_benefit']['e']['name'] = 'True';
          $facets['sustainability_benefit']['e']['display'] = 'True';
        }
      } else {
        foreach($facets['sustainability_benefit']['e'] as $key => $value) {
          if(!is_array($value)){
						if($facets['sustainability_benefit']['e']['name'] == 0){
              $facets['sustainability_benefit']['e']['name'] = 'False';
              $facets['sustainability_benefit']['e']['display'] = 'False';
            } elseif($facets['sustainability_benefit']['e']['name'] == 1) {
              $facets['sustainability_benefit']['e']['name'] = 'True';
              $facets['sustainability_benefit']['e']['display'] = 'True';
            }
					}
					else{
            if($facets['sustainability_benefit']['e'][$key]['name'] == 0){
              $facets['sustainability_benefit']['e'][$key]['name'] = 'False';
              $facets['sustainability_benefit']['e'][$key]['display'] = 'False';
            } elseif($facets['sustainability_benefit']['e'][$key]['name'] == 1) {
              $facets['sustainability_benefit']['e'][$key]['name'] = 'True';
              $facets['sustainability_benefit']['e'][$key]['display'] = 'True';
            }
					}
        }
      }

      // Managing Rating Values and Count.
      if(isset($facets['ratings']) && !empty($facets['ratings'])){
        foreach($facets['ratings']['e'] as $key => $value) {
					if(is_array($value)){
            $ratingrangedata[$value['name']] = $value['count'];
					}
					else{
						$ratingrangedata[$facets['ratings']['e']['name']] = $facets['ratings']['e']['count'];
					}
        }
        $fArray = array_keys($ratingrangedata);
        $miniRating = min($fArray);
        $rating_value_array['display'] = 'Between 4 and 5';
        $rating_value_array['name'] = '80-100';
        $rating_value_array['count'] = $ratingrangedata['80'] + $ratingrangedata['100'];
        if($rating_value_array['count'] > 0) {
          $rating_display_array[] = $rating_value_array;
        }
        if($miniRating < 80) {
          $rating_value_array['display'] = 'Between 3 and 4';
        $rating_value_array['name'] = '60-79';
          $rating_value_array['count'] = $ratingrangedata['60'];
          if($rating_value_array['count'] > 0) {
            $rating_display_array[] = $rating_value_array;
          }
        }
        if($miniRating < 60) {
          $rating_value_array['name'] = '0-59';
          $rating_value_array['display'] = 'Lower than 3';
          if (array_key_exists('0', $ratingrangedata)) {
          $rating_value_array['count'] = $ratingrangedata['0'] + $ratingrangedata['20'] + $ratingrangedata['40'];
        } else {
          $rating_value_array['count'] = $ratingrangedata['20'] + $ratingrangedata['40'];
        }
          if($rating_value_array['count'] > 0) {
            $rating_display_array[] = $rating_value_array;
          }
        }
        if(isset($rating_display_array)){
          $facets['ratings']['e'] = $rating_display_array;
        } else {
          $facets['ratings'] = [];
        }
      }
      if(isset($facets['deal_size']) && !empty($facets['deal_size'])) {
        if(isset($facets['deal_size']['e']['name'])){
					$dealrangedata[$facets['deal_size']['e']['name']] = $facets['deal_size']['e']['count'];
				}
				else{
          foreach($facets['deal_size']['e'] as $dealkey => $dealvalue) {
            $dealrangedata[$dealvalue['name']] = $dealvalue['count'];
          }
				}
        $finalcount1 = $finalcount2 = $finalcount3 = $finalcount4 = $finalcount5 = $finalcount6 = $finalcount7 = 0;
        foreach($dealrangedata as $dealsize => $dealcount){

          if((int)$dealsize >= 0 && (int)$dealsize < 500000){
            $finalcount1 += $dealcount;
            $final_array['0 - 0.5m'] = $finalcount1;
          }
          if((int)$dealsize > 500001 && (int)$dealsize < 1000000){
            $finalcount2 += $dealcount;
            $final_array['0.5 - 1m'] = $finalcount2;
          }
          if((int)$dealsize > 1000001 && (int)$dealsize < 5000000){
            $finalcount3 += $dealcount;
            $final_array['1 - 5m'] = $finalcount3;
          }
          if((int)$dealsize > 5000001 && (int)$dealsize < 10000000){
            $finalcount4 += $dealcount;
            $final_array['5 - 10m'] = $finalcount4;
          }
          if((int)$dealsize > 10000001 && (int)$dealsize < 20000000){
            $finalcount5 += $dealcount;
            $final_array['10 - 20m'] = $finalcount5;
          }
          if((int)$dealsize > 20000001 && (int)$dealsize < 50000000){
            $finalcount6 += $dealcount;
            $final_array['20 - 50m'] = $finalcount6;
          }
          if((int)$dealsize > 50000001){
            $finalcount7 += $dealcount;
            $final_array['>50m'] = $finalcount7;
          }
        }
        foreach($final_array as $fcname => $fcvalue){
          $value_array['name'] = $fcname;
          $value_array['display'] = $fcname;
          $value_array['count'] = $fcvalue;
          $display_array[] = $value_array;
        }
        $facets['deal_size']['e'] = $display_array;
      }
      if(isset($facets['updated_date']) && !empty($facets['updated_date'])) {
        $display_array = array();
        $data = array();
				if(array_key_exists(0,$facets['updated_date']['e']) == false){
					$facets['updated_date']['e'] = array($facets['updated_date']['e']);
				}
        foreach($facets['updated_date']['e'] as $last_updated_date_key => $last_updated_date_value) {
          if(!empty($last_updated_date_value['name'])) {
            $last_updated_date = strtotime($last_updated_date_value['name']);
            $contractDateBegin = strtotime(date('Y-m-d h:i:s'));
            $start_date_string = date('Y-m-d h:i:s',$last_updated_date);
            $dteStart = new DrupalDateTime($start_date_string);
            $end_date_string = date('Y-m-d h:i:s',$contractDateBegin);
            $dteEnd   = new DrupalDateTime($end_date_string);
            $dteDiff  = $dteStart->diff($dteEnd);
            $date_difference = $dteDiff->format('%a');

            if($date_difference < 180){
              if (array_key_exists('0-6', $data)) {
                $sixmonths = $data['0-6'] + $last_updated_date_value['count'];
              } else {
                $sixmonths = $last_updated_date_value['count'];
              }
              $data['0-6'] = $sixmonths;
            }
            if($date_difference > 180 && $date_difference < 365){
              if (array_key_exists('6-12', $data)) {
                $oneyear = $data['6-12'] + $last_updated_date_value['count'];
              } else {
                $oneyear = $last_updated_date_value['count'];
              }
              $data['6-12'] = $oneyear;
            }
            if($date_difference > 365 && $date_difference < 730){
              if (array_key_exists('12-24', $data)) {
                $twoyear = $data['12-24'] + $last_updated_date_value['count'];
              } else {
                $twoyear = $last_updated_date_value['count'];
              }
              $data['12-24'] = $twoyear;
            }
            if($date_difference > 730 && $date_difference < 1095){
              if (array_key_exists('24-36', $data)) {
                $threeyear = $data['24-36'] + $last_updated_date_value['count'];
              } else {
                $threeyear = $last_updated_date_value['count'];
              }
              $data['24-36'] = $threeyear;
            }
            if($date_difference > 1095){
              if (array_key_exists('36', $data)) {
                $morethreeyear = $data['36'] + $last_updated_date_value['count'];
              } else {
                $morethreeyear = $last_updated_date_value['count'];
              }
              $data['36'] = $morethreeyear;
            }
          }
        }
        if(!empty($data['0-6'])){
          $value_array['name'] = '0 - 6 months';
          $value_array['display'] = '0 - 6 months';
          $value_array['count'] = $data['0-6'];
          $display_array[] = $value_array;
        }
        if(!empty($data['6-12'])){
          $value_array['name'] = ' 6 months - 1 year';
          $value_array['display'] = ' 6 months - 1 year';
          $value_array['count'] = $data['6-12'];
          $display_array[] = $value_array;
        }
        if(!empty($data['12-24'])){
          $value_array['name'] = '1 year - 2 years';
          $value_array['display'] = '1 year - 2 years';
          $value_array['count'] = $data['12-24'];
          $display_array[] = $value_array;
        }
        if(!empty($data['24-36'])){
          $value_array['name'] = '2 years - 3 years';
          $value_array['display'] = '2 years - 3 years';
          $value_array['count'] = $data['24-36'];
          $display_array[] = $value_array;
        }
        if(!empty($data['36'])){
          $value_array['name'] = 'More than 3 years';
          $value_array['display'] = 'More than 3 years';
          $value_array['count'] = $data['36'];
          $display_array[] = $value_array;
        }
        $facets['updated_date']['e'] = $display_array;
      }
      // Complete Facet iteration for processing the null values and facet urls
      // Note : any logic related to Facets can be added in this function : _process_facets()
      $facets = _process_facets($facets);
      foreach($sinequa_facets_display['general_filters'] as $gen_filter) {
        if(isset($facets[$gen_filter]) && $facets[$gen_filter] != null && count($facets[$gen_filter]) && array_key_exists($gen_filter,$facets)) {
          if($gen_filter == 'knowledge_object' || $gen_filter == 'submitter') {
            foreach ($facets[$gen_filter]['e'] as $key => $value) {
              $facets[$gen_filter]['e'][$key]['display'] = Unicode::ucwords($facets[$gen_filter]['e'][$key]['display']);
            }
            $new_general_filters[$sinequa_facets_names[$gen_filter]] = $facets[$gen_filter]['e'];
          }
          else {
            foreach ($facets[$gen_filter]['e'] as $key => $value) {
              $facets[$gen_filter]['e'][$key]['display'] = Unicode::ucwords($facets[$gen_filter]['e'][$key]['display']);
            }
            $new_general_filters[$sinequa_facets_names[$gen_filter]] = $facets[$gen_filter]['e'];
          }
        }
      }
      foreach($sinequa_facets_display['additional_filters'] as $add_filter) {
        if(isset($facets[$add_filter]) && $facets[$add_filter] != null && count($facets[$add_filter]) && array_key_exists($add_filter,$facets)) {
          foreach ($facets[$add_filter]['e'] as $key => $value) {
            $facets[$add_filter]['e'][$key]['display'] = Unicode::ucwords($facets[$add_filter]['e'][$key]['display']);
          }
          $new_additional_filters[$sinequa_facets_names[$add_filter]] = $facets[$add_filter]['e'];
        }
      }
      if(empty($new_general_filters) && empty($new_additional_filters)) {
        $norecord_message = "Facet section is empty.";
      }
    } else {
      $norecord_message = "Facet section is empty.";
    }
    return [
      '#theme' => 'custom_search_facets',
      '#general_filters' => $new_general_filters,
      '#additional_filters' => $new_additional_filters,
      '#norecord_message' => $norecord_message,
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }
  /**
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }
}
