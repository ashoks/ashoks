<?php

namespace Drupal\custom_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;

/**
 *
 */
class CustomAdvancedSearchAssetReferenceForm extends FormBase {

  /**
   *
   */
  public function getFormId() {
    return 'custom_advanced_search_asset_reference_form';
  }

  /**
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
		$query_url = [];
    $adv_gid = '';
    $adv_gid = \Drupal::request()->get('adv_gid');
    if((isset($adv_gid) && !empty($adv_gid))) {
      $query_url = ['adv_gid' => $adv_gid];
    }
    $asset_link = Link::createFromRoute(t('Assets'), 'custom_search.advanced_search_asset_form',$query_url);
    $asset_string = $asset_link->toString();
    
    $reference_link = Link::createFromRoute(t('References'), 'custom_search.advanced_search_reference_form',$query_url);
    $reference_string = $reference_link->toString();

    $asset_reference_link = Link::createFromRoute(t('Assets & References'), 'custom_search.advanced_search_asset_reference_form',$query_url);
    $asset_reference_string = $asset_reference_link->toString();

    $people_link = Link::createFromRoute(t('People'), 'custom_search.advanced_search_people_form',$query_url);
    $people_string = $people_link->toString();

    
    $form['advanced_form_link_tab'] = [
      '#type' => 'item',
      '#markup' => '<div class="ko-header bg-surface-secondary border-bottom-subtel p-3">
        <h3 class="h4 mb-0">Advanced Search</h3>
    </div><div class="d-flex flex-column"><div class=""><div class="subnav-list px-3 pt-3 bg-surface-secondary"><ul class="d-flex gap-3 secondary-nav"><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$reference_string->getGeneratedLink().'</li><li class="subnav-list-item active d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_reference_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$people_string->getGeneratedLink().'</li></ul></div></div></div>',
    ];
    $form['fieldset_advanced_search'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '0',
    ];

    $form['fieldset_advanced_search']['with_all_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With <strong>all</strong> of the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#weight' => '0',
      '#prefix' => '<div class="d-flex flex-row p-3 ko-created bg-surface-primary"><div class="searchKeyword"><div class="row"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_the_exact_phrase'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With the <strong>exact phrase</strong>'),
      '#required' => FALSE,
      '#weight' => '1',
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_at_least_one_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With <strong>at least one</strong> of the words'),
      '#required' => FALSE,
      '#weight' => '2',
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['fieldset_advanced_search']['without_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('<strong>Without</strong> the words'),
      '#required' => FALSE,
      '#weight' => '3',
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div>',
    ];

    $form['fieldset_scope'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '1',
    ];

    $scope_options = [
      '0' => $this->t('PRISM Platform'),
      '1' => $this->t('Communities Joined'),
      /* '3' => $this->t('Communities Joined and Sub Communities'), */
    ];

    $form['fieldset_scope']['advanced_search_scope'] = [
      '#type' => 'radios',
      '#options' => $scope_options,
      '#default_value' => 0,
      '#validated' => TRUE,
      '#weight' => '4',
      '#prefix' => '<div class="accordion" id="scope"><div class="accordion-item"><h2 class="accordion-header" id="scopeHeading"></h2><div id="scopeCollapse" class="accordion-collapse collapse show" aria-labelledby="scopeHeading" data-bs-parent="#scope"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-12">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $form['fieldset_basics'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '3',
    ];

    $url = Url::fromRoute(
      'custom_search.advancedsearch_autocomplete',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_basics']['field_adv_submitter'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $url,
      '#new_terms' => 1,
      '#target_type' => 'user',
      '#selection_handler' => 'default',
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '5',
      '#prefix' => '<div class="accordion" id="basicInfo"><div class="accordion-item"><h2 class="accordion-header" id="basicInfoHeading"></h2><div id="basicInfoCollapse" class="accordion-collapse collapse show" aria-labelledby="basicInfoHeading" data-bs-parent="#basicInfo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6"><span for="editSubmitter" class="form-label">Submitter</span><div class="input-group mb-3 select2-wrap">',
      '#suffix' => '</div></div>',
    ];
    $urlAc = Url::fromRoute(
      'custom_search.search_sinequa_account_asset_reference_results',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_basics']['field_adv_search_account'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $urlAc,
      '#target_type' => 'node',
      '#selection_settings' => [
        'target_bundles' => ['asset'],
      ],
      '#selection_handler' => 'default',
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '6',
      '#element_validate' => [[$this, 'field_account_validator']],
      '#prefix' => '<div class="col-6"><div class="mb-3"><span for="editAccount" class="form-label">Accounts</span><div class="input-group mb-3 select2-wrap">',
      '#suffix' => '</div></div></div>',
    ];

    // Fetching Reference - Status Field Data.
    $field_instance = \Drupal::entityTypeManager()->getStorage('field_storage_config')->load('node.field_status_ref');
    $entityTypeManager = \Drupal::service('entity_type.manager');
    $entity = $entityTypeManager->getStorage('node')->create(['type' => 'reference']);
    //$status_options = $field_instance->getOptionsProvider('allowed_value', $entity)->getSettableOptions(); //uncomment
    $status_options = [
     '0' => $this->t('Live - Not Reviewed by Community Leaders/Moderators'),
      '1' => $this->t('Live Gold - Validated by Community Leaders/Moderators'),
      '2' => $this->t('Archived'),
    ];
    $form['fieldset_basics']['field_status'] = [
      '#type' => 'checkboxes',
      '#options' => $status_options,
      '#validated' => TRUE,
      '#title' => '',
      '#weight' => '9',
      '#prefix' => '<div class="col-12 mb-3"><div class="d-flex gap-2 flex-column"><span class="form-label">Status</span>',
      '#suffix' => '</div></div>',
    ];

    $form['fieldset_global_taxonomy'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '4',
    ];

    $sector_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',0,1);
    $sector_terms_listing['none'] = '- None -';
    foreach($sector_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $sector_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);;
    }
    $form['fieldset_global_taxonomy']['field_sector'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($sector_terms_listing)?$sector_terms_listing:[],
      '#title'        => 'Sectors',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_segment',
        'wrapper'  => 'field-segment'
      ],
      '#weight' => '17',
      '#prefix' => '<div class="accordion" id="globalTaxo"><div class="accordion-item"><h2 class="accordion-header" id="globalTaxoHeading"></h2><div id="globalTaxoCollapse" class="accordion-collapse collapse show" aria-labelledby="globalTaxoHeading" data-bs-parent="#globalTaxo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];

    $segment_terms_listing = array();
    $sector_term_selection = $form_state->getValue('field_sector');
    if(isset($sector_term_selection) && !empty($sector_term_selection)) {
      foreach($sector_term_selection as $t => $tv){
        $segment_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',$tv,1,False);
        foreach($segment_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $segment_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $segment_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_segment'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($segment_terms_listing)?$segment_terms_listing:[],
      '#title'        => 'Industries',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#description' => $this->t('Values are displayed only when Sector is selected.'),
      '#prefix' => '<div id="field-segment">',
      '#suffix' => '</div>',
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_subsegment',
        'wrapper'  => 'field-subsegment'
      ],
      '#weight' => '18',
      '#prefix' => '<div id="field-segment" class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $subsegment_terms_listing = array();
    $segment_term_selection = $form_state->getValue('field_segment');
    if(isset($segment_term_selection) && !empty($segment_term_selection)) {
      foreach($segment_term_selection as $t => $tv){
        $subsegment_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',$tv,1,False);
        foreach($subsegment_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $subsegment_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $subsegment_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_subsegment'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($subsegment_terms_listing)?$subsegment_terms_listing:[],
      '#title'        => 'Industry Segment',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
			'#description' => $this->t('Values are displayed only when Industry is selected.'),
      '#prefix' => '<div id="field-subsegment">',
      '#suffix' => '</div>',
      '#weight' => '19',
      '#prefix' => '<div id="field-subsegment" class="col-6"><div class="mb-3 mt-3">',
      '#suffix' => '</div></div>',
    ];

    $form['fieldset_global_taxonomy']['field_gen_ai_offer'] = [
      '#type' => 'checkbox',
      '#title' => 'Gen AI Offer',
      '#size' => 10,
      '#maxlength' => 255,
      '#default_value' => 0,
      '#required' => FALSE,
      '#weight' => '22',
      '#prefix' => '<div class="col-12 order-first"><div class="mb-3">',
      '#suffix' => '</div></div></div>',
    ];

    $genAiPortfolios = [];
    $flag = 0;
    $entry_portfolio_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('entry_portfolio',0,1);
    $entry_portfolio_terms_listing['none'] = '- None -';
    foreach($entry_portfolio_terms as $tid => $term_value) {
      $term_node = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term_value->tid);
      if ($flag == 0) {
        $term_value->name = html_entity_decode($term_value->name);
        $entry_portfolio_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
      }
      if($term_node->get('field_gen_ai')->value == 1){
        $genAiPortfolios[] = $term_value->tid;
      }
    }
    $form['#attached']['drupalSettings']['custom_search']['relatedTids'] = $genAiPortfolios;
    $form['fieldset_global_taxonomy']['field_entry_portfolio'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($entry_portfolio_terms_listing)?$entry_portfolio_terms_listing:[],
      '#title'        => 'Entry Portfolio',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_offer',
        'wrapper'  => 'field-offer'
      ],
      '#weight' => '20',
      '#prefix' => '<div class="row d-flex"><div class="col-6"><div class="mb-3">',
        '#suffix' => '</div></div>',
        '#attached' => [
          'library' => [
            'custom_search/custom_search.custom-search-js',
          ],
        ],
    ];
    $offer_terms_listing = array();
    $entry_portfolio_term_selection = $form_state->getValue('field_entry_portfolio');
    if(isset($entry_portfolio_term_selection) && !empty($entry_portfolio_term_selection)) {
      foreach($entry_portfolio_term_selection as $t => $tv){
        $offer_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('entry_portfolio',$tv,1,False);
        foreach($offer_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $offer_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $offer_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_offer'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($offer_terms_listing)?$offer_terms_listing:[],
      '#title'        => 'Offer',
      '#description' => $this->t('Values are displayed only when Entry Portfolio is selected. Multiple selection is possible with CTRL.'),
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#prefix' => '<div id="field-offer">',
      '#suffix' => '</div>',
      '#weight' => '21',
      '#prefix' => '<div id="field-offer" class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];

    $partner_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('partner');
    $partners_term_list['none'] = '- None -';
    foreach($partner_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $partners_term_list[$term_value->tid] = html_entity_decode($term_value->name);;
    }
    $form['fieldset_global_taxonomy']['field_adv_search_partner'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($partners_term_list)?$partners_term_list:[],
      '#title'        => 'Alliance/Partner',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#weight' => '22',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];

    $managed_services_options = [
      '2' => $this->t('Any'),
      '1' => $this->t('True'),
      '3' => $this->t('False'),
    ];
    $form['fieldset_global_taxonomy']['field_managed_services_am_im'] = [
      '#type' => 'radios',
      '#title' => '',
      '#size' => 10,
      '#maxlength' => 255,
      '#options' => $managed_services_options,
      '#default_value' => '2',
      '#required' => FALSE,
      '#weight' => '23',
      '#prefix' => '<div class="col-6"><span for="managedService" class="form-label">Managed Services(AM/IM)</span><div class=" d-flex gap-3">',
      '#suffix' => '</div></div>',
    ];

    $url = Url::fromRoute(
      'custom_search.search_sinequa_technologies_results',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_global_taxonomy']['field_technologies'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $url,
      '#target_type' => 'taxonomy_term',
      '#selection_handler' => 'default',
      '#selection_settings' => [
        'target_bundles' => [
          'technologies'
        ],
      ],
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '24',
      '#prefix' => '<div class="col-6"><span for="tech" class="form-label">Technologies</span><div class="input-group  select2-wrap">',
      '#suffix' => '</div></div>',
    ];

    $form['fieldset_community_taxonomy_and_user_tags'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '5',
    ];
    $form['fieldset_community_taxonomy_and_user_tags']['field_community_taxonomy'] = [
      '#type' => 'textfield',
      '#title' => 'Community taxonomy',
      '#required' => FALSE,
      '#weight' => '25',
      '#prefix' => '<div class="accordion" id="communityTaxoUser"><div class="accordion-item"><h2 class="accordion-header" id="communityTaxoUserHeading"></h2><div id="communityTaxoUserCollapse" class="accordion-collapse collapse show" aria-labelledby="communityTaxoUserHeading" data-bs-parent="#communityTaxoUser"><div class="accordion-body border-top-subtel"><small id="helpId" class="form-text text-muted mb-3">Commas can be used as separators in fields below.</small><div class="row"><div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['fieldset_community_taxonomy_and_user_tags']['field_adv_search_tags'] = [
      '#type' => 'textfield',
      '#title' => 'User Tags',
      '#required' => FALSE,
      '#weight' => '27',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];
    $results_options = [
      '20' => t('20 results'),
      '50' => t('50 results'),
      '100' => t('100 results'),
    ];
    $form['field_results_each_page'] = [
      '#type' => 'select',
      '#options' => $results_options,
      '#validated' => TRUE,
      '#default_value' => '50',
      '#title' => 'Results on each page',
      '#weight' => '20',
      '#prefix' => '<div class="d-flex flex-row justify-content-between align-items-center"><div class="">',
      '#suffix' => '</div>',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
      '#button_type' => 'primary',
      '#prefix' => '<div class="">',
      '#suffix' => '</div></div>',
    ];

    return $form;
  }

  /**
   *
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   *
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    unset($_SESSION['search']);
    $form_data = [];
    $values = $form_state->cleanValues()->getValues();
    if (empty($_SESSION['search'])) {
       // Converting Keyword values for the advance search
       if(isset($values['with_all_of_the_words'])) {
        $form_data['with_all_of_the_words'] = $values['with_all_of_the_words'];
      }
      if(isset($values['with_the_exact_phrase'])) {
        $form_data['with_the_exact_phrase'] = $values['with_the_exact_phrase'];
      }
      if(isset($values['with_at_least_one_of_the_words'])) {
        $form_data['with_at_least_one_of_the_words'] = $values['with_at_least_one_of_the_words'];
      }
      if(isset($values['without_the_words'])) {
        $form_data['without_the_words'] = $values['without_the_words'];
      }
      // Scope
      $form_data['scope'] = $values['advanced_search_scope'];
      if(isset($values['field_adv_submitter'])) {
		    foreach($values['field_adv_submitter'] as $key => $uval){
          $user = \Drupal\user\Entity\User::load($uval['target_id']);
          $firstname = $user->get('field_name_first')->getValue();
          $lastname = $user->get('field_name_last')->getValue();
          if(isset($firstname[0]['value']) && isset($lastname[0]['value'])){
            $form_data['submitter'][] = $firstname[0]['value'] . ' ' . $lastname[0]['value'];
          }
        }
      }
      if(isset($values['field_adv_search_account']) && !empty($values['field_adv_search_account']) && $values['field_adv_search_account'] != '""') {
				$values['field_adv_search_account'] = str_replace('"','',$values['field_adv_search_account']);
        if(strpos($values['field_adv_search_account'],',')) {
          $account_raw = explode(',',$values['field_adv_search_account']);
        } else {
          $account_raw[] = $values['field_adv_search_account'];
        }
        if(isset($account_raw) && !empty($account_raw)){
          $form_data['account'] = $account_raw;
        }
      }
      $field_instance = \Drupal::entityTypeManager()->getStorage('field_storage_config')->load('node.field_status');
      $entityTypeManager = \Drupal::service('entity_type.manager');
      $entity = $entityTypeManager->getStorage('node')->create(['type' => 'asset']);
      $status_options = $field_instance->getOptionsProvider('allowed_value', $entity)->getSettableOptions();
      $status_data = [];
      foreach($values['field_status'] as $key => $value) {
        if($value !== 0) {
          $status_data[(int)$value] = $status_options[(int)$value];
        }
      }
      if(isset($status_data) && !empty($status_data)){
        $form_data['status'] = $status_data;
      }
      
      if(isset($values['field_sector']) && !empty($values['field_sector']) && ($values['field_sector']['none'] != 'none')) {
        foreach($values['field_sector'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $sector_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['sector'][$tvalue] = $sector_term_name;
        }
      }
      if(isset($values['field_segment']) && !empty($values['field_segment'])) {
        foreach($values['field_segment'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $segment_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['industry'][$tvalue] = $segment_term_name;
        }
      }
      if(isset($values['field_subsegment']) && !empty($values['field_subsegment'])) {
        foreach($values['field_subsegment'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $subsegment_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['industry_segment'][$tvalue] = $subsegment_term_name;
        }
      }
      if(isset($values['field_entry_portfolio']) && !empty($values['field_entry_portfolio']) && ($values['field_entry_portfolio']['none'] != 'none')) {
        foreach($values['field_entry_portfolio'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $portfolio_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['entry_portfolio'][$tvalue] = $portfolio_term_name;
        }
      }
      if(isset($values['field_offer']) && !empty($values['field_offer'])) {
        foreach($values['field_offer'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $offer_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['offer'][$tvalue] = $offer_term_name;
        }
      }
      if(isset($values['field_adv_search_partner']) && !empty($values['field_adv_search_partner']) && ($values['field_adv_search_partner']['none'] != 'none')) {
        foreach($values['field_adv_search_partner'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $oartner_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['alliance_partner'][$tvalue] = $oartner_term_name;
        }
      }
      if(isset($values['field_technologies']) && !empty($values['field_technologies'])) {
        foreach($values['field_technologies'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue['target_id']);
          $offer_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['technologies'][$tvalue['target_id']] = $offer_term_name;
        }  
      }
      if(isset($values['field_managed_services_am_im']) && !empty($values['field_managed_services_am_im']) && $values['field_managed_services_am_im']!=2) {
        $form_data['managed_services'] = $values['field_managed_services_am_im'];
      }
      if(isset($values['field_community_taxonomy']) && !empty($values['field_community_taxonomy'])) {
        if(strpos($values['field_community_taxonomy'],',')){
          $ct_array = explode(',',$values['field_community_taxonomy']);
          $form_data['community_taxonomy'] = $ct_array; 
        } else {
          $form_data['community_taxonomy'] = $values['field_community_taxonomy'];
        }
      }
      if(isset($values['field_adv_search_tags']) && !empty($values['field_adv_search_tags'])) {
        if(strpos($values['field_adv_search_tags'],',')){
          $tag_array = explode(',',$values['field_adv_search_tags']);
          $form_data['user_tags'] = $tag_array; 
        } else {
          $form_data['user_tags'] = $values['field_adv_search_tags'];
        } 
      }
	  if(isset($values['field_results_each_page']) && !empty($values['field_results_each_page'])) {
        $form_data['results_each_page'] = $values['field_results_each_page'];
      }
      $form_data['form_id'] = 'custom_advanced_search_asset_reference_form';
      $form_data['source'] = 'form';
      $form_data['is_new'] = TRUE;
      #dump($form_data); exit;
      $_SESSION['search'] = $form_data;
    }
    $form_state->setRedirect('custom_search.search_sinequa_content_results');
  }

  /**
   *
   */
  public function custom_date_format($form_element, &$form_state) {
    // We unset the current values.
    unset($form_element['year']['#options']);

    // Now we set the range we want.
    // 100 years ago.
    $max_age = date('Y') - 100;
    // 7 years ago
    $min_age = date('Y') - 7;

    // Now we populate the array.
    $form_element['year']['#options'] = [];
    foreach (range($max_age, $min_age) as $year) {
      $form_element['year']['#options'][$year] = $year;
    }

    // We return our modified element.
    return $form_element;
  }
  function populate_segment(array $form, FormStateInterface $form_state){
    unset($form['fieldset_global_taxonomy']['field_subsegment']['#options']);
    $response = new AjaxResponse();
    $response->addCommand(new ReplaceCommand("#field-segment", ($form['fieldset_global_taxonomy']['field_segment'])));
    $response->addCommand(new ReplaceCommand("#field-subsegment", ($form['fieldset_global_taxonomy']['field_subsegment'])));
    return $response;
  }
  function populate_subsegment(array $form, FormStateInterface $form_state){
    return $form['fieldset_global_taxonomy']['field_subsegment'];
  }
  function populate_offer(array $form, FormStateInterface $form_state) {
    return $form['fieldset_global_taxonomy']['field_offer'];
  }
	public function field_account_validator(&$element, FormStateInterface $form_state, &$complete_form) {
    $element['#needs_validation'] = false;
  }
}