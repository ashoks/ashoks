<?php

namespace Drupal\custom_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Url;
use Drupal\Core\Link;

/**
 *
 */
class CustomAdvancedSearchPeopleForm extends FormBase {

  /**
   *
   */
  public function getFormId() {
    return 'custom_advanced_search_people_form';
  }

  /**
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $query_url = [];
    $adv_gid = '';
    $adv_gid = \Drupal::request()->get('adv_gid');
    if((isset($adv_gid) && !empty($adv_gid))) {
      $query_url = ['adv_gid' => $adv_gid];
    }
    $asset_link = Link::createFromRoute(t('Assets'), 'custom_search.advanced_search_asset_form',$query_url);
    $asset_string = $asset_link->toString();
    

    $reference_link = Link::createFromRoute(t('References'), 'custom_search.advanced_search_reference_form',$query_url);
    $reference_string = $reference_link->toString();

    $asset_reference_link = Link::createFromRoute(t('Assets & References'), 'custom_search.advanced_search_asset_reference_form',$query_url);
    $asset_reference_string = $asset_reference_link->toString();

    $people_link = Link::createFromRoute(t('People'), 'custom_search.advanced_search_people_form',$query_url);
    $people_string = $people_link->toString();
    

    $form['advanced_form_link_tab'] = [
      '#type' => 'item',
      '#markup' => '<div class="ko-header bg-surface-secondary border-bottom-subtel p-3">
        <h3 class="h4 mb-0">Advanced Search</h3>
    </div><div class="d-flex flex-column"><div class=""><div class="subnav-list px-3 pt-3 bg-surface-secondary"><ul class="d-flex gap-3 secondary-nav"><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$reference_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_reference_string->getGeneratedLink().'</li><li class="subnav-list-item active d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$people_string->getGeneratedLink().'</li></ul></div></div></div>',
    ];

    $form['fieldset_advanced_search'] = [
      '#type' => 'fieldset',
      '#title' => t(''),
    ];

    $form['fieldset_advanced_search']['with_all_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => t('With <strong>all</strong> of the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="d-flex flex-row p-3 ko-created bg-surface-primary"><div class="searchKeyword"><div class="row"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_the_exact_phrase'] = [
      '#type' => 'textfield',
      '#title' => t('With the <strong>exact phrase</strong>'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_at_least_one_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => t('With <strong>at least one</strong> of the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['fieldset_advanced_search']['without_the_words'] = [
      '#type' => 'textfield',
      '#title' => t('<strong>Without</strong> the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div>',
    ];

    $form['fieldset_scope'] = [
      '#type' => 'fieldset',
      '#title' => '',
    ];

    $scope_options = [
      '0' => $this->t('PRISM Platform'),
      '1' => $this->t('Communities Joined'),
      /* '3' => $this->t('Communities Joined and Sub Communities') */
    ];
    $default_op_value = 0;
    if((isset($adv_gid) && !empty($adv_gid))) {
      $scope_options[2] = t('This Community');
      $default_op_value = 2;
    }
    $form['fieldset_scope']['group_id'] = array(
      '#type' => 'hidden',
      '#value' => $adv_gid, 
    );
    $form['fieldset_scope']['advanced_search_scope'] = [
      '#type' => 'radios',
      '#options' => $scope_options,
      '#default_value' => $default_op_value,
      '#validated' => TRUE,
      '#weight' => '4',
      '#prefix' => '<div class="accordion" id="scope"><div class="accordion-item"><h2 class="accordion-header" id="scopeHeading"></h2><div id="scopeCollapse" class="accordion-collapse collapse show" aria-labelledby="scopeHeading" data-bs-parent="#scope"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-12">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $form['group_adv_search_info'] = [
      '#type' => 'fieldset',
      '#title' => '',
    ];

    $form['group_adv_search_info']['field_job_title_role'] = [
      '#type' => 'textfield',
      '#title' => 'Job Title/Role',
      '#required' => FALSE,
      '#prefix' => '<div class="accordion" id="personalInfo"><div class="accordion-item"><h2 class="accordion-header" id="personalInfoHeading"></h2><div id="personalInfoCollapse" class="accordion-collapse collapse show" aria-labelledby="personalInfoHeading" data-bs-parent="#personalInfo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['group_adv_search_info']['field_skill_tags'] = [
      '#type' => 'textfield',
      '#title' => 'Skill/Tags',
      '#required' => FALSE,
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
   
    $form['group_adv_search_info']['field_adv_search_base_location'] = [
      '#type' => 'textfield',
      '#title' => 'Base Location',
      '#required' => FALSE,
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];
    $country_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('country_user');
    foreach($country_terms as $tid => $term_value) {
      $country_terms_listing[$term_value->tid] = $term_value->name;
    }
    $form['group_adv_search_info']['field_entity_country'] = [
      '#type'         => 'select',
      '#empty_option' => '- None -',
      '#options'      => isset($country_terms_listing)?$country_terms_listing:[],
      '#title'        => 'Country',
      '#required'     => false,
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];


    $languageTerm = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('language',0,1);
    $language_terms_listing['none'] = '- None -';
    foreach($languageTerm as $tid => $term_value) {
      $language_terms_listing[$term_value->tid] = $term_value->description__value;
    }
    
    $form['group_adv_search_info']['field_user_language'] = [
      '#type' => 'select',
      '#title' => 'Language',
      '#empty_option' => 'None',
      '#options'      => isset($language_terms_listing)?$language_terms_listing:[],
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ]; 

    $sbu_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('strategic_business_unit',0,1);
    $sbu_terms_listing['none'] = '- None -';
    foreach($sbu_terms as $tid => $term_value) {
      $sbu_terms_listing[$term_value->tid] = $term_value->name;
    }
    $form['group_adv_search_info']['field_adv_entity_sbu'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($sbu_terms_listing)?$sbu_terms_listing:[],
      '#title'        => 'Business Unit',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#weight' => '17',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div></div></div></div></div></div>',
    ];

   
    /* $form['group_adv_search_work_assignment'] = [
      '#type' => 'fieldset',
      '#title' => '',
    ];

    $form['group_adv_search_work_assignment']['field_adv_search_engagement'] = [
      '#type' => 'textfield',
      '#title' => '',
      '#required' => FALSE,
      '#prefix' => '<div class="accordion" id="workAssign"><div class="accordion-item"><h2 class="accordion-header" id="workAssignHeading"></h2><div id="workAssignCollapse" class="accordion-collapse collapse show" aria-labelledby="workAssignHeading" data-bs-parent="#workAssign"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6"><span for="editEngagement" class="form-label">Engagement</span>',
      '#suffix' => '</div>',
    ];
    $form['group_adv_search_work_assignment']['field_adv_search_client'] = [
      '#type' => 'textfield',
      '#title' => '',
      '#required' => FALSE,
      '#prefix' => '<div class="col-6"><span for="editClient" class="form-label">Client</span>',
      '#suffix' => '</div></div></div></div></div></div>',
    ];
 */
    $results_options = [
      '20' => t('20 results'),
      '50' => t('50 results'),
      '100' => t('100 results'),
    ];
    $form['field_results_each_page'] = [
      '#type' => 'select',
      '#options' => $results_options,
      '#validated' => TRUE,
      '#title' => 'Results on Each Page',
      '#default_value' => '50',
      '#prefix' => '<div class="d-flex flex-row justify-content-between align-items-center"><div class="">',
      '#suffix' => '</div>',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
      '#button_type' => 'primary',
      '#prefix' => '<div class="">',
      '#suffix' => '</div></div>',
    ];

    return $form;
  }

  /**
   *
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   *
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    unset($_SESSION['search']);
    $form_data = [];
    $values = $form_state->cleanValues()->getValues();
    if (empty($_SESSION['search'])) {
      // Converting Keyword values for the advance search
      if(isset($values['with_all_of_the_words'])) {
        $form_data['with_all_of_the_words'] = $values['with_all_of_the_words'];
      }
      if(isset($values['with_the_exact_phrase'])) {
        $form_data['with_the_exact_phrase'] = $values['with_the_exact_phrase'];
      }
      if(isset($values['with_at_least_one_of_the_words'])) {
        $form_data['with_at_least_one_of_the_words'] = $values['with_at_least_one_of_the_words'];
      }
      if(isset($values['without_the_words'])) {
        $form_data['without_the_words'] = $values['without_the_words'];
      }
      // Scope
      $form_data['scope'] = $values['advanced_search_scope'];

      if(isset($values['field_job_title_role']) && !empty($values['field_job_title_role'])) {
        $form_data['job_title_role'] = $values['field_job_title_role'];
      }
      if(isset($values['field_skill_tags']) && !empty($values['field_skill_tags'])) {
        $form_data['skills_tags'] = $values['field_skill_tags'];
      }
      if(isset($values['field_user_language']) && !empty($values['field_user_language'])) {
        foreach($values['field_user_language'] as $tid => $tvalue) {
          if ($tvalue != 'none') {
            $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
            $language_term_name = $term ? $term->get('name')->value : NULL;
            $form_data['languages'][$tvalue] = $language_term_name;
          }
        } 
        
      }
      if(isset($values['field_entity_country']) && !empty($values['field_entity_country'])) {
        $term = \Drupal\taxonomy\Entity\Term::load($values['field_entity_country']);
        $country_term_name = $term ? $term->get('name')->value : NULL;
        $form_data['user_country'] = $country_term_name;
      }
      if(isset($values['field_adv_entity_sbu']) && !empty($values['field_adv_entity_sbu']) && ($values['field_adv_entity_sbu']['none'] != 'none')) {
        foreach($values['field_adv_entity_sbu'] as $tid => $tvalue) {
          $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
          $sbu_term_name = $term ? $term->get('name')->value : NULL;
          $form_data['strategic_business_unit'][$tvalue] = $sbu_term_name;
        }
      }
      if(isset($values['field_adv_search_base_location']) && !empty($values['field_adv_search_base_location'])) {
        $form_data['base_location'] = $values['field_adv_search_base_location'];
      }
      if(isset($values['field_adv_search_engagement']) && !empty($values['field_adv_search_engagement'])) {
        $form_data['engagement'] = $values['field_adv_search_engagement'];
      }
      if(isset($values['field_adv_search_client']) && !empty($values['field_adv_search_client'])) {
        $form_data['account'] = $values['field_adv_search_client'];
      }
      if(isset($values['field_results_each_page']) && !empty($values['field_results_each_page'])) {
        $form_data['results_each_page'] = $values['field_results_each_page'];
      }
      $form_data['form_id'] = 'custom_advanced_search_people_form';
      $form_data['source'] = 'form';
      $form_data['is_new'] = TRUE;
      #dump($form_data); exit;
      $_SESSION['search'] = $form_data;
    }
    $form_state->setRedirect('custom_search.search_sinequa_content_results');
  }

  /**
   *
   */
  public function custom_date_format($form_element, &$form_state) {
    // We unset the current values.
    unset($form_element['year']['#options']);

    // Now we set the range we want.
    // 100 years ago.
    $max_age = date('Y') - 100;
    // 7 years ago
    $min_age = date('Y') - 7;

    // Now we populate the array.
    $form_element['year']['#options'] = [];
    foreach (range($max_age, $min_age) as $year) {
      $form_element['year']['#options'][$year] = $year;
    }

    // We return our modified element.
    return $form_element;
  }

}
