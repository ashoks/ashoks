<?php
/**
 * @file
 * Contains \Drupal\custom_search\Form\CustomSearchSortingForm.
 *
 */
namespace Drupal\custom_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Routing;
use \Drupal\Core\Url;

class CustomSearchSortingForm extends FormBase {
  public function getFormId() {
    return 'custom_search_sorting_form';
  }
  public function buildForm(array $form, FormStateInterface $form_state) {

    $current_sorting_params = isset($_SESSION['search']['sort']) ? $_SESSION['search']['sort'] : array ();
    $current_scope_params = isset($_SESSION['search']['search_scope']) ? $_SESSION['search']['search_scope'] : 0;
    $current_community = isset($_SESSION['search']['fake_group_id']) ? $_SESSION['search']['fake_group_id'] : 0;
    $class = isset($_SESSION['search']['class']) ? $_SESSION['search']['class'] : ''; // Added isset for Notice: Undefined index: class.

    // $gid = _is_relevant_group();
    $scope_options = [
      '0' => t('PRISM Platform'),
      '1' => t('Communities Joined'),
      '3' => t('Communities Joined  + Sub Communities'),
    ];
    if($current_community > 0 && $current_scope_params == 2) {
    $scope_options['2'] = t('This Community');
    } elseif(isset($_SESSION['this_group'])) {
    unset($_SESSION['this_group']);
    }

    $filter_scope_default = $current_scope_params;
    if($filter_scope_default == 2 && $current_community == 0)
    $filter_scope_default = 0;
    /*
    * if (isset($current_sorting_params['search_filter_scope'])) {
    * $filter_scope_default = $current_sorting_params['search_filter_scope'];
    * }
    * elseif (isset($current_query['search_basic_search_scope'])) {
    * $filter_scope_default = $current_query['search_basic_search_scope'];
    * }
    * elseif (isset($current_query['field_adv_seach_scope_list'])) {
    * $filter_scope_default = $current_query['field_adv_seach_scope_list'];
    * }
    */
    // Remove go_back parameter when user go back search results
    if((isset($_GET['go_back'])) && $_GET['go_back'] == 1) {
      $form['#action'] = url('search/content/results', array (
      'absolute' => TRUE
      ));
    }

    /* Changes Related To sinequa start*/

    $sort_array_options = array ('' => t('--Select --'));
    $facet_ko = isset($_GET['facets']) ? $_GET['facets']['knowledge_object'][0] : NULL;
    if($_SESSION['search']['form_id'] == 'custom_advanced_search_reference_form' || (isset($facet_ko) && $facet_ko == 'reference')) {
      $sort_array_options['sourcestr19'] = t('Account');
    }
    //$sort_array_options['sourcestr38'] = t('Author');
    $sort_array_options['sourcestr38'] = t('Submitter'); //Author to Submitter CR.
    $sort_array_options['title'] = t('Title');
    $sort_array_options['sourcedatetime9'] = t('Date created');
    $sort_array_options['sourcedatetime10'] = t('Date updated');
    #dump($_SESSION['search']);
    if($_SESSION['search']['form_id'] == 'custom_advanced_search_reference_form' || (isset($facet_ko) && $facet_ko == 'reference')) {
      $sort_array_options['sourcedatetime14'] =t('Engagement start date');
      $sort_array_options['sourcedatetime15'] =t('Engagement end date');
      $sort_array_options['sourcestr38'] = t('Submitter'); //Author to Submitter CR.
    }
    $form['search_sorted_by'] = array (
      '#title' => t('Sorted by'),
      '#type' => 'select',
      '#options' => $sort_array_options,
      '#default_value' => isset($current_sorting_params['search_sorted_by']) ? $current_sorting_params['search_sorted_by'] : '',
      '#attributes' => array (
        'class' => array (
          'formSelect-processed'
        )
      )
		);
    /* Changes Related To sinequa end*/


    $form['search_sorted_order'] = array (
      '#title' => t('Order'),
      '#type' => 'select',
      '#options' => array (
        '' => t('--Select --'),
        'asc' => t('ASC'),
        'desc' => t('DESC')
      ),
      '#default_value' => isset($current_sorting_params['search_sorted_order']) ? $current_sorting_params['search_sorted_order'] : '',
      '#attributes' => array (
        'class' => array (
          'formSelect-processed'
        )
      )
    );
		// Removed as per user story 1236802
    /*$form['search_filter_scope'] = array (
      '#title' => t('Scope'),
      '#type' => 'select',
      '#options' => $scope_options,
      '#default_value' => isset($current_sorting_params['search_filter_scope']) ? $current_sorting_params['search_filter_scope'] : $filter_scope_default,
      '#attributes' => array (
        'class' => array (
          'formSelect-processed'
        )
      )
    );*/
    $form['search_filter_submit'] = array (
      '#type' => 'submit', 
			'#value' => t('Apply'), 
			'#attributes'=>array('class'=> array('btn-ghost')),
			'#prefix' => '<div class="d-flex justify-content-end align-items-end gap-2"><div class="form-actions form-item">', 
			'#suffix' => '</div>'
    );
    $form['search_filter_reset'] = array (
      '#type' => 'submit', '#value' => t('Reset Filters'), 
      '#prefix' => '<div class="form-actions form-item">',
      '#attributes'=>array('class'=> array('btn-secondary')),			
      '#suffix' => ($_SESSION['search']['form_id'] == 'custom_advanced_search_people_form')?'</div></div>':'</div>',
    );
    if($_SESSION['search']['form_id'] != 'custom_advanced_search_people_form'){
      $form['search_add_all_to_cart'] = array (
        '#type' => 'submit', '#value' => t('Add all to Cart'),
        '#attributes' => array('rel'=>$_SESSION['search']['all_cart_ids'],'title'=>'Add all to Cart will add all Assets, References and Files from the currently displayed page to the Cart.'),
        '#prefix' => '<div class="form-actions form-item add-all-to-cart-cls" id="allCartAddRemove">',
        '#suffix' => '</div></div>',
        '#weight' => 112,
      );
    }
    return $form;
  }
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->cleanValues()->getValues();
    $_SESSION['search']['sort'] = array();
    $_SESSION['search']['sort'] = $values;
    $_SESSION['search']['is_new'] = TRUE;
    $params = \Drupal::request()->query->all();
    if(isset($params['captured']) && !empty($params['captured'])) {
      $params['sortby'] = $values['search_sorted_order'].'-'.$values['search_sorted_by'];
      $current_path = \Drupal::request()->getpathInfo();
      $arg  = explode('/',$current_path);
      if($arg[2] == 'all') {
        $url = new Url('custom_search.search_sinequa_all_results');
        $url->setOptions($params);
        $url->setRouteParameters($params);
        $form_state->setRedirectUrl($url);
      } else {
        $url = new Url('custom_search.search_sinequa_content_results');
        $url->setOptions($params);
        $url->setRouteParameters($params);
        $form_state->setRedirectUrl($url);
      }
    }
  }
}
