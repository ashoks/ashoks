<?php

namespace Drupal\custom_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;

/**
 *
 */
class CustomAdvancedSearchReferenceForm extends FormBase {

  /**
   *
   */
  public function getFormId() {
    return 'custom_advanced_search_reference_form';
  }

  /**
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $query_url = [];
    $adv_gid = '';
    $adv_gid = \Drupal::request()->get('adv_gid');
    if((isset($adv_gid) && !empty($adv_gid))) {
      $query_url = ['adv_gid' => $adv_gid];
    }
    $asset_link = Link::createFromRoute(t('Assets'), 'custom_search.advanced_search_asset_form',$query_url);
    $asset_string = $asset_link->toString();
    

    $reference_link = Link::createFromRoute(t('References'), 'custom_search.advanced_search_reference_form',$query_url);
    $reference_string = $reference_link->toString();

    $asset_reference_link = Link::createFromRoute(t('Assets & References'), 'custom_search.advanced_search_asset_reference_form',$query_url);
    $asset_reference_string = $asset_reference_link->toString();

    $people_link = Link::createFromRoute(t('People'), 'custom_search.advanced_search_people_form',$query_url);
    $people_string = $people_link->toString();
    
    
    $form['advanced_form_link_tab'] = [
      '#type' => 'item',
      '#markup' => '<div class="ko-header bg-surface-secondary border-bottom-subtel p-3">
        <h3 class="h4 mb-0">Advanced Search</h3>
    </div><div class="d-flex flex-column"><div class=""><div class="subnav-list px-3 pt-3 bg-surface-secondary"><ul class="d-flex gap-3 secondary-nav"><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_string->getGeneratedLink().'</li><li class="subnav-list-item active d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$reference_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$asset_reference_string->getGeneratedLink().'</li><li class="subnav-list-item d-flex flex-column border-bottom-0 position-relative right-ko-trigger">'.$people_string->getGeneratedLink().'</li></ul></div></div></div>',
    ];

    /*$form['fieldset_advanced_search'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Advanced Search - Reference'),
      '#weight' => '0',
    ];*/
    $form['fieldset_advanced_search']['with_all_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With <strong>all</strong> of the words'),
      '#required' => FALSE,
      '#weight' => '0',
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#prefix' => '<div class="d-flex flex-row p-3 ko-created bg-surface-primary"><div class="searchKeyword"><div class="row"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_the_exact_phrase'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With the <strong>exact phrase</strong>'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#weight' => '1',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_advanced_search']['with_at_least_one_of_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('With <strong>at least one</strong> of the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#weight' => '2',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['fieldset_advanced_search']['without_the_words'] = [
      '#type' => 'textfield',
      '#title' => $this->t('<strong>Without</strong> the words'),
      '#required' => FALSE,
      '#attributes' => ['placeholder' => t('Type Keyword to Search'),],
      '#weight' => '3',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div>',
    ];

    $form['fieldset_scope'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '1',
    ];

    $scope_options = [
      '0' => $this->t('PRISM Platform'),
      '1' => $this->t('Communities Joined'),
      /* '3' => $this->t('Communities Joined and Sub Communities'), */
    ];
    $default_op_value = 0;
    $adv_gid = '';
    $adv_gid = \Drupal::request()->get('adv_gid');
    if((isset($adv_gid) && !empty($adv_gid))) {
      $scope_options[2] = t('This Community');
      $default_op_value = 2;
    } else {
      $default_op_value = isset($_SESSION['search']['scope'])?$_SESSION['search']['scope']:'';
    }
    $form['fieldset_scope']['group_id'] = array(
      '#type' => 'hidden',
      '#value' => $adv_gid, 
    );
    $form['fieldset_scope']['advanced_search_scope'] = [
      '#type' => 'radios',
      '#options' => $scope_options,
      '#default_value' => $default_op_value,
      '#validated' => TRUE,
      '#weight' => '4',
      '#prefix' => '<div class="accordion" id="scope"><div class="accordion-item"><h2 class="accordion-header" id="scopeHeading"></h2><div id="scopeCollapse" class="accordion-collapse collapse show" aria-labelledby="scopeHeading" data-bs-parent="#scope"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-12">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $form['fieldset_basics'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '2',
    ];

    $url = Url::fromRoute(
      'custom_search.advancedsearch_autocomplete',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_basics']['field_adv_submitter'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $url,
      '#new_terms' => 1,
      '#target_type' => 'user',
      '#selection_handler' => 'default',
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '5',
      '#prefix' => '<div class="accordion" id="basicInfo"><div class="accordion-item"><h2 class="accordion-header" id="basicInfoHeading"></h2><div id="basicInfoCollapse" class="accordion-collapse collapse show" aria-labelledby="basicInfoHeading" data-bs-parent="#basicInfo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6"><span for="editSubmitter" class="form-label">Submitter</span><div class="input-group mb-3 select2-wrap">',
      '#suffix' => '</div></div>',
    ];
    $form['fieldset_basics']['field_adv_contact'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $url,
      '#target_type' => 'user',
      '#selection_handler' => 'default',
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '6',
      '#prefix' => '<div class="col-6"><div class="mb-3"><span for="editContact" class="form-label">Contacts</span><div class="input-group mb-3 select2-wrap">',
      '#suffix' => '</div></div></div>',
    ];
    $urlAc = Url::fromRoute(
      'custom_search.search_sinequa_account_reference_results',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_basics']['field_adv_search_account'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $urlAc,
      '#target_type' => 'node',
      '#selection_settings' => [
        'target_bundles' => ['reference'],
      ],
      '#selection_handler' => 'default',
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '8',
      '#element_validate' => [[$this, 'field_account_validator']],
      '#prefix' => '<div class="col-6"><div class="mb-3"><span for="editAccount" class="form-label">Accounts</span><div class="input-group mb-3 select2-wrap">',
      '#suffix' => '</div></div></div>',
    ];
    $country_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('country');
    foreach($country_terms as $tid => $term_value) {
			//$term_value->name = html_entity_decode($term_value->name);
      $country_terms_listing[$term_value->tid] = $term_value->name;
    }
    $form['fieldset_basics']['field_account_country'] = [
      '#type'         => 'select',
      '#empty_option' => '- None -',
      '#options'      => isset($country_terms_listing)?$country_terms_listing:[],
      '#title'        => 'Account Country',
      '#required'     => false,
      '#weight' => '9',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];

    $star_options = [
      '' => $this->t('- None -'),
      '20' => $this->t('One star'),
      '40' => $this->t('Two stars'),
      '60' => $this->t('Three stars'),
      '80' => $this->t('Four stars'),
      '100' => $this->t('Five stars'),
    ];
    $form['fieldset_basics']['field_adv_search_rating'] = [
      '#type' => 'select',
      '#options' => $star_options,
      '#validated' => TRUE,
      '#title' => 'Rating',
      '#weight' => '9',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];

    $form['fieldset_basics']['field_ultimate_parent_account'] = [
      '#type' => 'textfield',
      '#title' => 'Ultimate Parent Account',
      '#required' => FALSE,
      '#weight' => '10',
      '#autocomplete_route_name' => 'custom_search.autocomplete',
      '#multiple' => FALSE,
      '#autocomplete_min_length' => 1,
      '#prefix'=> '<div class="col-6">',
      '#suffix' => '</div>',
    ];
    
    // Fetching Reference - Status Field Data.
    $field_instance = \Drupal::entityTypeManager()->getStorage('field_storage_config')->load('node.field_status_ref');
    $entityTypeManager = \Drupal::service('entity_type.manager');
    $entity = $entityTypeManager->getStorage('node')->create(['type' => 'reference']);
    //$status_options = $field_instance->getOptionsProvider('allowed_value', $entity)->getSettableOptions(); //uncomment
    //unset($status_options[0]);
    $status_options = [
      '1' => $this->t('Live Gold - Validated by Community Leaders/Moderators'),
      '2' => $this->t('Archived'),
    ];
    $form['fieldset_basics']['field_status'] = [
      '#type' => 'checkboxes',
      '#options' => $status_options,
      '#validated' => TRUE,
      '#title' => '',
      '#weight' => '11',
      '#prefix' => '<div class="col-6 ref-status"><div class="mb-3"><div class="d-flex gap-2 flex-column"><span class="form-label">Status</span><div class="d-flex flex-column gap-2">',
      '#suffix' => '</div></div></div></div>',
    ];

    $color_options = [
      '_none' => t('Any'),
      'green' => t('Green'),
      'yellow' => t('Yellow'),
      'red' => t('Red'),
    ];
    $form['fieldset_basics']['field_permission_status'] = [
      '#type' => 'radios',
      '#options' => $color_options,
      '#validated' => TRUE,
      '#default_value' => '_none',
      '#title' => '',
      '#weight' => '12',
      '#prefix' => '<div class="col-6 ref-conflevel"><div class="d-flex gap-1 flex-column"><span for="editRating" class="form-label">Confidentiality level</span><div class="d-flex gap-3">',
      '#suffix' => '</div></div></div></div></div></div></div></div>',
    ];


    $form['fieldset_global_taxonomy'] = [
      '#type' => 'fieldset',
      '#weight' => '3',
    ];
    $sector_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',0,1);
    $sector_terms_listing['none'] = '- None -';
    foreach($sector_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $sector_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
    }
    //asort($sector_terms_listing);
    $form['fieldset_global_taxonomy']['field_sector'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($sector_terms_listing)?$sector_terms_listing:[],
      '#title'        => 'Sectors',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_segment',
        'wrapper'  => 'field-segment'
      ],
      '#weight' => '16',
      '#prefix' => '<div class="accordion" id="globalTaxo"><div class="accordion-item"><h2 class="accordion-header" id="globalTaxoHeading"></h2><div id="globalTaxoCollapse" class="accordion-collapse collapse show" aria-labelledby="globalTaxoHeading" data-bs-parent="#globalTaxo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6">',
      '#suffix' => '</div>',
    ];

    $segment_terms_listing = array();
    $sector_term_selection = $form_state->getValue('field_sector');
    if(isset($sector_term_selection) && !empty($sector_term_selection)) {
      foreach($sector_term_selection as $t => $tv){
        $segment_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',$tv,1,False);
        foreach($segment_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $segment_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $segment_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_segment'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($segment_terms_listing)?$segment_terms_listing:[],
      '#title'        => 'Industries',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#description' => $this->t('Values are displayed only when Sector is selected.'),
      '#prefix' => '<div id="field-segment" class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_subsegment',
        'wrapper'  => 'field-subsegment'
      ],
      '#weight' => '17',
    ];
    $subsegment_terms_listing = array();
    $segment_term_selection = $form_state->getValue('field_segment');
    if(isset($segment_term_selection) && !empty($segment_term_selection)) {
      foreach($segment_term_selection as $t => $tv){
        $subsegment_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('groupsector',$tv,1,False);
        foreach($subsegment_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $subsegment_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $subsegment_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_subsegment'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($subsegment_terms_listing)?$subsegment_terms_listing:[],
      '#title'        => 'Industry Segment',
      '#description' => $this->t('Values are displayed only when Industry is selected.'),
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#prefix' => '<div id="field-subsegment" class="col-6"><div class="mb-3 mt-3">',
      '#suffix' => '</div></div>',
      '#weight' => '18',
    ];

    $form['fieldset_global_taxonomy']['field_gen_ai_offer'] = [
      '#type' => 'checkbox',
      '#title' => 'Gen AI Offer',
      '#size' => 10,
      '#maxlength' => 255,
      '#default_value' => 0,
      '#required' => FALSE,
      '#weight' => '22',
      '#prefix' => '<div class="col-12 order-first"><div class="mb-3">',
      '#suffix' => '</div></div></div>',
    ];

    $genAiPortfolios = [];
    $flag = 0;
    $entry_portfolio_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('entry_portfolio',0,1);
    $entry_portfolio_terms_listing['none'] = '- None -';
    foreach($entry_portfolio_terms as $tid => $term_value) {
      $term_node = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term_value->tid);
      if ($flag == 0) {
        $term_value->name = html_entity_decode($term_value->name);
        $entry_portfolio_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
      }
      if($term_node->get('field_gen_ai')->value == 1){
        $genAiPortfolios[] = $term_value->tid;
      }
    }
    $form['#attached']['drupalSettings']['custom_search']['relatedTids'] = $genAiPortfolios;
    $form['fieldset_global_taxonomy']['field_entry_portfolio'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($entry_portfolio_terms_listing)?$entry_portfolio_terms_listing:[],
      '#title'        => 'Entry Portfolio',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_offer',
        'wrapper'  => 'field-offer'
      ],
      '#weight' => '19',
      '#prefix' => '<div class="row d-flex"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
      '#attached' => [
        'library' => [
          'custom_search/custom_search.custom-search-js',
        ],
      ],
    ];
    $offer_terms_listing = array();
    $entry_portfolio_term_selection = $form_state->getValue('field_entry_portfolio');
    if(isset($entry_portfolio_term_selection) && !empty($entry_portfolio_term_selection)) {
      foreach($entry_portfolio_term_selection as $t => $tv){
        $offer_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('entry_portfolio',$tv,1,False);
        foreach($offer_terms as $tid => $term_value) {
					$term_value->name = html_entity_decode($term_value->name);
          $offer_terms_listing[$term_value->tid] = html_entity_decode($term_value->name);
        }
      }
    } else {
      $offer_terms_listing = array();
    }
    $form['fieldset_global_taxonomy']['field_offer'] = [
      '#type'         => 'select',
      '#empty_option' => 'None',
      '#options'      => isset($offer_terms_listing)?$offer_terms_listing:[],
      '#title'        => 'Offer',
      '#description' => $this->t('Values are displayed only when Entry Portfolio is selected.Multiple selection is possible with CTRL'),
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#prefix' => '<div id="field-offer" class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
      '#weight' => '20',
    ];
    $partner_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('partner');
    $partners_term_list['none'] = '- None -';
    foreach($partner_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $partners_term_list[$term_value->tid] = html_entity_decode($term_value->name);
    }
    $form['fieldset_global_taxonomy']['field_partner'] = [
      '#type'         => 'select',
      '#title'        => 'Alliance/Partner',
      '#options'      => isset($partners_term_list)?$partners_term_list:[],
      '#empty_option' => $this->t('None'),
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#weight' => '21',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div>',
    ];

    $sustainbility_benefit_options = [
      '2' => $this->t('Any'),
      '1' => $this->t('True'),
      '3' => $this->t('False'),
    ];
    $form['fieldset_global_taxonomy']['field_sustainability_benefit'] = [
      '#type' => 'radios',
      '#title' => '',
      '#size' => 10,
      '#maxlength' => 255,
      '#options' => $sustainbility_benefit_options,
      '#default_value' => '2',
      '#required' => FALSE,
      '#weight' => '22',
      '#prefix' => '<div class="col-6"><div class="mb-3"><span for="" class="form-label">Sustainability Benefit</span><div class=" d-flex gap-3 align-items-center">',
      '#suffix' => '</div></div></div>',
    ];
    
    $managed_services_options = [
      '2' => $this->t('Any'),
      '1' => $this->t('True'),
      '3' => $this->t('False'),
    ];
    $form['fieldset_global_taxonomy']['field_managed_services_am_im'] = [
      '#type' => 'radios',
      '#title' => '',
      '#size' => 10,
      '#maxlength' => 255,
      '#options' => $managed_services_options,
      '#default_value' => '2',
      '#required' => FALSE,
      '#weight' => '23',
      '#prefix' => '<div class="col-6"><div class="mb-3"><span for="managedService" class="form-label">Managed Services(AM/IM)</span><div class=" d-flex gap-3 align-items-center">',
      '#suffix' => '</div></div></div>',
    ];
    
    
    $url = Url::fromRoute(
      'custom_search.search_sinequa_technologies_results',
      [],
      ['absolute' => TRUE]
    )->getInternalPath();
    $form['fieldset_global_taxonomy']['field_technologies'] = [
      '#title' => '',
      '#type' => 'autocomplete_deluxe',
      '#autocomplete_deluxe_path' => $url,
      '#target_type' => 'taxonomy_term',
      '#selection_handler' => 'default',
      '#selection_settings' => [
        'target_bundles' => [
          'technologies'
        ],
      ],
      '#multiple' => TRUE,
      '#size' => 40,
      '#delimiter' => ',',
      '#weight' => '24',
      '#prefix' => '<div class="col-6"><span for="tech" class="form-label">Technologies</span><div class="input-group select2-wrap">',
      '#suffix' => '</div></div>',
    ];

		$accounty_type_options = [
      'none' => $this->t('- None -'),
      'Platinum' => $this->t('Platinum'),
      'Gold' => $this->t('Gold'),
      'Account' => $this->t('Account'),
    ];
    $form['fieldset_global_taxonomy']['field_account_type'] = [
      '#type' => 'select',
      '#options' => $accounty_type_options,
      '#validated' => TRUE,
      '#title' => 'Account Type',
			'#multiple' => true,
      '#weight' => '25',
      '#prefix' => '<div class="col-6"><div class="select2-wrap">',
      '#suffix' => '</div></div></div></div></div></div></div>',
    ];
    
    $form['group_adv_search_c_taxonomy'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '4',
    ];
    $form['group_adv_search_c_taxonomy']['field_community_taxonomy'] = [
      '#type' => 'textfield',
      '#title' => 'Community Taxonomy',
      '#required' => FALSE,
      '#weight' => '25',
      '#prefix' => '<div class="accordion" id="communityTaxoUser"><div class="accordion-item"><h2 class="accordion-header" id="communityTaxoUserHeading"></h2><div id="communityTaxoUserCollapse" class="accordion-collapse collapse show"
      aria-labelledby="communityTaxoUserHeading" data-bs-parent="#communityTaxoUser"><div class="accordion-body border-top-subtel"><small id="helpId" class="form-text text-muted mb-3">Commas can be used as separators in fields below</small><div class="row"><div class="col-6">',
      '#suffix' => '</div>',
    ];
    $form['group_adv_search_c_taxonomy']['field_community_folders'] = [
      '#type' => 'textfield',
      '#title' => 'Community Folders',
      '#required' => FALSE,
      '#weight' => '27',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $form['group_adv_search_c_taxonomy']['field_adv_search_tags'] = [
      '#type' => 'textfield',
      '#title' => 'User Tags',
      '#required' => FALSE,
      '#weight' => '28',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $form['group_contract_information'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '5',
    ];
    $contract_type_options = [
			"none" => '- None -',
			"time_hire_bodyshop" => "Resource Based - T&M",
			"time_materials" => "Resource Based – Manage T&M",
			"fixed_price" => "Deliverable Based – Fixed Price",
			"shared_risk_shared_reward" => "Deliverable Based – Shared Risk and Reward",
			"pay_per_use_outcome" => "Service Based - Volume Based",
			"service_based_fixed_fees" => "Service Based - Fixed Fees",
			"value_added_reseller_agreements" => "Value Added Reseller Agreements",
			"referral_fees" => "Referral Fees",
			"not_known" => "Not Known",
		];
    $form['group_contract_information']['field_contract_type'] = [
      '#type'      => 'select',
      '#options'   => $contract_type_options,
      '#multiple'  => TRUE,
      '#size'      => 5,
      '#validated' => TRUE,
      '#title'     => 'Contract Type',
      '#weight' => '29',
      '#prefix' => '<div class="accordion" id="Contractinfo"><div class="accordion-item"><h2 class="accordion-header" id="ContractinfoHeading"></h2><div id="ContractinfoCollapse" class="accordion-collapse collapse show" aria-labelledby="ContractinfoHeading" data-bs-parent="#Contractinfo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $currency_options = [
      "AUD" => "AUD",
      "BRL" => "BRL",
      "CNY" => "CNY",
      "EUR" => "EUR",
      "GBP" => "GBP",
      "USD" => "USD",
    ];
    $form['group_contract_information']['field_currency'] = [
      '#type' => 'select',
      '#options' => $currency_options,
      '#validated' => TRUE,
      '#empty_value' => '',
      '#empty_option' => $this->t('- None -'),
      '#title' => 'Currency',
      '#ajax' => [
        'event'    => 'change',
        'callback' => '::populate_deal_size',
        'wrapper'  => 'field-deal-size'
      ],
      '#weight' => '30',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '</div></div>',
    ];
    $deal_size_listing = array();
    $currency_selection = $form_state->getValue('field_currency');
    if(isset($currency_selection) && !empty($currency_selection)) {
      $get_deal_size = $this->get_deal_size_default($currency_selection,0);
      $deal_size_listing = $get_deal_size['deal_size_arr'];
			array_shift($deal_size_listing);
    }    
    $form['group_contract_information']['field_deal_size'] = [
      '#type' => 'select',
      '#options' => $deal_size_listing,
      '#validated' => TRUE,
      '#title' => 'Deal size',
      '#weight' => '31',
      '#prefix' => '<div id="field-deal-size" class="col-6">',
      '#sufix' => '</div></div></div></div></div></div>',
    ];

    $form['group_delivery_information'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '6',
    ];
    
    $form['group_delivery_information']['field_start_date_from'] = [
      '#type' => 'date',
      '#title' => 'Start Date from',
      '#date_date_format' => 'd-m-Y',
      '#required' => FALSE,
      '#weight' => '32',
      '#prefix' => '<div class="accordion" id="Deliveryinfo"><div class="accordion-item"><h2 class="accordion-header" id="DeliveryinfoHeading"></h2><div id="DeliveryinfoCollapse" class="accordion-collapse collapse show" aria-labelledby="DeliveryinfoHeading" data-bs-parent="#Deliveryinfo"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-3">',
      '#suffix' => '</div>',
    ];
    $form['group_delivery_information']['field_start_date_to'] = [
      '#type' => 'date',
      '#title' => 'Start Date to',
      '#date_date_format' => 'd-m-Y',
      '#required' => FALSE,
      '#weight' => '33',
      '#prefix' => '<div class="col-3">',
      '#suffix' => '</div>',
    ];
    
    $form['group_delivery_information']['field_end_date_from'] = [
      '#type' => 'date',
      '#title' => 'End Date from',
      '#date_date_format' => 'd-m-Y',
      '#required' => FALSE,
      '#weight' => '34',
      '#prefix' => '<div class="col-3">',
      '#suffix' => '</div>',
    ];
    $form['group_delivery_information']['field_end_date_to'] = [
      '#type' => 'date',
      '#title' => 'End Date to',
      '#date_date_format' => 'd-m-Y',
      '#required' => FALSE,
      '#weight' => '35',
      '#prefix' => '<div class="col-3">',
      '#suffix' => '</div>',
    ];

    $country_deliver_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('country_deliver');
    $country_delivery_term_list['none'] = '- None -';
    foreach($country_deliver_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $country_delivery_term_list[$term_value->tid] = html_entity_decode($term_value->name);
    }
    $form['group_delivery_information']['field_capgemini_country_ies_that'] = [
      '#type'         => 'select',
      '#empty_value' => '',
      '#empty_option' => $this->t('None'),
      '#options'      => isset($country_delivery_term_list)?$country_delivery_term_list:[],
      '#title'        => 'Capgemini Country(ies) that Delivered',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#weight' => '36',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '<small id="helpId" class="form-text text-muted helptext">Multiple selection is possible with CTRL.</small></div></div>',
    ];

    $country_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('country');
    $country_term_list['none'] = '- None -';
    foreach($country_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $country_term_list[$term_value->tid] = html_entity_decode($term_value->name);
    }
    $form['group_delivery_information']['field_entity_country'] = [
      '#type'         => 'select',
      '#empty_option' => $this->t('None'),
      '#empty_value' => '',
      '#options'      => isset($country_term_list)?$country_term_list:[],
      '#title'        => 'Client Country(ies) where Delivered',
      '#required'     => false,
      '#multiple'     => true,
      '#size'         => 5,
      '#weight' => '37',
      '#prefix' => '<div class="col-6"><div class="mb-3">',
      '#suffix' => '<small id="helpId" class="form-text text-muted helptext">Multiple selection is possible with CTRL.</small></div></div>',
    ];

    $project_status_options = [
      '0' => $this->t('New Win'),
      '1' => $this->t('Delivery'),
      '2' => $this->t('Project Completion')
    ];
    $form['group_delivery_information']['field_project_status'] = [
      '#type' => 'checkboxes',
      '#options' => $project_status_options,
      '#validated' => TRUE,
      '#title' => '',
      '#weight' => '38',
      '#prefix' => '<div class="col-6"><div class="d-flex gap-2 flex-column"><span class="form-label">Project Status</span>',
      '#suffix' => '</div></div>',
    ];

    $rightshore_model_options = [
      "Radical Rightshore" => "Radical Rightshore",
      "Rightshore" => "Rightshore",
      "Nearshore" => "Nearshore",
      "None" => "None",
      "Not Known" => "Not Known",
    ];
    $form['group_delivery_information']['field_rightshore_model'] = [
      '#type' => 'select',
      '#options' => $rightshore_model_options,
      '#empty_option' => $this->t('None'),
      '#empty_value' => '',
      '#validated' => TRUE,
			'#multiple' => false,
      '#title' => 'Rightshore Model',
      '#weight' => '39',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $form['group_attachments'] = [
      '#type' => 'fieldset',
      '#title' => '',
      '#weight' => '7',
    ];

    $file_options = [
      "project_snapshot_new" => "Project Snapshot - New Win",
      "project_snapshot_delivery" => "Project Snapshot – Delivery Milestone",
      "project_snapshot" => "Project Snapshot – Project Completion/ Final Project Qualification",
      "case_study" => "Case Study",
      "video" => "Video",
      "press" => "Press Release",
      "article" => "Internal Article",
      "logo" => "Logo",
      "other" => "Other",
    ];
    $form['group_attachments']['field_type_rf'] = [
      '#type' => 'select',
      '#options' => $file_options,
      '#empty_value' => '',
      '#empty_option' => $this->t('None'),
      '#validated' => TRUE,
			'#multiple'  => false,
      '#title' => 'Attachment Type',
      '#weight' => '40',
      '#prefix' => '<div class="accordion" id="Attachments"><div class="accordion-item"><h2 class="accordion-header" id="AttachmentsHeading"></h2><div id="AttachmentsCollapse" class="accordion-collapse collapse show" aria-labelledby="AttachmentsHeading" data-bs-parent="#Attachments"><div class="accordion-body border-top-subtel"><div class="row"><div class="col-6">',
      '#suffix' => '</div>',
    ];
    $language_terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('language');
    foreach($language_terms as $tid => $term_value) {
			$term_value->name = html_entity_decode($term_value->name);
      $language_term_list[$term_value->tid] = html_entity_decode($term_value->name);
    }
    $form['group_attachments']['field_language_rf'] = [
      '#type' => 'select',
      '#title' => 'Language',
      '#empty_value' => '',
      '#empty_option' => $this->t('None'),
			'#multiple'  => false,
      '#options' => isset($language_term_list)?$language_term_list:[],
      '#weight' => '41',
      '#prefix' => '<div class="col-6">',
      '#suffix' => '</div></div></div></div></div></div>',
    ];

    $results_options = [
      '20' => t('20 results'),
      '50' => t('50 results'),
      '100' => t('100 results'),
    ];
    $form['field_results_each_page'] = [
      '#type' => 'select',
      '#options' => $results_options,
      '#validated' => TRUE,
      '#title' => 'Results on Each Page',
      '#weight' => '42',
      '#default_value' => '50',
      '#prefix' => '<div class="d-flex flex-row justify-content-between align-items-center"><div class="">',
      '#suffix' => '</div>',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
      '#button_type' => 'primary',
      '#weight' => '43',
      '#prefix' => '<div class="">',
      '#suffix' => '</div></div>',
    ];

    return $form;
  }

  public function field_account_validator(&$element, FormStateInterface $form_state, &$complete_form) {
    $element['#needs_validation'] = false;
  }

  /**
   *
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   *
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    unset($_SESSION['search']); 
    $form_data = [];
    $values = $form_state->cleanValues()->getValues();
    if (empty($_SESSION['search'])) {
      // Converting Keyword values for the advance search
      if(isset($values['with_all_of_the_words'])) {
        $form_data['with_all_of_the_words'] = $values['with_all_of_the_words'];
      }
      if(isset($values['with_the_exact_phrase'])) {
        $form_data['with_the_exact_phrase'] = $values['with_the_exact_phrase'];
      }
      if(isset($values['with_at_least_one_of_the_words'])) {
        $form_data['with_at_least_one_of_the_words'] = $values['with_at_least_one_of_the_words'];
      }
      if(isset($values['without_the_words'])) {
        $form_data['without_the_words'] = $values['without_the_words'];
      }

      // Scope
      $form_data['scope'] = $values['advanced_search_scope'];

      if(isset($values['group_id']) && $values['advanced_search_scope'] == 2) {
        $form_data['group_id'] = $values['group_id'];
      }

      if(isset($values['field_adv_submitter'])) {
		    foreach($values['field_adv_submitter'] as $key => $uval){
          $user = \Drupal\user\Entity\User::load($uval['target_id']);
          $firstname = $user->get('field_name_first')->getValue();
          $lastname = $user->get('field_name_last')->getValue();
          if(isset($firstname[0]['value']) && isset($lastname[0]['value'])){
            $form_data['submitter'][] = $firstname[0]['value'] . ' ' . $lastname[0]['value'];
          }
        }
      }

      if(isset($values['field_adv_contact'])) {
		    foreach($values['field_adv_contact'] as $key => $uval){
          $user = \Drupal\user\Entity\User::load($uval['target_id']);
          $firstname = $user->get('field_name_first')->getValue();
          $lastname = $user->get('field_name_last')->getValue();
          if(isset($firstname[0]['value']) && isset($lastname[0]['value'])){
            $form_data['contacts'][] = $firstname[0]['value'] . ' ' . $lastname[0]['value'];
          }
        }
      }

      /* Removed this field as per Ticket no 970354
      if(isset($values['field_adv_other_contributors'])) {
		    foreach($values['field_adv_other_contributors'] as $key => $uval){
          $user = \Drupal\user\Entity\User::load($uval['target_id']);
          $firstname = $user->get('field_name_first')->getValue();
          $lastname = $user->get('field_name_last')->getValue();
          if(isset($firstname[0]['value']) && isset($lastname[0]['value'])){
            $form_data['other_contributors'][] = $firstname[0]['value'] . ' ' . $lastname[0]['value'];
          }
        }
      }*/
      
      if(isset($values['field_adv_search_account']) && !empty($values['field_adv_search_account']) && $values['field_adv_search_account'] != '""') {
				$values['field_adv_search_account'] = str_replace('"','',$values['field_adv_search_account']);
        if(strpos($values['field_adv_search_account'],',')) {
          $account_raw = explode(',',$values['field_adv_search_account']);
        } else {
          $account_raw[] = $values['field_adv_search_account'];
        }
        if(isset($account_raw) && !empty($account_raw)){
          $form_data['account'] = $account_raw;
        }
      }

      if(isset($values['field_account_country']) && !empty($values['field_account_country'])) {
        if (isset($values['field_account_country']) && !empty($values['field_account_country'])) {
          $term = \Drupal\taxonomy\Entity\Term::load($values['field_account_country']);
          $form_data['account_country'] = $term ? $term->get('name')->value : NULL;
        }
      }
      if(isset($values['field_ultimate_parent_account']) && !empty($values['field_ultimate_parent_account'])) {
        $form_data['ultimate_parent_account'] = $values['field_ultimate_parent_account'];
      }
      if($values['field_permission_status']!='_none') {
        $form_data['confidentiality_level'] = ucfirst($values['field_permission_status']);
      }
      if(isset($values['field_reference_usage']) && !empty($values['field_reference_usage']) && ($values['field_reference_usage']['none'] != 'none')) {
        $form_data['reference_usage'] = $values['field_reference_usage'];
      }
      
      $field_instance = \Drupal::entityTypeManager()->getStorage('field_storage_config')->load('node.field_status');
      $entityTypeManager = \Drupal::service('entity_type.manager');
      $entity = $entityTypeManager->getStorage('node')->create(['type' => 'asset']);
      $status_options = $field_instance->getOptionsProvider('allowed_value', $entity)->getSettableOptions();
      $status_data = [];
      foreach($values['field_status'] as $key => $value) {
        if($value !== 0) {
          $status_data[(int)$value] = $status_options[(int)$value];
        }
      }
      if(isset($status_data) && !empty($status_data)){
        $form_data['status'] = $status_data;
      }
      
      if(isset($values['field_adv_search_rating']) && !empty($values['field_adv_search_rating'])) {
        $form_data['ratings'] = $values['field_adv_search_rating']-20;
      }

      if(isset($values['field_start_date_from']) && !empty($values['field_start_date_from']) && isset($values['field_start_date_to']) && !empty($values['field_start_date_to'])) {
        $c_date_from_with_time = $values['field_start_date_from'].' 00:00:00';
        $c_date_to_with_time = $values['field_start_date_to'].' 23:59:59';
        $form_data['reference_start_date'] = $c_date_from_with_time . ' TO ' .$c_date_to_with_time;
      }
			else if(isset($values['field_start_date_from']) && !empty($values['field_start_date_from']) && (!isset($values['field_start_date_to']) || empty($values['field_start_date_to']))){
				$c_date_from_with_time = $values['field_start_date_from'].' 00:00:00';
				$form_data['reference_start_date'] = $c_date_from_with_time;
			}
      if(isset($values['field_end_date_from']) && !empty($values['field_end_date_from']) && isset($values['field_end_date_to']) && !empty($values['field_end_date_to'])) {
        $u_date_from_with_time = $values['field_end_date_from'].' 00:00:00';
        $u_date_to_with_time = $values['field_end_date_to']. ' 23:59:59';
        $form_data['reference_end_date'] = $u_date_from_with_time.' TO '.$u_date_to_with_time;
      }
			else if(isset($values['field_end_date_from']) && !empty($values['field_end_date_from']) && (!isset($values['field_end_date_to']) || empty($values['field_end_date_to']))){
				$u_date_from_with_time = $values['field_end_date_from'].' 00:00:00';
				$form_data['reference_end_date'] = $u_date_from_with_time;
			}
      if(isset($values['field_contract_type']) && !empty(isset($values['field_contract_type'])) && ($values['field_contract_type']['none'] != 'none')) {
        $form_data['contract_type'] = $values['field_contract_type'];
      }
      if(isset($values['field_currency']) && !empty(isset($values['field_currency']))) {
        $form_data['currency'] = $values['field_currency'];
      }
      if(isset($values['field_deal_size']) && !empty($values['field_deal_size'])) {
        $deal_size_arr = $this->build_deal_size($values['field_currency'],$values['field_deal_size']);
        $form_data['deal_size'] = $deal_size_arr[0] . ' TO ' . $deal_size_arr[1]; 
      }

      if(isset($values['field_sector']) && !empty($values['field_sector']) && ($values['field_sector']['none'] != 'none')) {
        foreach($values['field_sector'] as $tid => $tvalue) {
          $sector_term_name = NULL; // Or handle the case where $tvalue is empty as needed
          if (!empty($tvalue)) {
            $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
            $sector_term_name = $term ? $term->get('name')->value : NULL;
            $form_data['sector'][$tvalue] = $sector_term_name;
          }
        }
      }
      if(isset($values['field_segment']) && !empty($values['field_segment'])) {
        foreach($values['field_segment'] as $tid => $tvalue) {
          $segment_term_name = NULL; // Handle the case where $tvalue is empty as needed
          if (!empty($tvalue)) {
            $term = \Drupal\taxonomy\Entity\Term::load($tvalue);
            $segment_term_name = $term ? $term->get('name')->value : NULL;
          }
        $form_data['industry'][$tvalue] = $segment_term_name;
        }
      }
      if(isset($values['field_subsegment']) && !empty($values['field_subsegment'])) {
        foreach($values['field_subsegment'] as $tid => $tvalue) {
          $subsegment_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['industry_segment'][$tvalue] = $subsegment_term_name;
        }
      }
      if(isset($values['field_entry_portfolio']) && !empty($values['field_entry_portfolio']) && ($values['field_entry_portfolio']['none'] != 'none')) {
        foreach($values['field_entry_portfolio'] as $tid => $tvalue) {
          $portfolio_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['entry_portfolio'][$tvalue] = $portfolio_term_name;
        }
      }
      if(isset($values['field_offer']) && !empty($values['field_offer'])) {
        foreach($values['field_offer'] as $tid => $tvalue) {
          $offer_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['offer'][$tvalue] = $offer_term_name;
        }
      }
      if(isset($values['field_partner']) && !empty($values['field_partner']) && ($values['field_partner']['none'] != 'none')) {
        foreach($values['field_partner'] as $tid => $tvalue) {
          $oartner_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['alliance_partner'][$tvalue] = $oartner_term_name;
        }  
      }
      if(isset($values['field_account_type']) && !empty($values['field_account_type']) && ($values['field_account_type']['none'] != 'none')) {
        $form_data['account_type'] = $values['field_account_type'];
      }
      if(isset($values['field_technologies']) && !empty($values['field_technologies'])) {
        foreach($values['field_technologies'] as $tid => $tvalue) {
          $tech_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue['target_id'])->get('name')->value;
          $form_data['technologies'][$tvalue['target_id']] = $tech_term_name;
        }  
      }

      if($values['field_sustainability_benefit']!='2') {
        $form_data['sustainability_benefit'] = $values['field_sustainability_benefit'];
      }
      if(isset($values['field_managed_services_am_im']) && !empty($values['field_managed_services_am_im']) && $values['field_managed_services_am_im']!=2) {
        $form_data['managed_services'] = $values['field_managed_services_am_im'];
      }
      if(isset($values['field_community_taxonomy']) && !empty($values['field_community_taxonomy'])) {
        if(strpos($values['field_community_taxonomy'],',')){
          $ct_array = explode(',',$values['field_community_taxonomy']);
          $form_data['community_taxonomy'] = $ct_array; 
        } else {
          $form_data['community_taxonomy'] = $values['field_community_taxonomy'];
        }
      }
      if(isset($values['field_community_folders']) && !empty($values['field_community_folders'])) {
        if(strpos($values['field_community_folders'],',')){
          $cf_array = explode(',',$values['field_community_folders']);
          $form_data['community_folders'] = $cf_array; 
        } else {
          $form_data['community_folders'] = $values['field_community_folders'];
        }        
      }
      if(isset($values['field_adv_search_tags']) && !empty($values['field_adv_search_tags'])) {
        if(strpos($values['field_community_folders'],',')){
          $tag_array = explode(',',$values['field_adv_search_tags']);
          $form_data['user_tags'] = $tag_array; 
        } else {
          $form_data['user_tags'] = $values['field_adv_search_tags'];
        } 
      }
      if(isset($values['field_rightshore_model'])) {
        $form_data['rightshore_model'] = $values['field_rightshore_model'];
      }
      if(isset($values['field_entity_country']) && !empty($values['field_entity_country']) && ($values['field_entity_country']['none'] != 'none')) {
        foreach($values['field_entity_country'] as $tid => $tvalue) {
          $entity_country_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['originating_countries'][$tvalue] = $entity_country_term_name;
        }
      }
      if(isset($values['field_capgemini_country_ies_that']) && !empty($values['field_capgemini_country_ies_that']) && ($values['field_capgemini_country_ies_that']['none'] != 'none')) {
        foreach($values['field_capgemini_country_ies_that'] as $tid => $tvalue) {
          $cap_country_ies_that_term_name = \Drupal\taxonomy\Entity\Term::load($tvalue)->get('name')->value;
          $form_data['capgemini_countries_that_delivered'][$tvalue] = $cap_country_ies_that_term_name;
        }
      }
      if(isset($values['field_type_rf'])) {
        $form_data['attachment_type'] = $values['field_type_rf'];
      }
      if(isset($values['field_language_rf']) && !empty($values['field_language_rf']) && ($values['field_language_rf'] != 'none')) {
				$language_rf_term_name = \Drupal\taxonomy\Entity\Term::load($values['field_language_rf'])->get('name')->value;
				$form_data['language_rf'][$tvalue] = $language_rf_term_name;
      }

	    if(isset($values['field_results_each_page']) && !empty($values['field_results_each_page'])) {
        $form_data['results_each_page'] = $values['field_results_each_page'];
      }
    }
    $form_data['form_id'] = 'custom_advanced_search_reference_form';
    $form_data['source'] = 'form';
    $form_data['is_new'] = TRUE;
    $_SESSION['search'] = $form_data;
    $form_state->setRedirect('custom_search.search_sinequa_content_results');
  }

  /**
   *
   */
  public function custom_date_format($form_element, &$form_state) {
    // We unset the current values.
    unset($form_element['year']['#options']);

    // Now we set the range we want.
    // 100 years ago.
    $max_age = date('Y') - 100;
    // 7 years ago
    $min_age = date('Y') - 7;

    // Now we populate the array.
    $form_element['year']['#options'] = [];
    foreach (range($max_age, $min_age) as $year) {
      $form_element['year']['#options'][$year] = $year;
    }

    // We return our modified element.
    return $form_element;
  }
  public function populate_segment(array $form, FormStateInterface $form_state){
    unset($form['fieldset_global_taxonomy']['field_subsegment']['#options']);
    $response = new AjaxResponse();
    $response->addCommand(new ReplaceCommand("#field-segment", ($form['fieldset_global_taxonomy']['field_segment'])));
    $response->addCommand(new ReplaceCommand("#field-subsegment", ($form['fieldset_global_taxonomy']['field_subsegment'])));
    return $response;
  }
  public function populate_subsegment(array $form, FormStateInterface $form_state){
    return $form['fieldset_global_taxonomy']['field_subsegment'];
  }
  public function populate_offer(array $form, FormStateInterface $form_state) {
    return $form['fieldset_global_taxonomy']['field_offer'];
  }
  public function populate_deal_size(array $form, FormStateInterface $form_state) {
    return $form['group_contract_information']['field_deal_size'];
  }
  public function get_deal_size_default($currency, $contract_value) {
    $sign_currency = '';
    switch ($currency) {
      case "AUD":
        $sign_currency = "AU$";
        break;
      case "BRL":
        $sign_currency = "R$";
        break;
      case "CNY":
        $sign_currency = "¥";
        break;
      case "EUR":
        $sign_currency = "€";
        break;
      case "GBP":
        $sign_currency = "£";
        break;
      case "USD":
        $sign_currency = "$";
        break;
      case "MXN":
        $sign_currency = "Mex$";
        break;
    }
    $deal_size_arr = array('_none' => 'None',
      $currency . '_1' => '0 ' . $sign_currency . ' - 0.5 M' . $sign_currency,
      $currency . '_2' => '0.5 M' . $sign_currency . ' - 1 M' . $sign_currency,
      $currency . '_3' => '1 M' . $sign_currency . ' - 5 M' . $sign_currency,
      $currency . '_4' => '5 M' . $sign_currency . ' - 10 M' . $sign_currency,
      $currency . '_5' => '10 M' . $sign_currency . ' - 20 M' . $sign_currency,
      $currency . '_6' => '20 M' . $sign_currency . ' - 50 M' . $sign_currency,
      $currency . '_7' => 'more than 50 M' . $sign_currency,
    );
    $select = '';
    $label = '';
    switch (TRUE) {
      case (($contract_value > 0 || $contract_value == 0) && $contract_value < 500001):
        $select = $currency . '_1';
        $label = '0 ' . $sign_currency . ' - 0.5 M' . $sign_currency;
        break;
      case ($contract_value > 500000 && $contract_value < 1000001):
        $select = $currency . '_2';
        $label = '0.5 M' . $sign_currency . ' - 1 M' . $sign_currency;
        break;
      case ($contract_value > 100000 && $contract_value < 5000001):
        $select = $currency . '_3';
        $label = '1 M' . $sign_currency . ' - 5 M' . $sign_currency;
        break;
      case ($contract_value > 500000 && $contract_value < 10000001):
        $select = $currency . '_4';
        $label = '5 M' . $sign_currency . ' - 10 M' . $sign_currency;
        break;
      case ($contract_value > 1000000 && $contract_value < 20000001):
        $select = $currency . '_5';
        $label = '10 M' . $sign_currency . ' - 20 M' . $sign_currency;
        break;
      case ($contract_value > 20000000 && $contract_value < 50000001):
        $select = $currency . '_6';
        $label = '20 M' . $sign_currency . ' - 50 M' . $sign_currency;
        break;
      case $contract_value > 50000000:
        $select = $currency . '_7';
        $label = 'more than 50 M' . $sign_currency;
        break;
      default:
        $select = '_none';
        $label = '(none)';
        break;
    }  
    return array('deal_size_arr' => $deal_size_arr, 'selected' => $select, 'ds_value' => $label);
  }
  public function build_deal_size($currency,$deal_size){
    $rate_array = ['aud'=>'1.65','brl'=>'5.48','cny'=>'7.60','gbp'=>'0.88','mxn'=>'19.70','usd'=>'1.09'];
    if(isset($currency) && $currency != '_none') {
      $ref_currency = strtolower($currency);
      if(isset($deal_size) && $deal_size != '_none') {
        if($ref_currency != 'eur') {
          $x_rate_currency = 'eur';
          $x_rate = $rate_array[$ref_currency];
        }
        $ranges = array ();
        $group = 0;
        $options = array (
          '1' => array (
          'min' => 0, 'max' => 500000
        ), '2' => array (
          'min' => 500001, 'max' => 1000000
        ), '3' => array (
          'min' => 1000001, 'max' => 5000000
        ), '4' => array (
          'min' => 5000001, 'max' => 10000000
        ), '5' => array (
          'min' => 10000001, 'max' => 20000000
        ), '6' => array (
          'min' => 20000001, 'max' => 50000000
        ), '7' => array (
          'min' => 50000001, 'max' => ''
        ), '8' => array (
          'min' => 10000001, 'max' => ''
        )
        );
  
        $temp_value = substr($deal_size,  - 1);
  
        if($temp_value && $temp_value != '')
          $ranges[$group][] = $temp_value;
				if(is_array($deal_size)){
					$deal_count = count($deal_size);
					for($i = 1; $i < $deal_count;  ++ $i) {
						$value = substr($deal_size[$i],  - 1);
						if($value != $temp_value + 1) {
							$group ++ ;
						}
						$ranges[$group][] = $value;
						$temp_value = $value;
					}
				}
  
        if(count($ranges) > 0) {
          $deal_size = '';
          $x_rate_deal_size = '';
          foreach($ranges as $key => $range) {
            $min = $options[$range[0]]['min'];
            $the_last = end($range);
            $max = $options[$the_last]['max'];
            $temp = ($max != '') ? $min . '-' . $max :  $min;
            $deal_size .= ($key > 0) ? (' OR ' . $temp) : $temp;
            if(isset($x_rate)) {
              if(is_numeric($max)) {
                $temp = $max / $x_rate;
                if($temp < 100000)
                  $x_max = round($temp / 1000) * 1000;
                else
                  $x_max = round($temp / 100000) * 100000;
              }
  
              $temp = $min / $x_rate;
              if($temp < 100000)
                $x_min = round($temp / 1000) * 1000;
              else
                $x_min = round($temp / 100000) * 100000;
  
              $x_rate_temp = (isset($x_max)) ? $x_min . '-' . $x_max : $x_min;
              $x_rate_deal_size .= ($key > 0) ? (' OR ' . $x_rate_temp) : $x_rate_temp;
            }
          }
          if($deal_size != '' && strstr($deal_size, 'OR')){
            return explode('OR', $deal_size);
          }
          else{
            return explode('-', $deal_size);
          }
        }
      }
    }
  }
}
