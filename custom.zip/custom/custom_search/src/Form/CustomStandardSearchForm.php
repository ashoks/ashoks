<?php
/**
 * @file
 * Contains \Drupal\custom_search\Form\CustomStandardSearchForm.
 *
 */
namespace Drupal\custom_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Routing;

class CustomStandardSearchForm extends FormBase {
  public function getFormId() {
    return 'custom_standard_search_form';
  }
  public function buildForm(array $form, FormStateInterface $form_state) {
    $route_name = \Drupal::routeMatch()->getRouteName();
    $non_search_page = ['social_core.homepage','view.all_news_listing.page_1','view.all_reference_listing.page_1','view.all_event_listing.page_1','view.all_communities.page_1','view.my_communities.page_1','custom_cart.crp_view_cart','entity.webform.canonical','front_Page.home_page'];
    
    if(in_array($route_name,$non_search_page)) {
      unset($_SESSION['search']);
      unset($_SESSION['fake_group_id']);
    }

    if(empty($_SESSION['search'])) {
      $_SESSION['search'] = [];
    }
    #dump($_SESSION['fake_group_id']);
    /**
     * Scope Logic which handle the scope of the search with related to community and entire KM Platform
     */
    $scope_options = array (
      '0' => t('PRISM Platform'), '1' => t('Communities Joined'),/* '3' => t('Communities & Sub Communities Joined') */
    );
    $current_uri = \Drupal::request()->getRequestUri();
    $path_args = explode('/', $current_uri);
		$is_folder = explode('=',$path_args[1]);
    $ko_array = ['asset','reference','event','news','community','node','page','group','community_folder'];
    // Handling Group id when search multiple time after community page.
    if(isset($_SESSION['fake_group_id']) && !empty($_SESSION['fake_group_id'])) {
      if(empty($_SESSION['search']['group_id'])) {
        $_SESSION['search']['group_id'] = $_SESSION['fake_group_id'];
      }
    }
    // scope == 0  (standard)
    // scope == 1  (my communities)
    // scope == 2  (this community)
    // scope == 3  (My Communities + Related Communities)
    $default_op_value = 0;
    if((in_array($path_args[1],$ko_array) || isset($_GET['adv_gid']) || (isset($_SESSION['search']['group_id'])) && $_SESSION['search']['scope'] == 2) || ($path_args[1] == 'node' && $path_args[2] == 'add')  || (isset($is_folder[0]) && $is_folder[0] == 'folderlist?community_id') || ($path_args[1] == 'community-tag-clouds' && is_numeric($path_args[2]) && is_numeric($path_args[3]))) {
      $scope_options[2] = t('This Community');
      $default_op_value = 2;
    } else {
      if(isset($_SESSION['search']['scope']) && is_array($_SESSION['search']['scope'])){
        $default_op_value = (array_key_exists('search',$_SESSION['search']['scope']))?$_SESSION['search']['scope']:null;
			}
			elseif(isset($_SESSION['search']['scope']) && !is_array($_SESSION['search']['scope'])){
				$default_op_value = $_SESSION['search']['scope'];
			}
    }

    $option_html = '';
    /*foreach($scope_options as $key => $option) {
      $option_html.= '<li data-val="'.$key.'">'.$option.'</li>';
    }*/
    $form['#method'] = "POST";

    if((in_array($path_args[1],$ko_array) || isset($_GET['adv_gid']) || (isset($_SESSION['search']['group_id'])) && $_SESSION['search']['scope'] == 2) || ($path_args[1] == 'node' && $path_args[2] == 'add')) {
    $form['standard_search_scope_markup'] = array(
      /* '#markup' => '<div class="dropdown-wrap">
      <div class="value-holder">This Community</div>
      <ul class="custom-dropdown" aria-label="custom select" style="display: block;">
        '.$option_html.'
      </ul>
    </div>', */
    );
  } else {
    if(isset($_SESSION['search']['scope']) && !empty($_SESSION['search']['scope']) && is_numeric($_SESSION['search']['scope'])) {
      $form['standard_search_scope_markup'] = array(
        '#markup' => '<div class="dropdown-wrap">
        <div class="value-holder">'.$scope_options[$_SESSION['search']['scope']].'</div>
        <ul class="custom-dropdown" aria-label="custom select" style="display: block;">
          '.$option_html.'
        </ul>
      </div>',
      );
    } else {
      $form['standard_search_scope_markup'] = array(
        '#markup' => '<div class="dropdown-wrap">
        <!--<div class="value-holder">PRISM Platform</div>-->
        <ul class="custom-dropdown" aria-label="custom select" style="display: block;">
          '.$option_html.'
        </ul>
      </div>',
      );
    }
  }
  if(in_array($path_args[1],$ko_array) || isset($_GET['adv_gid']) || isset($_SESSION['search']['group_id']) || ($path_args[1] == 'node' && $path_args[2] == 'add')) {
    $group_id_value = _get_custom_group_id();
    if(!empty($group_id_value)) {
      $group_id_value = _get_custom_group_id();
    } else {
      $group_id_value = isset($_SESSION['search']['group_id']) ? $_SESSION['search']['group_id'] : '';
    }
    $form['group_id'] = array(
      '#type' => 'hidden',
      '#value' => $group_id_value, 
    );
  }
 
    
    $current_path = \Drupal::service('path.current')->getPath();
    $keyword = "";
    if($path_args[1] == 'searchsinequa' && $path_args[2] == 'all'){
      $keyword = $_SESSION['search']['keyword'];
    }
    $is_front = \Drupal::service('path.matcher')->isFrontPage();
    if ( $is_front) {
      $form['standard_search_keyword'] = array(
        '#type' => 'textfield',
        '#default_value' => htmlspecialchars_decode($keyword),
        '#autocomplete_route_name' => 'custom_search.standardsearch_keywordautocomplete',
        '#placeholder' => 'What are you looking for?',
      );
    }
    else {
      $form['standard_search_keyword'] = array(
        '#type' => 'textfield',
        '#default_value' => htmlspecialchars_decode($keyword),
        '#autocomplete_route_name' => 'custom_search.standardsearch_keywordautocomplete',
        '#placeholder' => 'What are you looking for?',
      );
    }
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t(' '),
      '#button_type' => 'primary',
      '#prefix' => ' <i class="material-symbols-outlined">search',
      '#suffix' => '</i>',
    );
    $form['standard_search_scope_option'] = array(
      '#type' => 'select', 
      '#options' => $scope_options,
      '#validated' => TRUE,
      '#default_value' => $default_op_value,
    );

    return $form;
  }
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $form_data = array();
    unset($_SESSION['search']);
    $values = $form_state->cleanValues()->getValues();
    if(empty($_SESSION['search'])) {
      if(isset($values['group_id']) && $values['standard_search_scope_option'] == 2) { 
        $form_data['group_id'] = $_SESSION['fake_group_id'] = $values['group_id'];
      }
      $form_data['keyword'] = $values['standard_search_keyword'];
      $form_data['scope'] = $values['standard_search_scope_option'];
      $form_data['form_id'] = 'custom_standard_search_form';
      $form_data['source'] = 'form';
      $form_data['is_new'] = TRUE;
      $_SESSION['search'] = $form_data;
    }
    $form_state->setRedirect('custom_search.search_sinequa_all_results');
  }
}
