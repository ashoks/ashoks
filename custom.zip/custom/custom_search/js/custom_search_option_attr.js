(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.addDataFlagsToOptions = {
    attach: function (context) {
      const $checkbox = $('#edit-field-gen-ai-offer', context);
      const related = drupalSettings.custom_search?.relatedTids || [];
      const $select = $('#edit-field-entry-portfolio', context);
      $checkbox.on('change', function (e) {
        e.stopPropagation();
        const isChecked = $(this).is(':checked');
        const isNotChecked = !$(this).is(':checked');
        $select.find('option').each(function () {
          const $opt = $(this);
          const val = $opt.val();
          const isRelated = related.includes(val);
          $opt.attr('data-flag', isRelated ? 'related' : 'unrelated');
          if (isChecked && isRelated) {
            $opt.prop('selected', true);
          } else {
            if(isNotChecked && isRelated) {
              $opt.prop('selected', false);
            }
          }
        });
        $select.trigger('click');
      });
    }
  };
})(jQuery, Drupal, drupalSettings);
