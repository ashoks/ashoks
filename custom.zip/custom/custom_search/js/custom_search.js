(function ($, Drupal) {
  'use strict';
  Drupal.behaviors.custom_search = {
    attach: function (context) {
      $(".facet-block").each(function () {
        var facet_ul = $(this).find("ul");
        var facet_li = facet_ul.find("li");
        var facet_li_size = facet_li.length;
        var x = 5;
        var facet_ul_id = "#" + facet_ul.attr("id");
        var facet_loadMore_id = "#load_more_" + facet_ul.attr("id");
    
        $(facet_ul_id + ' li:lt(' + x + ')').show();
    
        if (facet_li_size <= 5) {
          $(facet_loadMore_id).remove();
        }
    
        $(facet_loadMore_id).click(function () {
          x = (x + 5 <= facet_li_size) ? x + 5 : facet_li_size;
          $(facet_ul_id + ' li:lt(' + x + ')').removeClass('hidden');
          if (x >= facet_li_size) {
            $(facet_loadMore_id).remove();
          }
        });
      });

      $('#edit-search-filter-reset').on('click',function(event){
        event.preventDefault();
        $('#custom-search-sorting-form #edit-search-sorted-by').val("");
        $('#custom-search-sorting-form #edit-search-sorted-order').val("");
        $('#custom-search-sorting-form #edit-search-filter-scope').val(0);
        return false;
      });

      $('#edit-search-sorted-by').change(function(){
        if($(this).val() == 'sourcedatetime14' || $(this).val() == 'sourcedatetime15' ||  $(this).val() == 'sourcedatetime9') {
          $('#edit-search-sorted-order').val('desc');
        } else if($(this).val() == 'sourcestr5') {
          $('#edit-search-sorted-order').val('asc');
        } else if($(this).val() == 'sourcedatetime10'){
          $('#edit-search-sorted-order').val('');
        } else {
          $('#edit-search-sorted-order').val('asc');
        }
      });
    }
  };
})(jQuery, Drupal);
(function ($) {
  $(document).ready(function () {
		window.addEventListener("pageshow", () => {
		 // This code runs when the search page is loaded from the back/forward cache.
		 $('form.custom-advanced-search-asset-form #edit-submit').removeAttr('disabled');
		 $('form.custom-advanced-search-reference-form #edit-submit').removeAttr('disabled');
		 $('form.custom-advanced-search-asset-reference-form #edit-submit').removeAttr('disabled');
		 $('form.custom-advanced-search-people-form #edit-submit').removeAttr('disabled');
		});
    $('.path-advanced-search-asset-form #scopeHeading, .path-advanced-search-reference-form #scopeHeading, .path-advanced-search-asset-reference-form #scopeHeading, .path-advanced-search-people-form #scopeHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#scopeCollapse" aria-expanded="true" aria-controls="scopeCollapse">Scope</button>');

    $('.path-advanced-search-asset-form div.form-item-advanced-search-scope, .path-advanced-search-reference-form div.form-item-advanced-search-scope').addClass('form-check');
    $('.path-advanced-search-asset-form div.form-check input.form-radio, .path-advanced-search-reference-form div.form-check input.form-radio').addClass('form-check-input');
    $('.path-advanced-search-asset-form div.form-check label.option, .path-advanced-search-reference-form div.form-check label.option').addClass('form-check-label');
    $('.path-advanced-search-asset-form #edit-advanced-search-scope, .path-advanced-search-reference-form #edit-advanced-search-scope').addClass('d-flex gap-3 align-items-center');

    $('.path-advanced-search-asset-form #basicInfoHeading, .path-advanced-search-reference-form #basicInfoHeading, .path-advanced-search-asset-reference-form #basicInfoHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#basicInfoCollapse" aria-expanded="true" aria-controls="basicInfoCollapse">Basics</button>');

    $('.path-advanced-search-people-form #personalInfoHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#personalInfoCollapse" aria-expanded="true" aria-controls="personalInfoCollapse">Personal Information</button>');

    $('.path-advanced-search-asset-form .js-form-item-field-adv-search-rating,.path-advanced-search-reference-form .js-form-item-field-account-country,.path-advanced-search-reference-form .js-form-item-field-adv-search-rating,.path-advanced-search-reference-form .js-form-item-field-ultimate-parent-account').addClass('mb-3');

    $('.path-advanced-search-asset-form #edit-field-adv-search-rating,.path-advanced-search-reference-form #edit-field-account-country,.path-advanced-search-reference-form #edit-field-adv-search-rating,.path-advanced-search-reference-form #edit-field-ultimate-parent-account').addClass('br-2');

    $('.path-advanced-search-asset-form #edit-field-status .js-form-type-checkbox').addClass('form-check');
    $('.path-advanced-search-asset-form #edit-field-status .js-form-type-checkbox input').addClass('form-check-input');
    $('.path-advanced-search-asset-form #edit-field-status .js-form-type-checkbox label').addClass('form-check-label');
    $('.path-advanced-search-asset-form #edit-field-status').addClass('d-flex gap-3 align-items-center');

    $('.path-advanced-search-asset-form #globalTaxoHeading, .path-advanced-search-reference-form #globalTaxoHeading, .path-advanced-search-asset-reference-form #globalTaxoHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#globalTaxoCollapse" aria-expanded="true" aria-controls="globalTaxoCollapse">Global Taxonomy</button>');

    $('.path-advanced-search-asset-form #communityTaxoUserHeading, .path-advanced-search-reference-form #communityTaxoUserHeading, .path-advanced-search-asset-reference-form #communityTaxoUserHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#communityTaxoUserCollapse" aria-expanded="true" aria-controls="communityTaxoUserCollapse"> Community Taxonomy and User Tags </button>');

    $('.path-advanced-search-asset-form #AttachmentsHeading,.path-advanced-search-reference-form #AttachmentsHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#AttachmentsCollapse" aria-expanded="true" aria-controls="AttachmentsCollapse"> Attachments </button>');

    $('.path-advanced-search-reference-form #ContractinfoHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#ContractinfoCollapse" aria-expanded="true" aria-controls="ContractinfoCollapse"> Contract Information </button>');

    $('.path-advanced-search-reference-form #DeliveryinfoHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#DeliveryinfoCollapse" aria-expanded="true" aria-controls="DeliveryinfoCollapse"> Delivery Information </button>');

    $('.path-advanced-search-people-form #workAssignHeading').html('<button class="accordion-button h5 mb-0" type="button" data-bs-toggle="collapse" data-bs-target="#workAssignCollapse" aria-expanded="true" aria-controls="workAssignCollapse"> Work Assignments </button>');

    $('.path-advanced-search-reference-form #edit-field-permission-status--wrapper #edit-field-permission-status, .path-advanced-search-reference-form #edit-field-managed-services-am-im-, .path-advanced-search-reference-form #edit-field-sustainability-benefit, .path-advanced-search-reference-form #edit-field-project-status, .path-advanced-search-asset-form #edit-field-managed-services-am-im, .path-advanced-search-asset-reference-form #edit-advanced-search-scope, .path-advanced-search-asset-reference-form #edit-field-status, .path-advanced-search-asset-reference-form #edit-field-managed-services-am-im-, .path-advanced-search-people-form #edit-advanced-search-scope').addClass('d-flex gap-4');

    $('.path-advanced-search-asset-form input[name="field_adv_submitter[textfield]"], .path-advanced-search-asset-form input[name="field_adv_contact[textfield]"], .path-advanced-search-reference-form input[name="field_adv_submitter[textfield]"], .path-advanced-search-reference-form input[name="field_adv_contact[textfield]"], .path-advanced-search-asset-reference-form input[name="field_adv_submitter[textfield]"]').attr("placeholder", "Type Name to Search");

    $('.path-advanced-search-asset-form input[name="field_adv_search_account[textfield]"],.path-advanced-search-reference-form input[name="field_adv_search_account[textfield]"], .path-advanced-search-asset-reference-form input[name="field_adv_search_account[textfield]"]').attr("placeholder", "Type Account Name to Search");

    $('.path-advanced-search-asset-form input[name="field_technologies[textfield]"], .path-advanced-search-reference-form input[name="field_technologies[textfield]"], .path-advanced-search-asset-reference-form input[name="field_technologies[textfield]"]').attr("placeholder", "Type Keyword to Search");

    $('.path-advanced-search-asset-form input#edit-field-community-taxonomy, .path-advanced-search-reference-form input#edit-field-community-taxonomy, .path-advanced-search-asset-reference-form input#edit-field-community-taxonomy').attr("placeholder", "Select appropriate Taxonomy");

    $('.path-advanced-search-asset-form input#edit-field-community-taxonomy, .path-advanced-search-reference-form input#edit-field-community-taxonomy').attr("placeholder", "Select appropriate Taxonomy");

    $('.path-advanced-search-asset-form input#edit-field-community-folders, .path-advanced-search-reference-form input#edit-field-community-folders').attr("placeholder", "Select appropriate Folder(s)");
		
		$('form.custom-search-sorting-form').addClass('d-flex gap-3');
		$('form.custom-search-sorting-form #edit-search-filter-submit, form.custom-search-sorting-form #edit-search-filter-reset').removeClass('btn-primary');
		$('#edit-field-creation-date-from, #edit-field-creation-date-to, #edit-field-last-updated-date-from, #edit-field-last-updated-date-to').keypress(function (e) { return false; });
		$('#edit-field-start-date-from, #edit-field-start-date-to, #edit-field-end-date-from, #edit-field-end-date-to').keypress(function (e) { return false; });
    //$('.search-result .pagination li a[rel="next"]').text('»');
    //$('.search-result .pagination li a[rel="prev"]').text('«');
		if(window.location.hash){
			var hash = decodeURIComponent(window.location.hash.substring(1));
			var cleanedhash = hash.replace(/[^a-zA-Z0-9 ]/g, "");
			$('#attachments tbody tr td .attachment-wrapper a').each(function(index, element) {
			var itemText = $(element).text();  // Get text content of the <li> element
			var cleaneditemText = itemText.replace(/[^a-zA-Z0-9 ]/g, "");
				// Check if the text contains the search string
				if (cleaneditemText.includes(cleanedhash)) {
					var highlightedText = cleaneditemText.replace(
						new RegExp(cleanedhash, 'gi'),  // 'g' for global match, 'i' for case-insensitive match
						function(match) {
							return '<span style="background-color:silver">' + itemText + '</span>';  // Wrap matched text in a span
						}
					);
				// Set the new HTML with highlighted text
				$(element).html(highlightedText);
				}
			});
		}
  });
})(jQuery);
(function ($, Drupal) {
  Drupal.behaviors.storeSelectValues = {
    attach: function (context, settings) {
      // Reload the page if the user comes back using the back button
      $(window).on('pageshow', function (event) {
        if (event.originalEvent.persisted && (window.location.pathname === "/advanced_search_asset_form" || window.location.pathname === "/advanced_search_reference_form" || window.location.pathname === "/advanced_search_asset_reference_form")) {
          window.location.reload();
        }
      });
    }
  };
})(jQuery, Drupal);