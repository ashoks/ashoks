<?php

namespace Drupal\custom_comment_count\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class CommentCountController extends ControllerBase {

  /**
   * Updates the comment count for the given node.
   *
   * @param int $node
   *   The node ID from the URL.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   A JSON response containing the comment count or an error message.
   */
  public function updateCommentCount($node) {
    // Load the node object by node ID.
    $node = \Drupal::entityTypeManager()->getStorage('node')->load($node);

    if ($node) {
      // Get the comment count field from the node.
      $comment_count = $node->get('field_comments')->comment_count ?? 0;
      return new JsonResponse(['comment_count' => $comment_count]);
    }

    // Return error response if node not found.
    return new JsonResponse(['error' => 'Node not found'], 400);
  }

}
