(function ($, Drupal) {
  Drupal.behaviors.customCommentCount = {
    attach: function (context, settings) {
      // Function to extract the node ID from the URL.
      function getNodeIdFromUrl() {
        var path = window.location.pathname; // Get the current path.
        // Regular expression to match 'node', 'asset', 'event', 'pages', 'news', or 'reference' followed by a number.
        var regex = /(?:node|asset|event|pages|news|reference)\/(\d+)/;
        var match = path.match(regex); // Match the regex to the current path.
        if (match) {
          return match[1]; // Return the captured node ID.
        }
        else {
          if ($('.pages-edit-link').length) {
           let nid = $('.pages-edit-link').attr('nid');
           return nid; 
          }
        }
 
        return null; // Return null if no match is found.
      }

     // $(document, context).ajaxComplete(function () {
      if ($('#comment-count').length) {
        var nodeId = getNodeIdFromUrl(); // Get the node ID from the URL.
        if (nodeId) {
          // AJAX POST request to the custom controller.
          $.ajax({
            url: '/comment-update/' + nodeId,
            type: 'POST',
            dataType: 'json',
            success: function (response) {
              if (response.comment_count !== undefined) {
                // Update the comment count in the DOM.
                setTimeout(() => {
                  $('#comment-count').text('Total Comments: '+ response.comment_count);
                }, 300);
                
              } else {
                console.error('Error: ' + response.error);
              }
            },
            error: function () {
              console.error('Failed to update comment count');
            }
          });
        } else {
          console.error('Node ID not found in URL');
        }
      }
      //});
    }
  };
})(jQuery, Drupal);
