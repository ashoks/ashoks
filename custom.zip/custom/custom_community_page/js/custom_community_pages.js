(function ($) {
  $(document).ready(function () {
  $('.form-item--book-bid label.form-item__label').text('Pages');
  $('.form-item--book-bid select option:contains("- Create a new book -")').text('- Create a new page -');
  $('#edit-book summary span:contains("Not in book")').text('Not in pages');
  $('#edit-book em:contains("No book selected.")').text('No pages selected.');

  $('.communityPages.treeview li').has('ul').each(function () {
      $(this).addClass('branch');
    })
  $('.communityPages.treeview ul').first().addClass( "d-flex flex-column gap-1" );
  $(".communityPages .branch > ul").addClass("nested-ul ps-3");
  $(".communityPages .branch > ul.nested-ul li").removeClass("border-bottom-subtel");
  $(".communityPages.treeview li:not(:has(ul))").each(function () {
      $(this).addClass('no-nested py-1');
  });
  $('.communityPages.treeview li.no-nested').on('click', function (e) {
      e.stopPropagation();
  })

  /* Hide Expand/Collapse if no Child data available */
  /*if ($('#communityPages .communityPages.treeview ul li').length != 0) {
    if ($('#communityPages .communityPages.treeview ul li').hasClass('branch')) {
      if ($('#communityPagesCollapse .treeview-trigger').hasClass('hide-collapse')) {
        $('#communityPagesCollapse .treeview-trigger').removeClass('hide-collapse');
      }
    }
    else {
      $('#communityPagesCollapse .treeview-trigger').addClass('hide-collapse');
    }
  }

  // Adding Expand/Collapse All functionality for Community Folders Block
  $(document).on('click', '.communityPagesButton.treeview-trigger button', function () {
    if($(this).index() == 0){
      $(this).closest('.accordion-body').find('.communityPages.treeview input[type=checkbox]').prop('checked', true);
    } else{
      $(this).closest('.accordion-body').find('.communityPages.treeview input[type=checkbox]').prop('checked', false);
    }
  });*/
  // End of Expand/Collapse All functionality for Community Folders Block
  /* Start js for community pages treestructure view* */  

 

  /* End js for community pages treestructure view* */
  $('#node-pages-form .vertical-tabs .book-outline-form').addClass('active');
  $('#node-pages-edit-form .vertical-tabs .book-outline-form').addClass('active');

  $('#node-pages-form .vertical-tabs #edit-book').find('.custom-btn-wrap').hide();
  $('#node-pages-edit-form .vertical-tabs #edit-book').find('.custom-btn-wrap').hide();

  $('#node-pages-form .vertical-tabs #edit-book').find('label[for="edit-book-bid"]').text('Community Page');
  $('#node-pages-edit-form .vertical-tabs #edit-book').find('label[for="edit-book-bid"]').text('Community Page');

  $('#node-pages-form .vertical-tabs .vertical-tab-button.last').find('a').hide();
  $('#node-pages-edit-form .vertical-tabs .vertical-tab-button.last').find('a').hide();
  $('a[href="#edit-revision-information"]').hide();
  //$('#node-pages-form .vertical-tabs').prepend('<h5 style="margin-left:10px"><b>Parent</b></h5>');
  //$('#node-pages-edit-form .vertical-tabs').prepend('<h5 style="margin-left:10px"><b>Parent</b></h5>');
});
})(jQuery);

(function (Drupal, $, once) {

  Drupal.behaviors.activeTreeView = {
    attach: function (context, settings) {
      const treeViewActive = '.treeview a.active';
      once('activeTreeView', treeViewActive, context).forEach(function (element) {
        const treeView = $(element).parents('.treeview');
        const treeViewLiCount = treeView.find('> ul > li').length;
        if (treeViewLiCount == 1) {
          setTimeout(() => {
            let tree_view_trigger = treeView.parents('.accordion').find('.treeview-trigger > a');
            $(tree_view_trigger).addClass('check-all');
            $(tree_view_trigger).find('.ec-text').text('Collapse All');
            $(tree_view_trigger).find('.ec-icon').text('do_not_disturb_on');
          }, 200);
        }
      });
    }
  };
  Drupal.behaviors.isVisibleTreeView = {
    attach: function (context) {
      const treeView = '.treeview';
      once('isVisibleTreeView', treeView, context).forEach(function (element) {
        let hasSecondlevelItems =  $(element).find('ul  ul').length > 0;
        if(hasSecondlevelItems == false) {
          let treeViewTrigger =  $(element).parents('.accordion').find('.treeview-trigger');
          $(treeViewTrigger).addClass('hide-collapse');
        }
      })
    }
  }

  Drupal.behaviors.addActiveDefaultItems = {
    attach: function (context) {
      const treeView = '.treeview ul li';
      once('addActiveDefaultItems', treeView, context).forEach(function (element) {
        let elementItem = $(element);
        if (elementItem.find('a.active').length > 0) {
          elementItem.find(' > input.dropdown-toggle-checkbox').prop('checked', true);
        }
      });
    }
  };
  Drupal.behaviors.loadajaxifyTags = {
    attach: function (context) {
      once('loadajaxifyTags', ".ajaxify-tag-community", context).forEach(function (element) {
        $(element).trigger('click');
      });
    }
  };
})(Drupal, jQuery, once);

