<?php

namespace Drupal\custom_mass_operations\Plugin\Action;

use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Database;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\taxonomy\Entity\Term;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsPreconfigurationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\views\ViewExecutable;
use Drupal\node\Entity\Node;

/**
 * Some description.
 *
 * @Action(
 *   id = "delete_content",
 *   label = @Translation("Delete Content (Custom)"),
 *   type = "",
 *   confirm = FALSE,
 *   requirements = {
 *     "_permission" = "access content",
 *     "_custom_access" = TRUE,
 *   },
 * )
 */
class DeleteContent extends ViewsBulkOperationsActionBase implements ContainerFactoryPluginInterface, ViewsBulkOperationsPreconfigurationInterface, PluginFormInterface {

  use StringTranslationTrait;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private Temp store.
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The current user.
   */
  protected AccountProxyInterface $currentUser;

  /**
   * Drupal\Core\Database\Connection.
   */
  protected Connection $database;

  /**
   * Object constructor.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   The plugin Id.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $tempStore
   *   The private temp store object.
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user object.
   * @param \Drupal\Core\Database\Connection $database
   *   The connection object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entityTypeManager,
    PrivateTempStoreFactory $tempStore,
    AccountProxyInterface $currentUser,
    Connection $database,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entityTypeManager, $tempStore, $currentUser, $database);
    $this->entityTypeManager = $entityTypeManager;
    $this->tempStore = $tempStore;
    $this->currentUser = $currentUser;
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->get('entity_type.manager'),
          $container->get('tempstore.private'),
          $container->get('current_user'),
          $container->get('database')
      );
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $item_count = 0;
    $items = $form['list']['#items'];
    foreach ($items as $title) {
      $item_count++;
    }
    $store->set('action_id', 'delete_content');
    $store->set('item_count', $item_count);
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function buildPreConfigurationForm(array $form, array $values, FormStateInterface $form_state): array {

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
  }

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
    $nid = $entity->get('entity_id')->getValue()[0]['target_id'];
    $node = Node::load($nid);
    $node->original = $node;
    $node->delete();
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->delete('delete_content');
    $store->delete('item_count');

    return $this->t('Performed action Delete Content on @count item(s)', ['@count' => $count]);
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    return $object->access('update', $account, $return_as_object);
  }

  /**
   * Default custom access callback.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user the access check needs to be preformed against.
   * @param \Drupal\views\ViewExecutable $view
   *   The View Bulk Operations view data.
   *
   * @return bool
   *   Has access.
   */
  public static function customAccess(AccountInterface $account, ViewExecutable $view): bool {
    custom_notification_user_has_group_roles($account, $view);
    parent::customAccess($account, $view);
    return TRUE;
  }

}
