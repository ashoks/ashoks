<?php

namespace Drupal\custom_mass_operations\Plugin\Action;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsPreconfigurationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\views\ViewExecutable;

/**
 * Some description.
 *
 * @Action(
 *   id = "change_submitter_action",
 *   label = @Translation("Change Submitter Action"),
 *   type = "",
 *   confirm = TRUE,
 *   requirements = {
 *     "_permission" = "access content",
 *     "_custom_access" = TRUE,
 *   },
 * )
 */
class ChangeSubmitterAction extends ViewsBulkOperationsActionBase implements ContainerFactoryPluginInterface, ViewsBulkOperationsPreconfigurationInterface, PluginFormInterface {

  use StringTranslationTrait;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private Temp store.
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The current user.
   */
  protected AccountProxyInterface $currentUser;

  /**
   * Object constructor.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   The plugin Id.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $tempStore
   *   The private temp store object.
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entityTypeManager,
    PrivateTempStoreFactory $tempStore,
    AccountProxyInterface $currentUser,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entityTypeManager, $tempStore, $currentUser);
    $this->entityTypeManager = $entityTypeManager;
    $this->tempStore = $tempStore;
    $this->currentUser = $currentUser;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->get('entity_type.manager'),
          $container->get('tempstore.private'),
          $container->get('current_user')
      );
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $request = \Drupal::request();
    $first_part_name = 'community';
    $group_id = '';
    // Get the referring URL.
    $referer_url = $request->headers->get('referer');
    // Parse the URL to get path parameters.
    $parsed_url = parse_url($referer_url);
    $path_parts = [];
    if (isset($parsed_url['path'])) {
      // Extract path parameters as an array.
      $path_parts = explode('/', trim($parsed_url['path'], '/'));
    }
    if (isset($path_parts[0]) && $path_parts[0] == $first_part_name && $path_parts[2] == 'manage-content') {
      $group_id = $path_parts[1];
    }
    // Currently the code is referenced
    // from custom_group_features_link_block module.
    $submitter_id = $this->currentUser->id();
    $account = $this->entityTypeManager->getStorage('user')->load($submitter_id);
    $email = $account->getEmail();
    $firstname = $account->get('field_name_first')->value;
    $lastname = strtoupper($account->get('field_name_last')->value);
    $realname = $firstname . ' ' . $lastname;
    $default_value = $realname . ' [' . $email . '] [' . $submitter_id . ']';
    $form['submitter'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Enter new submitter's name for selected items."),
      '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
      '#suffix' => '</div>',
      '#attributes' => ['placeholder' => $this->t('Type Keyword to Search')],
      '#default_value' => $default_value,
      '#autocomplete_route_name' => 'custom_autocomplete.autocomplete',
      '#autocomplete_route_parameters' => ['field_name' => 'field_author', 'count' => 0],
      '#weight' => 10,
      '#required' => TRUE,
    ];
    $field_author = $default_value = $realname . ' [' . $email . '] [' . $submitter_id . ']';

    $form['table_head'] = [
      '#markup' => '<div>User selected below will become submitter for following items</div>
        <table class="vbo-table table table-hover table-striped">
        <thead>
        <tr>
        <th class="views-field views-field-title">Content Title</th>
        </tr>
        </thead>
                            <tbody>',
    ];

    $items = $form['list']['#items'];
    unset($form['list']);

    foreach ($items as $title) {

      $form['table_row'][] = [
        '#markup' => '<tr class="odd views-row-first">
                  <td class="views-field views-field-title">' . $title . '</td>
                  </tr>',
      ];
    }
    $form['table_footer'] = [
      '#markup' => '</tbody>
              </table>',
    ];

    $form['actions']['submit']['#value'] = $this->t('Next');
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->set('action_id', 'change_submitter_action');
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function buildPreConfigurationForm(array $form, array $values, FormStateInterface $form_state): array {
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
    if (!empty($form_state->getValue('submitter'))) {

    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $string = $form_state->getValue('submitter');
    $field_author = preg_match('/([^ ]*$)/', $string, $results);
    // explode("][", $results[0]);.
    $last_word = $results[0];
    $uid = str_replace(['\'', '"', ',', ';', '<', '>', '[', ']', '(', ')', ''], '', $last_word);
    $this->configuration['submitter'] = $uid;
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->set('uid', $uid);
  }

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
    // Do some processing..
    $node_id = $entity->get('entity_id')->getValue()[0]['target_id'];
    $node = $this->entityTypeManager->getStorage('node')->load($node_id);
    $node->set('field_author', $this->configuration['submitter']);
    $node->save();
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->delete('action_id');
    $store->delete('uid');
    return $this->t('The submitter has been updated.');
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    return $object->access('update', $account, $return_as_object);
  }


  /**
   * Default custom access callback.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user the access check needs to be preformed against.
   * @param \Drupal\views\ViewExecutable $view
   *   The View Bulk Operations view data.
   *
   * @return bool
   *   Has access.
   */
  public static function customAccess(AccountInterface $account, ViewExecutable $view): bool {
    custom_notification_user_has_group_roles($account, $view);
    parent::customAccess($account, $view);
    return TRUE;
  }

}
