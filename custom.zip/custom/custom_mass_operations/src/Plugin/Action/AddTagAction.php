<?php

namespace Drupal\custom_mass_operations\Plugin\Action;

use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Database;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\taxonomy\Entity\Term;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsPreconfigurationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\views\ViewExecutable;

/**
 * Some description.
 *
 * @Action(
 *   id = "add_tag_action",
 *   label = @Translation("Add Tag Action"),
 *   type = "",
 *   confirm = TRUE,
 *   requirements = {
 *     "_permission" = "access content",
 *     "_custom_access" = TRUE,
 *   },
 * )
 */
class AddTagAction extends ViewsBulkOperationsActionBase implements ContainerFactoryPluginInterface, ViewsBulkOperationsPreconfigurationInterface, PluginFormInterface {

  use StringTranslationTrait;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private Temp store.
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The current user.
   */
  protected AccountProxyInterface $currentUser;

  /**
   * Drupal\Core\Database\Connection.
   */
  protected Connection $database;

  /**
   * Object constructor.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   The plugin Id.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $tempStore
   *   The private temp store object.
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user object.
   * @param \Drupal\Core\Database\Connection $database
   *   The connection object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entityTypeManager,
    PrivateTempStoreFactory $tempStore,
    AccountProxyInterface $currentUser,
    Connection $database,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entityTypeManager, $tempStore, $currentUser, $database);
    $this->entityTypeManager = $entityTypeManager;
    $this->tempStore = $tempStore;
    $this->currentUser = $currentUser;
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->get('entity_type.manager'),
          $container->get('tempstore.private'),
          $container->get('current_user'),
          $container->get('database')
      );
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $request = \Drupal::request();
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $first_part_name = 'community';
    $group_id = '';
    // Get the referring URL.
    $referer_url = $request->headers->get('referer');
    // Parse the URL to get path parameters.
    $parsed_url = parse_url($referer_url);
    $path_parts = [];
    if (isset($parsed_url['path'])) {
      // Extract path parameters as an array.
      $path_parts = explode('/', trim($parsed_url['path'], '/'));
    }
    if (isset($path_parts[0])
        && $path_parts[0] == $first_part_name
        && $path_parts[2] == 'manage-content') {
      $group_id = $path_parts[1];
      $store->set('gid', $group_id);
    }

    // Currently the code is
    // referenced from custom_group_features_link_block module.
    $form['tags'] = [
      '#type' => 'textfield',
      '#multiple' => TRUE,
      '#title' => $this->t('Enter the tags you want to add to selected items.'),
      '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
      '#suffix' => '</div>',
      '#attributes' => ['placeholder' => $this->t('Type Keyword to Search')],
      '#description' => t('* Use comma as a separator between values'),
      '#autocomplete_route_name' => 'custom_group_features_link_block.autocomplete',
      '#weight' => 10,
      '#required' => TRUE,
    ];
    $form['table_head'] = [
      '#markup' => '<div>Tag(s) will be added to following items. </div>
        <table class="vbo-table table table-hover table-striped">
        <thead>
        <tr>
        <th class="views-field views-field-title">Content Title</th>
        </tr>
        </thead>
            <tbody>',
    ];
    $items = $form['list']['#items'];
    unset($form['list']);
    $item_count = 0;
    foreach ($items as $title) {
      $form['table_row'][] = [
        '#markup' => '<tr class="odd views-row-first">
                  <td class="views-field views-field-title">' . $title . '</td>
                  </tr>',
      ];
      $item_count++;
    }
    $form['table_footer'] = [
      '#markup' => '</tbody>
              </table>',
    ];
    $form['actions']['submit']['#value'] = $this->t('Next');
    $store->set('action_id', 'add_tag_action');
    $store->set('item_count', $item_count);
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function buildPreConfigurationForm(array $form, array $values, FormStateInterface $form_state): array {

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
    if (!empty($form_state->getValue('tags'))) {

    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->set('tags', $form_state->getValue('tags'));

  }

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
  $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
  if(isset($_SESSION['assign_users'])){
  foreach($_SESSION['assign_users'] as $nid){
    $tags = ($store->get('tags')) ? $store->get('tags') : '';
    $specialCheckTrimmed = [];
    if ($tags) {
      $specialCheck = explode(",", trim($store->get('tags')));
      $specialCheckTrimmed = array_map('trim', $specialCheck);
    }

    $term_value_exp = array_filter($specialCheckTrimmed);
    // $nid = $entity->get('entity_id')->getValue()[0]['target_id'];
    $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
    if (count($term_value_exp) > 0) {
      $term_objects = $node->get('field_tags')->referencedEntities();

      $term_labels = [];
      $multiple_tids = [];
      $tags = '';
      foreach ($term_objects as $term_object) {
        // The id of the term.
        $term_object->id();
        // The term title.
        $term_object->label();
        // Build an array of term labels.
        $term_labels[] = $term_object->label();
        $tags .= $term_object->label() . ',';
      }

      $arrayTags = explode(",", $tags);

      // New code starts here.
      $vid = 'tags';
      // $term_value_exp = explode(",", $form_state->getValue('field_tags'));
      $multiple_tids = [];
      foreach ($term_value_exp as $key => $term_value) {

        if (in_array(strtolower($term_value), array_map("strtolower", $term_labels))) {
          // Do something.
          unset($term_value_exp[$key]);
        }

        $storage = $this->entityTypeManager->getStorage('taxonomy_term');
        $terms = $storage->loadByProperties(
              [
                'name' => $term_value,
                'vid' => $vid,
              ]
          );

        if ($terms) {
          // Only use the first term returned;
          // there should only be one anyways if we do this right.
          $term = reset($terms);
        }
        else {
          $term = Term::create(
          [
            'name' => $term_value,
            'vid' => $vid,
          ]
            );
          $term->save();
        }
        $tid = $term->id();
        $query = $this->database->select('taxonomy_term__field_author', 'gcf');
        $query->fields('gcf', ['field_author_target_id', 'deleted']);
        $query->condition('gcf.field_author_target_id', $this->currentUser->id());
        $query->condition('gcf.entity_id', $tid);
        $query->condition('gcf.node_id', $nid);
        $query->condition('gcf.deleted', 0);
        $result = $query->execute()->fetchAll();

        if (!$result) {
          // Now relate the user as author of the term.
          $conn = Database::getConnection();
          $conn->insert('taxonomy_term__field_author')
            ->fields(
              [
                'bundle' => $vid,
                'deleted' => 0,
                'entity_id' => $tid,
                'revision_id' => $tid,
                'language' => "en",
                'delta' => 0,
                'field_author_target_id' => $this->currentUser->id(),
                'node_id' => $nid,
              ]
                )->execute();

        }

        // Handling comma seperated case ends here.
        $existingTags = $this->entityTypeManager
          ->getStorage("taxonomy_term")
          ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);

        $termTagsId = [];
        $termTagsName = [];
        foreach ($existingTags as $key => $term) {
          $termTagsName[$term->tid] = $term->name;
        }

        // New code ends here.
        foreach ($arrayTags as $tag) {

          $categories_vocabulary = 'tags';
          // print_r(!in_array($tag, $termTagsName));.
          if (!in_array($tag, $termTagsName)) {
            $multiple_tids[] = $tid;
          }
          else {
            $multiple_tids[] = array_search($tag, $termTagsName);
          }
        }

      }

      $node->set('field_tags', array_unique($multiple_tids));
      $node->save();

    }
  }
}

    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $count = $store->get('item_count');
    $store->delete('tags');
    return $this->t('Performed action Add Tag on @count item(s)', ['@count' => $count]);
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    return $object->access('update', $account, $return_as_object);
  }

  /**
   * Default custom access callback.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user the access check needs to be preformed against.
   * @param \Drupal\views\ViewExecutable $view
   *   The View Bulk Operations view data.
   *
   * @return bool
   *   Has access.
   */
  public static function customAccess(AccountInterface $account, ViewExecutable $view): bool {
    custom_notification_user_has_group_roles($account, $view);
    parent::customAccess($account, $view);
    return TRUE;
  }

}
