<?php

namespace Drupal\custom_mass_operations\Plugin\Action;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\group\Entity\GroupRelationship;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsPreconfigurationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\views\ViewExecutable;

/**
 * Some description.
 *
 * @Action(
 *   id = "move_to_other_community_action",
 *   label = @Translation("Move To Other Community Action"),
 *   type = "",
 *   confirm = TRUE,
 *   requirements = {
 *     "_permission" = "access content",
 *     "_custom_access" = TRUE,
 *   },
 * )
 */
class MoveToOtherCommunityAction extends ViewsBulkOperationsActionBase implements ContainerFactoryPluginInterface, ViewsBulkOperationsPreconfigurationInterface, PluginFormInterface {

  use StringTranslationTrait;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private Temp store.
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The current user.
   */
  protected AccountProxyInterface $currentUser;

  /**
   * Object constructor.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   The plugin Id.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $tempStore
   *   The private temp store object.
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entityTypeManager,
    PrivateTempStoreFactory $tempStore,
    AccountProxyInterface $currentUser,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entityTypeManager, $tempStore, $currentUser);
    $this->entityTypeManager = $entityTypeManager;
    $this->tempStore = $tempStore;
    $this->currentUser = $currentUser;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->get('entity_type.manager'),
          $container->get('tempstore.private'),
          $container->get('current_user')
      );
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $request = \Drupal::request();
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $first_part_name = 'community';
    $group_id = '';
    // Get the referring URL.
    $referer_url = $request->headers->get('referer');
    // Parse the URL to get path parameters.
    $parsed_url = parse_url($referer_url);
    $path_parts = [];
    if (isset($parsed_url['path'])) {
      // Extract path parameters as an array.
      $path_parts = explode('/', trim($parsed_url['path'], '/'));
    }
    if (isset($path_parts[0]) && $path_parts[0] == $first_part_name && $path_parts[2] == 'manage-content') {
      $group_id = $path_parts[1];
      $store->set('old_gid', $group_id);
      $_SESSION['ccid'] = $group_id;
    }
    // Currently the code is referenced
    // from custom_group_features_link_block module.
    $form['community'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Enter name of community to which you want to move selected items.'),
      '#prefix' => '<div class="col-md-12" id="add_tag_msg">',
      '#suffix' => '</div>',
      '#attributes' => ['placeholder' => $this->t('Type Keyword to Search')],
      '#description' => t('* Please note that the items will actually be moved to the new community. They will not show up anymore in the original community.'),
      '#autocomplete_route_name' => 'custom_mass_operations.community_list_autocomplete',
      '#autocomplete_route_parameters' => ['gid' => $group_id],
      '#weight' => 10,
      '#required' => TRUE,
    ];

    $form['table_head'] = [
      '#markup' => '<div>Following items will be moved to community selected below</div>
        <table class="vbo-table table table-hover table-striped">
        <thead>
        <tr>
        <th class="views-field views-field-title">Content Title</th>
        </tr>
        </thead>
                            <tbody>',
    ];

    $items = $form['list']['#items'];
    unset($form['list']);
    $item_count = 0;
    foreach ($items as $title) {
      $form['table_row'][] = [
        '#markup' => '<tr class="odd views-row-first">
                                  <td class="views-field views-field-title">' . $title . '</td>
                                </tr>',
      ];
      $item_count++;
    }

    $form['table_footer'] = [
      '#markup' => '</tbody>
                             </table>',
    ];

    $form['actions']['submit']['#value'] = $this->t('Next');
    $store->set('action_id', 'move_to_other_community_action');
    $store->set('item_count', $item_count);
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function buildPreConfigurationForm(array $form, array $values, FormStateInterface $form_state): array {
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
    if (!empty($form_state->getValue('community'))) {

    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $string = $form_state->getValue('community');
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $field_author = preg_match('/([^ ]*$)/', $string, $results);
    // explode("][", $results[0]);.
    $last_word = $results[0];
    $gid = str_replace(['\'', '"', ',', ';', '<', '>', '[', ']', '(', ')', ''], '', $last_word);
    $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
    $store->set('community', $string);
    $store->set('new_gid', $group);
    $_SESSION['newGid'] = $gid;
  }

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $group = $store->get('new_gid');
    $node_id = $entity->get('entity_id')->getValue()[0]['target_id'];
    $node = \Drupal::entityTypeManager()->getStorage('node')->load($node_id);
    $old_gid = $store->get('old_gid') ?? $node->field_community->target_id;
    $plugin_id = "";
    if ($node) {
      $plugin_id = 'group_node:' . $node->bundle();
    // Checking if content exist in community 1.
      $group_contents = GroupRelationship::loadByPluginId($plugin_id);
      if (is_object($group)) {
        if (($group_contents = GroupRelationship::loadByEntity($node)) && !empty($group_contents)) {
          if ($group) {
          isset($group) && !empty($group) ? $group->addRelationship($node, $plugin_id) : NULL;
          //$group->addRelationship($node, $plugin_id);
          $group->save();
          }
          $node->field_community->target_id = $group->id();
          $node->set('changed', time());
          $node->save();
        }
        // removeGroupContent(NodeInterface $node, Group $group);.
        $removeFromGroup = \Drupal::entityTypeManager()->getStorage('group')->load($old_gid);
        // Try to load group content from entity.
        if (($group_contents = GroupRelationship::loadByEntity($node)) && !empty($group_contents)) {
          /**
          * @var @param \Drupal\group\Entity\GroupContent $group_content
          */
          foreach ($group_contents as $group_content) {
            if ($removeFromGroup->id() === $group_content->getGroup()->id()) {
              $group_content->delete();
              $group->save();
            }
          }
        }
      }
    }
    // Do some processing..
    // move_group_content($gid, );.
    $store = $this->tempStore->get('views_bulk_operations_mass_operation_page_1');
    $store->delete('action_id');
    $store->delete('old_gid');
    // $store->delete('new_gid');
    $count = $store->get('item_count');
    $store->delete('item_count');
    return $this->t('Performed action Move To Other Community on @count item(s)', ['@count' => $count]);
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    return $object->access('update', $account, $return_as_object);
  }

  /**
   * Default custom access callback.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user the access check needs to be preformed against.
   * @param \Drupal\views\ViewExecutable $view
   *   The View Bulk Operations view data.
   *
   * @return bool
   *   Has access.
   */
  public static function customAccess(AccountInterface $account, ViewExecutable $view): bool {
    custom_notification_user_has_group_roles($account, $view);
    parent::customAccess($account, $view);
    return TRUE;
  }

}
