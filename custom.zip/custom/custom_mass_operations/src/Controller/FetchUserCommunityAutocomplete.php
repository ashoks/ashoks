<?php

namespace Drupal\custom_mass_operations\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\group\GroupMembershipLoader;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * An example controller.
 */
class FetchUserCommunityAutocomplete extends ControllerBase {

  /**
   * Group membership loader service.
   *
   * @var \Drupal\group\GroupMembershipLoader
   */
  protected $membershipLoader;

  /**
   * Group membership loader service.
   *
   * @var \Drupal\Core\Session\AccountProxyInterfacer
   */
  protected $currentUser;

  /**
   * {@inheritdoc}
   */
  public function __construct(GroupMembershipLoader $membership_loader, $current_user) {
    $this->membershipLoader = $membership_loader;
    $this->currentUser = $current_user;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
          $container->get('group.membership_loader'),
          $container->get('current_user')
      );
  }

  /**
   * Returns a renderable array for a test page.
   *
   * Return []
   */
  public function renderCommunityList() {
    $gid = \Drupal::request()->get('gid');
    $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
    $com_type = $group->get('field_community_type')->value;
    $current_user = \Drupal::currentUser()->id();
    $results = [];
    $input = \Drupal::request()->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    $query = \Drupal::database()->select('groups_field_data', 'ttfd');
    $query->join('group_relationship_field_data', 'gc', 'ttfd.id = gc.gid');
    $query->join('group__field_community_type', 'ct', 'ttfd.id = ct.entity_id');
    $query->addField('ttfd', 'label', 'label');
    $query->addField('ttfd', 'id', 'id');
    $query->condition('ttfd.label', '%' . $input . '%', 'LIKE');
    $query->condition('gc.uid', $current_user);
    $query->condition('ct.field_community_type_value', $com_type);
    $query->groupBy('ttfd.label');
    $query->range(0, 10);
    $existingGroups = $query->execute()->fetchAll();
    // $existingTags = ($existingTags) ? $existingTags : [];
    $values = [];
    foreach ($existingGroups as $result) {
      $label = [
        $result->label, '(' . $result->id . ')',
      ];
      $values[] = [
        'label' => implode(' ', $label),
      ];
    }
    return new JsonResponse($values);
  }

}
