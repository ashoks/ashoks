<?php

namespace Drupal\custom_mass_operations\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    // Change path.
    if ($route = $collection->get('views_bulk_operations.execute_configurable')) {
      $path = $route->getPath();
      $updated_path = '/group' . $path;
      $route->setPath($updated_path);
      $route->setOption('_admin_route', FALSE);
    }
    if ($route = $collection->get('views_bulk_operations.confirm')) {
      $path = $route->getPath();
      $updated_path = '/group' . $path;
      $route->setPath($updated_path);
      $route->setOption('_admin_route', FALSE);
    }
  }

}
