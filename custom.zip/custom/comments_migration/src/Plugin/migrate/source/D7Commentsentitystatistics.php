<?php

namespace Drupal\comments_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "comments_entity_statistics"
 * )
 */
class D7Commentsentitystatistics extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('node_comment_statistics', 'n')
      ->fields('n', [
        'nid',
        'cid',
        'last_comment_timestamp',
        'last_comment_name',
        'last_comment_uid',
        'comment_count',
      ]);
    $query->leftJoin('field_data_comment_body', 'b', 'b.entity_id = n.cid');
    $query->addField('b', 'bundle');
    $query->addField('b', 'entity_type');
    $query->addField('b', 'comment_body_format');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'nid' => $this->t('NID'),
      'cid' => $this->t('CID'),
      'last_comment_timestamp' => $this->t('last_comment_timestamp'),
      'last_comment_name' => $this->t('last_comment_name'),
      'last_comment_uid' => $thsi->t('last_comment_uid'),
      'comment_count' => $this->t('comment_count'),
      'entity_type' => $this->t('entity_type'),
      'comment_body_format' => $this->t('comment_body_format'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $comment_type = $row->getSourceProperty('bundle');

    if ($comment_type == 'comment_node_book') {
      $row->setSourceProperty('comment_body_format', 'field_comment_node_page');
    }
    elseif ($comment_type == 'comment_node_news') {
      $row->setSourceProperty('comment_body_format', 'field_comments');
    }
    elseif ($comment_type == 'comment_node_reference') {
      $row->setSourceProperty('comment_body_format', 'field_comments_reference');
    }
    elseif ($comment_type == 'comment_node_asset') {
      $row->setSourceProperty('comment_body_format', 'comment_node_asset');
    }
    else {
      return FALSE;
    }
    $row->setSourceProperty('entity_type', 'node');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['cid' => ['type' => 'integer']];
  }

}
