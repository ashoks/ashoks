<?php

namespace Drupal\comments_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "comments_data"
 * )
 */
class D7Comments extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('comment', 'n')
      ->fields('n', [
        'cid',
        'nid',
        'language',
        'hostname',
        'subject',
      ]);
    $query->innerJoin('field_data_comment_body', 'b', 'b.entity_id = n.cid');
    $query->addField('b', 'bundle');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'cid' => $this->t('CID'),
      'nid' => $this->t('Revision ID'),
      'language' => $this->t('Language'),
      'hostname' => $this->t('Title'),
      'subject' => $thsi->t('subject'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $comment_type = $row->getSourceProperty('bundle');

    if ($comment_type == 'comment_node_book') {
      $row->setSourceProperty('subject', 'comment');
    }
    elseif ($comment_type == 'comment_node_news') {
      $row->setSourceProperty('subject', 'news_comment');
    }
    elseif ($comment_type == 'comment_node_reference') {
      $row->setSourceProperty('subject', 'reference_comment');
    }
    elseif ($comment_type == 'comment_node_asset') {
      $row->setSourceProperty('subject', 'comment_node_asset');
    }
    else {
      return FALSE;
    }

    $row->setSourceProperty('language', 'en');

    // Generate UUID.
    $uuid_service = \Drupal::service('uuid');
    $uuid = $uuid_service->generate();
    $row->setSourceProperty('hostname', $uuid);

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['cid' => ['type' => 'integer']];
  }

}
