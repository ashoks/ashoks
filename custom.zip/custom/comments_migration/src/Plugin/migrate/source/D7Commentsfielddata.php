<?php

namespace Drupal\comments_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "comments_field_data"
 * )
 */
class D7Commentsfielddata extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('comment', 'n')
      ->fields('n', [
        'cid',
        'pid',
        'nid',
        'uid',
        'subject',
        'hostname',
        'created',
        'changed',
        'status',
        'name',
        'thread',
        'mail',
        'homepage',
        'language',
      ]);
    $query->innerJoin('field_data_comment_body', 'b', 'b.entity_id = n.cid');
    $query->addField('b', 'bundle');
    $query->addField('b', 'entity_type');
    $query->addField('b', 'delta');
    $query->addField('b', 'comment_body_format');
    $query->addField('b', 'comment_body_value');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'cid' => $this->t('CID'),
      'pid' => $this->t('PID'),
      'nid' => $this->t('Revision ID'),
      'uid' => $this->t('UID'),
      'subject' => $thsi->t('subject'),
      'hostname' => $this->t('hostname'),
      'created' => $this->t('Created'),
      'changed' => $this->t('Changed'),
      'status' => $this->t('Status'),
      'name' => $this->t('Name'),
      'thread' => $this->t('Thread'),
      'mail' => $this->t('Mail'),
      'homepage' => $this->t('Homepage'),
      'language' => $this->t('Language'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $comment_type = $row->getSourceProperty('bundle');
    $row->setSourceProperty('comment_body_format', 'comment');
    $row->setSourceProperty('comment_body_value', 'field_comments');

    // if ($comment_type == 'comment_node_book') {
    //   $row->setSourceProperty('comment_body_format', 'comment');
    //   $row->setSourceProperty('comment_body_value', 'field_comments');
    // }
    // elseif ($comment_type == 'comment_node_news') {
    //   $row->setSourceProperty('comment_body_format', 'news_comment');
    //   $row->setSourceProperty('comment_body_value', 'field_comments');
    // }
    // elseif ($comment_type == 'comment_node_reference') {
    //   $row->setSourceProperty('comment_body_format', 'reference_comment');
    //   $row->setSourceProperty('comment_body_value', 'field_comments_reference');
    // }
    // elseif ($comment_type == 'comment_node_asset') {
    //   $row->setSourceProperty('comment_body_format', 'comment_node_asset');
    //   $row->setSourceProperty('comment_body_value', 'comment_node_asset');
    // }
    // else {
    //   return FALSE;
    // }
    $row->setSourceProperty('language', 'en');
    $row->setSourceProperty('entity_type', 'node');
    $row->setSourceProperty('delta', '1');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['cid' => ['type' => 'integer']];
  }

}
