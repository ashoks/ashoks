<?php

declare(strict_types=1);

namespace Drupal\custom_community_folder\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\group\Entity\Group;
use Drupal\node\Entity\Node;

final class CustomCommunityFolderSubscriber implements EventSubscriberInterface
{

  /**
   * Kernel request event handler.
   */
  public function onKernelRequest(RequestEvent $event): void
  {
    if (!$event->isMainRequest()) {
      return;
    }
    $request = $event->getRequest();
    $path = \Drupal::service('path.current')->getPath();
    $args = array_values(array_filter(explode('/', $path)));
    $gid = $request->query->get('community_id');
    $del = $request->query->get('del');
    $groupId = null;
    $nodeId= null;
    switch (true) {
      case !empty($gid):
        $groupId = $gid;
        break;
      case !empty($del):
        $groupId = $del;
        break;
      case isset($args[0], $args[1]) && $args[0] === 'community' && is_numeric($args[1]):
        $groupId = $args[1];
        break;
      case isset($args[0], $args[1], $args[2]) && $args[0] === 'status' && $args[1] === 'unpublished' && is_numeric($args[2]):
        $groupId = $args[2];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'export-content' && is_numeric($args[1]):
        $groupId = $args[1];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'community-tag-clouds' && is_numeric($args[1]):
        $groupId = $args[2];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'community-taxonomy' && is_numeric($args[1]):
        $groupId = $args[2];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'global-taxonomy' && is_numeric($args[1]):
        $groupId = $args[2];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'group' && is_numeric($args[1]):
        $groupId = $args[1];
        break;
        case isset($args[0], $args[1]) && $args[0] === 'file-download' && is_numeric($args[2]):
        $nodeId = $args[2];
        break;
         case isset($args[0], $args[1]) && $args[0] === 'files' && is_numeric($args[4]):
        $nodeId = $args[4];
        break;
      case isset($args[0], $args[1]) && $args[0] === 'community_folder' && is_numeric($args[2]):
        $groupId = $args[2];
        break;
    }
    if ($groupId !== null && is_numeric($groupId) && $groupId > 0) {
      $group = Group::load($groupId);
      if ($group === null) {
        throw new NotFoundHttpException('Invalid community ID.');
      }
      return;
    }
    if ($nodeId !== null && is_numeric($nodeId) && $nodeId > 0){
      $node = node::load($nodeId);
         if($node===null){
        throw new NotFoundHttpException('Invalid node ID.');
      }
    }
  }



  /**
   * Kernel response event handler.
   */
  public function onKernelResponse(ResponseEvent $event): void
  {
    // Optional: Add response logic if needed
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array
  {
    return [
      KernelEvents::REQUEST => ['onKernelRequest'],
      KernelEvents::RESPONSE => ['onKernelResponse'],
    ];
  }
}
