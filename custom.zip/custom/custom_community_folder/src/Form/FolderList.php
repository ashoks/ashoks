<?php

namespace Drupal\custom_community_folder\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\taxonomy\Entity\Term;

/**
 * Formbase.
 */
class FolderList extends FormBase {

  /**
   * Returns a unique string identifying the list.
   *
   * The returned ID should be a unique string that can be a valid PHP function
   * name, since it's used in hook implementation names such as
   * hook_form_FORM_ID_alter().
   *
   * @return string
   *   The unique string identifying the form.
   */
  public function getFormId() {
    return 'custom_community_folder_list';
  }

  /**
   * Form constructor.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $gid = \Drupal::request()->query->get('community_id');
    $term_name = 'cap_com_folder_' . $gid;
    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
      ->loadByProperties(['name' => $term_name, 'vid' => 'community_folders']);
    $group = Group::load($gid);
    if ($group instanceof GroupInterface) {
      $group_type = $group->get('field_community_type')->value;
      $term_id = !empty($term) ? array_keys($term) : NULL;
      $vid = 'community_folders';
      // The parent term id.
      $parent_tid = !empty($term_id[0]) ? $term_id[0] : NULL;
      // 1 to get only immediate children, NULL to load entire tree
      $depth = NULL;
      // True will return loaded entities rather than ids.
      $load_entities = FALSE;
      $child_terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid, $parent_tid, $depth, $load_entities);
    }

    $form['title']['#prefix'] = '<div><h2 class="h4">Community Folder List</h2>';
    $form['title']['#suffix'] = '</div>';

    $helpmarkup = '<p>You can drag folders to right or left to make them as child or parent folders. You can also drag up or down to re-order.</p><br />';
    $form['help'] = [
      '#type' => 'item',
      '#markup' => $helpmarkup,
    ];

    if (!empty($child_terms) && count($child_terms) > 0) {
      $form['table'] = [
        '#type' => 'table',
        '#header' => [t('Title'), t('Updated'), t('Operation'), ['data' => t('Operations'), 'colspan' => '1']],
        '#attributes' => [
          'id' => 'community-folder-table',
        ],
        '#tabledrag' => [
        [
          'action' => 'match',
          'relationship' => 'parent',
          'group' => 'folder-parent',
          'subgroup' => 'folder-parent',
          'source' => 'folder-id',
          'hidden' => FALSE,
          'limit' => 10,
        ],
        [
          'action' => 'order',
          'relationship' => 'sibling',
          'group' => 'folder-weight',
        ],
        ],
      ];

      foreach ($child_terms as $row => $child) {
        $form['table'][$row]['#weight'] = $child->weight;

        $prefix = '';
        $depthcount = $child->depth;

        $prefixtext = '<div class="js-indentation indentation">
        <svg xmlns="http://www.w3.org/2000/svg" class="tree" width="25" height="25" viewBox="0 0 25 25">
        <path class="tree__item tree__item-child-ltr tree__item-child-last-ltr tree__item-horizontal tree__item-horizontal-right" d="M12,12.5 H25" stroke="#888"></path>
        <path class="tree__item tree__item-child-rtl tree__item-child-last-rtl tree__item-horizontal tree__horizontal-left" d="M0,12.5 H13" stroke="#888"></path>
        <path class="tree__item tree__item-child-ltr tree__item-child-rtl tree__item-child-last-ltr tree__item-child-last-rtl tree__vertical tree__vertical-top" d="M12.5,12 v-99" stroke="#888"></path>
        <path class="tree__item tree__item-child-ltr tree__item-child-rtl tree__vertical tree__vertical-bottom" d="M12.5,12 v99" stroke="#888"></path>
        </svg>
        </div>';

        $prefix = str_repeat($prefixtext, $depthcount);

        $form['table'][$row]['title'] = [
          '#type' => 'item',
          '#markup' => str_replace(array('&amp;amp;', '&amp;'), '&', $child->name),
          '#prefix' => $prefix,
        ];

        $form['table'][$row]['created/updated'] = [
          '#type' => 'item',
          '#markup' => date('d M Y', $child->changed),
        ];

        $form['table'][$row]['edit'] = [
          '#type' => 'link',
          '#title' => t('Edit'),
          '#url' => Url::fromUserInput('/folderedit?community_id=' . $gid . '&folderterm=' . $child->tid),
          '#attributes' => ['class' => 'secondary-btn small add pull-right'],
        ];

        // Optionally, to add tableDrag support:
        $form['table'][$row]['#attributes']['class'][] = 'draggable';
        $titleName = str_replace(array('&amp;amp;', '&amp;'), '&', $child->name);
        $form['table'][$row]['weight'] = [
          '#type' => 'textfield',
          '#title' => t('Weight for @title', ['@title' => $titleName]),
          '#title_display' => 'invisible',
          '#size' => 4,
          '#default_value' => $child->weight,
          '#attributes' => ['class' => ['folder-weight']],
        ];

        $form['table'][$row]['id'] = [
          '#type' => 'hidden',
          '#value' => $child->tid,
          '#attributes' => ['class' => ['folder-id']],
        ];
        $form['table'][$row]['parent'] = [
          '#type' => 'hidden',
          '#default_value' => $child->parents['0'],
          '#attributes' => ['class' => ['folder-parent']],
        ];
      }

      // Show the save and cancel button only when there is more that one folder exist starts.
      if (count($child_terms) > 1) {

        $form['actions'] = [
          '#type' => 'actions',
        ];
        // Add a submit button that handles the submission of the form.
        $form['actions']['submit'] = [
          '#type' => 'submit',
          '#value' => $this->t('Save'),
        ];
        $form['actions']['cancel'] = [
          '#type' => 'button',
          '#value' => $this->t('Cancel'),
        ];
      }
      // Show the save and cancel button only when there is more that one folder exist ends.
    }
    else {
      $form['table'] = [
        '#type' => 'table',
        '#header' => [t('Title'), t('Created/Updated'), t('Operation'), ['data' => t('Operations'), 'colspan' => '1']],
        '#empty' => t("No folders available."),
      ];
    }
    $markup = '<a id="addfolder" href="/folderform?community_id=' . $gid . '">Add Community Folder</a>';
    $form['description'] = [
      '#type' => 'item',
      '#markup' => $markup,
    ];

    return $form;
  }

  /**
   * FormStateInterface.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Here we process the form and do what needs to be done.
    // Show all form values as status message.
    $db = \Drupal::service('database');
    // $complete_form = &$form_state->getCompleteForm();
    $complete_form_table = $form_state->getValue('table');

    foreach ($complete_form_table as $table) {
      if (array_key_exists('id', $table)) {
        $tid = $table['id'];
        $parent = $table['parent'];
        $term = Term::load($tid);
        if (!empty($term)) {
          $term->parent = ['target_id' => $parent];
          $term->save();
        }
        $num_updated = $db->update('taxonomy_term_field_data')
          ->fields([
            'weight' => $table['weight'],
          ])
          ->condition('tid', $table['id'], '=')
          ->execute();
        \Drupal::messenger()->addStatus(t('Community Folders have been saved successfully.'));
      }
    }
  }

}
