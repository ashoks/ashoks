<?php

namespace Drupal\custom_community_folder\Form;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Formbase.
 */
class FolderForm extends FormBase {

  /**
   * Returns a unique string identifying the form.
   *
   * The returned ID should be a unique string that can be a valid PHP function
   * name, since it's used in hook implementation names such as
   * hook_form_FORM_ID_alter().
   *
   * @return string
   *   The unique string identifying the form.
   */
  public function getFormId() {
    return 'custom_community_folder_form';
  }

  /**
   * Form constructor.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['description'] = [
      '#type' => 'item',
      '#markup' => $this->t('Add Folder'),
    ];
    $form['title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#description' => $this->t('Enter the name of the folder.'),
      '#required' => TRUE,
    ];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];

    $form['actions']['cancel'] = [
      '#type' => 'button',
      '#value' => $this->t('Cancel'),
      '#attributes' => array('onClick' => 'history.go(-1); event.preventDefault();'),
    ];

    return $form;

  }

  /**
   * FormStateInterface.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Here we process the form and do what needs to be done.
    // Show all form values as status message.
    try {
      foreach ($form_state->getValues() as $key => $value) {
        if ($key == 'title') {
          $error = 0;
          $gid = \Drupal::request()->query->get('community_id');
          $term_name = 'cap_com_folder_' . $gid;
          $vid = 'community_folders';
          $added_folder = $form_state->getValues();
          $term_name_new = Xss::filter($added_folder['title']);
          $term_name_new = html_entity_decode($term_name_new, ENT_QUOTES | ENT_HTML5, 'UTF-8');
         // $term_name_new = htmlspecialchars($term_name_new);
          $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(
            ['name' => $term_name, 'vid' => $vid]
          );
          $new_term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(
          ['name' => $term_name_new, 'vid' => $vid]
          );

          $term = reset($term);
          $new_term = reset($new_term);
          $curr_user_id = \Drupal::currentUser()->id();

          if ($term) {
            $parent = $term->id();
            $term_list = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid, $term->id(), 1);
            foreach ($term_list as $terms) {
              $child_terms[] = $terms->name;
            }
            if ($new_term) {
              $term_parents = $new_term->get('parent')->getValue();
              $term_parent = $term_parents[0]['target_id'];
              if (!empty($child_terms) && in_array($term_name_new, $child_terms)) {
                $error = 1;
                \Drupal::messenger()->addError(t('Folder already exists.'));
                break;
              }
              if (isset($term_parent) && $term_parent == $parent) {
                $error = 1;
                \Drupal::messenger()->addError(t('Folder already exists.'));
                break;
              }
              else {
                $new_term = Term::create(
                  ['name' => $term_name_new, 'vid' => $vid, 'parent' => $parent, 'field_community_folder_uid' => $curr_user_id]
                )->save();
              }
            }
            else {
              $new_term = Term::create(
                ['name' => $term_name_new, 'vid' => $vid, 'parent' => $parent, 'field_community_folder_uid' => $curr_user_id]
              )->save();
            }
            \Drupal::service('cache.render')->invalidateAll();
          }
          else {
            $created_term = Term::create(['name' => $term_name, 'vid' => $vid])->save();
            if ($created_term == 1) {
              $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(
              ['name' => $term_name, 'vid' => $vid]
              );
              $parent = array_key_first($term);
              // If (!$new_term) {.
              $new_term = Term::create(
                ['name' => $term_name_new, 'vid' => $vid, 'parent' => $parent, 'field_community_folder_uid' => $curr_user_id]
              )->save();
              // }
            }
            \Drupal::service('cache.render')->invalidateAll();
          }
          $redirect_to_folderList = new RedirectResponse(URL::fromUserInput('/folderlist?community_id=' . $gid)->toString());
          $redirect_to_folderList->send();
          \Drupal::messenger()->addStatus(t('The Folder "' . $term_name_new . '" has been created successfully.'));
        }
      }
    }
    catch (Exception $e) {
      // Generic exception handling if something else gets thrown.
      \Drupal::messenger()->addError(t('Error occurred while adding folder.'));
      \Drupal::logger('widget')->error($e->getMessage());
    }
  }

}
