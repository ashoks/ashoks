<?php

namespace Drupal\custom_statistics\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Controller\ControllerResolverInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Component\Utility\Xss;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupRelationshipInterface;
use Drupal\grequest\Plugin\GroupContentEnabler\GroupMembershipRequest;
use Drupal\group\Entity\GroupMembership;

/**
 * Manage Content Status Controller class.
 */
class StatisticsController extends ControllerBase {

  /**
   * Callback for changing the content status.
   */
  public function statistics($gid) {

    /*
    Community type Asset or Reference
     */
    $query = \Drupal::database()->select('group__field_community_type', 'gfdd');
    $query->addField('gfdd', 'field_community_type_value');
    $query->condition('gfdd.entity_id', $gid);
    $defaultDisplay = $query->execute()->fetchObject();
    $defaultDisplayValue = $defaultDisplay->field_community_type_value;


    /*
    Count No. for Asset
     */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->addExpression('COUNT(DISTINCT(n.`nid`))', 'totalnode');
      $query->fields('n', ['type']);
      $query->innerJoin('group_relationship_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
      $query->innerJoin('node', 'n', 'n.nid = gcfd.`entity_id`');
      $query->condition('n.type', ['asset'] , 'IN');
      $query->condition('gcfd.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('gcfd.gid', $gid);
      $query->condition('nfd.status', 1);
      $query->groupBy('gcfd.gid');
      $query->groupBy('n.type');
      $query->orderBy('gcfd.gid');
      $query->orderBy('n.type');
      $TotalCountQuery = $query->execute()->fetchobject();
      $noassetcount = '';
      if(!empty($TotalCountQuery)){ 
          $noassetcount = $TotalCountQuery->totalnode;
      }

      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.created),NOW())),1)', 'month');
      $query->condition('n.type', ['asset'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgcreationCount = $query->execute()->fetchobject();
      $avg_asset_created = '';
      if(!empty($KOavgcreationCount)){
          $avg_asset_created = $KOavgcreationCount->month;
      }

      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.changed),NOW())),1)', 'updatedmonth');
      $query->condition('n.type', ['asset'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgupdateCount = $query->execute()->fetchobject();
      $avg_asset_updated = '';
      if(!empty($KOavgupdateCount)){       
          $avg_asset_updated = $KOavgupdateCount->updatedmonth;
      }
      if (!empty($noassetcount)) {
        $assetCount = "Number of Assets: " . $noassetcount;
        $assetMonth = "Average age (based upon creation date): " . $avg_asset_created . " months";
        $assetUpdatedDate = "Average age (based upon update date): " . $avg_asset_updated . " months";
      }
    }

    /*
    Count No. for News , Pages, Events
     */
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->addExpression('COUNT(DISTINCT(n.`nid`))', 'totalnode');
      $query->fields('n', ['type']);
      $query->innerJoin('group_relationship_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
      $query->innerJoin('node', 'n', 'n.nid = gcfd.`entity_id`');
      $query->condition('n.type', ['news','pages','event'] , 'IN');
      $query->condition('gcfd.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('gcfd.gid', $gid);
      $query->condition('nfd.status', 1);
      $query->groupBy('gcfd.gid');
      $query->groupBy('n.type');
      $query->orderBy('gcfd.gid');
      $query->orderBy('n.type');
      $TotalCountQuery = $query->execute()->fetchAll();
      $nonewscount = '';
      $noeventcount = '';
      $nopagescount = '';
      if(!empty($TotalCountQuery)){
        foreach($TotalCountQuery as $key => $totalcount){       
          if($totalcount->type == 'news'){        
            $nonewscount = $totalcount->totalnode;
          }
          if($totalcount->type == 'event'){        
            $noeventcount = $totalcount->totalnode;
          }
          if($totalcount->type == 'pages'){        
            $nopagescount = $totalcount->totalnode;
          }
        }
      }
      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.created),NOW())),1)', 'month');
      $query->condition('n.type', ['news','pages','event'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgcreationCount = $query->execute()->fetchAll();
      $avgnewscreation = '';
      $avgeventcreation = '';
      $avgpagescreation = '';
      if(!empty($KOavgcreationCount)){
        foreach($KOavgcreationCount as $key => $kocount){       
        if($kocount->type == 'news'){        
          $avgnewscreation = $kocount->month;
        }
        if($kocount->type == 'event'){        
          $avgeventcreation = $kocount->month;
        }
        if($kocount->type == 'pages'){        
          $avgpagescreation = $kocount->month;
        }
       }
      }

      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.changed),NOW())),1)', 'updatedmonth');
      $query->condition('n.type', ['news','pages','event'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgupdateCount = $query->execute()->fetchAll();
      $avgassetupdate = '';
      $avgnewsupdate = '';
      $avgeventupdate = '';
      $avgpagesupdate = '';
      if(!empty($KOavgupdateCount)){
        foreach($KOavgupdateCount as $key => $kocount){      
        if($kocount->type == 'news'){        
          $avgnewsupdate = $kocount->updatedmonth;
        }
        if($kocount->type == 'event'){        
          $avgeventupdate = $kocount->updatedmonth;
        }
        if($kocount->type == 'pages'){        
          $avgpagesupdate = $kocount->updatedmonth;
        }
       }
      }
      if (!empty($nonewscount)) {
        $newsCount = "Number of News: " . $nonewscount;
        $newsMonth = "Average age (based upon creation date): " . $avgnewscreation . " months";
        $newsUpdatedDate = "Average age (based upon update date): " . $avgnewsupdate . " months";
      }
      if (!empty($noeventcount)) {
        $eventCount = "Number of Events: " . $noeventcount;
        $eventMonth = "Average age (based upon creation date): " . $avgeventcreation . " months";
        $eventUpdatedDate = "Average age (based upon update date): " . $avgeventupdate . " months";;
      }
      if (!empty($nopagescount)) {
        $pagesCount = "Number of Community Pages: " . $nopagescount;
        $pagesMonth = "Average age (based upon creation date): " . $avgpagescreation . " months";
        $pagesUpdatedDate = "Average age (based upon update date): " . $avgpagesupdate . " months";
      }
    
    /*
    Count No. for Reference
     */
    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->addExpression('COUNT(DISTINCT(n.`nid`))', 'totalnode');
      $query->fields('n', ['type']);
      $query->innerJoin('group_relationship_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
      $query->innerJoin('node', 'n', 'n.nid = gcfd.`entity_id`');
      $query->condition('n.type', ['reference'] , 'IN');
      $query->condition('gcfd.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('gcfd.gid', $gid);
      $query->condition('nfd.status', 1);
      $query->groupBy('gcfd.gid');
      $query->groupBy('n.type');
      $query->orderBy('gcfd.gid');
      $query->orderBy('n.type');
      $TotalCountQuery = $query->execute()->fetchobject();
      $norefcount = '';
      if(!empty($TotalCountQuery)){
          $norefcount = $TotalCountQuery->totalnode;
      }

      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.created),NOW())),1)', 'month');
      $query->condition('n.type', ['reference'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgcreationCount = $query->execute()->fetchobject();
      $avg_ref_created = '';
      if(!empty($KOavgcreationCount)){
          $avg_ref_created = $KOavgcreationCount->month;
      }

      $query = \Drupal::database()->select('node_field_data', 'n');
      $query->innerJoin('node__field_community', 'om', 'n.nid = om.entity_id');
      $query->fields('n', ['type']);
      $query->addExpression('ROUND(AVG(TIMESTAMPDIFF(MONTH,FROM_UNIXTIME(n.changed),NOW())),1)', 'updatedmonth');
      $query->condition('n.type', ['reference'] , 'IN');
      $query->condition('om.field_community_target_id', $gid);
      $query->groupBy('om.field_community_target_id');
      $query->groupBy('n.type');
      $query->orderBy('om.field_community_target_id');
      $query->orderBy('n.type');
      $KOavgupdateCount = $query->execute()->fetchobject();
      $avg_ref_updated = '';
      if(!empty($KOavgupdateCount)){    
          $avg_ref_updated = $KOavgupdateCount->updatedmonth;
      }

      if (!empty($norefcount)) {
        $referenceCount = "Number of Reference: " . $norefcount;
        $referenceMonth = "Average age (based upon creation date): " . $avg_ref_created . " months";
        $referenceUpdatedDate = "Average age (based upon update date): " . $avg_ref_updated . " months";
      }
    }

    /*
    Status Value Count
     */
    $allowedValues = [];
    $entityType = 'node';
    $fieldName = 'field_status';
    $bundle = 'asset';
    $live = '';
    $liveGold = '';
    $archived = '';

    $fields = \Drupal::service('entity_field.manager')->getFieldDefinitions($entityType, $bundle);
    if (array_key_exists($fieldName, $fields)) {
      /** @var \Drupal\field\Entity\FieldConfig $fieldConfig */
      $fieldConfig = $fields[$fieldName];
      $allowedValues = $fieldConfig->getSetting('allowed_values');
      $live = $allowedValues[0];
      $liveGold = $allowedValues[1];
      $archived = $allowedValues[2];
    }

    /* liveCount */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node__field_status', '');
      $query->addExpression('COUNT(node__field_status.field_status_value)', 'totalcount');
      $query->fields('node__field_status', array('field_status_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status.field_status_value', 0);
      $query->groupBy('node__field_community.field_community_target_id');
      $livestatusCount = $query->execute()->fetchObject();

      if (!empty($livestatusCount) && $livestatusCount->field_status_value == 0) {
        $liveCount =  "Total Number of Assets \"" .$live. "\": " . $livestatusCount->totalcount;
      }
    }

    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node__field_status_rf', '');
      $query->addExpression('COUNT(node__field_status_rf.field_status_rf_value)', 'totalcount');
      $query->fields('node__field_status_rf', array('field_status_rf_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status_rf.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status_rf.field_status_rf_value', 0);
      $query->groupBy('node__field_community.field_community_target_id');
      $livestatusCount = $query->execute()->fetchObject();

      if (!empty($livestatusCount) && $livestatusCount->field_status_rf_value == 0) {
        $liveCount = "Total Number of References \"" .$live . "\": " . $livestatusCount->totalcount;
      }
    }

    /* liveGoldCount */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node__field_status', '');
      $query->addExpression('COUNT(node__field_status.field_status_value)', 'totalcount');
      $query->fields('node__field_status', array('field_status_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status.field_status_value', 1);
      $query->groupBy('node__field_community.field_community_target_id');
      $liveGoldstatusCount = $query->execute()->fetchObject();

      if (!empty($liveGoldstatusCount) && $liveGoldstatusCount->field_status_value == 1) {
        $liveGoldCount = "Total Number of Assets \"" . $liveGold . "\": " . $liveGoldstatusCount->totalcount;
      }
    }

    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node__field_status_rf', '');
      $query->addExpression('COUNT(node__field_status_rf.field_status_rf_value)', 'totalcount');
      $query->fields('node__field_status_rf', array('field_status_rf_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status_rf.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status_rf.field_status_rf_value', 1);
      $query->groupBy('node__field_community.field_community_target_id');
      $liveGoldstatusCount = $query->execute()->fetchObject();

      if (!empty($liveGoldstatusCount) && $liveGoldstatusCount->field_status_rf_value == 1) {
        $liveGoldCount = "Total Number of References \"" .$liveGold . "\": " . $liveGoldstatusCount->totalcount;
      }
    }

    /* archivedCount */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node__field_status', '');
      $query->addExpression('COUNT(node__field_status.field_status_value)', 'totalcount');
      $query->fields('node__field_status', array('field_status_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status.field_status_value', 2);
      $query->groupBy('node__field_community.field_community_target_id');
      $archivedstatusCount = $query->execute()->fetchObject();
  
      if (!empty($archivedstatusCount) && $archivedstatusCount->field_status_value == 2) {
        $archivedCount = "Total Number of Assets \"" .$archived . "\": " . $archivedstatusCount->totalcount;
      }
    }

    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node__field_status_rf', '');
      $query->addExpression('COUNT(node__field_status_rf.field_status_rf_value)', 'totalcount');
      $query->fields('node__field_status_rf', array('field_status_rf_value'));
      $query->innerJoin('node__field_community', '', 'node__field_status_rf.entity_id = node__field_community.entity_id');
      $query->condition('node__field_community.field_community_target_id', $gid);
      $query->condition('node__field_status_rf.field_status_rf_value', 2);
      $query->groupBy('node__field_community.field_community_target_id');
      $archivedstatusCount = $query->execute()->fetchObject();

      if (!empty($archivedstatusCount) && $archivedstatusCount->field_status_rf_value == 2) {
        $archivedCount = "Total Number of References \"" .$archived . "\": " . $archivedstatusCount->totalcount;
      }
    }

    $assetfiletcount = 0;
    $reffiletcount = 0;
    /*
    Total Number of Asset File count
     */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(distinct(ff.field_files_target_id))', 'totalFiles');
      $query->join('paragraph__field_attachment', 'fa', 'ff.field_files_target_id = fa.entity_id');
      $query->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
      $query->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $gid);
      $query->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('pd.field_type_of_document_value', 0);
      $query->condition('ff.bundle', ['asset'] , 'IN');
      $query->groupBy('o.gid');
      $assetFile = $query->execute()->fetchObject();

      if (!empty($assetFile)) {
        $assetFileCount = "Total Number of Files for Assets: " . $assetFile->totalFiles;
        $assetfiletcount = $assetFile->totalFiles;
      }
    }
    /*
    Total Number of Reference File count
     */
    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(distinct(ff.field_files_target_id))', 'totalFiles');
      $query->join('paragraph__field_attachment', 'fa', 'ff.field_files_target_id = fa.entity_id');
      $query->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
      $query->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $gid);
      $query->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('pd.field_type_of_document_value', 0);
      $query->condition('ff.bundle', ['reference'] , 'IN');
      $query->groupBy('o.gid');
      $referenceFile = $query->execute()->fetchObject();

      if (!empty($referenceFile)) {
        $referenceFileCount = "Total Number of Files for Reference: " . $referenceFile->totalFiles;
        $reffiletcount = $referenceFile->totalFiles;
      }
    }
    $newsfiletcount = 0;
    $pagesfiletcount = 0;
    $eventsfiletcount = 0;

    /*
    Total Number of News, Pages, Events File count
     */
    $query = \Drupal::database()->select('node__field_content_files', 'ff');
    $query->addExpression('count(distinct(ff.field_content_files_target_id))', 'ctotalFiles');
    $query->fields('ff', ['bundle']);
    $query->join('paragraph__field_attachment', 'fa', 'ff.field_content_files_target_id = fa.entity_id');
    $query->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
    $query->condition('o.gid', $gid);
    $query->condition('ff.bundle', ['news','pages','event'] , 'IN');
    $query->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
    $query->groupBy('o.gid');
    $query->groupBy('ff.bundle');
    $query->orderBy('o.gid');
    $query->orderBy('ff.bundle');
    $comm_pages_file = $query->execute()->fetchAll();
    $newsfcount = '';
    $eventfcount = '';
    $pagesfcount = '';
    if(!empty($comm_pages_file)){
      foreach($comm_pages_file as $key => $kocount){      
      if($kocount->bundle == 'news'){        
        $newsfcount = $kocount->ctotalFiles;
      }
      if($kocount->bundle == 'pages'){        
        $pagesfcount = $kocount->ctotalFiles;
      }
      if($kocount->bundle == 'event'){        
        $eventfcount = $kocount->ctotalFiles;
      }
     }
    }
    if (!empty($newsfcount)) {
      $newsFileCount = "Total Number of Files for News: " . $newsfcount;
      $newsfiletcount = $newsfcount;
    }

    if (!empty($pagesfcount)) {
      $pagesFileCount = "Total Number of Files for Community Pages: " . $pagesfcount;
      $pagesfiletcount = $pagesfcount;
    }
    
    if (!empty($eventfcount)) {
      $eventsFileCount = "Total Number of Files for Events: " . $eventfcount;
      $eventsfiletcount = $eventfcount;
    }
    

    $totalNumberOfFile = $assetfiletcount + $reffiletcount + $newsfiletcount + $pagesfiletcount + $eventsfiletcount;

    $assetlnkcount = 0;
    $reflnkcount = 0;
    /* Total No. of asset link count */
    if ($defaultDisplayValue == '0') {
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(distinct(fa.field_link_uri))', 'totalFiles');
      $query->join('paragraph__field_link', 'fa', 'ff.field_files_target_id = fa.entity_id');
      $query->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
      $query->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $gid);
      $query->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('pd.field_type_of_document_value', 1);
      $query->condition('ff.bundle', ['asset'] , 'IN');
      $query->groupBy('o.gid');
      $assetLinkCount = $query->execute()->fetchObject();

      if (!empty($assetLinkCount)) {
        $assetLink = "Total Number of Links for Assets: " . $assetLinkCount->totalFiles;
        $assetlnkcount = $assetLinkCount->totalFiles;
      }
    }
    /* Total No. of reference link count */
    if ($defaultDisplayValue == '3') {
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(distinct(fa.field_link_uri))', 'totalFiles');
      $query->join('paragraph__field_link', 'fa', 'ff.field_files_target_id = fa.entity_id');
      $query->join('paragraph__field_type_of_document', 'pd', 'ff.field_files_target_id = pd.entity_id');
      $query->join('group_relationship_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $gid);
      $query->condition('o.plugin_id', '%group_membership%' , 'NOT LIKE');
      $query->condition('pd.field_type_of_document_value', 1);
      $query->condition('ff.bundle', ['reference'] , 'IN');
      $query->groupBy('o.gid');
      $referenceLinkCount = $query->execute()->fetchObject();

      if (!empty($referenceLinkCount)) {
        $referenceLink = "Total Number of Links for Reference: " . $referenceLinkCount->totalFiles;
        $reflnkcount = $referenceLinkCount->totalFiles;
      }
    }

    $totalNumberOfLink = $assetlnkcount + $reflnkcount;

    $gidMember = Group::load($gid);
    $grp_membership_service = \Drupal::service('group.membership_loader');
    $grp_membership = $grp_membership_service->loadByGroup($gidMember);
    $memberCount = count($grp_membership);
    return [
      '#theme' => 'statistics_template',
      '#assetCount' => $assetCount,
      '#eventCount' => $eventCount,
      '#newsCount' => $newsCount ,
      '#referenceCount' => $referenceCount,
      '#pagesCount' => $pagesCount,
      "#assetMonth" => $assetMonth,
      "#newsMonth" => $newsMonth,
      "#referenceMonth" => $referenceMonth,
      '#pagesMonth' => $pagesMonth,
      "#eventMonth" => $eventMonth,
      "#memberCount" => $memberCount,
      "#assetUpdatedDate" => $assetUpdatedDate,
      "#newsUpdatedDate" => $newsUpdatedDate,
      "#referenceUpdatedDate" => $referenceUpdatedDate,
      '#pagesUpdatedDate' => $pagesUpdatedDate,
      "#eventUpdatedDate" => $eventUpdatedDate,
      "#live" => $liveCount,
      "#liveGold" => $liveGoldCount,
      "#archived" => $archivedCount,
      "#newsFileCount" => $newsFileCount,
      "#assetFileCount" => $assetFileCount,
      "#referenceFileCount" => $referenceFileCount,
      "#pagesFileCount" => $pagesFileCount,
      "#eventsFileCount" => $eventsFileCount,
      '#newsLink' => $newsLink,
      '#assetLink' => $assetLink,
      '#referenceLink' => $referenceLink,
      '#pagesLink' => $pagesLink,
      '#totalNumberOfFile' => $totalNumberOfFile,
      '#totalNumberOfLink' => $totalNumberOfLink,
    ];
  }

}
