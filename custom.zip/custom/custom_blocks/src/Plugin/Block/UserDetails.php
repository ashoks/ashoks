<?php

namespace Drupal\custom_blocks\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;

/**
 * Provides the UtilityLinks block.
 *
 * @Block(
 *   id = "custom_blocks_user_profile_details",
 *   admin_label = @Translation("User Profile Details")
 * )
 */
class UserDetails extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $path = \Drupal::request()->getpathInfo();
    // $arg  = explode('/',$path);
    $user = NULL;
    $uid = NULL;
    if (\Drupal::currentUser()->isAuthenticated()) {
      $userId = \Drupal::currentUser()->id();
      $access_restricted = 0;
      $str = $_SERVER['REQUEST_URI'];
      $variable = explode("/", $str);
      if (isset($variable[2])) {
        $uid = $variable[2];
        $user = User::load($uid);
      }
      else {
        $uid = $userId;
        $user = \Drupal::entityTypeManager()->getStorage('user')->load($userId);
      }
      $userImage = ($user->get('user_picture')->entity) ? $user->get('user_picture')->entity->uri->value : NULL;
      $firstName = ($user) ? $user->get('field_name_first')->getValue()[0]['value'] : NULL;
      $secondName = ($user) ? $user->get('field_name_last')->getValue()[0]['value'] : NULL;
      $displayName = $firstName . ' ' . strtoupper($secondName);

      if ($userImage) {
        $userImage = $user->get('user_picture')->entity->uri->value;
      }
      else {
        $userImage = '/themes/custom/capgemini_b5/images/default img.svg';
      }
      $profile_picture = $userImage;
      if ($user) {
        $baselocation = (!empty($user->get('field_base_location')->getValue()[0])) ? $user->get('field_base_location')->getValue()[0]['value'] : '';
        // $email = \Drupal::currentUser()->getEmail();
        $email = $user->get('mail')->getValue()[0]['value'];
        $sbu = isset($user->field_entity_sbu->entity) ? $user->field_entity_sbu->entity->name->value : '';

      }
      $current_user_roles = \Drupal::currentUser()->getRoles();
      if ($uid != $userId && !in_array('administrator', $current_user_roles)) {
        $access_restricted = 1;
      }
      $urlPath = "/user/" . $uid . "/profile";
      $editUrl = "/user/" . $uid . "/edit";
      $urlasset = "/user/" . $uid . "/assets";
      $urlref = "/user/" . $uid . "/references";
      $urlnews = "/user/" . $uid . "/news";
      $urlevents = "/user/" . $uid . "/events";
      $urlpendinginvitations = "/user/" . $uid . "/community-invites/all";
      $urlpendingrequests = "/user/" . $uid . "/pending-request/all";
      $data = [
        'uid' => $uid,
        'profile_picture' => $profile_picture,
        'email' => $email,
        'baseLocation' => $baselocation,
        'sbu' => $sbu,
        'urlPath' => $urlPath,
        'displayName' => $displayName,
        'currentUser' => $userId,
        'editUrl' => $editUrl,
        'urlasset' => $urlasset,
        'urlref' => $urlref,
        'urlnews' => $urlnews,
        'urlevents' => $urlevents,
        'urlpendinginvitations' => $urlpendinginvitations,
        'urlpendingrequests' => $urlpendingrequests,
        'accessRestricted' => $access_restricted,
      ];
    }
    else {
      $data = [];
    }
    return [
      '#theme' => 'userprofiledetail',
      '#data' => $data,
    ];
  }

  /**
   * Get CacheMaxAge.
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
