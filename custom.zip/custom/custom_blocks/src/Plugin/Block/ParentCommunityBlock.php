<?php

namespace Drupal\custom_blocks\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\user\Entity\User;

/**
 * Parent communities block.
 *
 * @Block(
 *   id = "parent_communities_block",
 *   admin_label = "Parent Community Block"
 * )
 */
class ParentCommunityBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $parameters = \Drupal::routeMatch()->getParameters()->all();
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
      if ($group instanceof GroupInterface) {
        $gid = $group->id();
      }
    }
    else {
      $group = \Drupal::routeMatch()->getParameter('group');
      if ($group instanceof GroupInterface) {
        /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
      }
    }
    if (empty($gid)) {
      $nid = \Drupal::routeMatch()->getRawParameter('node');
      $node = ($nid)?Node::load($nid):null;
      $groupSocialId = ($node) ? $node->get('field_community')->getValue()[0]['target_id'] : "";
      if ($groupSocialId) {
        $group = Group::load($groupSocialId);
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
      }
    }
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name == 'node.add') {
      $gid = \Drupal::request()->get('community_id');
    }
    if($route_name == "view.taxonomy_term_entity_reference_listing.page_1"){
      if(strpos(\Drupal::request()->getRequestUri(), '/global-taxonomy') !== false){
        $current_uri = \Drupal::request()->getRequestUri();
        $group_display_path = explode("/",$current_uri);
        $gid = $group_display_path[3];
      }
    }
    elseif($route_name == "view.taxonomy_term_entity_reference_listing.page_2"){
      if(strpos(\Drupal::request()->getRequestUri(), '/community-tag-clouds') !== false){
        $current_uri = \Drupal::request()->getRequestUri();
        $group_display_path = explode("/",$current_uri);
        $gid = $group_display_path[3];
      }
    }
    $parentcomm_check = '';
    if (isset($gid)) {
      $group = Group::load($gid);
    }
    $parent_gid = NULL;
    $parent_name = NULL;
    $parent_group = NULL;
    if ($group instanceof GroupInterface) {
      if (isset($group->get('field_og_group_ref')->getValue()[0]['target_id'])) {
        $parent_gid = $group->get('field_og_group_ref')->getValue()[0]['target_id'];
      }
      if ($parent_gid) {
        $parentcomm_check = 1;
        $parent_group = Group::load($parent_gid);
        $parent_name = ($parent_group instanceof GroupInterface)?$parent_group->get('label')->getValue()[0]['value']:null;
      }
    }
    $data = [];
    $data['parent_gid'] = (($parent_group instanceof GroupInterface) && $parent_group->isPublished())? $parent_gid: null;
    $data['parent_name'] = $parent_name;
    if ($parentcomm_check == 1) {
      return [
        '#theme' => 'parent_community_block',
        '#data' => $data,
        '#parentcommcheck' => $parentcomm_check,
        '#cache' => [
          'max-age' => 0,
        ],
      ];
    }
    else {
      return [];
    }
  }

  /**
   * Get CacheMaxAge.
   *
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
