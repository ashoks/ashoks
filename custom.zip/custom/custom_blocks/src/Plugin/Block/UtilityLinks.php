<?php

namespace Drupal\custom_blocks\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides the UtilityLinks block.
 *
 * @Block(
 *   id = "custom_blocks_utility_links",
 *   admin_label = @Translation("Utility Links")
 * )
 */
class UtilityLinks extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $cart_num = count($_SESSION['reference_cart']);
    $link_array = [
      0 => [
        // 'is_active' => 'active',
        'label' => 'Notification',
        'url' => '/notofication',
        'class' => '',
      ],
      1 => [
       // 'is_active' => 'inactive',
        'label' => 'Cart',
        'url' => '/view-cart',
        'class' => 'view-reference-cart',
        'total_cart' => $cart_num,
      ],
    ];

    return [
      '#theme' => 'utilitylinks',
      '#tabs' => $link_array,
    ];
  }

  /**
   * Get CacheMaxAge.
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
