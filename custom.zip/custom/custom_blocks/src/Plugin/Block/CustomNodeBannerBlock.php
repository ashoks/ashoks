<?php

namespace Drupal\custom_blocks\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\NodeInterface;

/**
 * Provides the NodeBannerBlock block.
 *
 * @Block(
 *   id = "custom_blocks_node_banner_block",
 *   admin_label = @Translation("Node Banner Block")
 * )
 */
class CustomNodeBannerBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node && $node instanceof NodeInterface) {
      $community_id = isset($node) && !empty($node->get('field_community')->getValue()[0]['target_id']) ? $node->get('field_community')->getValue()[0]['target_id'] : NULL;
      $submitter = isset($node) && !empty($node->get('field_author')[0]->getValue()['target_id']) ? $node->get('field_author')[0]->getValue()['target_id'] : NULL;
      $group = Group::load($community_id);
      $membership = ($group) ? $group->getMember(\Drupal::currentUser()) : NULL;
      $group_rl = isset($membership) && !empty($membership) ? $membership->getGroupRelationship()->get('group_roles')->getValue() : NULL;
      if (isset($group_rl) && !empty($group_rl)) {
        $user_role_in_group_roles = array_column($group_rl, 'target_id');
        $group_type = ($group) ? $group->getGroupType()->id() : NULL;
        $acctRole = \Drupal::currentUser()->getRoles();
        $current_usr = \Drupal::currentUser()->id();
        if (in_array('administrator', $acctRole)) {
          $admin_role = 1;
        }

        if ($current_usr == $submitter) {
          $customowner = 1;
        }
        if (in_array($group_type . '-group_manager', $user_role_in_group_roles) || in_array($group_type . '-moderator', $user_role_in_group_roles)) {
          $other_role = 2;
        }
        elseif (in_array($group_type . '-group_manager', $user_role_in_group_roles) && in_array($group_type . '-group_admin', $user_role_in_group_roles) || in_array($group_type . '-moderator', $user_role_in_group_roles) && in_array($group_type . '-group_admin', $user_role_in_group_roles)) {
          $other_role = 2;
        }
      }
      if ($customowner == '1') {
        $edit_data = '<a href="/node/' . $node->id() . '/edit" class="d-flex align-items-center" title="Edit">
	 <i class="material-symbols-outlined md-4">edit</i></a>';
      }
      elseif ($admin_role == '1') {
        $edit_data = '<a href="/node/' . $node->id() . '/edit" class="d-flex align-items-center" title="Edit">
	 <i class="material-symbols-outlined md-4">edit</i></a>';
      }
      elseif ($other_role == '2') {
        $edit_data = '<a href="/node/' . $node->id() . '/edit" class="d-flex align-items-center" title="Edit">
	<i class="material-symbols-outlined md-4">edit</i></a>';
      }
      else {
        $edit_data = '';
      }

      $nid = $node->id();
    }

    $data = [
      'node_title' => $node->getTitle(),
      'node_edit_url' => $edit_data,
      'node_revision_url' => '/node/' . $nid . '/revisions',
    ];

    return [
      '#markup' => '<div id="koListContainner" class="">
			<div class="d-flex flex-column gap-3">
			<div class="d-flex flex-row gap-3 ko-created">
			<div class="p-3 d-flex flex-row flex-fill gap-3">
				<div class="d-flex flex-column flex-fill gap-3">
					<h4 class="h4 mb-0">' . $data["node_title"] . '</h4>
				</div>
			</div>
			<div class="ps-button d-flex flex-column p-3 gap-3 bg-accent-aqua-subtle">
				' . $data["node_edit_url"] . '
				<a href="' . $data["node_revision_url"] . '" class="d-flex align-items-center" title="Revision">
					<i class="material-symbols-outlined md-4">update</i>
				</a>
			</div>
		</div>
		</div>
		</div>',
    ];

  }

  /**
   * Get CacheMaxAge.
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
