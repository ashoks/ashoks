<?php

namespace Drupal\custom_blocks\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implements a Config Form API.
 */
class NoticeMessageForm extends ConfigFormBase {

  /**
   * Get FormID.
   *
   * @return string
   */
  public function getFormId() {
    return 'set_notice_form_api_admin_settings';
  }

  /**
   * Gets the configuration names that will be editable.
   *
   * @return array
   *   An array of configuration object names that are editable if called in
   *   conjunction with the trait's config() method.
   */
  protected function getEditableConfigNames() {
    return [
      'noticemessage_form_api.settings',
    ];
  }

  /**
   * Build form.
   *
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *
   * @return array
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('noticemessage_form_api.settings');

    $form['notice_message'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Scorller message'),
      '#description' => $this->t('Enter Scorller message'),
      '#default_value' => $config->get('notice_message'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * Submit form.
   *
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $config = $this->config('noticemessage_form_api.settings');
    $config->set('notice_message', $form_state->getValue('notice_message'))->save();
    \Drupal::messenger()->addStatus("Settings updated");

  }

}
