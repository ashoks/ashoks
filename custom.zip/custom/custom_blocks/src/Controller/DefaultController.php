<?php

namespace Drupal\custom_blocks\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;

/**
 * Default controller for the custom_blocks module.
 */
class DefaultController extends ControllerBase {

  /**
   * Function to load Custom Yammer Page.
   */
  public function custom_yammer_page() {
    $data = [];
    $parameters = \Drupal::routeMatch()->getParameters()->all();
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
      $data['FeedType'] = 'group';
      if ($group instanceof Group) {
        $gid = $group->id();
        $group_type = $group->getGroupType()->id();
        if ($gid == 1) {
          $data['FeedID'] = "all";
        }
        else {
          $field_feeds_yammer_groups = $group->get('field_feeds_yammer_groups')->value;
          if (isset($field_feeds_yammer_groups)) {
            if (is_numeric(trim($field_feeds_yammer_groups))) {
              $data['FeedID'] = $field_feeds_yammer_groups;
            }
            else {
              $yammers = explode(',', $field_feeds_yammer_groups);
              $data['FeedID'] = $yammers[0];
            }
          }
        }
      }
    }
    return [
      '#theme' => 'yammer_display_page',
      '#data' => $data,
    ];
  }

}
