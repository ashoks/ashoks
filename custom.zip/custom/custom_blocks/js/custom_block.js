(function ($) {
  Drupal.behaviors.ajax_example = {
    attach: function (context) {
      if ($("#cart_error_message").length) {
        $("#cart_error_message").remove();
      }
      $("#cart_error_message").html("");
      $("#cart_error_message").css("display", "none !important");

      // these code block we may remove once testing is complete

      $("a.add-to-cart-btn_removed").live("click", function () {
        $("#cart_error_message").html("");
        $("#cart_error_message").css("display", "none !important");
        var total_count = $("li.view-reference-cart a .unread-message").html();
        if (parseInt(total_count) < 200) {
          var ref_id = $(this).attr("rel");
          var fid = $(this).attr("fid");
          console.log(ref_id);
          console.log(fid);

          /*            $('article#node-' + ref_id + ' nav ul li span#add-to-cart-' + ref_id).html('<a href="javascript:void(0)" class="action-item-small" rel="' + ref_id + '">Add to Cart</a>');
            $('article#node-' + ref_id + ' nav ul li span#add-to-cart-' + ref_id).attr('class', 'flag-waiting');*/
          $.ajax({
            type: "POST",
            url: Drupal.settings.basePath + "add-to-cart",
            data: { ref_id: ref_id, fid: fid },
            success: function (data) {
              /*                $('article#node-' + ref_id + ' nav ul li span#add-to-cart-' + ref_id).removeClass('flag-waiting');
                $('article#node-' + ref_id + ' nav ul li span#add-to-cart-' + ref_id).attr("id","remove-from-cart-"+ ref_id);*/
              //console.log(fid);
              if (fid) {
                var nfid = parseInt(fid);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).removeClass("flag-waiting");
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).attr("id", "remove-from-cart-" + ref_id + "-" + nfid);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#remove-from-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).html(
                  '<a href="/remove-from-cart/' + ref_id + '" class="action-item remove-from-cart-btn use-ajax" rel="' +
                  ref_id +
                  '" fid="' +
                  fid +
                  '"' +
                  "><button class='btn-ghost d-flex align-items-center gap-1 font12'><span class='material-symbols-outlined md-4'>shopping_cart</span>Remove from Cart</button></a>"
                );
              } else {
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id
                ).removeClass("flag-waiting");
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id
                ).attr("id", "remove-from-cart-" + ref_id);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#remove-from-cart-" +
                  ref_id
                ).html(
                  '<a href="/remove-from-cart/' + ref_id + '" class="action-item remove-from-cart-btn use-ajax" rel="' +
                  ref_id +
                  '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
                );
              }
              $("li.view-reference-cart a .unread-message").html(
                data.total_cart
              );
            },
          });
        } else {
          if (!$("#cart_error_message").length) {
            $("#page-top").before("<div id='cart_error_message'></div>");
          }
          $("#cart_error_message").addClass("messages error");
          $("#cart_error_message").css("display", "block !important");
          $("#cart_error_message").append(
            '<ul><li class="message-item">There is a limit of 200 items in the cart at one time. Please refine your search (to reduce number of items to add in the cart), or extract then clear your cart to add new items.</li></ul>'
          );
        }
      });

      $("a.remove-from-cart-btn").live("click", function () {
        var ref_id = $(this).attr("rel");
        var fid = $(this).attr("fid");
        $("#cart_error_message").remove();
        $(
          "article#node-" +
          ref_id +
          " nav ul li span span#remove-from-cart-" +
          ref_id
        ).html(
          '<a href="/remove-from-cart/' + ref_id + '" class="action-item-small use-ajax" rel="' +
          ref_id +
          '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
        );
        $(
          "article#node-" +
          ref_id +
          " nav ul li span span#remove-from-cart-" +
          ref_id
        ).attr("class", "flag-waiting");
        $.ajax({
          type: "POST",
          url: Drupal.settings.basePath + "remove-from-cart",
          data: { ref_id: ref_id, fid: fid },
          success: function (data) {
            var url = $(location).attr("href");
            var url_split = url.split("/");
            var split_res = $.inArray("view-cart", url_split);
            if (split_res > 0) {
              $("article#node-" + ref_id)
                .parent()
                .remove();
            } else {
              $(
                "article#node-" +
                ref_id +
                " nav ul li span#remove-from-cart-" +
                ref_id
              ).attr("id", "add-to-cart-" + ref_id);
              $(
                "article#node-" +
                ref_id +
                " nav ul li span#add-to-cart-" +
                ref_id
              ).attr("class", "flag-wrapper");
              if (fid) {
                var nfid = parseInt(fid);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#remove-from-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).attr("id", "add-to-cart-" + ref_id + "-" + nfid);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).attr("class", "flag-wrapper");
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id +
                  "-" +
                  nfid
                ).html(
                  '<a href="/add-to-cart/' + ref_id + '" class="action-item add-to-cart-btn use-ajax" rel="' +
                  ref_id +
                  '" fid="' +
                  fid +
                  '"' +
                  "><div class='action-group btn-ghost d-flex align-items-center gap-1 font12'><span class='material-symbols-outlined md-4'>shopping_cart</span>Add to Cart</div></a>"
                );
              } else {
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#remove-from-cart-" +
                  ref_id
                ).attr("id", "add-to-cart-" + ref_id);
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id
                ).attr("class", "flag-wrapper");
                $(
                  "article#node-" +
                  ref_id +
                  " nav ul li span#add-to-cart-" +
                  ref_id
                ).html(
                  '<a href="/add-to-cart/' + ref_id + '" class="action-item add-to-cart-btn use-ajax" rel="' +
                  ref_id +
                  '"><div class="action-group btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Add to Cart</div></a>'
                );
              }
            }
            $("li.view-reference-cart a .unread-message").html(data.total_cart);
            $("p#car-num").html(data.cart_num + " selected items");
            if ($(".node.node-teaser").length <= 0) {
              $("p#car-num").html("Your Cart is empty");
              $("#attach-references-opp").remove();
              $("#attach-ishowcase-opp").remove();
              $("#export-references-cart").remove();
              $("#clear-cart").remove();
            }
          },
        });
      });

      $("#clear-cart").click(function () {
        window.location.href =
          Drupal.settings.basePath + "clear-cart-confirm";
      });

      $("#attach-references-opp").click(function () {
        var communities_list_form = jQuery("#entering-oppid-popup");
        if (communities_list_form.length) {
          $.colorbox({
            inline: TRUE,
            href: "#entering-oppid-popup",
            closeButton: FALSE,
            overlayClose: TRUE,
            escKey: TRUE,
            innerHeight: 135,
          });
        }
      });

      $("#attach-ishowcase-opp").click(function () {
        var communities_list_form = jQuery("#entering-ishowcase-popup");
        if (communities_list_form.length) {
          $.colorbox({
            inline: TRUE,
            href: "#entering-ishowcase-popup",
            closeButton: FALSE,
            overlayClose: TRUE,
            escKey: TRUE,
            innerHeight: 230,
          });
        }
      });
      //KM3-iShowCase

      // Add all to cart function
      $("a.cart-btn")
        .off()
        .on("click", function () {
          $("#cart_error_message").html("");
          $("#cart_error_message").css("display", "none !important");
          var total_count = $(
            "li.view-reference-cart a .unread-message"
          ).html();
          /*alert(total_count);
        return false;*/
          if (!$("#cart_error_message").length) {
            $("#page-top").before("<div id='cart_error_message'></div>");
          }

          if (parseInt(total_count) < 200) {
            //var ref_id = $(this).attr('rel');
            var ref_id = $(this).attr("rel") ? $(this).attr("rel") : ",";
            var fid = $(this).attr("fid") ? $(this).attr("fid") : ",";

            $(".add_cart_wrap ul li span").attr("class", "flag-waiting");

            //if (ref_id.length > 0) {
            if (ref_id != "") {
              $.ajax({
                type: "POST",
                url: Drupal.settings.basePath + "add-all-to-cart",
                data: { ref_id: ref_id, fid: fid },
                success: function (data) {
                  var node = data.ref_id;
                  if (node.length > 0) {
                    $.each(node, function (index, ref_value) {
                      var node_id_split = ref_value.split("-");
                      var ref_value = node_id_split[0];
                      if (node_id_split.length == 1) {
                        $(
                          "article#node-" +
                          ref_value +
                          " nav ul li span#add-to-cart-" +
                          ref_value
                        ).attr("id", "remove-from-cart-" + ref_value);
                        $(
                          "article#node-" +
                          ref_value +
                          " nav ul li span#remove-from-cart-" +
                          ref_value
                        ).html(
                          '<a href="/remove-from-cart/' + ref_value + '" class="action-item remove-from-cart-btn use-ajax" rel="' +
                          ref_value +
                          '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
                        );
                      } else {
                        var nfid = parseInt(node_id_split[1]);
                        $(
                          "article#node-" +
                          ref_value +
                          " nav ul li span#add-to-cart-" +
                          ref_value +
                          "-" +
                          nfid
                        ).attr(
                          "id",
                          "remove-from-cart-" + ref_value + "-" + nfid
                        );
                        $(
                          "article#node-" +
                          ref_value +
                          " nav ul li span#remove-from-cart-" +
                          ref_value +
                          "-" +
                          nfid
                        ).html(
                          '<a href="/remove-from-cart/' + ref_value + '" class="action-item remove-from-cart-btn use-ajax" rel="' +
                          ref_value +
                          '" fid="' +
                          nfid +
                          '"' +
                          '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
                        );
                      }
                    });
                    $("li.view-reference-cart a .unread-message").html(
                      data.total_cart
                    );
                    $(".add_cart_wrap ul li span").attr(
                      "class",
                      "flag-wrapper"
                    );
                    if (!$("#cart_error_message").length) {
                      $("#page-top").before(
                        "<div id='cart_error_message'></div>"
                      );
                    }
                    $("#cart_error_message").addClass("messages status");
                    $("#cart_error_message").append(
                      '<ul><li class="message-item">' +
                      node.length +
                      " items have been added to your Cart</li></ul>"
                    );
                  } else {
                    $(".add_cart_wrap ul li span").attr(
                      "class",
                      "flag-wrapper"
                    );
                    if (!$("#cart_error_message").length) {
                      $("#page-top").before(
                        "<div id='cart_error_message'></div>"
                      );
                    }
                    $("#cart_error_message").addClass("messages status");
                    $("#cart_error_message").append(
                      '<ul><li class="message-item">0 items have been added to your Cart</li></ul>'
                    );
                  }
                },
              });
            } else {
              $("#cart_error_message").addClass("messages status");
              $("#cart_error_message").append(
                '<ul><li class="message-item">0 items have been added to your Cart</li></ul>'
              );
            } // Non emnpty string
          } // End of total count condition
          else {
            $("#cart_error_message").addClass("messages error");
            $("#cart_error_message").css("display", "block !important");
            $("#cart_error_message").append(
              '<ul><li class="message-item">There is a limit of 200 items in the cart at one time. Please refine your search (to reduce number of items to add in the cart), or extract then clear your cart to add new items.</li></ul>'
            );
          }
          $(".add_cart_wrap ul li span").attr("class", "flag-wrapper");
          if (!$("#cart_error_message").length) {
            $("#page-top").before("<div id='cart_error_message'></div>");
          }
        });

      // Common user followers tabs
      var url = $(location).attr("href");
      var url_split = url.split("?");
      var split_res = $.inArray("qt-people=3", url_split);

      var url1 = $(location).attr("href");
      var url_split1 = url1.split("/");
      var split_res1 = $.inArray("followers", url_split1);
      if (split_res == 1 || split_res1 == 3) {
        $(".messages.error").html("");
        $(".messages.error").html(
          '<h2 class="element-invisible">warning message</h2>You must first select one (or more) followers before you can take that action.'
        );
        $(".messages.error").attr("id", "custom_message");
        //$('#custom_message').switchClass(".messages.error", ".messages.warning");
      }

      var button = $("#views-form-followers-page-1 .container-inline").html();
      //console.log(jar);
      $("#views-form-followers-page-1 .container-inline").remove();
      $("#views-form-followers-page-1 input[name='form_build_id']").addClass(
        "custom_follower_class"
      );
      $("#views-form-followers-page-1 input.custom_follower_class").before(
        "<div class='container-inline form-wrapper' id='edit-select'>" +
        button +
        "</div>"
      );

      var collection = $("#views-form-followers-page-1 .form-checkbox");
      collection.each(function () {
        if (
          $("#views-form-followers-page-1 .form-checkbox").not(":checked")
            .length
        ) {
          $(this).attr("title", "Select all rows in this table");
        }
      });
      // checkbox clicked and not clicked event

      $("#views-form-followers-page-1 .form-checkbox").each(function (index) {
        $(
          "#views-form-followers-page-1 #edit-views-bulk-operations-" + index
        ).hover(function () {
          //console.log('IValue '+index);
          var isChecked = $("#edit-views-bulk-operations-" + index).prop(
            "checked"
          );
          //console.log('Value '+isChecked);
          if (isChecked) {
            $(this).removeAttr("title");
          } else {
            $(this).attr("title", "Select all rows in this table");
          }
        });
      });
      // Select all checkbox
      $("#views-form-followers-page-1 .vbo-table-select-all").hover(
        function () {
          var isChecked = $(".vbo-table-select-all").prop("checked");
          //console.log('Value '+isChecked);
          if (isChecked) {
            $(this).removeAttr("title");
          } else {
            $(this).attr("title", "Select all rows in this table");
          }
        }
      );
    },
  };
})(jQuery);
