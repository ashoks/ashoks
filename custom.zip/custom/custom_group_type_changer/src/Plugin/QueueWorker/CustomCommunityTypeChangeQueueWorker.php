<?php

namespace Drupal\custom_group_type_changer\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\group\Entity\Group;
use Drupal\taxonomy\Entity\Term;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;
use Drupal\node\NodeInterface;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_group_type_changer_queue",
 *   title = @Translation("Custom Community Type Change Queue"),
 *   cron = {"time" = 60}
 * )
 */
class CustomCommunityTypeChangeQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
     custom_community_type_change($data['record'],$data['old_type'],$data['new_type'], $data['grp_label']);
  }
}



