(function ($, Drupal, drupalSettings) {
  // setTimeout(function () { triggerCount(); }, 1000);
  // Checking if autocomplete is plugged in.
  if (Drupal.autocomplete) {
    /**
     * Handles an autocompleteselect event.
     *
     * Override the autocomplete method to add a custom event.
     *
     * @param {jQuery.Event} event
     *   The event triggered.
     * @param {object} ui
     *   The jQuery UI settings object.
     *
     * @return {bool}
     *   Returns false to indicate the event status.
     */
    // Drupal.autocomplete.options.select = function selectHandler(event, ui) {
    //   var terms = Drupal.autocomplete.splitValues(event.target.value);
    //   // Remove the current input.
    //   terms.pop();
    //   // Add the selected item.
    //   if (ui.item.value.search(',') > 0) {
    //     terms.push('"' + ui.item.value + '"');
    //   }
    //   else {
    //     terms.push(ui.item.value);
    //   }

    //   event.target.value = terms.join(', ');
    //   event.target.value = terms.pop();
    //   // Fire custom event that other controllers can listen to.
    //   jQuery(event.target).trigger('field--name-groups .ui-autocomplete-input');
    //   // Return false to tell jQuery UI that we've filled in the value already.
    //   //jQuery(event.target).trigger('field--name-field-ecommunity .ui-autocomplete-input');
    //   return false;
    // };
  }

  var session_cart_value = drupalSettings.custom_cart.session_cart_value;
  // Code to get local timezone and sending it in cookie to use in theme file Starts
                 // var localeTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                 // document.cookie = 'session_local_timezone=' + localeTimezone;
  // Code to get local timezone and sending it in cookie to use in theme file Ends
// httpOnly Cookie Flag Not Set issue fixed for SAST Scan-start
 const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      sessionStorage.removeItem('timezoneSent');
      if (timezone && !sessionStorage.getItem('timezoneSent')) {
        $.ajax({
          url: '/set-timezone',
          method: 'POST',
          data: { timezone },
          success: function () {
            sessionStorage.setItem('timezoneSent', 'true');
          },
          error: function (xhr, status, error) {
            console.error('AJAX error:', status, error);
          }
        });
      }
// httpOnly Cookie Flag Not Set issue fixed for SAST Scan-end
  $.each(session_cart_value, function (index, value) {
    $("span#add-to-cart-" + value).html(
      '<a class="remove-from-cart-btn action-item-small secondary-btn use-ajax" href="/remove-from-cart/' + value + '"  rel="' +
      value +
      '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
    );

  });

  (function (Drupal, once) {
  Drupal.behaviors.exampleModule = {
    attach: function (context, settings) {

     /* if (window.location.pathname === "/node/add/reference") {
        $("body").addClass("page-create-reference");
      }*/
      // while save the rating will be show loading icon
     /* $('select[name="vote"]').once('exampleModule').on('change', function (event) {
        $('.fivestar-widget-5 .ajax-throbber').remove();
        $(this).next('.fivestar-widget-5').append('<span class="ajax-throbber glyphicon-spin icon glyphicon glyphicon-refresh loader-thobber"></span>');
        $(document).ajaxComplete(function (event, xhr, settings) {
        // Remove the loader once preview link is clicked
          $('.fivestar-widget-5 .ajax-throbber').remove();
        });
      });*/
      // Changes for 767859 starts
     /* $('select[id="edit-users-fieldset-user"]').once('exampleModule').on('change', function (event) {
        var inputTextVal = $("#edit-users-fieldset-user").val();
        if (inputTextVal) {
          $('button[value="Send your invite(s) by email"]').prop("disabled", false);
        }
      });
      $('button[name="field_files_files_add_more"]').once('exampleModule').on('mousedown', function (event) {
        //  console.log("Name =========>>>>"+this.name);
        if (this.name == 'field_files_files_add_more') {
          // append the throbber
          $('.input-group').find('.glyphicon-refresh').removeClass('glyphicon-spin');
          $(this).append('<span class="ajax-throbber glyphicon-spin icon glyphicon glyphicon-refresh loader-thobber"></span>');
        }
      });
      $('button[value="Remove"]').once('exampleModule').on('mousedown', function (event) {
        $('.input-group').find('.glyphicon-refresh').removeClass('glyphicon-spin');
        if (this.name == 'field_files_files_add_more') {
          // append the throbber
          $('.input-group').find('.glyphicon-refresh').removeClass('glyphicon-spin');
          $(this).append('<span class="ajax-throbber glyphicon-spin icon glyphicon glyphicon-refresh loader-thobber"></span>');
        }
      });

      $('#views-exposed-form-mass-operation-page-group-manage-content input#edit-combine').once('exampleModule').on('click', function (event) {
        $(document).ajaxComplete(function (event, xhr, settings) {
          // Remove the loader once preview link is clicked
          $('.input-group-addon').find('.glyphicon-refresh').removeClass('glyphicon-spin');
        });
      });


      $('a#hidden_link_popup_div').hide();
      $("span.ui-dialog-title").remove();
      $("div.ui-dialog-titlebar").css("background-color", "#FFF");
      $(".ui-dialog:not(.ui-dialog-off-canvas)[role='dialog'] .ui-dialog-titlebar .ui-dialog-titlebar-close").css("background", "grey !important");
      $(document).ajaxComplete(function (event, xhr, settings) {
        if (event.currentTarget.activeElement.id === 'edit-preview') {
          $("#edit-preview").prop('disabled' ,true);
          setTimeout(function () { triggerPreview(); }, 0);
        }
      });


      $('div.reference-com-tax > span').each(function () {
        if ($(this).children().length == 0) {
          $(this).hide();
        }
      });

      $('div.news-com-tax > span').each(function () {
        if ($(this).children().length == 0) {
          $(this).hide();
        }
      });*/

      /*$('a#hidden_link_popup').once('exampleModule').on('click', function (event) {
        $(document).ajaxComplete(function (event, xhr, settings) {
          // Remove the loader once preview link is clicked
          $('#edit-preview .ajax-throbber').remove();
          setTimeout(function () { triggerPreviewLink(); }, 1000);
        });
      });*/

      // Changes for 767859 ends
      // $("[for=edit-field-asking-client-names-0-value]").append('<span class="form-required" title="This field is required">*</span>');
      // Deal Size on Page Load Starts
     /* var currency = $("#edit-field-currency").val();
      var contract_value = $("#edit-field-contract-value-0-value").val();

      if (((currency !== null || currency !== '') && currency !== "_none") && ((contract_value !== null || contract_value !== '') && contract_value > 0)) {
        setTimeout(function () { rerender_size_range_value(); }, 1000);
      } else {
        $("#edit-field-fake-deal-size-status").text("");
      }
      // Deal Size on Page Load Ends

      // Hide Organisers Menu from JS on Event Page
      $("a:contains('Organisers')").hide();
      $(".navbar a:contains('Details')").hide();
      // remove - delete -button starts

      var removeDeleteButton = $("button#edit-cancel").attr("rel");

      if (removeDeleteButton == "remove-delete-button") {
        $("a#edit-delete").remove();
      }*/

      // remove - delete -button ends

      // Remove tags field values
     // $("#edit-field-tags").val('');

      // Show hide stuff for reference will start

     /* if ($('#edit-field-enable-masking-value').is(":checked")) {
        $(".field--name-field-asking-client-names").show();
      } else {
        $(".field--name-field-asking-client-names").hide();
      }

      $('#edit-field-enable-masking-value').once('exampleModule').on('click', function (event) {
        if ($('#edit-field-enable-masking-value').is(":checked")) {
          $(".field--name-field-asking-client-names").show();
        } else {
          $(".field--name-field-asking-client-names").hide();
        }

      });*/

      // Show hide stuff for reference will end

      // logic to handle checkbox select all in manage member starts

      /*var pathname = window.location.pathname;
      var path = "/membership";

      if (pathname.indexOf(path) != -1) {
        $(".material-form-item.form-item.js-form-item.form-type-checkbox.js-form-type-checkbox.form-item-select-all.js-form-item-select-all.checkbox.form-group").css("display", "none");
        $('button[value="Change the role of selected members"]').prop('disabled', false);
        $('button[value="Remove selected members"]').prop('disabled', false);

      }*/

      // logic to handle checkbox select all in manage member ends

      /*$('input[name^="social_views_bulk_operations_bulk_form_group"]:checkbox').once('exampleModule').on('click', function (event) {
        setTimeout(function () { checkedCount(); }, 1000);
      });*/

      // ########## Deal Size Logic Handling Starts ##########

     /* $('select[name="field_currency"]').once('exampleModule').on('change', function (event) {

        var currency = $("#edit-field-currency").val();
        var contract_value = $("#edit-field-contract-value-0-value").val();
        if ((currency !== null && currency !== "_none") && (contract_value !== null && contract_value > 0)) {
          setTimeout(function () { rerender_size_range_value(); }, 1000);
        } else {
          $("#edit-field-fake-deal-size-status").text("");
        }

      });

      $('input[name^="field_contract_value"]').once('exampleModule').on('change', function (event) {
        var currency = $("#edit-field-currency").val();
        var contract_value = $("#edit-field-contract-value-0-value").val();
        if ((currency !== null && currency !== "_none") && (contract_value !== null && contract_value > 0)) {
          setTimeout(function () { rerender_size_range_value(); }, 1000);
        } else {
          $("#edit-field-fake-deal-size-status").text("");
        }

      });*/

      // ########## Deal Size Logic Handling Ends ##########

      var pathname = window.location.pathname;
      if (pathname === "/view-cart") {
        $('.remove-from-cart-btn').click(function () {
          var ref_id = $(this).attr("rel");
          $('[data-history-node-id="' + ref_id + '"]').fadeOut(300, function () {
            $(this).remove();
          });
        });
        if ($('a.nav-link').hasClass('Cart')) {
          $('a.Cart').addClass('active');
          $('li.Cart').addClass('active');
        }
      }
      if (pathname === "/") {
        if ($('a.nav-link').hasClass('Home')) {
          $('a.Home').addClass('active');
        }
      }
      if (pathname === "/messages/inbox") {
        if ($('a.nav-link').hasClass('Notifications')) {
          $('a.Notifications').addClass('active');
        }
      }

      $(once('exampleModule', '#edit-search-add-all-to-cart', context)).on('click', function (event) {
        event.preventDefault();
        var allIds = $(this).attr("rel");
        var result = allIds.split(',');
        cart_count = (Number)($("li.view-reference-cart a .unread-message .cart-item").html());
        if (allIds == "asset-reference-listing") {

          $('a.add-to-cart-btn span').each(function () {
            $cart_button_text = $(this).text();
            if ($cart_button_text.indexOf('Add to Cart') && cart_count < 200) {
              // Will trigger all the logic
              $(this).trigger('click');
              cart_count = cart_count + 1;
            }
          })
        } else {
          // button with cart id
          $.each(result, function (index, value) {
            if ($('#add-to-cart-' + value).find('a.add-to-cart-btn').text().indexOf('Add to Cart') && cart_count < 200) {
              // Will trigger all the logic
              if (cart_count < 200) {
                $('#add-to-cart-' + value).find('a.add-to-cart-btn').trigger('click');
                cart_count = cart_count + 1;
              }
            }

          });
        }

      });

      /*$('a.add-to-cart-btn').once('exampleModule').on('click', function () {
        var ref_id = $(this).attr("rel");
        if ($(this).text() == "Add to Cart") {
          $("span#add-to-cart-" + ref_id).html(
            '<a class="action-item remove-from-cart-btn btn-default btn btn-lg btn-accent use-ajax" href="/remove-from-cart/' + ref_id + '"  rel="' +
            ref_id +
            '">Remove from Cart</a>'
          );
        } else {
          $("span#add-to-cart-" + ref_id).html(
            '<a class="action-item-small add-to-cart-btn btn-default btn btn-lg btn-accent use-ajax" href="/add-to-cart/' + ref_id + '"  rel="' +
            ref_id +
            '">Add to Cart</a>'
          );
        }

        var pathname = window.location.pathname;
        if (pathname === "/view-cart") {
          setTimeout(function () { removeCartItem(ref_id); }, 1000);
        }

      });

      $('a.remove-from-cart-btn').once('exampleModule').on('click', function () {
        var ref_id = $(this).attr("rel");
        // var fid = $(this).attr("fid");
        $("#cart_error_message").remove();
        if ($(this).text() == "Add to Cart") {
          $("span#add-to-cart-" + ref_id).html(
            '<a class="action-item remove-from-cart-btn btn-default btn btn-lg btn-accent use-ajax" href="/remove-from-cart/' + ref_id + '"  rel="' +
            ref_id +
            '">Remove from Cart</a>'
          );
        } else {

          $("span#add-to-cart-" + ref_id).html(
            '<a class="action-item-small add-to-cart-btn btn-default btn btn-lg btn-accent use-ajax" href="/add-to-cart/' + ref_id + '"  rel="' +
            ref_id +
            '">Add to Cart</a>'
          );

          var pathname = window.location.pathname;
          if (pathname === "/view-cart") {
            $("span#add-to-cart-" + ref_id).html('');
          }

        }

        // $(".update-cart-count").text(count(session_cart_value));

        var pathname = window.location.pathname;
        if (pathname === "/view-cart") {
          setTimeout(function () { removeCartItem(ref_id); }, 1000);
        }

      });

      // This script is used for handling the sequence of rating and user tag block in preview pop up starts
      $(window).once().on('dialog:aftercreate', function(dialog, $element, settings) {
        $('.unique-sequence-user-tags').insertBefore('.preview-full .group-ass-vote-feedback-comment ');
        $('.unique-sequence-user-tags').insertBefore('.preview-full .cart-rating');
        $('.new-rating-feedback-comment').insertAfter('.unique-sequence-user-tags');
      });
      // This script is used for handling the sequence of rating and user tag block in preview pop up ends

      $('#attach-references-opp').click(function () {
        var communities_list_form = jQuery('#entering-oppid-popup');
        if (communities_list_form.length) {
          $.colorbox({ inline: true, href: "#entering-oppid-popup", closeButton: false, overlayClose: true, escKey: true, innerHeight: 135 });
        }
      });

      addIndustryTooltip(); */ // Tooltip function called from main.js to load tooltip for Industry, Industry Segment and Offer on Adv Search.

    },
  }
}(Drupal, once));

  // ########## Deal Size Logic Handling Starts ##########
/*
  function rerender_size_range_value() {
    var currency = $("#edit-field-currency").val();
    if (currency != "_none") {
      var contract_value = $("#edit-field-contract-value-0-value").val() * 1000;
      if (currency == "EUR") {
        render_deal_size_range(["EUR"]);
        var select = get_deal_size_range(currency, contract_value);
        $("#edit-field-fake-deal-size-status").val(select);
        // if($.browser.msie && $('.field-name-field-contract-value-form input.form-text').val() != '')
        //     $('.form-item-fake-deal-size-status input.active_oppid_1').val($('body.page-node-edit #edit-field-fake-deal-size-status option[value="'+$('#edit-field-fake-deal-size-status').val()+'"]').text());
        // else if($.browser.msie)
        //   $('.form-item-fake-deal-size-status input.active_oppid_1').val('');
        // "cap_notify":{"eur_usd":"1.1170","eur_gbp":"0.7331","eur_brl":"3.3062","eur_aud":"1.4273","eur_cny":"6.8283","eur_mxn":"17.7579","base_path_conf":"\/"}
      } else {
        render_deal_size_range([currency]);
        switch (currency) {
          case "AUD":
            var contract_value_eur =
              contract_value / 1.4273; //Drupal.settings.cap_notify.eur_aud;

            break;

          case "BRL":
            var contract_value_eur =
              contract_value / 3.3062;//Drupal.settings.cap_notify.eur_brl;
            break;

          case "CNY":
            var contract_value_eur =
              contract_value / 6.8283;//Drupal.settings.cap_notify.eur_cny;
            break;

          case "GBP":
            var contract_value_eur =
              contract_value / 0.7331;//Drupal.settings.cap_notify.eur_gbp;
            break;

          case "USD":
            var contract_value_eur =
              contract_value / 1.1170; //Drupal.settings.cap_notify.eur_usd;
            break;

          case "MXN":
            var contract_value_eur =
              contract_value / 17.7579; //Drupal.settings.cap_notify.eur_mxn;
            break;
        }
        var select = get_deal_size_range(currency, contract_value);
        $("#edit-field-fake-deal-size-status").val(select);
      }
      if ($(".field-name-field-contract-value-form input.form-text").val() == "") {
        $("#edit-field-fake-deal-size-status").text("");
      }
    } else {
      $("#edit-field-fake-deal-size-status").text("");
    }
  };


  function get_deal_size_range(currency, contract_value) {
    var select = "";
    switch (true) {
      case contract_value == "" || contract_value == "undefined":
        select = currency + "_1";
        break;

      case contract_value > 0 && contract_value < 500001:
        select = currency + "_1";
        break;

      case contract_value > 500000 && contract_value < 1000001:
        select = currency + "_2";
        break;

      case contract_value > 100000 && contract_value < 5000001:
        select = currency + "_3";
        break;

      case contract_value > 500000 && contract_value < 10000001:
        select = currency + "_4";
        break;

      case contract_value > 1000000 && contract_value < 20000001:
        select = currency + "_5";
        break;

      case contract_value > 20000000 && contract_value < 50000001:
        select = currency + "_6";
        break;

      case contract_value > 50000000:
        select = currency + "_7";
        break;

      default:
        select = "_none";
        break;
    }
    return select;
  };
  function render_deal_size_range(currencys) {
    var list_option = "";
    var sign_currency = "";
    for (var i = 0, l = currencys.length; i < l; i++) {
      switch (currencys[i]) {
        case "AUD":
          sign_currency = "AU$";
          break;

        case "BRL":
          sign_currency = "R$";
          break;

        case "CNY":
          sign_currency = "¥";
          break;

        case "EUR":
          sign_currency = "€";
          break;

        case "GBP":
          sign_currency = "£";
          break;

        case "USD":
          sign_currency = "$";
          break;

        case "MXN":
          sign_currency = "Mex$";
          break;
      }
      if (sign_currency != "") {
        list_option +=
          '<option value="' + currencys[i] + '_1">' + "0" + sign_currency + " - 0.5 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_2">' + "0.5" + sign_currency + " - 1 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_3">' + "1 M" + sign_currency + " - 5 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_4">' + "5 M" + sign_currency + " - 10 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_5">' + "10 M" + sign_currency + " - 20 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_6">' + "20 M" + sign_currency + " - 50 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_7">' + "more than 50 M" + sign_currency + "</option>";
      } else {
        list_option = '<option value="_none">' + "- None -" + "</option>";
      }
    }
    $("#edit-field-fake-deal-size-status").html(list_option);
  };
*/

  // ########## Deal Size Logic Handling Ends ##########

  function removeCartItem(ref_id) {
    var counterCart = $(".counter-extra-cls").text();
    $("#remove-cart-" + ref_id).html('<span></span>');

    if (counterCart === '0') {
      $('#block-mainpagecontent').html("Cart is empty");
    }
  }

 /* function triggerCount() {
    var i = 0;
    jQuery("input[name^='social_views_bulk_operations_bulk_form_group']").each(function () {
      // $(this).attr('checked', false);
      if (i === 0) {
        $(this).trigger('change');
        $(this).trigger('change');
      }
      i++;
    });
    $(".path-advanced-search-reference-form .tooltiptext").remove();
  }


  function triggerReferenceUpdate() {
    $('.reference-label-update').each(function (i, obj) {
      var ref_node_id = $(this).attr('id');
      if (ref_node_id) {
        var ref_id = ref_node_id.split('-');
        var nid = ref_id[2];
        $.ajax({
          url: Drupal.url('reference/label/update/' + nid),
          type: 'POST',
          dataType: 'json',
          success: function (response) {

            $.each(response, function (k, v) {
              $("#label-update-" + k).html('');
              $("#label-update-" + k).html(v);

            });
          }
        });

      }

    })


  }*/

  /*$(document).on('change', 'input', function () {
    // Does some stuff and logs the event to the console
    setTimeout(function () { checkedCount(); }, 1000);
  });*/

  $(window).on('load', function () {
    // This code is used for loading the paragraph bundle in case its distorted Starts
    var field_contacts_text = $('#edit-field-contacts-text').text();
    var field_file_text = $('#edit-field-files-text').text();
    var field_content_files_text = $('#edit-field-content-files-text').text();
    var pattern = "No Paragraph added yet.";
    if (field_contacts_text.indexOf(pattern) !== -1) {
      $("input[name=field_contacts_contacts_add_more]").mousedown();
    }
    if (field_file_text.indexOf(pattern) !== -1) {
        $("input[name=field_files_files_add_more]").mousedown();
    }
    if (field_content_files_text.indexOf(pattern) !== -1) {
      $("input[name=field_content_files_files_content_add_more]").mousedown();
    }
    // This code is used for loading the paragraph bundle in case its distorted

    // # Removing hide row weight link from community page and folder list page starts
    if(($("#community-taxonomy-list-form").length > 0) || ($("#custom-community-folder-list").length > 0)) {
     // check if tabledrag-toggle-weight class has text Show row weights the simply hide the text button
     var tabledragButtonText = $('button.tabledrag-toggle-weight').text();
     if(tabledragButtonText == 'Show row weights'){
      $('button.tabledrag-toggle-weight').hide();
     } else {
      // else trigger click and hide button
      $('button.tabledrag-toggle-weight').click();
      $('button.tabledrag-toggle-weight').hide();
     }
    }
    // # Removing hide row weight link from community page and folder list page ends
  });

  (function ($, Drupal) {
    Drupal.behaviors.keepScrollOnAddMore = {
      attach: function (context, settings) {
        // Avoid attaching multiple times
        if (typeof Drupal.behaviors.keepScrollOnAddMore.initialized === 'undefined') {
          $(document).ajaxComplete(function (e) {
            var loadStringScroll = e.target.activeElement?.name || '';
            if (
              loadStringScroll.includes('field_content_files_files_content_add_more') ||
              loadStringScroll.includes('field_files_files_add_more') ||
              loadStringScroll.includes('field_contacts_contacts_add_more')
            ) {
              var scrollPosition = [
                self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
                self.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
              ];
              window.scrollTo(scrollPosition[0], scrollPosition[1]);
            }
          });
          Drupal.behaviors.keepScrollOnAddMore.initialized = true;
        }
      }
    };
  })(jQuery, Drupal);
  

  /*$(window).on('load', function () {
  // Community Pages Sequence for Add Tags Starts
  $('#community-folders-add-tag').insertAfter('.page-node-type-pages #custom-community-page-attachment');
  // Community Pages Sequence for Add Tags Ends

    // code for reference form radio button green / yellow / red
    $("label[for='edit-field-permission-status-green']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-yellow']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-red']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-green']").append('<span class="tooltiptext">Can be used externally directly without contacting the Account executive.</span>');
    $("label[for='edit-field-permission-status-yellow']").append('<span class="tooltiptext">Please contact reference owner prior to using the reference externally.</span>');
    $("label[for='edit-field-permission-status-red']").append('<span class="tooltiptext">Capgemini must not share client name/logo and engagement information for any external purpose.</span>');

    // code here
    $("#edit-allow-request-value").prop('checked', true);
    // Making checkbox checked for Request to Join Type Community
    $('fieldset#edit-group-request-membership').hide();

    $('#edit-group-roles-public-group-members').prop('checked', true);
    $('#edit-group-roles-closed-group-members').prop('checked', true);
    $('#edit-group-roles-secret-group-members').prop('checked', true);

    setTimeout(function () { triggerCount(); }, 1000);
    setTimeout(function () { triggerReferenceUpdate(); }, 1000);
    $('div.community-listings').each(function () {
      var i = $(this).attr('id');
      var i_group_id = i.split('-');
      var group_id = i_group_id[2];

      $('a#community-listings-id-' + group_id)[0].click();
      if ($('a#member-count-id-' + group_id).length){
        $('a#member-count-id-' + group_id)[0].click();
      }
      if ($('a#ko-count-id-' + group_id).length){
        $('a#ko-count-id-' + group_id)[0].click();
      }
      if ($('a#files-count-id-' + group_id).length){
        $('a#files-count-id-' + group_id)[0].click();
      }
      if ($('a#links-count-id-' + group_id).length){
        $('a#links-count-id-' + group_id)[0].click();
      }
    });
  });

  function openForm() {
    document.getElementById("AttachRefIDForm").style.display = "block";
  }

  function closeForm() {
    document.getElementById("AttachRefIDForm").style.display = "none";
  }

  function checkedCount() {
    $('button[value="Change the role of selected members"]').prop('disabled', false);
    $('button[value="Remove selected members"]').prop('disabled', false);

  }

  $('div.vbo-info-list-wrapper').bind('DOMNodeInserted DOMSubtreeModified DOMNodeRemoved', function (event) {
    var data = $("div.vbo-info-list-wrapper").text();
    var arr = data.split(' ');

    if (arr[0] > 1) {
      $('.path-group .vbo-view-form .form-group .btn-group.dropdown').addClass('social-group-invitations-enable');
      $('.path-group .vbo-view-form .form-group .btn-group.dropdown').removeClass('social-group-invitations-disable');
    } else {
      $('.path-group .vbo-view-form .form-group .btn-group.dropdown').addClass('social-group-invitations-disable');
      $('.path-group .vbo-view-form .form-group .btn-group.dropdown').removeClass('social-group-invitations-enable');
    }

  });

  function HandleBackFunctionality() {
    if (window.event) {
      if (window.event.clientX < 40 && window.event.clientY < 0) {
        alert("Browser back button is clicked...");
      }
      else {
        alert("Browser refresh button is clicked...");
      }
    }
    else {
      if (event.currentTarget.performance.navigation.type == 1) {
        alert("Browser refresh button is clicked...");
      }
      if (event.currentTarget.performance.navigation.type == 2) {
        alert("Browser back button is clicked...");
      }
    }
  }
  function addIndustryTooltip() {
    $('#field-segment select option').each(function () {
      let $optionText = $(this).text();
      $(this).attr('title', $optionText);
    });
    $('#field-subsegment select option').each(function () {
      let $optionText = $(this).text();
      $(this).attr('title', $optionText);
    });
    $('#field-offer select option').each(function () {
      let $optionText = $(this).text();
      $(this).attr('title', $optionText);
    });
  }

  function triggerPreview() {
    $('a#hidden_link_popup')[0].click();
    // Adding changes for showing loader untill popup is visible
    $('#edit-preview .ajax-throbber').remove();
    $('#edit-preview').append('<span class="ajax-throbber glyphicon-spin icon glyphicon glyphicon-refresh loader-thobber"></span>');

  }


  function triggerPreviewLink() {

    $('.preview-trimmed .select-wrapper').html('<div class="fivestar-widget clearfix fivestar-widget-5"><div class="star star-1 odd star-first"><a href="#20" title="Give it 1/5">Give it 1/5</a></div><div class="star star-2 even"><a href="#40" title="Give it 2/5">Give it 2/5</a></div><div class="star star-3 odd"><a href="#60" title="Give it 3/5">Give it 3/5</a></div><div class="star star-4 even"><a href="#80" title="Give it 4/5">Give it 4/5</a></div><div class="star star-5 odd star-last"><a href="#100" title="Give it 5/5">Give it 5/5</a></div></div>');
    $('.preview-full .select-wrapper').html('<div class="fivestar-widget clearfix fivestar-widget-5"><div class="star star-1 odd star-first"><a href="#20" title="Give it 1/5">Give it 1/5</a></div><div class="star star-2 even"><a href="#40" title="Give it 2/5">Give it 2/5</a></div><div class="star star-3 odd"><a href="#60" title="Give it 3/5">Give it 3/5</a></div><div class="star star-4 even"><a href="#80" title="Give it 4/5">Give it 4/5</a></div><div class="star star-5 odd star-last"><a href="#100" title="Give it 5/5">Give it 5/5</a></div></div>');
    // $('.select-wrapper').css('display', 'none');

    var rating = Math.ceil($('.preview-full .average-rating span').text());
    $('.preview-trimmed div.star').each(function (index) {
      if (index < rating) {
        $(this).addClass('on');
      }
    });

    $('.preview-full div.star').each(function (index) {
      if (index < rating) {
        $(this).addClass('on');
      }
    });


    $('.hide-field').show();
    $('.hide-initials-cs-taxonomy').each(function () {
      if ($.isNumeric($(this).text())) {
        $(this).hide();
      }
    });

  }

  window.addEventListener('click', function(event) {
    if (event.target.className == "ui-dialog-titlebar-close") {
      $("#edit-preview").prop('disabled' ,false);
     }
  });
  window.addEventListener('keydown', function(e) {
    if (e.key == "Escape") {
      $("#edit-preview").prop('disabled' ,false);
    }
  });*/

})(jQuery, Drupal, drupalSettings);