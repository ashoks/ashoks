<?php

namespace Drupal\custom_cart\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 *
 */
class ClearCartConfirm extends ConfirmFormBase {

  /**
   * @return string
   */
  public function getFormId() {
    return "confirm_delete_form";
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   * @return array
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    return parent::buildForm($form, $form_state);

  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {
    return new Url('custom_cart.crp_view_cart');
  }

  /**
   *
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    unset($_SESSION['reference_cart']);

    // Update cart related data for this user from database.
    $user_id = \Drupal::currentUser()->id();
    \Drupal::database()->update('custom_cart_info')
      ->fields(['status' => 1])
      ->condition('user_id', $user_id)
      ->condition('status', 0)
      ->execute();

    return $form_state->setRedirect('custom_cart.crp_view_cart');
  }

  /**
   * Returns the question to ask the user.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup
   *   The form question. The page title will be set to this value.
   */
  public function getQuestion() {
    return t('Are you sure you want to remove all items from your Cart?');
  }

}
