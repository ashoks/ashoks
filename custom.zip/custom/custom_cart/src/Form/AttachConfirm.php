<?php

namespace Drupal\custom_cart\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 *
 */
class AttachConfirm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'attach_confirm';
  }

  /**
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $args = arg();
    if ($args[1] == 'opportunity') {
      $title = t('Attach as Opportunity Reference(s)');
      // Prepare reference name list.
      $confirm_message = $reference_name_list = '';
      $refs_list = \Drupal::database()->query("select `nid`, `title` from {node} where `type` = 'reference' AND `nid` IN (:nids)", [
        ':nids' => $_SESSION['reference_cart'],
      ])->fetchAll();
      $_SESSION['reference_attach'] = [];
      if ($refs_list && count($refs_list) > 0) {
        $confirm_message = '<h3>' . t('The following item(s) will be attached as Opportunity Reference(s) to the Opportunity with ID ') . $_SESSION['ws_oppID'] . '</h3>';
        $reference_name_list = '<ul>';
        foreach ($refs_list as $ref) {
          $_SESSION['reference_attach'][] = $ref->nid;
          $reference_name_list .= '<li>' . $ref->title . '</li>';
        }
        $reference_name_list .= '</ul>';
      }

      // Prepare asset name list.
      $warning_message = $asset_name_list = '';
      $asset_list = \Drupal::database()->query("select `title` from {node} where `type` = 'asset' AND `nid` IN (:nids)", [
        ':nids' => $_SESSION['reference_cart'],
      ])->fetchAll();

      if ($asset_list && count($asset_list) > 0) {
        $warning_message = '<h3>' . t('The following item(s), which is (are) asset(s), cannot be attached as Opportunity Reference(s).') . '</h3>';
        $asset_name_list = '<ul>';
        foreach ($asset_list as $asset) {
          $asset_name_list .= '<li>' . $asset->title . '</li>';
        }
        $asset_name_list .= '</ul>';
      }

      $description = $confirm_message . $reference_name_list . $warning_message . $asset_name_list;
    }
    else {
      $title = t('Attach as Showcase Content');
      // Prepare showcase list.
      $confirm_message = $showcase_name_list = '';
      $showcase_list = \Drupal::database()->query("SELECT n.`nid`, n.`title` FROM {node} n INNER JOIN {field_data_field_showcase} s ON n.`nid` = s.`entity_id` WHERE s.`field_showcase_value` = 1 AND `nid` IN (:nids)", [
        ':nids' => $_SESSION['reference_cart'],
      ])->fetchAll();
      $_SESSION['showcase_attach'] = [];
      if ($showcase_list && count($showcase_list) > 0) {
        $confirm_message = '<h3>' . t('The following item(s) will be attached as Showcase Content to the ' . $_SESSION['ws_ishowcase']['type'] . ' with ID ') . $_SESSION['ws_ishowcase']['id'] . '</h3>';
        $showcase_name_list = '<ul>';
        foreach ($showcase_list as $showcase) {
          $_SESSION['showcase_attach'][] = $showcase->nid;
          $showcase_name_list .= '<li>' . $showcase->title . '</li>';
        }
        $showcase_name_list .= '</ul>';
      }

      // Prepare not showcase content list.
      $warning_message = $not_showcase_name_list = '';
      $not_showcase_attach = array_diff($_SESSION['reference_cart'], $_SESSION['showcase_attach']);
      if (count($not_showcase_attach) > 0) {
        $not_showcase_list = \Drupal::database()->query("SELECT n.`nid`, n.`title` FROM {node} n WHERE `nid` IN (:nids)", [
          ':nids' => $not_showcase_attach,
        ])->fetchAll();
      }
      if ($not_showcase_list && count($not_showcase_list) > 0) {
        $warning_message = '<h3>' . t('The following item(s), which is (are) not approved by Marketing, cannot be attached as Showcase Content') . '</h3>';
        $not_showcase_name_list = '<ul>';
        foreach ($not_showcase_list as $showcase) {
          $not_showcase_name_list .= '<li>' . $showcase->title . '</li>';
        }
        $not_showcase_name_list .= '</ul>';
      }

      $description = $confirm_message . $showcase_name_list . $warning_message . $not_showcase_name_list;
    }

    // Store the node object in a form for using in submit handler later.
    $form['type_value'] = [
      '#type' => 'value',
      '#value' => $args[1],
    ];

    $form['#theme'] = 'opportunity_reference_add_form';
    return $form;

  }

  /**
   *
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $values = $form_state->getValues();

    // User clicked on the "Execute" button.
    if ($form_state->getValue(['confirm'])) {
      $type_value = $values['type_value'];
      // Attach References content.
      if ($type_value == 'opportunity') {
        $user = \Drupal::currentUser();
        $opp_id = $_SESSION['ws_oppID'] ?? '';
        $references = $_SESSION['reference_attach'] ?? [];
        if ($opp_id && $references) {

          try {
            ws_login_to_thor();
            $client = new SoapClient(WS_INTERGATION, ['trace' => 1]);
            $sforce_header = new SoapHeader(WS_NAMESPACE, "SessionHeader", [
              "sessionId" => $_SESSION['ws_sessionId'],
            ]);
            $client->__setSoapHeaders([$sforce_header]);

            $OpportunityReference = [];
            foreach ($references as $ref_id) {
              $ref = \Drupal::entityTypeManager()->getStorage('node')->load($ref_id);
              if ($ref) {
              }
            }

            $updateOpportunity = $client->UpdateOpportunityReference([
              "request" => [
                "opportunityId" => $opp_id,
                "opportunityReference" => $OpportunityReference,
              ],
            ]);

            if ($updateOpportunity->result->Error->Code == 0) {
              \Drupal::messenger()->addStatus('References has been successfully attached to the opportunity on THOR');
              // $_SESSION['reference_cart'] = array_diff($_SESSION['reference_cart'], $_SESSION['reference_attach']);
              unset($_SESSION['ws_oppID']);
              unset($_SESSION['attach_button']);
              // $redirect_path = url('<front>', array('absolute' => TRUE));
            }
            else {
              // drupal_set_message(t('The opportunity ID entered is invalid, please enter a valid opportunity ID'), 'error');.
              \Drupal::messenger()->addError(($updateOpportunity->result->Error->Description));
            }
          }
          catch (Exception $e) {
            \Drupal::messenger()->addError(t('Web service failed - References not attached to opportunity'));
            \Drupal::logger('WS02')->notice('webservice from THOR has error when attach references in THOR: ' . $e->getMessage() . '\n', []);
          }
        }
      }
      else {
        // Attach iShowCase content.
        $user = \Drupal::currentUser();
        $id = $_SESSION['ws_ishowcase']['id'] ?? '';
        $type_options = $_SESSION['ws_ishowcase']['type'] ?? '';
        $showcases = $_SESSION['showcase_attach'] ?? [];

        if ($id && $showcases) {
          try {
            ws_login_to_thor();
            $client = new SoapClient(WS_ISHOWCASE_INTERGATION, ['trace' => 1]);
            $sforce_header = new SoapHeader(WS_ISHOWCASE_NAMESPACE, "SessionHeader", [
              "sessionId" => $_SESSION['ws_sessionId'],
            ]);
            $client->__setSoapHeaders([$sforce_header]);

            $OpportunityReference = [];
            foreach ($showcases as $ref_id) {
              $ref = \Drupal::entityTypeManager()->getStorage('node')->load($ref_id);
              if ($ref) {

              }
            }
            if ($type_options == 'Opportunity ID') {
              $ws_name = 'opportunity';
              $updateOpportunity = $client->UpdateOpportunityiShowCaseDetails([
                "request" => [
                  "OpportunityId" => $id,
                  "iShowCaseContent" => $OpportunityReference,
                ],
              ]);
            }
            elseif ($type_options == 'Account ID') {
              $updateOpportunity = $client->UpdateAccountiShowCaseDetails([
                "request" => [
                  "AccountId" => $id,
                  "iShowCaseContent" => $OpportunityReference,
                ],
              ]);
              $ws_name = 'account';
            }
            elseif ($type_options == 'Contact ID') {
              $updateOpportunity = $client->UpdateContactiShowCaseDetails([
                "request" => [
                  "ContactId" => $id,
                  "iShowCaseContent" => $OpportunityReference,
                ],
              ]);
              $ws_name = 'contact';
            }

            if ($updateOpportunity->result->Error->Code == 0) {
              \Drupal::messenger()->addStatus('ShowCase contents has been successfully attached to the ' . $type_options . ' on THOR');
              // $_SESSION['reference_cart'] = array_diff($_SESSION['reference_cart'], $_SESSION['showcase_attach']);
              unset($_SESSION['ws_ishowcase']);
              unset($_SESSION['attach_button']);
            }
            else {
              \Drupal::messenger()->addError(($updateOpportunity->result->Error->Description));
            }
          }
          catch (Exception $e) {
            \Drupal::messenger()->addError(t('Web service failed - ShowCase contents not attached to ' . $type_options));
            \Drupal::logger('WS02')->notice($ws_name . 'webservice from THOR has error when attach ShowCase contents in THOR: ' . $e->getMessage() . '\n', []);
          }
        }
      }

      drupal_goto($redirect_path);
    }

    return FALSE;
  }

}
