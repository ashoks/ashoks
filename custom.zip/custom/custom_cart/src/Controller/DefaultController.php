<?php
 
namespace Drupal\custom_cart\Controller;
 
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\RemoveCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\profile\Entity\Profile;
use Drupal\taxonomy\Entity\Term;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
 
/**
 * Default controller for the custom_cart module.
 */
class DefaultController extends ControllerBase {
 
  /**
   * Initialise the cart value crp_init_cart.
   */
  public function crp_init_cart() {
 
    $response = new AjaxResponse();
    $user_id = \Drupal::currentUser()->id();
    // Now as we are handling everything from db so in session will add it from db only.
    $cartData = \Drupal::database()->select('custom_cart_info', 'c')
      ->fields('c', ['id', 'cart_id', 'user_id', 'status'])
      ->condition('c.user_id', $user_id)
      ->condition('c.status', 0)
      ->execute();
    $cart_db = [];
    foreach ($cartData as $data) {
      $cart_db[] = $data->cart_id;
    }
 
    $_SESSION['reference_cart'] = $cart_db;
 
    $total_cart = count($_SESSION['reference_cart']) + count($_SESSION['ishowcase_cart']);
 
    // Return new JsonResponse($options);
    $response->addCommand(
      new HtmlCommand(
      '.counter-cls',
      '<span class="cart-item">' . $total_cart . '</span>'
      ),
      );
 
    // $response->addCommand(new \Drupal\Core\Ajax\InvokeCommand('#add-to-cart-'.$ref_id, 'attr', array('href', '123')));
    return $response;
  }
 
  /**
   *
   */
  public function crp_add_to_cart($ref_id) {
 
    $response = new AjaxResponse();
    // $ref_id = \Drupal::request()->request->get('ref_id');
    $ref_id = $ref_id ?? '';
    $all_req = NULL;
    $fid = \Drupal::request()->request->get('fid');
    $fid = $fid ?? '';
    $appendFid = '';
    $cart_session = $_SESSION['reference_cart'] ?? [];
    $cart_count = count($cart_session);
    $result = FALSE;
    if (is_numeric($ref_id) && empty($fid)) {
      $ref_node = \Drupal::entityTypeManager()->getStorage('node')->load($ref_id);
      $cart_count = $cart_count + 1;
      // If (isset($ref_node)) {.
      if (!in_array($ref_id, $cart_session) && $cart_count <= 200) {
        // Just Save the Data in custom cart table before adding it in table.
        $cart_session[] = $ref_id;
        $result = TRUE;
      }
      // }
    }
    else {
      $explodeArr = explode("-", $ref_id);
 
      $ref_id = $explodeArr[0];
      $fid = $explodeArr[1];
      $appendFid = ($fid) ? "-" . $fid : '';
 
      if ($cart_count < 200) {
        $cart_session[] = $ref_id . '-' . $fid;
        $cart_count = $cart_count + 1;
      }
      $result = TRUE;
    }
    $data = $_SESSION['refined_data'];
    if (!empty($data['RowObjects']['e'][0])) {
      $data = $data['RowObjects']['e'];
      foreach ($data as $key => $value) {
        $nfid = is_numeric($fid) ? $fid : substr($fid, 0, -1);
        if ($value['sourceint1'] == $ref_id && $value['sourcestr23'] == 'km file' && $value['sourcecsv23'] == $nfid) {
          $_SESSION['file_data_cart'][$value['sourceint1'] . "-" . $value['sourcecsv23']] = $value;
          break;
        }
      }
    }
    else {
      $data = $data['RowObjects']['e'];
      $nfid = is_numeric($fid) ? $fid : substr($fid, 0, -1);
      if ($data['sourceint1'] == $ref_id && $data['sourcestr23'] == 'km file' && $data['sourcecsv23'] == $nfid) {
        $_SESSION['file_data_cart'][$data['sourceint1'] . "-" . $data['sourcecsv23']] = $data;
      }
    }
 
    $user_id = \Drupal::currentUser()->id();
 
    // Check the id and user with status 0 in to custom_cart_info table in database.
    if (isset($cart_session)) {
      foreach ($cart_session as $cart_id) {
        $query = \Drupal::database()->select('custom_cart_info', 'c');
        $query->addExpression('COUNT([id])');
        $count = $query->condition('c.cart_id', $cart_id)
          ->condition('c.user_id', $user_id)
          ->condition('c.status', 0)
          ->execute()
          ->fetchField();
 
        if ($count == 0) {
 
          \Drupal::database()->insert('custom_cart_info')
            ->fields([
              'cart_id' => $cart_id,
              'user_id' => $user_id,
            ])
            ->execute();
 
        }
 
      }
 
    }
 
    // Now as we are handling everything from db so in session will add it from db only.
    $cartData = \Drupal::database()->select('custom_cart_info', 'c')
      ->fields('c', ['id', 'cart_id', 'user_id', 'status'])
      ->condition('c.user_id', $user_id)
      ->condition('c.status', 0)
      ->execute();
    $cart_db = [];
    foreach ($cartData as $data) {
      $cart_db[] = $data->cart_id;
    }
 
    $_SESSION['reference_cart'] = $cart_db;
 
    $total_cart = count((array) $_SESSION['reference_cart']) + count((array) $_SESSION['ishowcase_cart']);
    $options = [
      'ref_id' => $ref_id,
      'result' => $result,
      'cart_num' => count($_SESSION['reference_cart']),
      'total_cart' => $total_cart,
      'all_req' => $all_req,
    ];
    // Return new JsonResponse($options);
    $response->addCommand(
      new HtmlCommand(
      '.counter-cls',
      '<span class="cart-item">' . $total_cart . '</span>'
      ),
      );
 
    if ($cart_count <= 200) {
      $response->addCommand(
          new HtmlCommand(
          'span#add-to-cart-' . $ref_id . $appendFid,
          '<a class="remove-from-cart-btn action-item-small secondary-btn use-ajax" href="/remove-from-cart/' . $ref_id . $appendFid . '"  rel="' . $ref_id . $appendFid .
          '"><button class="btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Remove from Cart</button></a>'
          ),
      );
    }
 
    // $response->addCommand(new \Drupal\Core\Ajax\InvokeCommand('#add-to-cart-'.$ref_id, 'attr', array('href', '123')));
    return $response;
  }
 
  /**
   * Handling ajax call from all community & my community pages.
   */
  public function AllCommunityMemberCount($group_id) {
    $response = new AjaxResponse();
    $memberCount = [];
    if (is_numeric($group_id)) {
      $query = \Drupal::database()->select('groups_field_data', 'n');
      $query->addExpression('count(o.gid)', 'memberCount');
      $query->fields('n', ['id', 'label']);
      $query->leftJoin('group_content_field_data', 'o', 'o.`gid` = n.`id`');
      $query->leftJoin('node', 'content', 'content.nid = o.`id`');
      $query->condition('o.gid', $group_id);
      $query->groupBy('n.id');
      $memberCount = $query->execute()->fetchAll();
 
      if ($memberCount[0]->memberCount) {
        $member_count = ($memberCount[0]->memberCount) ? $memberCount[0]->memberCount : 0;
      }
    }
 
    $response->addCommand(
      new HtmlCommand(
        '#member-count-' . $group_id,
      $member_count . " ")
    );
 
    return $response;
  }
 
  /**
   * Handling ajax call from all community & my community pages.
   */
  public function AllCommunityFilesCount($group_id) {
    $response = new AjaxResponse();
    $file_count = 0;
    $group = Group::load($group_id);
    $community_type = $group->get('field_community_type')->value;
    $type = [0 => 'asset', 3 => 'reference'];
    $TotalCount = [];
    if (is_numeric($group_id)) {
 
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(fa.field_attachment_target_id)', 'totalFiles');
      $query->fields('ff', ['`field_files_target_id`', '`entity_id`', 'bundle']);
      $query->fields('fu', ['`id`', '`fid`']);
      $query->fields('fm', ['`fid`', 'filename']);
      $query->fields('o', ['`id`']);
      $query->leftJoin('file_usage', 'fu', 'ff.`field_files_target_id` = fu.`id`');
      $query->leftJoin('file_managed', 'fm', 'fu.`fid` = fm.`fid`');
      $query->leftJoin('paragraph__field_attachment', 'fa', 'fa.field_attachment_target_id = fm.fid');
      $query->leftJoin('group_content_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $group_id);
      $query->condition('ff.bundle', [$type[$community_type], 'news', 'pages', 'event'], 'IN');
      $query->groupBy('o.gid');
      $TotalCount = $query->execute()->fetchAll();
 
      if ($TotalCount[0]->totalFiles) {
        $file_count = ($TotalCount[0]->totalFiles) ? $TotalCount[0]->totalFiles : 0;
      }
    }
 
    $response->addCommand(
      new HtmlCommand(
        '#files-count-' . $group_id,
      $file_count . " ")
    );
 
    return $response;
  }
 
  /**
   * Handling ajax call from all community & my community pages.
   */
  public function AllCommunityLinksCount($group_id) {
    $response = new AjaxResponse();
    $file_count = 0;
    $group = Group::load($group_id);
    $community_type = $group->get('field_community_type')->value;
    $type = [0 => 'asset', 3 => 'reference'];
    $TotalCount = [];
 
    if (is_numeric($group_id)) {
      $query = \Drupal::database()->select('node__field_files', 'ff');
      $query->addExpression('count(fa.field_link_uri)', 'totalFiles');
      $query->leftJoin('file_usage', 'fu', 'ff.`field_files_target_id` = fu.`id`');
      $query->leftJoin('file_managed', 'fm', 'fu.`fid` = fm.`fid`');
      $query->leftJoin('paragraph__field_link', 'fa', 'fa.entity_id = ff.field_files_target_id');
      $query->leftJoin('node', 'content', 'content.nid = ff.`entity_id`');
      $query->leftJoin('group_content_field_data', 'o', 'o.`entity_id` = ff.`entity_id`');
      $query->condition('o.gid', $group_id);
      $query->condition('ff.bundle', [$type[$community_type], 'news', 'pages', 'event'], 'IN');
      $query->groupBy('o.gid');
      $TotalCount = $query->execute()->fetchAll();
      if ($TotalCount[0]->totalFiles) {
        $file_count = ($TotalCount[0]->totalFiles) ? $TotalCount[0]->totalFiles : 0;
      }
    }
    $response->addCommand(
      new HtmlCommand(
        '#links-count-' . $group_id,
      $file_count . " ")
    );
 
    return $response;
  }
 
  /**
   * Handling ajax call from all community & my community pages.
   */
  public function AllCommunityKoCount($group_id) {
    $response = new AjaxResponse();
 
    $group = Group::load($group_id);
    $field_community_type = $group->get('field_community_type')->value;
    $koCount = 0;
    if ($group instanceof GroupInterface) {
 
      if ($field_community_type == '3') {
        $query = \Drupal::database()->select('node_field_data', 'nfd');
        $query->addExpression('COUNT(n.`nid`)', 'totalnode');
        $query->fields('nfd', ['title']);
        $query->fields('gcfd', ['label', 'gid']);
        $query->fields('n', ['nid', 'type']);
        $query->innerJoin('group_content_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
        $query->innerJoin('node', 'n', 'n.nid = gcfd.`entity_id`');
        $query->condition('n.type', 'reference');
        $query->condition('gcfd.gid', $group_id);
        $or = $query->orConditionGroup();
        $or->condition('gcfd.type', 'group_content_type_36a34989b2c57');
        $or->condition('gcfd.type', 'group_content_type_55819aead6bb5');
        $or->condition('gcfd.type', 'group_content_type_7e7dc07d3e03c');
        $query->condition($or);
        $query->condition('nfd.status', 1);
        $query->groupBy('gcfd.gid');
        $referenceTotalCount = $query->execute()->fetchAll();
 
        if ($referenceTotalCount[0]->totalnode) {
          $koCount = ($referenceTotalCount[0]->totalnode) ? $referenceTotalCount[0]->totalnode : 0;
        }
      }
 
      if ($field_community_type == '0') {
        $query = \Drupal::database()->select('node_field_data', 'nfd');
        $query->addExpression('COUNT(n.`nid`)', 'totalnode');
        $query->fields('nfd', ['title']);
        $query->fields('gcfd', ['label', 'gid']);
        $query->fields('n', ['nid', 'type']);
        $query->innerJoin('group_content_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
        $query->innerJoin('node', 'n', 'n.nid = gcfd.`entity_id`');
        $query->condition('n.type', 'asset');
        $query->condition('gcfd.gid', $group_id);
        $query->condition('gcfd.type', '%group_node-asset%', 'LIKE');
        $query->condition('nfd.status', 1);
        $query->groupBy('gcfd.gid');
        $assetTotalCount = $query->execute()->fetchAll();
 
        if ($assetTotalCount[0]->totalnode) {
          $koCount = ($assetTotalCount[0]->totalnode) ? $assetTotalCount[0]->totalnode : 0;
        }
      }
 
    }
 
    $response->addCommand(
    new HtmlCommand(
    '#ko-count-' . $group_id,
    $koCount . " ")
    );
 
    return $response;
  }
 
  /**
   * Handling ajax call from all community & my community pages.
   */
  public function community_listings($group_id, $type_community) {
    $response = new AjaxResponse();
    $arrayjoined = [];
    $fileCount = [];
    $group_manager = [];
    $state_label = [];
 
    $route_name = \Drupal::routeMatch()->getRouteName();
    $groupArray = [];
 
    $account = \Drupal::currentUser();
    $user_id = \Drupal::currentUser()->id();
 
    $query = \Drupal::database()->select('group_content_field_data', 'gc');
    $query->join('group_content__grequest_status', 'gr', 'gc.id = gr.entity_id');
    $query->fields('gc', ['id']);
    $query->fields('gr', ['grequest_status_value']);
    $query->condition('gc.uid', $user_id);
    $query->condition('gc.gid', $group_id);
    $query->orderBy('id', 'DESC');
    $query->range(0, 1);
    $result = $query->execute()->fetchObject();
    // $result = $query->execute()->fetchAllKeyed(0,1); // $query->execute()->fetchAll();
    $request_status = $result->grequest_status_value;
    // State label data goes here.
    $group = Group::load($group_id);
    $group_type_value = $group->getGroupType()->id();
 
    if ($group instanceof GroupInterface) {
      $account = \Drupal::currentUser();
      $account_id = \Drupal::currentUser()->id();
      $member = $group->getMember($account);
      $rol = ($member) ? $member->getRoles() : [];
      $group_manager = 0;
      $owner = $group->getOwner();
      $uid = $owner->uid->getValue()[0]['value'];
      if (array_key_exists($group->bundle() . "-moderator", $rol) || array_key_exists($group->bundle() . "-group_manager", $rol)) {
        $group_manager = 1;
      }
    }
 
    $grouptype = $group->getGroupType()->id();
    $group_member = 0;
    if ($group->getMember($account)) {
      $group_member = 1;
    }
 
    if ($group_type_value == "public_group") {
      $group_type_value = "Public";
    }
    else {
      $group_type_value = "Private";
    }
 
    $moderation_state = $group->get('moderation_state')->getString();
    if ($moderation_state == "unpublished") {
      $group_status_value = "(Unpublished)";
    }
    else {
      $group_status_value = "";
    }
 
    $html_manager_text = "";
    if ($group_member == 1) {
      $html_manager_text .= '<div class="btn btn-accent btn-block btn-lg btn-raised result_message_' . $group_id . '">
    <a href="/group/' . $group_id . '/leave-community" class="joined-btn use-ajax">Leave</a>
    </div>';
    }
    if ($group_manager == 1) {
      $html_manager_text .= '<span class="group-manager  message_note_' . $group_id . '">You have Moderator Rights for this Community</span>';
    }
    elseif ($grouptype == "secret_group" && $request_status == "0") {
      $html_manager_text .= '<span class="pending-request">Pending Joining Request</span>';
    }
    elseif ($grouptype == "secret_group" && $type_community != "my-community" && $group_member == 0 && ($request_status == "2" or $request_status == "1" or $request_status == "")) {
      $html_manager_text .= '<div class="btn btn-accent btn-block btn-lg btn-raised result_message_' . $group_id . '">
      <a href="/group/' . $group_id . '/membership-request-community" class="use-ajax">Join</a>
      </div>';
    }
    elseif ($grouptype == "closed_group") {
      $html_manager_text .= '<span class="invitation-only">By Invitation Only </span>';
    }
    elseif ($grouptype == "public_group" && $type_community != "my-community" && $group_member == 0) {
      $html_manager_text .= '<div class="btn btn-accent btn-block btn-lg btn-raised result_message_' . $group_id . '">
            <a href="/group/' . $group_id . '/join-community" class="use-ajax">Join</a>
            </div>';
    }
 
    $response->addCommand(
    new HtmlCommand(
    '#publishing-state-' . $group_id,
    $group_type_value . " " . $group_status_value)
    );
 
    $response->addCommand(
    new HtmlCommand(
    '#joined-text-' . $group_id,
    $html_manager_text)
    );
 
    return $response;
  }
 
  /**
   *
   */
  public function crp_remove_from_cart($ref_id) {
    $response = new AjaxResponse();
 
    $user_id = \Drupal::currentUser()->id();
 
    // $ref_id = \Drupal::request()->request->get('ref_id');
    $fid = \Drupal::request()->request->get('fid');
    $ref_id = isset($ref_id) && !isset($fid) ? $ref_id : $ref_id . "-" . $fid;
 
    $cart_session = $_SESSION['reference_cart'] ?? [];
    $result = FALSE;
 
    if (in_array($ref_id, $cart_session)) {
      if (($key = array_search($ref_id, $cart_session)) !== FALSE) {
 
        \Drupal::database()->update('custom_cart_info')
          ->fields(['status' => 1])
          ->condition('cart_id', $ref_id)
          ->condition('user_id', $user_id)
          ->condition('status', 0)
          ->execute();
 
        unset($cart_session[$key]);
      }
      $result = TRUE;
    }
    // Now as we are handling everything from db so in session will add it from db only.
    $cartData = \Drupal::database()->select('custom_cart_info', 'c')
      ->fields('c', ['id', 'cart_id', 'user_id', 'status'])
      ->condition('c.user_id', $user_id)
      ->condition('c.status', 0)
      ->execute();
    $cart_db = [];
    foreach ($cartData as $data) {
      $cart_db[] = $data->cart_id;
    }
 
    $_SESSION['reference_cart'] = $cart_db;
 
    // $_SESSION['reference_cart'] = $cart_session;
    $total_cart = count((array) $_SESSION['reference_cart']) + count((array) $_SESSION['ishowcase_cart']);
    $options = [
      'ref_id' => $ref_id,
      'result' => $result,
      'cart_num' => count($_SESSION['reference_cart']),
      'total_cart' => $total_cart,
    ];
    // Return new JsonResponse($options);
    // Return new JsonResponse($options);
    $response->addCommand(
      new HtmlCommand(
      '.counter-cls',
      '<span class="cart-item">' . $total_cart . '</span>'
      ),
      );
 
    $response->addCommand(
        new HtmlCommand(
        'span#add-to-cart-' . $ref_id,
        '<a class="action-item-small add-to-cart-btn secondary-btn use-ajax" href="/add-to-cart/' . $ref_id . '"  rel="' .
        $ref_id .
        '"><div class="action-group btn-ghost d-flex align-items-center gap-1 font12"><span class="material-symbols-outlined md-4">shopping_cart</span>Add to Cart</div></a>'
        ),
    );
 
    $selector = '#remove-cart-' . $ref_id;
    $response->addCommand(new RemoveCommand($selector));
    return $response;
  }
 
  /**
   *
   */
  public function crp_view_cart() {
    unset($_SESSION['reference_cart']);
    // Now as we are handling everything from db so in session will add it from db only.
    $user_id = \Drupal::currentUser()->id();
    $cartData = \Drupal::database()->select('custom_cart_info', 'c')
      ->fields('c', ['id', 'cart_id', 'user_id', 'status'])
      ->condition('c.user_id', $user_id)
      ->condition('c.status', 0)
      ->extend('Drupal\Core\Database\Query\PagerSelectExtender')
      ->limit(200)
      ->execute();
    $cart_db = [];
    foreach ($cartData as $data) {
      $cart_db[] = $data->cart_id;
    }
 
    $_SESSION['reference_cart'] = $cart_db;
 
    $references = $_SESSION['reference_cart'] ?? [];
    // print_r($references);die;
    foreach ($references as $item) {
      if (!is_numeric($item)) {
        $nid_fid = explode('-', $item);
        $fids[] = $nid_fid[1];
      }
    }
    $files_list = [];
    $viewCounter = [];
 
    foreach ($references as $key => $item) {
      $nid = $item;
      $statistics = \Drupal::service('statistics.storage.node')->fetchView($nid);
      $statisticsCount = ($statistics) ? $statistics->getTotalCount() : 0;
      $variables = \Drupal::translation()->formatPlural($statisticsCount, '1 view', '@count views');
      $var_convert_arr = get_mangled_object_vars($variables);
      $viewCount = array_values($var_convert_arr);
      $viewCounter['cartViewCount'][$nid] = $viewCount[0] . '-' . $nid;
 
      if (!is_numeric($item)) {
        $nid_fid = explode('-', $item);
        if (!is_numeric($nid_fid[1])) {
          $nfid = substr($nid_fid[1], 0, -1);
        }
        else {
          $nfid = $nid_fid[1];
        }
        if (!array_key_exists($nfid, $files_list)) {
          unset($_SESSION['reference_cart'][$nid_fid[0] . '-' . $nfid]);
        }
      }
    }
    // Echo "<pre>";  print_r($viewCounter);
    // echo "result"; die();
    $_SESSION['viewCounter'] = $viewCounter;
    // Node and file ids.
    $ref = (isset($viewCounter['cartViewCount']) && is_array($viewCounter['cartViewCount'])) ? array_keys($viewCounter['cartViewCount']) : NULL;
    $nodes = Node::loadMultiple($references);
    $sDate = [];
    $eDate = [];
    $entryPortfolio = [];
    $s_date = [];
    $fcount = [];
    $variable_portfolio = [];
    $category_portfolio = [];
    $countFileAttachment = [];
    foreach ($nodes as $node) {
      $nodeId = $node->get('nid')->getValue()[0]['value'];
      $start_date = ($node->hasField('field_engagement_start_date')) ? $node->get('field_engagement_start_date')->getValue()[0]['value'] : NULL;
      $startDat = date_create($start_date ?? '');
      $startDate = date_format($startDat, "d M y") . '-' . $nodeId;
 
      $end_date = ($node->hasField('field_engagement_end_date')) ? $node->get('field_engagement_end_date')->getValue()[0]['value'] : NULL;
      $endDat = date_create($end_date ?? '');
      $endDate = date_format($endDat, "d M y") . '-' . $nodeId;
 
      $s_date['startDate'][$nodeId] = $startDate;
      array_push($sDate, $startDate);
      array_push($eDate, $endDate);
      $entryPortfolio = ($node->hasField('field_entry_portfolio')) ? $node->get('field_entry_portfolio')->getValue()[0]['target_id'] . '-' . $nodeId : NULL;
 
      // Fetching the portfolio entry field starts.
      $field_portfolio = ($node->hasField('field_entry_portfolio')) ? $node->get('field_entry_portfolio')->getValue() : NULL;
      foreach ($field_portfolio as $key => $business_portfolio) {
        $taxonomyTermName = \Drupal::service('entity_type.manager')
          ->getStorage("taxonomy_term")
          ->load($business_portfolio['target_id']);
          if ($taxonomyTermName) {
            $variable_portfolio[] = $taxonomyTermName->label() . "@#" . $nodeId;
          }
      }
 
      // Fetching the portfolio entry field ends.
      $files = ($node->hasField('field_files')) ? $node->get('field_files')->getValue() : NULL;
      $attachments = ($node->hasField('field_files')) ? $node->get('field_files')->getValue() : NULL;
      $edit_attachments = [];
      $user_in_attachments = [];
      foreach ($attachments as $key => $attachment) {
        $edit_attachments[] = $attachment['target_id'];
      }
      $file_in_attachment = [];
      $fileinattachment = [];
      $linkinattachment = [];
      $countFileAttachment[$nodeId] = [];
      foreach ($edit_attachments as $key => $con) {
        $entity = \Drupal::entityTypeManager()->getStorage('paragraph')->load($con);
        if(isset($entity)){
          $file_id = is_array($entity->get('field_attachment')->getValue()) && array_key_exists(0, $entity->get('field_attachment')->getValue()) ? $entity->get('field_attachment')->getValue()[0]['target_id'] : NULL;
        }
        if (isset($file_id)) {
          $files = File::load($file_id);
          if (isset($files)) {
            $url = Url::fromUri($files->createFileUrl(FALSE));
            $countFileAttachment[$nodeId][] = $url;
          }
        }
      }
 
      $fileCount = count($countFileAttachment[$nodeId]) . '-' . $nodeId;
      array_push($fcount, $fileCount);
    }
    $_SESSION['variable_portfolio'] = $variable_portfolio;
 
    $_SESSION['startDate'] = $sDate;
    $_SESSION['endDate'] = $eDate;
    $_SESSION['fcount'] = $fcount;
    // assests, reference
    // And then you can view/build them all together:
    // $build = \Drupal::entityTypeManager()->getViewBuilder('node')->viewMultiple($nodes, 'node.reference_cart');
    // .
    $build_nodes_files = [];
    $creffids = [];
    if(isset($ref)){
      foreach ($ref as $key => $view_ref) {
        // dump($view_ref);
        if (!is_numeric($view_ref)) {
          // Files.
          $cnid_fid = explode('-', $view_ref);
          // dump($cnid_fid);
          $creffids[] = (int) $cnid_fid[1];
          if (isset($cnid_fid[1]) && isset($cnid_fid[0]) && is_numeric($cnid_fid[1]) && is_numeric($cnid_fid[0])) {
            // dump($cnid_fid[0]);.
            $node_entity = Node::load($cnid_fid[0]);
            if($node_entity) {
              $node_type = $node_entity->get('type')->getValue()[0]['target_id'];
              $gid = $node_entity->get('field_community')->getValue()[0]['target_id'];
              $query = \Drupal::database()->select('groups_field_data', 'gc');
              $query->fields('gc', ['label']);
              $query->condition('gc.id', $gid);
              $result = $query->execute()->fetchObject();
              $grp_label = $result->label;
              $file = File::load($cnid_fid[1]);
              $file_id = $file->get('fid')->getValue()[0]['value'];
              $node_id = $node_entity->get('nid')->getValue()[0]['value'];
              $filename = $file->get('filename')->getValue()[0]['value'];
              $file_pathinfo = pathinfo($filename);
              $file_extension = $file_pathinfo['extension'];
              $extension = $file_extension;
              $image_path = '';
              if (isset($extension)) {
                switch ($extension) {
                  case "jpg":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/jpg-icon.gif";
                    break;
    
                  case "7z":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/7z-icon.gif";
                    break;
    
                  case "jpeg":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/jpg-icon.gif";
                    break;
    
                  case "attach":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/attach-icon.gif";
                    break;
    
                  case "csv":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/csv-icon.gif";
                    break;
    
                  case "doc":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/doc-icon.gif";
                    break;
    
                  case "docx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/docx-icon.gif";
                    break;
    
                  case "dotx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/dotx-icon.gif";
                    break;
    
                  case "eml":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/eml-icon.gif";
                    break;
    
                  case "gif":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/gif-icon.gif";
                    break;
    
                  case "htm":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/htm-icon.gif";
                    break;
    
                  case "html":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/html-icon.gif";
                    break;
    
                  case "mov":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/mov-icon.gif";
                    break;
    
                  case "mp4":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/mp4-icon.gif";
                    break;
    
                  case "oft":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/oft-icon.gif";
                    break;
    
                  case "pdf":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/pdf-icon.gif";
                    break;
    
                  case "png":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/png-icon.gif";
                    break;
    
                  case "potx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/potx-icon.gif";
                    break;
    
                  case "ppsx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/ppsx-icon.gif";
                    break;
    
                  case "ppt":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/ppt-icon.gif";
                    break;
    
                  case "pptx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/pptx-icon.gif";
                    break;
    
                  case "rar":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/rar-icon.gif";
                    break;
    
                  case "rft":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/rft-icon.gif";
                    break;
    
                  case "swf":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/swf-icon.gif";
                    break;
    
                  case "txt":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/txt-icon.gif";
                    break;
    
                  case "vsd":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/vsd-icon.gif";
                    break;
    
                  case "wmv":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/wmv-icon.gif";
                    break;
    
                  case "word":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/word-icon.gif";
                    break;
    
                  case "wordx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/wordx-icon.gif";
                    break;
    
                  case "xlsb":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/xlsb-icon.gif";
                    break;
    
                  case "xls":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/xls-icon.gif";
                    break;
    
                  case "xlsm":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/xlsm-icon.gif";
                    break;
    
                  case "xlsx":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/xlsx-icon.gif";
                    break;
    
                  case "xml":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/xml-icon.gif";
                    break;
    
                  case "zip":
                    $image_path = "/themes/custom/capgemini_b5/images/extension/zip-icon.gif";
                    break;
    
                  default:
                    $image_path = "/themes/custom/capgemini_b5/images/extension/unknown-icon.gif";
                }
              }
              else {
                $image_path = "/themes/custom/capgemini_b5/images/extension/unknown-icon.gif";
              }
              if($node_type == 'pages' || $node_type == 'event' || $node_type == 'news'){
                $fquery = \Drupal::database()->select('node__field_content_files', 'ff');
                $fquery->fields('fl', ['field_entity_language_target_id']);
                $fquery->fields('fd', ['field_file_date_value']);
                $fquery->join('paragraph__field_attachment', 'fa', 'ff.field_content_files_target_id = fa.entity_id');
                $fquery->join('paragraph__field_entity_language', 'fl', 'ff.field_content_files_target_id = fl.entity_id');
                $fquery->join('paragraph__field_file_date', 'fd', 'ff.field_content_files_target_id = fd.entity_id');
                $fquery->condition('fa.field_attachment_target_id', $file_id);
                $fquery->condition('ff.entity_id', $node_id);
                $filedata = $fquery->execute()->fetchObject();
              }
              else{
                    $fquery = \Drupal::database()->select('node__field_files', 'ff');
                          $fquery->fields('fl', ['field_entity_language_target_id']);
                          $fquery->fields('fd', ['field_file_date_value']);
                          $fquery->join('paragraph__field_attachment', 'fa', 'ff.field_files_target_id = fa.entity_id');
                          $fquery->join('paragraph__field_entity_language', 'fl', 'ff.field_files_target_id = fl.entity_id');
                          $fquery->join('paragraph__field_file_date', 'fd', 'ff.field_files_target_id = fd.entity_id');
                          $fquery->condition('fa.field_attachment_target_id', $file_id);
                          $fquery->condition('ff.entity_id', $node_id);
                          $filedata = $fquery->execute()->fetchObject();
                
              }
              $file_lang = $filedata->field_entity_language_target_id;
              if(isset($file_lang) && !empty($file_lang)){
                $tquery = \Drupal::database()->select('taxonomy_term_field_data', 'td');
                $tquery->fields('td', ['name']);
                $tquery->condition('td.tid', $file_lang);
                $tlanguage = $tquery->execute()->fetchObject();
                $language = !empty($tlanguage) ? $tlanguage->name: 'None';
                }else{  
                  $language = 'None';
              }
              $file_date = $filedata->field_file_date_value;
              $res_file_date = isset($file_date) && !empty($file_date) ? date('M Y', strtotime($file_date)) : 'None';
              // $build_nodes_files[$key] = \Drupal::entityTypeManager()->getViewBuilder('file')->view($file);
              $build_nodes_files[$key] = ['#theme' => 'crp_view_file_cart' , '#node' => $node_entity, '#file' => $file, '#grplabel' => $grp_label, '#lang' => $language, '#cfiledate' => $res_file_date, '#cfileimage' => $image_path];
            }
          }
        }
        else {
          if (!empty($view_ref)) {
            $node_entity = Node::load($view_ref);
            if ($node_entity) {
              $build_nodes_files[$key] = \Drupal::entityTypeManager()->getViewBuilder('node')->view($node_entity, 'node.reference_cart');
            }
          }
   
        }
      }
    }
    
    // dd($build_nodes_files);
    $build['pager'] = [
      '#type' => 'pager',
    ];
    return [
      '#theme' => 'crp_view_cart',
      '#items' => $ref,
      '#nodes' => ($build_nodes_files) ? \Drupal::service('renderer')->render($build_nodes_files) : '',
      '#viewCounter' => $viewCounter,
      '#startDate' => $sDate,
      '#endDate' => $eDate,
      '#fcount' => $fcount,
    ];
  }
 
  /**
   *
   */
  public function crp_add_all_to_cart() {
 
    $nid = $_POST['ref_id'] ?? '';
    $fid = $_POST['fid'] ?? '';
    $ref_id = trim($nid . ',' . $fid, ',');
    $cart_session = $_SESSION['reference_cart'] ?? [];
    $result = FALSE;
    $node_ids = explode(",", $ref_id);
    $ref_nodes = '';
    if (!empty($node_ids)) {
      foreach ($node_ids as $ref_id) {
        if (is_numeric($ref_id)) {
          if (!in_array($ref_id, $cart_session)) {
            $card_count = count($_SESSION['reference_cart']);
            if ($card_count < 200) {
              $_SESSION['reference_cart'][] = $ref_id;
              $ref_nodes[] = $ref_id;
              $data = $_SESSION['refined_data'];
            }
            $result = TRUE;
          }
        }
        else {
 
          $exp_node = explode("-", $ref_id);
          $node_id = $exp_node[0];
          if (!in_array($ref_id, $cart_session)) {
            $card_count = count($_SESSION['reference_cart']);
            if ($card_count < 200) {
              $_SESSION['reference_cart'][] = $ref_id;
              $ref_nodes[] = $ref_id;
              $data = $_SESSION['refined_data'];
              $nfid = is_numeric($exp_node[1]) ? $exp_node[1] : substr($exp_node[1], 0, -1);
              foreach ($data['RowObjects']['e'] as $key => $value) {
                // $nfid = is_numeric($fid) ? $fid : substr($fid, 0, -1);
                if ($value['sourceint1'] == $node_id && $value['sourcestr23'] == 'km file' && $value['sourcecsv23'] == $nfid) {
                  if (!in_array($value['sourceint1'] . "-" . $value['sourcecsv23'], $_SESSION['file_data_cart'])) {
                    $_SESSION['file_data_cart'][$value['sourceint1'] . "-" . $value['sourcecsv23']] = $value;
                    break;
                  }
                }
              }
            }
            $result = TRUE;
          }
        }
      }
    }
    $total_cart = count($_SESSION['reference_cart']) + count($_SESSION['ishowcase_cart']);
    $options = [
      'ref_id' => $ref_nodes,
      'result' => $result,
      'cart_num' => count($_SESSION['reference_cart']),
      'total_cart' => $total_cart,
    ];
    return new JsonResponse($options);
  }
 
  /**
   * Call to request updateReferenceLabel.
   */
  public function updateReferenceLabel($nid) {
    $node = Node::load($nid);
    if ($node instanceof NodeInterface) {
      $group = $node->get('groups')->getValue();
      $gid = $group[0]['target_id'];
    }
    $group = Group::load($gid);
    if ($group instanceof GroupInterface) {
      $group_id = $group->id();
      $group_label = $group->label();
    }
 
    $result[$nid] = '<a href="/group/' . $group_id . '/home" hreflang="en">' . $group_label . '</a>';
    return new JsonResponse($result);
 
  }
 
  /**
   * User load to update fname and lname.
   */
  public function crp_user_load_fname_lname() {
    $a = [];
    $query = \Drupal::database()->select('users_field_data', 'u');
    $query->fields('u', ['uid']);
    $query->condition('u.uid', 0, '<>');
    $query->condition('u.status', 1, '=');
    $query->range(0, 10);
    $result = $query->execute()->fetchall();
    $user_id = array_column($result, 'uid');
    foreach ($user_id as $user) {
      if (!empty($user)) {
        $userload = User::load($user);
        $firstname = $userload->get('field_name_first')->getValue()[0]['value'];
        $lastname = strtoupper($userload->get('field_name_last')->getValue()[0]['value']);
        $query = \Drupal::database()->select('profile', 'p');
        $query->fields('p', ['profile_id']);
        $query->condition('p.uid', $user);
        $result = $query->execute()->fetchAll();
        $profile_id = $result[0]->profile_id;
        $userload->addRole('verified');
        $userload->save();
        if (isset($profile_id)) {
          $profile = Profile::load($profile_id);
          $profile_first_name = ($profile) ? $profile->get('field_profile_first_name')->getValue() : '';
          $profile_last_name = ($profile) ? $profile->get('field_profile_last_name')->getValue() : '';
          if (empty($profile_first_name[0]['value']) || $profile_first_name[0]['value'] != $firstname) {
            $profile->set('field_profile_first_name', $firstname);
            $profile->save();
          }
          if (empty($profile_last_name[0]['value']) || $profile_last_name[0]['value'] != $lastname) {
            $profile->set('field_profile_last_name', $lastname);
            $profile->save();
          }
        }
      }
    }
    return $a;
  }
 
}