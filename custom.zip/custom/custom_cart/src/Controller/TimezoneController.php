<?php
namespace Drupal\custom_cart\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Controller\ControllerBase;

class TimezoneController extends ControllerBase {
  public function setTimezone(Request $request) {
    $timezone = $request->request->get('timezone');
    if ($timezone) {
      \Drupal::request()->getSession()->set('session_local_timezone', $timezone);
      return new JsonResponse(['status' => 'success']);
    }
    return new JsonResponse(['status' => 'error'], 400);
  }
}
