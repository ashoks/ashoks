<?php

namespace Drupal\custom_cart\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

use Drupal\custom_cart\Controller\DefaultController;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "view_cart_block",
 *   admin_label = @Translation("View Cart block"),
 * )
 */
class ViewCart extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $controller_variable = new DefaultController();
    $rendering_in_block = $controller_variable->crp_view_cart();
    return $rendering_in_block;
    /* $renderable = [
    '#theme' => 'crp_view_cart',
    '#items' => 'test variable',
    ];*/

    return $renderable;
    // Return new JsonResponse($references);
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['view_cart_block_settings'] = $form_state->getValue('view_cart_block_settings');
  }

}
