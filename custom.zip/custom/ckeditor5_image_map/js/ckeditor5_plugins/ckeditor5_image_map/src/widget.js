import { Plugin } from 'ckeditor5/src/core';
import { toWidget, toWidgetEditable } from 'ckeditor5/src/widget';
//import { upcastElementToElement } from '@ckeditor/ckeditor5-engine';
//import { downcastElementToElement, downcastAttributeToAttribute, upcastElementToElement } from '@ckeditor/ckeditor5-engine';


export default class ImageMapEditing extends Plugin {
    static get requires() {
        return [];
    }

    static get pluginName() {
        return 'ImageMapEditing';
    }
    init() {
        this._defineSchema();
        this._defineConverters();
    }

    _defineSchema() {
        const schema = this.editor.model.schema;

        schema.register( 'imagemap', {
            isObject: true,
            allowWhere: '$block',
            allowAttributes: ['data']
        });

        schema.register( 'imagemaparea', {
           isObject: true,
            allowWhere: '$block',
            allowAttributes: ['data']
        });

        schema.extend( '$text', {allowAttributes:['mapid']});


    }

    _defineConverters() {
         const conversion = this.editor.conversion;

        // <figure class="imagemap" data="...">
       conversion.for('upcast').elementToElement( {
            model: 'imagemap',
            view: {
                name: 'figure',
                classes: 'imagemap',
             },
           converterPriority: 'high'
       } );

        conversion.for('downcast').elementToElement( {
             model: 'imagemap',
             view: ( modelElement, { writer } ) => {
                 const figure = writer.createContainerElement( 'figure', {
                     class: 'imagemap'
                 } );
                 // Use existing data if available
                 const modelData = modelElement.getAttribute('data')
                 const json = JSON.parse(modelData || '{}');
                 const img = writer.createEmptyElement('img', {
                     src: json.src || 'https://via.placeholder.com/300x200',
                     usemap: '#map-' + modelElement.uid
                 });

                 const map = writer.createContainerElement('map',{
                    name: 'map-' + modelElement.uid
                 });

                 for(const areaData of (json.areas || [])){
                      const area = writer.createEmptyElement('area', {
                         shape: areaData.shape,
                         coords: areaData.coords,
                         href: areaData.href,
                         alt: areaData.alt
                     });
                      writer.insert(area, map)
                 }

                 writer.insert(img, figure);
                 writer.insert(map, figure)
                 return figure;
             },
            converterPriority: 'high'
         } );

         // data attribute
       conversion.for('upcast').attributeToAttribute({
           model: {key: 'data', name: 'imagemap'},
           view: {key: 'data'}
       })

        conversion.for('downcast').attributeToAttribute({
            model: {key: 'data', name: 'imagemap'},
            view: (attributeValue, { writer })=>{
                if(attributeValue){
                    return {key: 'data', value: attributeValue}
                }
            }
        })


       conversion.for('downcast').elementToAttribute(
           {
            model: 'imagemap',
               view: (modelElement, { writer } ) => {
                   return {key: 'mapid', value: modelElement.uid}
               }
           })


       conversion.for('upcast').elementToAttribute({
         view: {name: 'img', attributes:{'usemap': /#map-(.+)/}},
         model: {key: 'mapid', value: (viewElement) => {
                const usemapValue = viewElement.getAttribute('usemap')
                const uid = usemapValue.replace('#map-', '')
               return uid;
           }}
       });



       conversion.for('downcast').elementToElement({
          model: 'imagemaparea',
          view: (modelElement, { writer } ) => {

              const areaData = JSON.parse(modelElement.getAttribute('data'));
                const area = writer.createEmptyElement('area', {
                    shape: areaData.shape,
                    coords: areaData.coords,
                    href: areaData.href,
                    alt: areaData.alt
                });

                return area;
             }
       });

       conversion.for('upcast').attributeToAttribute({
           model: {key: 'data', name: 'imagemaparea'},
           view: {key: 'data'}
       });

       conversion.for('downcast').attributeToAttribute({
           model: {key: 'data', name: 'imagemaparea'},
           view: (attributeValue, { writer })=>{
                if(attributeValue){
                   return {key: 'data', value: attributeValue}
                 }
            }
       })

         // Convert <figure class="imagemap" ...> elements to widgets in the editor.
         conversion.for('editingDowncast').elementToElement({
             model: 'imagemap',
             view: ( modelElement, { writer } ) => {
                 const figure = writer.createContainerElement( 'figure', {
                     class: 'imagemap'
                 } );
                  // Use existing data if available
                 const modelData = modelElement.getAttribute('data')
                 const json = JSON.parse(modelData || '{}');
                 const img = writer.createEmptyElement('img', {
                     src: json.src || 'https://via.placeholder.com/300x200',
                     usemap: '#map-' + modelElement.uid
                 });

                 const map = writer.createContainerElement('map',{
                     name: 'map-' + modelElement.uid
                 });


                for(const areaData of (json.areas || [])){
                     const area = writer.createEmptyElement('area', {
                       shape: areaData.shape,
                        coords: areaData.coords,
                        href: areaData.href,
                        alt: areaData.alt
                    });
                    writer.insert(area, map)
                }
                 writer.insert(img, figure);
                 writer.insert(map, figure)

                 return toWidget( figure, writer, { label: 'Image map widget' } );
             },
             converterPriority: 'high'
         });
    }
}
