
import { Plugin } from 'ckeditor5/src/core';
import { ButtonView } from 'ckeditor5/src/ui';
import ImageMapModal from "./modal";
//import './styles.css';
import Icon from '../theme/icons/ImageMap.svg';

export default class ImageMapUI extends Plugin {

    init() {
        const editor = this.editor;
        const imageMapCommand =  editor.commands.add('imageMap', { execute: () => {} })


        editor.ui.componentFactory.add('imageMap', locale => {
           const view = new ButtonView(locale);
           view.set({
              label: 'Image Map',
              withText: true,
              tooltip: 'Add or Edit Image Map',
              icon: Icon
           });


           view.on('execute', () => {

               const imageElement = this._getSelectedImage(editor.model);


               const imageMapData =  imageElement ? imageElement.getAttribute('data') : null;
               //const isImageMap = imageElement ?  imageElement.findAncestor('imagemap') : false;
               const mapId = imageElement ?  imageElement.getAttribute('mapid') : null;
                new ImageMapModal(editor, imageMapData, mapId, imageElement).show();

            });
           return view;
        });
    }
    _getSelectedImage() {
      const editor = this.editor;

      const selectedElement = editor.model.document.selection.getSelectedElement();

      // Check if the selected element is an image
      if (selectedElement && (selectedElement.name === 'imageBlock' || selectedElement.name === 'imageInline')) {
          const imageElement = selectedElement;

          // Access image attributes like src, alt, etc.

          const entityUuid = imageElement.getAttribute('data-entity-uuid');
          const entityType = imageElement.getAttribute('data-entity-type');



          const imageSrc = imageElement.getAttribute('src');
          const imageAlt = imageElement.getAttribute('alt');
          const imageWidth = imageElement.getAttribute('width');
          const imageHeight = imageElement.getAttribute('height');

          console.log('Selected Image:', {
              src: imageSrc,
              alt: imageAlt,
              width: imageWidth,
              height: imageHeight
          });
          return imageElement;
      } else {
          console.log('No image is selected.');
      }
  }
}
