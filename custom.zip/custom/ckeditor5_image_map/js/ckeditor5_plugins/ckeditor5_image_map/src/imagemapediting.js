import { Plugin } from 'ckeditor5/src/core';
import ImageMapCommand from './imagemapcommand';

export default class ImageMapEditing extends Plugin {
  static get pluginName() {
    return 'ImageMapEditing';
  }

  constructor(editor) {
    super(editor);

    // Define default options for image maps
    editor.config.define('imageMap', {
      options: [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5],
    });
  }

  init() {
    const editor = this.editor;

    // Extend schema to allow <map> and <area> elements
    editor.model.schema.extend('imageBlock', {
      allowAttributes: ['usemap']
    });
    editor.model.schema.extend('imageInline', {
      allowAttributes: ['usemap']
    });

    editor.model.schema.register('map', {
      allowWhere: '$block',
      allowAttributes: ['name'],
      isObject: true,
    });

    editor.model.schema.register('area', {
      allowIn: 'map',
      allowAttributes: ['shape', 'coords', 'href', 'alt', 'target', 'title'],
      isObject: true
    });

    // Ensure attributes are explicitly allowed
    const attributes = ['shape', 'coords', 'href', 'alt', 'target', 'title'];
    attributes.forEach(attr => {
      editor.model.schema.extend('area', { allowAttributes: attr });
    });

    // Define converters
    this._defineConverters();

    // Register Image Map command
    editor.commands.add('imageMap', new ImageMapCommand(editor));
  }

  _defineConverters() {
    const editor = this.editor;

    // Allow 'usemap' attribute in <img> tag
    editor.conversion.attributeToAttribute({
      model: 'usemap',
      view: 'usemap'
    });

    // Convert <map> elements
    editor.conversion.for('upcast').elementToElement({
      view: 'map',
      model: 'map'
    });

    // Convert <area> elements individually
    editor.conversion.for('upcast').elementToElement({
      view: 'area',
      model: (viewElement, { writer }) => {
        return writer.createElement('area', {
          shape: viewElement.getAttribute('shape'),
          coords: viewElement.getAttribute('coords'),
          href: viewElement.getAttribute('href'),
          alt: viewElement.getAttribute('alt'),
          target: viewElement.getAttribute('target'),
          title: viewElement.getAttribute('title')
        });
      }
    });

    editor.conversion.for('downcast').elementToElement({
      model: 'map',
      view: (modelElement, { writer }) => {
        return writer.createContainerElement('map', {
          name: modelElement.getAttribute('name')
        });
      }
    });

    editor.conversion.for('downcast').elementToElement({
      model: 'area',
      view: (modelElement, { writer }) => {
        let areaElement = writer.createEmptyElement('area', {
          shape: modelElement.getAttribute('shape'),
          coords: modelElement.getAttribute('coords'),
          href: modelElement.getAttribute('href'),
          alt: modelElement.getAttribute('alt'),
          target: modelElement.getAttribute('target'),
          title: modelElement.getAttribute('title')
        });

        return areaElement;
      }
    });
  }
}

