import { Plugin } from 'ckeditor5/src/core';
import ImageMapEditing from './widget';
import ImageMapUI from './ui/imagemap';
export default class ImageMap extends Plugin {
    static get requires() {
        return [ ImageMapEditing, ImageMapUI ];
    }

    static get pluginName() {
        return 'ImageMapUI';
    }
}
