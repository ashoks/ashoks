import { Command } from 'ckeditor5/src/core';
import { first } from 'ckeditor5/src/utils';

const IMAGE_MAP = 'imageMap';

export default class ImageMapCommand extends Command {
  refresh() {
    const firstBlock = first(this.editor.model.document.selection.getSelectedBlocks());
    this.isEnabled = !!firstBlock && this._canSetImageMap(firstBlock);
    this.value = (this.isEnabled && firstBlock.hasAttribute(IMAGE_MAP)) ? firstBlock.getAttribute(IMAGE_MAP) : '1';
  }

  execute(options = {}) {
    const editor = this.editor;
    const model = editor.model;
    const doc = model.document;

    const value = options.value;

    model.change(writer => {
      const blocks = Array.from(doc.selection.getSelectedBlocks()).filter(block => this._canSetImageMap(block));
      const currentImageMap = blocks[0].getAttribute(IMAGE_MAP);

      const removeImageMap = /* isDefault( value ) ||  */currentImageMap === value || typeof value === 'undefined';

      if (removeImageMap) {
        removeImageMapFromSelection(blocks, writer);
      }
      else {
        setImageMapOnSelection(blocks, writer, value);
      }
    });
  }

  _canSetImageMap(block) {
    return this.editor.model.schema.checkAttribute(block, IMAGE_MAP);
  }
}

function removeImageMapFromSelection(blocks, writer) {
  for (const block of blocks) {
    writer.removeAttribute(IMAGE_MAP, block);
  }
}

function setImageMapOnSelection(blocks, writer, imageMap) {
  for (const block of blocks) {
    writer.setAttribute(IMAGE_MAP, imageMap, block);
  }
}
