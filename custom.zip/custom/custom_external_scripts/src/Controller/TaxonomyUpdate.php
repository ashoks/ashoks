<?php

namespace Drupal\custom_external_scripts\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\taxonomy\Entity\Term;
use Drupal\node\Entity\Node;

class TaxonomyUpdate extends ControllerBase {
  /**
  * Get body field data from database.
  */
  public function taxonomymigrate() {
    $vocabulary_array = ['sbu', 'partner', 'technologies', 'entry_portfolio', 'offer', 'sector','competitors', 'delivery_market_segment', 'selling_reporting_unit', 'selling_market_segment', 'selling_market_unit', 'selling_business_unit'];
    //$module_path = drupal_get_path('module', 'custom_external_scripts');
    $module_handler = \Drupal::service('module_handler');
    $module_path = $module_handler->getModule('custom_external_scripts')->getPath();
    $file_path = $module_path . '/files/' . date("d_m_Y") . '/taxonomy.xlsx';
    $remap_data = [];
    $flag = [];
    $flag_sheet = '';
    $i = 0;

    if (!file_exists($file_path)) {
      return new Response('File not found!', 404);
    }

    try {
      // Load the excel file.
      $spreadsheet = IOFactory::load($file_path);
      // Get all sheet names.
      $sheet_names = $spreadsheet->getSheetNames();
      $all_sheet_data = [];
      // Iterate through each sheet.
      foreach ($sheet_names as $key => $value) {
        $sheet = $spreadsheet->getSheet($key);
        // Get the data from the sheet.
        $data = $sheet->toArray();
        array_shift($data);
        if (in_array($value, $vocabulary_array)) {
          $all_sheet_data[$value] = $data;
        }
        else {
          $flag[$value] = FALSE;
        }
      }
      foreach($all_sheet_data as $key => $row_data) {
        if (!empty($key) && !empty($row_data)) {
          $remap_data[$key] = self::_taxonomy_migration_action($row_data);
          if(empty($remap_data[$key])) {
            $flag[$key] = FALSE;
          }
        }
      }
      array_shift($flag);
      if (!empty($flag)) {
        foreach ($flag as $key => $value) {
          $i++;
          if ($value == FALSE) {
            if ($i == count($flag)) {
              $flag_sheet.= $key . '.';
            }
            else {
              $flag_sheet.= $key . ', ';
            }
          }
        }
        return new Response('Error in data format for following sheets: ' . $flag_sheet, 500);
      }
      else {
        $header = [
          'rowid' => $this->t('Row ID'),  
          'action' => $this->t('Action'), 
          'oldid' => $this->t('Old term id'), 
          'oldname' => $this->t('Old term name'), 
          'newid' => $this->t('New term id'), 
          'newname' => $this->t('New term name'), 
          'tag' => $this->t('Add to Tag')
        ];
        foreach ($remap_data as $key => $excel_data) {
          $table_rows = self::_taxonomy_migration_make_table($excel_data);
          $output[] = [
            '#markup' => '<h4 align="center" style="background-color: rgba(45, 45, 45, 0.1)">' . $this->t(strtoupper($key)) . '</h4>',
          ];
          $output[] = [
            '#type' => 'table',
            '#header' => $header,
            '#rows' => $table_rows,
          ];
        }

        // $encoded_data = base64_encode(json_encode($remap_data));
        // SAST improper Exception Handling issue fixed below -start 
          try {
            // Attempt to encode the data to JSON with error throwing enabled
            $json = json_encode($remap_data, JSON_THROW_ON_ERROR);
            // Then perform the Base64 encoding
            $encoded_data = base64_encode($json);
          } catch (\JsonException $e) {
            // Log the error details and handle the exception appropriately
            \Drupal::logger('custom_external_scripts')->error('Error encoding taxonomy remap data: ' . $e->getMessage());
            // Optionally, throw a new exception or return an error response
            // throw new \Exception('Error processing taxonomy migration data.');
          }
        // SAST improper Exception Handling issue fixed below -end
        $url = Url::fromRoute('custom_external_scripts.proceedmapping', ['data' => $encoded_data]);
        $output[] = [
          '#markup' => '<div style="text-align:center; margin-top: 20px;"><a href="' . $url->toString() . '" class="btn-anchor">' . $this->t('Proceed Mapping') . '</a></div>',
        ];
        return $output;
      }
      return new Response('There are no more jobs to be performed.', Response::HTTP_OK);
    }
    catch (\Exception $e) {
      return new Response('Error reading Excel file' . $e->getMessage(), 500);
    }
  }

  /*
  * Function to perform action on data.
  * This function makes array as per the action keyword.
  */
  public function _taxonomy_migration_action($row_data) {
    $action_data = [];
    $action_list = self::_taxonomy_migration_excel_action_list();
    if(!empty($row_data)) {
      foreach ($row_data as $key => $data) {
        if (in_array($data[0], $action_list)) {
          $action_data[] = $data;
        }
        else {
          \Drupal::logger('custom_external_scripts_TaxonomyUpdate')->error('Please enter correct action value');
        }
      }
    }
    return $action_data;
  }

  /*
  * Excel sheet action array
  */
  public function _taxonomy_migration_excel_action_list() {
    return [
      '0' => 'remap',
      '1' => 'delete',
      '2' => 'tag',
      '3' => 'to be added',
      '4' => 'rename'
    ];
  }

  /*
  * Function to create table
  */
  public function _taxonomy_migration_make_table($excel_data) {
    // Prepare table header
    $excel_rows = [];
    $excel_rows = self::_taxonomy_migration_format_table_rows($excel_data);

    $table_rows = [];
    foreach($excel_rows as $row) {
      $table_rows[] = [
        'data' => $row,
      ];
    }

    return $table_rows;
  }

  public function _taxonomy_migration_format_table_rows($excel_data) {
    $rows = [];
    $i=0;
    foreach ($excel_data as $data) {
      $rows[] = [['data' => $i + 1, 'align' => 'center'],
                  ['data' => $data[0], 'align' => 'center'],
                  ['data' => $data[1], 'align' => 'center'],
                  ['data' => $data[2], 'align' => 'center'],
                  ['data' => $data[3], 'align' => 'center'],
                  ['data' => $data[4], 'align' => 'center'],
                  ['data' => $data[5], 'align' => 'center']];
      $i++;
    }
    return $rows;
  }

  public function taxonomy_migration_proceed($data) {
  // $decoded_data = !empty($data) ? json_decode(base64_decode($data), TRUE) : '';
  // SAST improper Exception Handling issue fixed below -start 
    try {
      // If $data is not empty, decode the data:
      // First, use base64_decode, then decode the JSON with error throwing enabled.
      $decoded_data = !empty($data) ? json_decode(base64_decode($data), TRUE, 512, JSON_THROW_ON_ERROR) : '';
    } catch (\JsonException $e) {
      // Log the exception for further analysis.
      \Drupal::logger('custom_external_scripts')->error('Error decoding data: @message', ['@message' => $e->getMessage()]);
      // Optionally, you might want to handle the error further.
      $decoded_data = '';
    }
  // SAST improper Exception Handling issue fixed below -end 
    $to_be_added = $rename = $map_data = $term_data = $delete_data = $node_ids = [];
    $vocabulary_name = '';
    $action_name = '';
    $i=0;
    if (!empty($decoded_data)) {
      foreach($decoded_data as $key => $array_data) {
        foreach ($array_data as $record) {
          $vocabulary_name = strtolower($key);
          $action_name = strtolower($record[0]);
          $node_ids[$vocabulary_name][] = isset($record[1]) ? $record[1] : '';
          // To be added
          if (!empty($record[0]) && !empty($record[4])) {
            $to_be_added[$action_name][$vocabulary_name][$i] = $record[4];
            $i++;
          }
          // rename
          if (!empty($record[0]) && !empty($record[1]) && !empty($record[2]) && !empty($record[3]) && !empty($record[4])) {
            $rename[$action_name][$vocabulary_name][$record[1]] = $record[4];
          }
          // Remap
          if (!empty($record[0]) &&  !empty($record[1]) && !empty($record[3])) {
            $map_data[$action_name][$vocabulary_name][$record[1]] = $record[3];
          }
          // Tag
          if(!empty($record[1]) && !empty($record[5])) {
            $term_data['tag'][$vocabulary_name][$record[1]] = $record[5];
          }
          // Delete
          if(!empty($record[1]) && !empty($record[2])) {
            $delete_data[$action_name][$vocabulary_name][$record[1]] = $record[2];
          }
        }
      }
    }

    // Call to taxonomy mapping function
    //self::_taxonomy_migration_node_backup($node_ids);
    // To be added Functionality
    self::_taxonomy_migration_perform_action($to_be_added, 'to be added');
    // Rename Functionality
    self::_taxonomy_migration_perform_action($rename, 'rename');
    // Tag Functionality
    self::_taxonomy_migration_perform_action($term_data, 'tag');
    // Remap Functionality
    self::_taxonomy_migration_perform_action($map_data, 'remap');
    // Delete Functionality
    self::_taxonomy_migration_perform_action($delete_data, 'delete');

    \Drupal::messenger()->addMessage($this->t('Taxonomy migration term updated successfully.'));
    return $this->redirect('custom_external_scripts.taxonomyupdate');
  }

  /*
  * Node backup
  */
  public function _taxonomy_migration_node_backup($node_ids) {
    $encode_data = '';
    if(!empty($node_ids)) {
      // Divide as per voc
      // Pass value to query builder as per tid
      // Get data as per voc and create db backup array
      foreach ($node_ids as $voc => $term_id) {
        foreach ($term_id as $tid) {
          $text = self::_taxonomy_migration_query_result($voc, $tid);
          if (!empty($text)) {
            $data = implode(",",$text);
            $encode_data[$tid][] = base64_encode($data);
          }
        }
      }
    }
    // Insert data in DB
    self::_taxonomy_migration_node_data_insert($encode_data);
  }

  /*
  * Perform mapping action
  */
  public function _taxonomy_migration_perform_action($term_data, $name) {
    //dump($name);
    $terms_id_arr = [];
    if (!empty($term_data)) {
      foreach ($term_data as $action_name => $actions) {
        foreach($actions as $voc_name => $rows) {
          if ($action_name == $name) {
            $terms_id_arr = self::_taxonomy_migration_term_ids($rows);
            self::_taxonomy_migration_mapping($action_name, $voc_name, $terms_id_arr);
          }
        }
      }
    }
    return 0;
  }

  /*
  * make term ids
  */
  public function _taxonomy_migration_term_ids($rows) {
    $term_ids = [];
    if(!empty($rows)) {
      foreach ($rows as $key => $value) {
        $term_ids[$key] = $value;
      }
    }
    return $term_ids;
  }

  /*
  * used to map taxonomy terms as per the requested action
  */
  public function _taxonomy_migration_mapping( $action_name, $vocabulary_name, $term_ids) {

    switch ($action_name) {
      case 'remap':
        switch ($vocabulary_name) {
          case 'sbu':
            $table = 'node__field_entity_sbu';
            $value_column = 'field_entity_sbu_target_id';
            $field_name = 'field_entity_sbu';
            $revision_table = 'node_revision__field_entity_sbu';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'entry_portfolio':
            $table = 'node__field_entry_portfolio';
            $value_column = 'field_entry_portfolio_target_id';
            $field_name = 'field_entry_portfolio';
            $revision_table = 'node_revision__field_entry_portfolio';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'offer':
            $table = 'node__field_offer';
            $value_column = 'field_offer_target_id';
            $field_name = 'field_offer';
            $revision_table = 'node_revision__field_offer';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'sector':
            $table = 'node__field_entity_sector';
            $value_column = 'field_entity_sector_target_id';
            $field_name = 'field_entity_sector';
            $revision_table = 'node_revision__field_entity_sector';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'industry':
            $table = 'node__field_segment';
            $value_column = 'field_segment_target_id';
            $field_name = 'field_segment';
            $revision_table = 'node_revision__field_segment';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'industry_segment':
            $table = 'node__field_subsegment';
            $value_column = 'field_subsegment_target_id';
            $field_name = 'field_subsegment';
            $revision_table = 'node_revision__field_subsegment';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'partner':
            $table = 'node__field_partner';
            $value_column = 'field_partner_target_id';
            $field_name = 'field_partner';
            $revision_table = 'node_revision__field_partner';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'technologies':
            //dump('remap technologies');
            $table = 'node__field_technologies';
            $value_column = 'field_technologies_target_id';
            $field_name = 'field_technologies';
            $revision_table = 'node_revision__field_technologies';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'competitors':
            $table = 'node__field_competitors_rf';
            $value_column = 'field_competitors_rf_target_id';
            $field_name = 'field_competitors_rf';
            $revision_table = 'node_revision__field_competitors_rf';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
          break;
          case 'selling_market_segment':
            $table = 'node__field_selling_market_segment';
            $value_column = 'field_selling_market_segment_target_id';
            $field_name = 'field_selling_market_segment';
            $revision_table = 'node_revision__field_selling_market_segment';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
            break;
          case 'selling_reporting_unit':
            $table = 'node__field_selling_reporting_unit';
            $value_column = 'field_selling_reporting_unit_target_id';
            $field_name = 'field_selling_reporting_unit';
            $revision_table = 'node_revision__field_selling_reporting_unit';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
            break;		 
          case 'delivery_market_segment':
            $table = 'node__field_delivery_market_segment';
            $value_column = 'field_delivery_market_segment_target_id';
            $field_name = 'field_delivery_market_segment';
            $revision_table = 'node_revision__field_delivery_market_segment';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
            break;	
          case 'selling_market_unit':
            $table = 'node__field_selling_market_unit';
            $value_column = 'field_selling_market_unit_target_id';
            $field_name = 'field_selling_market_unit';
            $revision_table = 'node_revision__field_selling_market_unit';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
            break;	
          case 'selling_business_unit':
            $table = 'node__field_selling_business_unit';
            $value_column = 'field_selling_business_unit_target_id';
            $field_name = 'field_selling_business_unit';
            $revision_table = 'node_revision__field_selling_business_unit';
            self::add_term($term_ids, $field_name, $table, $value_column, $revision_table);
            break;	
          default:
            $table = '';
            $value_column = '';
            $term_ids = array();
          break;
        }
        break;
      case 'to be added':
        //$vocabulary_record = self::taxonomy_vocabulary_machine_name_load($vocabulary_name);
        $vocabulary_record = Vocabulary::load($vocabulary_name);
        $vid = $vocabulary_record->id();
        foreach ($term_ids as $term_name) {
          if ($term_name != '') {
            //check if the term is exist before
            $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $term_name,'vid' => $vid,]);

            if (count($term) == 0) {
              //create the new term
              $term = Term::create([
                'name' => $term_name,
                'vid' => $vid,
                'parent' => 0,
              ]);
              $term->save();
            }
          }
        }
        break;
      case 'rename':
        foreach ($term_ids as $tid => $term_name) {
          $term = Term::load($tid);
          if ($term_name != '' && $term->getName() != $term_name) {
            $term->setName($term_name);
            $term->save();
          }
        }
        break;
      case 'delete':
        if (!empty($term_ids)) {
          $tids = $term_ids;
          foreach ($tids as $tid => $terms) {
            $term = Term::load($tid);
            if ($term) {
              $term->delete();
            }
          }
        }
        break;
      case 'tag':
        if (in_array($vocabulary_name, array('sbu','sector'))) {
          $table = 'node__field_entity_'.$vocabulary_name;
          $value_column = 'field_entity_'.$vocabulary_name.'_target_id';
        }
        else if($vocabulary_name == 'industry') {
          $table = 'node__field_segment';
          $value_column = 'field_segment_target_id';
        }
        else if($vocabulary_name == 'industry_segment') {
          $table = 'node__field_subsegment';
          $value_column = 'field_subsegment_target_id';
        }
        else if(in_array($vocabulary_name ,array('portfolio','partner'))) {
          $table = 'node__field_'.$vocabulary_name;
          $value_column = 'field_'.$vocabulary_name.'_target_id';
        }
        else if($vocabulary_name == 'entry_portfolio') {
          $table = 'node__field_entry_portfolio';
          $value_column = 'field_entry_portfolio_target_id';
        }
        else if($vocabulary_name == 'offer') {
          $table = 'node__field_offer';
          $value_column = 'field_offer_target_id';
        }
        elseif($vocabulary_name == 'technologies'){
          $table = 'node__field_technologies';
          $value_column = 'field_technologies_target_id';
        }
        elseif($vocabulary_name == 'competitors'){
          $table = 'node__field_competitors_rf';
          $value_column = 'field_competitors_rf_target_id';
        }
        elseif($vocabulary_name == 'delivery_market_segment'){
          $table = 'node__field_delivery_market_segment';
          $value_column = 'field_delivery_market_segment_target_id';
        }
        elseif($vocabulary_name == 'selling_reporting_unit'){
          $table = 'node__field_selling_reporting_unit';
          $value_column = 'field_selling_reporting_unit_target_id';
        }
        elseif($vocabulary_name == 'selling_market_segment'){
          $table = 'node__field_selling_market_segment';
          $value_column = 'field_selling_market_segment_target_id';
        }
        elseif($vocabulary_name == 'selling_market_unit'){
          $table = 'node__field_selling_market_unit';
          $value_column = 'field_selling_market_unit_target_id';
        }
        elseif($vocabulary_name == 'selling_business_unit'){
          $table = 'node__field_selling_business_unit';
          $value_column = 'field_selling_business_unit_target_id';
        }
        if (!empty($term_ids)) {
          self::tag($term_ids, $table, $value_column);
        }
      default:
        break;
    }
  }

  public function add_term($maps, $field_name, $table, $value_column, $revision_table) {
    $database = \Drupal::database();
    if (count($maps) > 0 && $table != '' && $value_column != '') {
    try{
      foreach ($maps as $old_tid => $new_tid) {
        //echo '<br /> Map from ' . $old_tid . ' to ' . $new_tid;
        //find the new parent id
        //$new_parents = taxonomy_get_parents($new_tid);
        $new_parents = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadParents($new_tid); 
        $new_parent = count($new_parents) === 1 ? array_shift($new_parents) : FALSE;
        $new_parent_tid = $new_parent ? $new_parent->tid->getValue()[0]['value'] : FALSE;
        $new_parent_vocab = $new_parent ? $new_parent->vid->getValue()[0]['target_id'] : FALSE;
        $new_parent_weight = $new_parent ? $new_parent->weight->getValue()[0]['value'] : FALSE;
        //find the old parent id
        //$old_parents = taxonomy_get_parents($old_tid);
        $old_parents = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadParents($old_tid);
        $old_parent = count($old_parents) === 1 ? array_shift($old_parents) : FALSE;
        $old_parent_tid = $old_parent ? $old_parent->tid->getValue()[0]['value'] : FALSE;
        //dump($old_parent_tid);
        $old_parent_vocab = $old_parent ? $old_parent->vid->getValue()[0]['target_id'] : FALSE;
        $new_parent_weight = $old_parent ? $old_parent->weight->getValue()[0]['value'] : FALSE;
        //get all content using old_tid
        $query = $database->query("SELECT entity_id FROM {" . $table . "} WHERE " . $value_column . "= :tid AND bundle!='user'", [':tid' => $old_tid]);
        $nids = $query->fetchAll();
        if ($nids && count($nids) > 0) {
          foreach ($nids as $nid) {
            //echo '<br />Nid:' . $nid;
            $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid->entity_id);
            if ($node) {
              $new_value = $node->get($field_name)->getValue();
              //dump($new_value);
              if (!empty($new_parent) && $new_parent_weight == 0) {
                if ($new_parent_vocab == 'entry_portfolio') {
                  $parent_field_name = 'field_entry_portfolio';
                  $new_value_parent = $node->get($parent_field_name)->getValue();
                }
              }
              //dump($new_value_parent);
              $check_new_parent_exist = FALSE;
              $check_new_tid_exist = FALSE;
              foreach ($node->get($field_name)->getValue() as $key => $old_value) {
                //dump($key);
                //dd($old_value['target_id']);
                //replace the old one by the new one
                if ($old_value['target_id'] == $old_tid) {
                  //echo 'old value == old tid';
                  if (!$check_new_tid_exist) {
                    $new_value[$key]['target_id'] = $new_tid;
                    $check_new_tid_exist = TRUE;
                  }
                  else {
                    unset($new_value[$key]);
                  }
                }
                if ($new_parent_tid && $old_value['target_id'] == $new_parent_tid) {
                  $check_new_parent_exist = TRUE;
                }
              }
              foreach ($node->get($parent_field_name)->getValue() as $key => $old_parent_value) {
                //delete old parent value if we have another parent for the new tid
                if ($old_parent_tid && $new_parent_tid && $old_parent_value['target_id'] == $old_parent_tid && $new_parent_tid != $old_parent_tid) {
                  unset($new_value_parent[$key]);
                }
              }
              if ($new_parent_tid && !$check_new_parent_exist) {
                $new_value_parent[] = array('target_id' => $new_parent_tid);
                if ($new_parent_weight == 0) {
                  if ($new_parent_vocab == 'entry_portfolio') {
                    $node->set('field_entry_portfolio', $new_value_parent);
                  }
                }
                //dump($new_parent_vocab);
                //dd($new_parent_weight);
                //$node->set($field_name, $new_value);
              }
              $node->set($field_name, $new_value);
              $node->save();

              //update the revision table
              if ($new_parent_tid && !$check_new_parent_exist) {
                if ($new_parent_vocab == 'entry_portfolio' && $new_parent_weight == 0) {
                  $parent_revision_table = 'node_revision__field_entry_portfolio';
                  $parent_value_column = 'field_entry_portfolio_target_id';
                }
                if ($new_parent_vocab == 'sector' && $new_parent_weight == 0) {
                  $parent_revision_table = 'node_revision__field_sector';
                  $parent_value_column = 'field_sector_target_id';
                }
                if ($new_parent_vocab == 'sector' && $new_parent_weight == 1) {
                  $parent_revision_table = 'node_revision__field_segment';
                  $parent_value_column = 'field_segment_target_id';
                }
                $database->update($parent_revision_table)
                  ->fields(array(
                    $parent_value_column => $new_parent_tid
                ))
                ->condition('entity_id', $nid)
                ->condition($parent_value_column, $old_parent_tid)
                ->execute();
              }
              $database->update($revision_table)
                ->fields(array(
                  $value_column => $new_tid
              ))
              ->condition('entity_id', $nid)
              ->condition($value_column, $old_tid)
              ->execute();
            }
          }
          \Drupal::entityTypeManager()->getStorage('node')->resetCache($nids);
        }
      }
    }
    catch (Exception $e) {
      drupal_set_message("Add term error: ".$e->getMessage(),'error');
    }
   }
  }

  public function tag($maps, $table, $value_column) {
    /*echo 'Maps-->';
    print_r($maps);
    print '</br>table---';
    print_r($table);*/
    $database = \Drupal::database();
    if (count($maps) > 0 && $table != '' && $value_column != '') {
      foreach ($maps as $tid => $tag_name) {
        $tag_name = trim($tag_name);
        $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $tag_name,'vid' => 'tags',]);
        if ($term && count($term) > 0) {
          $tag = array_shift($term);
        }
        else {
          $tag = Term::create([
            'name' => $tag_name,
            'vid' => 'tags',
          ]);
          $tag->save();
        }
        if ($tag) {
          $tag_id = $tag->tid->getValue()[0]['value'];
          $tag_revision_id = $tag->getRevisionId();
          //load all content using the tid
          $sql_query = $database->query("SELECT entity_id FROM {" . $table . "} WHERE " . $value_column . "= :tid AND bundle!='user'", [':tid' => $tid]);
          $nids = $sql_query->fetchCol();
          if ($nids && count($nids) > 0) {
            foreach ($nids as $nid) {
              $node = Node::load($nid);
              if (!$node) break;
              $exist = FALSE;
              foreach ($node->get('field_tags')->getValue() as $node_tag) {
                if ($node_tag['target_id'] == $tag_id) {
                  $exist = TRUE;
                  break;
                }
              }
              if (!$exist) {
                try {
                  $node_tags = $node->get('field_tags')->getValue();
                  $node_tags[] = ['target_id' => $tag_id];
                  $node->set('field_tags', $node_tags);
                  $node->save();
                  $upsert_query = $database->merge('taxonomy_term__field_author');
                  $upsert_query->keys([
                    'node_id' => $nid, 
                    'entity_id' => $tag_id,
                    'field_author_target_id' => 1,
                  ])
                  ->fields([
                    'node_id' => $nid,
                    'entity_id' => $tag_id,
                    'field_author_target_id' => 1,
                    'bundle' => 'tags',
                    'deleted' => 0,
                    'revision_id' => $tag_revision_id,
                    'language' => 'en',
                    'delta' => 0,
                  ])
                  ->execute();
                }
                catch (Exception $e) {
                  drupal_set_message("Error found: ".$e->getMessage(),'error');
                }
              }
            }
            \Drupal::entityTypeManager()->getStorage('node')->resetCache($nids);
          }
        }
      }
    }
  }
}

  