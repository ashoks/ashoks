<?php

namespace Drupal\custom_external_scripts\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class UpdateBody extends ControllerBase {
  /**
  * Get body field data from database.
  */
  public function getnodes() {
    $entity_id_column = [];
    $field_name_value = $result = '';
    $operations = [];
    $field_name_value = \Drupal::request()->get('field_name');

    if (!empty($field_name_value) && $field_name_value == 'body') {
      $result = $this->select_body_value();
      if (!empty($result)) {
        $entity_id_column =  array_column($result, 'entity_id');
        $result_chunks = array_chunk($entity_id_column, 10);
        foreach ($result_chunks as $result_chunk) {
          $operations[] = [[static::class, 'update_body_value'], [$result_chunk],];
        }
        $batch = [
          'title' => t('Processing items...'),
          'operations' => $operations,
          'finished' => [static::class, 'batchFinished'],
        ];
        batch_set($batch);
        return batch_process();
      }
    }

    if (!empty($field_name_value) && $field_name_value == 'ref-description') {
      $result = $this->select_ref_description_value();
      /*if (!empty($result)) {
        $entity_id_column =  array_column($result, 'entity_id');
        $result_chunks = array_chunk($entity_id_column, 10);
        foreach ($result_chunks as $result_chunk) {
          $operations[] = [[static::class, 'update_ref_description_value'], [$result_chunk],];
        }
        $batch = [
          'title' => t('Processing items...'),
          'operations' => $operations,
          'finished' => [static::class, 'batchFinished'],
        ];
        batch_set($batch);
        return batch_process();
      }*/
    }

    if (!empty($field_name_value) && $field_name_value == 'ref-notes') {
      $result = $this->select_notes_value();
      /*if (!empty($result)) {
        $entity_id_column =  array_column($result, 'entity_id');
        $result_chunks = array_chunk($entity_id_column, 10);
        foreach ($result_chunks as $result_chunk) {
          $operations[] = [[static::class, 'update_ref_notes_value'], [$result_chunk],];
        }
        $batch = [
          'title' => t('Processing items...'),
          'operations' => $operations,
          'finished' => [static::class, 'batchFinished'],
        ];
        batch_set($batch);
        return batch_process();
      }*/
    }
    return new Response(
      'There are no more jobs to be performed.', 
      Response::HTTP_OK
    );
  }

  public function select_body_value() {
    $database = \Drupal::database();
    $result_body = NULL;
    $query = $database->query("CREATE TABLE IF NOT EXISTS `log_update_body_fields` (
      `nid` int(11) NOT NULL,
      `node_type` varchar(255) NOT NULL,
      `old_value` LONGTEXT,
      `new_value` LONGTEXT,
      `date` varchar(20) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    $result = $query->fetchAll();

    $query_body = $database->query("SELECT entity_id FROM {node__body} where body_value LIKE :alias and bundle!='wiki' and entity_id IN (620043)", [':alias' => '%km3.capgemini.com/taxonomy/term/169582%']);
    $result_body = $query_body->fetchAll();

    $query_body_value = $database->query("SELECT entity_id, body_value, bundle FROM {node__body} where body_value LIKE :alias and bundle!='wiki' and entity_id IN (620043)", [':alias' => '%km3.capgemini.com/taxonomy/term/169582%']);
    $result_body_value = $query_body_value->fetchAll();
    /*echo "<table >";
    echo "<tr>";
    echo "<td>";
    echo "NID";
    echo "</td>";
    echo "<td>";
    echo "Node Type";
    echo "</td>";
    echo "<td>";
    echo "KM3 Links";
    echo "</td>";
    echo "</tr>";*/
    foreach($result_body_value as $res) {
      $old_values = '';
      $body_value = $res->body_value;
      $nid = $res->entity_id;
      $node_type = $res->bundle;
      //$find = 'km3.capgemini.com';
      //$pattern = '/(?:https?:\/\/)?' . preg_quote($find, '/') . '(?:\/[^\s"<]*)?/';
      $pattern = '/(?:https?:\/\/)?km3\.capgemini\.com\/taxonomy\/term\/169582[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);
      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $old_values.= $match . ', ';
        }
        else {
          $old_values.= $match;
        }
      }
      if ((\Drupal::database()->schema()->tableExists('log_update_body_fields'))) {
        $query_log_value = $database->query("SELECT nid, old_value FROM {log_update_body_fields} where nid = :nid", [':nid' => $nid]);
        $result_log_value = $query_log_value->fetchAll();
        if (empty($result_log_value)) {
          $data = [
            'nid' => $nid,
            'node_type' => $node_type,
            'old_value' => $old_values,
            'date' => \Drupal::time()->getRequestTime(),
          ];
          $insert_id = Database::getConnection()->insert('log_update_body_fields')
            ->fields($data)
            ->execute();
          \Drupal::logger('custom_external_scripts')->info('Record inserted in log_update_body_fields with ID: @id', ['@id' => $insert_id]);
        }
        else {
          $existing_old_value = $result_log_value[0]->old_value;
          $num_updated_rows = $database->update('log_update_body_fields')
            ->fields([
              'old_value' => $existing_old_value . ', ' . $old_values,
              'date' => \Drupal::time()->getRequestTime(),
            ])
          ->condition('nid', $nid, '=')
          ->execute();
        }
      }
      /*echo "<tr>";
      echo "<td>";
      echo $nid; 
      echo "</td>";
      echo "<td>";
      echo $node_type; 
      echo "</td>";
      echo "<td>";
      echo $old_values; 
      echo "</td>";
      echo "</tr></br>";*/
    }
    //echo "</table>";exit;
    return $result_body;
  }

  public function select_ref_description_value() {
    $database = \Drupal::database();
    $result_ref_description = NULL;
    $query = $database->query("CREATE TABLE IF NOT EXISTS `log_update_body_fields` (
      `nid` int(11) NOT NULL,
      `node_type` varchar(255) NOT NULL,
      `old_value` LONGTEXT,
      `new_value` LONGTEXT,
      `date` varchar(20) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    $result = $query->fetchAll();

    $query_ref_description = $database->query("SELECT entity_id FROM {node__field_reference_description} where field_reference_description_value LIKE :alias", [':alias' => '%km3.capgemini.com/asset/194769%']);
    $result_ref_description = $query_ref_description->fetchAll();

    $query_ref_description_value = $database->query("SELECT entity_id, field_reference_description_value, bundle FROM {node__field_reference_description} where field_reference_description_value LIKE :alias", [':alias' => '%km3.capgemini.com/asset/194769%']);
    $result_ref_description_value = $query_ref_description_value->fetchAll();
    /*echo "<table >";
    echo "<tr>";
    echo "<td>";
    echo "NID";
    echo "</td>";
    echo "<td>";
    echo "Node Type";
    echo "</td>";
    echo "<td>";
    echo "KM3 Links";
    echo "</td>";
    echo "</tr>";*/
    foreach($result_ref_description_value as $res) {
      $old_values = '';
      $body_value = $res->field_reference_description_value;
      $nid = $res->entity_id;
      $node_type = $res->bundle;
      //$find = 'km3.capgemini.com';
      //$pattern = '/(?:https?:\/\/)?' . preg_quote($find, '/') . '(?:\/[^\s"<]*)?/';
      $pattern = '/(?:https?:\/\/)?km3\.capgemini\.com\/asset\/194769[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);
      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $old_values.= $match . ', ';
        }
        else {
          $old_values.= $match;
        }
      }
      if ((\Drupal::database()->schema()->tableExists('log_update_body_fields'))) {
        $query_log_value = $database->query("SELECT nid, old_value FROM {log_update_body_fields} where nid = :nid", [':nid' => $nid]);
        $result_log_value = $query_log_value->fetchAll();
        if (empty($result_log_value)) {
          $data = [
            'nid' => $nid,
            'node_type' => $node_type,
            'old_value' => $old_values,
            'date' => \Drupal::time()->getRequestTime(),
          ];
          $insert_id = Database::getConnection()->insert('log_update_body_fields')
            ->fields($data)
            ->execute();
          \Drupal::logger('custom_external_scripts')->info('Record inserted in log_update_body_fields with ID: @id', ['@id' => $insert_id]);
        }
        else {
          $existing_old_value = $result_log_value[0]->old_value;
          $num_updated_rows = $database->update('log_update_body_fields')
            ->fields([
              'old_value' => $existing_old_value . ', ' . $old_values,
              'date' => \Drupal::time()->getRequestTime(),
            ])
          ->condition('nid', $nid, '=')
          ->execute();
        }
      }
      /*echo "<tr>";
      echo "<td>";
      echo $nid; 
      echo "</td>";
      echo "<td>";
      echo $node_type; 
      echo "</td>";
      echo "<td>";
      echo $old_values; 
      echo "</td>";
      echo "</tr></br>";*/
    }
    //echo "</table>";exit;
    return $result_ref_description;
  }

  public function select_notes_value() {
    $database = \Drupal::database();
    $result_ref_notes = NULL;
    /*$query = $database->query("CREATE TABLE IF NOT EXISTS `log_update_body_fields` (
      `nid` int(11) NOT NULL,
      `node_type` varchar(255) NOT NULL,
      `old_value` LONGTEXT,
      `new_value` LONGTEXT,
      `date` varchar(20) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    $result = $query->fetchAll();*/

    $query_ref_notes = $database->query("SELECT entity_id FROM {node__field_notes} where field_notes_value LIKE :alias", [':alias' => '%km3.capgemini.com%']);
    $result_ref_notes = $query_ref_notes->fetchAll();

    $query_ref_notes_value = $database->query("SELECT entity_id, field_notes_value, bundle FROM {node__field_notes} where field_notes_value LIKE :alias", [':alias' => '%km3.capgemini.com%']);
    $result_ref_notes_value = $query_ref_notes_value->fetchAll();
    echo "<table >";
    echo "<tr>";
    echo "<td>";
    echo "NID";
    echo "</td>";
    echo "<td>";
    echo "Node Type";
    echo "</td>";
    echo "<td>";
    echo "KM3 Links";
    echo "</td>";
    echo "</tr>";
    foreach($result_ref_notes_value as $res) {
      $old_values = '';
      $body_value = $res->field_notes_value;
      $nid = $res->entity_id;
      $node_type = $res->bundle;
      $find = 'km3.capgemini.com';
      $pattern = '/(?:https?:\/\/)?' . preg_quote($find, '/') . '(?:\/[^\s"<]*)?/';
      //$pattern = '/(?:https?:\/\/)?km3\.capgemini\.com\/files\/[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);
      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $old_values.= $match . ', ';
        }
        else {
          $old_values.= $match;
        }
      }
      /*if ((\Drupal::database()->schema()->tableExists('log_update_body_fields'))) {
        $query_log_value = $database->query("SELECT nid, old_value FROM {log_update_body_fields} where nid = :nid", [':nid' => $nid]);
        $result_log_value = $query_log_value->fetchAll();
        if (empty($result_log_value)) {
          $data = [
            'nid' => $nid,
            'node_type' => $node_type,
            'old_value' => $old_values,
            'date' => \Drupal::time()->getRequestTime(),
          ];
          $insert_id = Database::getConnection()->insert('log_update_body_fields')
            ->fields($data)
            ->execute();
          \Drupal::logger('custom_external_scripts')->info('Record inserted in log_update_body_fields with ID: @id', ['@id' => $insert_id]);
        }
        else {
          $existing_old_value = $result_log_value[0]->old_value;
          $num_updated_rows = $database->update('log_update_body_fields')
            ->fields([
              'old_value' => $existing_old_value . ', ' . $old_values,
              'date' => \Drupal::time()->getRequestTime(),
            ])
          ->condition('nid', $nid, '=')
          ->execute();
        }
      }*/
      echo "<tr>";
      echo "<td>";
      echo $nid; 
      echo "</td>";
      echo "<td>";
      echo $node_type; 
      echo "</td>";
      echo "<td>";
      echo $old_values; 
      echo "</td>";
      echo "</tr></br>";
    }
    echo "</table>";exit;
    return $result_ref_notes;
  }

  public static function update_body_value($result_chunk, &$context) {
    $database = \Drupal::database();
    $connection = Database::getConnection();

    foreach ($result_chunk as $entity_id) {
      $new_values = '';
      \Drupal::logger('custom_external_scripts_update_body')->info('Inside Update Body Value');
      \Drupal::logger('custom_external_scripts_update_body')->info('Processing: @item', ['@item' => $entity_id]);
      $context['message'] = t('Processing @item', ['@item' => $entity_id]);

      $find = 'km3.capgemini.com/taxonomy/term/169582';
      $replace = 'prism.capgemini.com/community-tag-clouds/169582/1072973';
      $query = $connection->update('node__body')
        ->expression('body_value', 'REPLACE(body_value, :old, :new)', [':old' => $find, ':new' => $replace])
        ->condition('entity_id', $entity_id);
      $query->execute();

      $query_body_value = $database->query("SELECT body_value FROM {node__body} where entity_id = :entity_id AND body_value LIKE :alias and bundle!='wiki'", [':entity_id' => $entity_id, ':alias' => '%prism.capgemini.com/community-tag-clouds/169582/1072973%']);
      $result_body_value = $query_body_value->fetchAll();
      $body_value = $result_body_value[0]->body_value;
      //$pattern = '/(?:https?:\/\/)?' . preg_quote($replace, '/') . '\/[^\s"]*/';
      $pattern = '/(?:https?:\/\/)?prism\.capgemini\.com\/community\-tag\-clouds\/169582\/1072973[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);

      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $new_values.= $match . ', ';
        }
        else {
          $new_values.= $match;
        }
      }

      $query_log_value = $database->query("SELECT nid, new_value FROM {log_update_body_fields} where nid LIKE :nid", [':nid' => $entity_id]);
      $result_log_value = $query_log_value->fetchAll();
      $existing_new_value = $result_log_value[0]->new_value;
      $num_updated_rows = $database->update('log_update_body_fields')
        ->fields([
          'new_value' => $existing_new_value . ', ' . $new_values,
          'date' => \Drupal::time()->getRequestTime(),
        ])
        ->condition('nid', $entity_id, '=')
        ->execute();
    }

    $context['results'][] = $entity_id;
    \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $context['results'])]));
    //\Drupal::logger('custom_external_scripts_update_body')->info('<pre>' . print_r($context) . '</pre>');
  }

  public static function update_ref_description_value($result_chunk, &$context) {
    $database = \Drupal::database();
    $connection = Database::getConnection();

    foreach ($result_chunk as $entity_id) {
      $new_values = '';
      \Drupal::logger('custom_external_scripts_update_body')->info('Inside Update Ref Description Value');
      \Drupal::logger('custom_external_scripts_update_body')->info('Processing: @item', ['@item' => $entity_id]);
      $context['message'] = t('Processing @item', ['@item' => $entity_id]);

      $find = 'km3.capgemini.com/asset/194769';
      $replace = 'prism.capgemini.com/asset/194769';
      $query = $connection->update('node__field_reference_description')
        ->expression('field_reference_description_value', 'REPLACE(field_reference_description_value, :old, :new)', [':old' => $find, ':new' => $replace])
        ->condition('entity_id', $entity_id);
      $query->execute();

      $query_body_value = $database->query("SELECT field_reference_description_value FROM {node__field_reference_description} where entity_id = :entity_id AND field_reference_description_value LIKE :alias", [':entity_id' => $entity_id, ':alias' => '%prism.capgemini.com/asset/194769%']);
      $result_body_value = $query_body_value->fetchAll();
      $body_value = $result_body_value[0]->field_reference_description_value;
      //$pattern = '/(?:https?:\/\/)?' . preg_quote($replace, '/') . '\/[^\s"]*/';
      $pattern = '/(?:https?:\/\/)?prism\.capgemini\.com\/asset\/194769[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);

      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $new_values.= $match . ', ';
        }
        else {
          $new_values.= $match;
        }
      }

      $query_log_value = $database->query("SELECT nid, new_value FROM {log_update_body_fields} where nid LIKE :nid", [':nid' => $entity_id]);
      $result_log_value = $query_log_value->fetchAll();
      $existing_new_value = $result_log_value[0]->new_value;
      $num_updated_rows = $database->update('log_update_body_fields')
        ->fields([
          'new_value' => $existing_new_value . ', ' . $new_values,
          'date' => \Drupal::time()->getRequestTime(),
        ])
        ->condition('nid', $entity_id, '=')
        ->execute();
    }

    $context['results'][] = $entity_id;
    \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $context['results'])]));
    //\Drupal::logger('custom_external_scripts_update_body')->info('<pre>' . print_r($context) . '</pre>');
  }

  public static function update_ref_notes_value($result_chunk, &$context) {
    $database = \Drupal::database();
    $connection = Database::getConnection();

    foreach ($result_chunk as $entity_id) {
      $new_values = '';
      \Drupal::logger('custom_external_scripts_update_body')->info('Inside Update Ref Notes Value');
      \Drupal::logger('custom_external_scripts_update_body')->info('Processing: @item', ['@item' => $entity_id]);
      $context['message'] = t('Processing @item', ['@item' => $entity_id]);

      $find = 'km3.capgemini.com/files/';
      $replace = 'prism.capgemini.com/files/';
      $query = $connection->update('node__field_notes')
        ->expression('field_notes_value', 'REPLACE(field_notes_value, :old, :new)', [':old' => $find, ':new' => $replace])
        ->condition('entity_id', $entity_id);
      $query->execute();

      $query_body_value = $database->query("SELECT field_notes_value FROM {node__field_notes} where entity_id = :entity_id AND field_notes_value LIKE :alias", [':entity_id' => $entity_id, ':alias' => '%prism.capgemini.com/files/%']);
      $result_body_value = $query_body_value->fetchAll();
      $body_value = $result_body_value[0]->field_notes_value;
      //$pattern = '/(?:https?:\/\/)?' . preg_quote($replace, '/') . '\/[^\s"]*/';
      $pattern = '/(?:https?:\/\/)?prism\.capgemini\.com\/files\/[^\s"<]*/';
      preg_match_all($pattern, $body_value, $matches);
      $lastKey = array_key_last($matches[0]);

      foreach($matches[0] as $key => $match) {
        if($key != $lastKey) {
          $new_values.= $match . ', ';
        }
        else {
          $new_values.= $match;
        }
      }

      $query_log_value = $database->query("SELECT nid, new_value FROM {log_update_body_fields} where nid LIKE :nid", [':nid' => $entity_id]);
      $result_log_value = $query_log_value->fetchAll();
      $existing_new_value = $result_log_value[0]->new_value;
      $num_updated_rows = $database->update('log_update_body_fields')
        ->fields([
          'new_value' => $existing_new_value . ', ' . $new_values,
          'date' => \Drupal::time()->getRequestTime(),
        ])
        ->condition('nid', $entity_id, '=')
        ->execute();
    }

    $context['results'][] = $entity_id;
    \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $context['results'])]));
    //\Drupal::logger('custom_external_scripts_update_body')->info('<pre>' . print_r($context) . '</pre>');
  }

  public static function batchFinished($success, $results, $operations) {
    if ($success) {
      \Drupal::messenger()->addMessage(t('Batch Completed successfully.'));
      \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $results)]));
    }
    else {
      \Drupal::messenger()->addMessage(t('Batch processing encountered errors.'), 'error');
    }
  }
}
