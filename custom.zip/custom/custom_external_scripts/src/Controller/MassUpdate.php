<?php

namespace Drupal\custom_external_scripts\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Drupal\node\Entity\Node;

class MassUpdate extends ControllerBase {
  /**
   * Function to perform mass updates on KOs.
   */
  public function mass_update() {
    $list_nid = array(78);
    $nid_chunks = array_chunk($list_nid, 2);
    foreach ($nid_chunks as $nid_chunk) {
      $operations[] = [[static::class, 'update_ko_fields'], [$nid_chunk],];
    }
    $batch = [
      'title' => t('Processing items...'),
      'operations' => $operations,
      'finished' => [static::class, 'batchFinished'],
    ];
    batch_set($batch);
    return batch_process();
  }

  public static function batchFinished($success, $results, $operations) {
    if ($success) {
      \Drupal::messenger()->addMessage(t('Batch Completed successfully.'));
      \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $results)]));
    }
    else {
      \Drupal::messenger()->addMessage(t('Batch processing encountered errors.'), 'error');
    }
  }

  public static function update_ko_fields($result_chunk, &$context) {
    $database = \Drupal::database();
    $connection = Database::getConnection();

    foreach ($result_chunk as $entity_id) {
      try {
        $node = Node::load($entity_id);
        $type = $node->type->getValue()[0]['target_id'];

        /* CHANGE OWNER NAME */
        /* if ($type=='reference') { 
          $node->set('field_author', 1748190);
          $node->save();
          echo 'done ' . $nid . '</br>';
        } */ 

        /* CHANGE ACCOUNT CATEGORY */
        /* if ($type=='reference') {
          $node->set('field_account_category', Standard);
          $node->save();
          echo 'done ' . $nid . '</br>';
        } */

        /* CHANGE NODE STATUS */
        //if ($type=='asset') {
          // Status : 0 = Live - Not reviewed by Community Leaders/Moderators, 1 = Live Gold - Validated by Community Leaders/Moderators, 2 = Archived.

          // Asset Status Update.
          /* if ($node->hasField('field_status')) {
            $node->set('field_status', 2);
            $node->save();
            echo 'done ' . $entity_id . '</br>';
          } */

          // Reference Status Update.
          /* if ($node->hasField('field_status_rf')) {
            $node->set('field_status_rf', 2);
            $node->save();
            echo 'done ' . $entity_id . '</br>';
          } */
        //}

        /* CHANGE OPPORTUNITY ID */
        /* if ($type=='reference' && $node->hasField('field_opportunity_id')) {
          $node->set('field_opportunity_id', 'OP# 00943021');
          $node->save();
          echo 'done ' . $nid . '</br>';
        } */

        /* Add carbon client and sustainability benefit default values */
        /* if ($type=='reference') {
          if(empty($node->field_client_carbon_benefit) && empty($node->field_sustainability_benefit)) {
          $node->field_client_carbon_benefit[LANGUAGE_NONE][0]['value'] = 0;
          $node->field_sustainability_benefit[LANGUAGE_NONE][0]['value'] = 0;
          $node->save();
          echo 'done ' . $nid . '</br>';
          }
        } */

        /* if($type=='book'){
          $node->og_group_ref[LANGUAGE_NONE][0]['target_id'] = 532048;
          $node->save();
          echo 'done ' . $nid . '</br>';
        } */

        /* if($type=='asset'){ // MOVE ASSET FROM ONE COMMUNITY TO ANOTHER COMMUNITY
          $node->og_group_ref['und'][0]['target_id'] = 1072973;
          $node->save();
          echo 'done ' . $nid . '</br>';
        }*/

        /* if($type=='reference'){
          $node->field_client[LANGUAGE_NONE][0]['value'] = 'CVS Corporation';
          $node->field_ultimate_parent_account[LANGUAGE_NONE][0]['value'] = 'CVS Corporation';
          $node->save();
          echo 'done ' . $nid . '</br>';
        } */

        /* UPDATING NODE BY CHANGING TIMESTAMP */
        /*if ($type=='asset') {
          //$today = date("d-m-Y");
          $todaytimestamp = strtotime("now");
          $node->set('changed', $todaytimestamp);
          $node->set('revision_timestamp', $todaytimestamp);
          $node->save();
          echo 'done ' . $nid . '</br>';
        }*/
      }
      catch (Exception $e) {
        drupal_set_message("Error in Mass Update: ".$e->getMessage(),'error');
      }
    }
    \Drupal::entityTypeManager()->getStorage('node')->resetCache($result_chunk);
  }
}