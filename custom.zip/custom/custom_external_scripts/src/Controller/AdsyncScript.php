<?php

namespace Drupal\custom_external_scripts\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class AdsyncScript extends ControllerBase {

  /**
  * Delete non-existing users from Database.
  */
  /*public function deleteusers() {
    $uids = [];
    // Connect with LDAP with username and password
    // Retrieve user ids
    $uids = self::get_ldap_users_uid();
  }*/

  /*
  * Connect with LDAP with username and password
  * Retrieve user ids
  */
  public function get_ldap_users_uid() {
    $config     = \Drupal::service('config.factory')->getEditable('variable_get_set.api');
    $operations = [];
    $names_arr = [];
    $arr = [];
    $ldapserver = 'ldapfr.capgemini.com';//;//ldap.capgemini.com
    $port       = 3268;
    $ldapuser   = 'svc-cor-km3';
    $ldappass   = base64_decode('U3VwcEBydEAhMjAyNVByaSRt');
    // Below settings to fetch active users in CORP Directory
    $ldaptree   = 'OU=Employees,DC=corp,DC=capgemini,DC=com';
    $filter     = "(&(objectClass=user))"; //"(&(objectClass=user)(cn=AABELLAN))"; // (&(objectClass=user)(whenCreated>=$when_created));
    $justthese = array("cn");
    // Below settings to fetch disabled users in CORP Directory
    /*$ldaptree   = 'OU=Leaver,DC=corp,DC=capgemini,DC=com';
    $filter     = "(&(objectClass=user)(whenchanged>=20241101000000.0Z)(employeeType=Employee))";
    $justthese = array("cn","whenchanged"); //cn: CORP ID;; sn: Last Name;; givenname: First Name;; displayname: Full Name;; mail: email*/
    $uid_res = [];
    
    // connect
    $ldapconn = ldap_connect($ldapserver, $port) or die("Could not connect to LDAP server.");
    if($ldapconn) {
      // binding to ldap server
      $ldapbind = ldap_bind($ldapconn, 'corp\\' . $ldapuser, $ldappass) or die ("Error trying to bind: ".ldap_error($ldapconn));
      // verify binding
      if ($ldapbind) {
        $names = '';
        $arr_users_not_delete = ['S-GLPRODESEARCHKM3','S-GUATESEARCHKM30','ecmkm30','ecmkm20','SVC-CORP-SGDRESEARCH','S-GINTESEARCHKM30','SVC-CORP-ESCLOUDVIEW','S-GLOBALTESTKM20'];
        //echo "LDAP bind successful...<br /><br />";
        $result = ldap_search($ldapconn, $ldaptree, $filter, $justthese) or die ("Error in search query: ".ldap_error($ldapconn));
        //dd($result);
        $data = ldap_get_entries($ldapconn, $result);
        // all done? clean up
        ldap_close($ldapconn);
        for ($i=0; $i<$data["count"]; $i++) {
          $character = '';
          if($i < ($data["count"]-1)) $character = ',';
          $names .= "'" . $data[$i]["cn"][0] . "'" . $character;
          $names_arr[] = $data[$i]["cn"][0];
          //print_r($data[$i]["cn"][0]);echo '</br>';
          //print_r($data[$i]["whenchanged"][0]);echo '</br></br></br></br></br>';
        }
        if ($names_arr) {
          $query = \Drupal::database()->select('users_field_data', 'u');
          $query->fields('u', ['uid', 'name']);
          $query->condition('u.name', 'superadmin', '<>');
          $query->condition('u.uid', 0, '<>');
          //$query->condition('u.mail', '%@capgemini.com', 'LIKE');
          $query->condition('u.status', 1, '=');
          $query->condition('u.name', $arr_users_not_delete, 'NOT IN');
          $query->condition('u.name', $names_arr, 'NOT IN');
          $query->orderBy('u.uid', 'ASC');
          $query->range(0, 1);
          $results = $query->execute()->fetchAll();
          if (!empty($results)) {
            foreach ($results as $value) {
              $uid_res[] = $value->uid;
            }
            //print '<pre>';print_r($uid_res);exit;
          }
        }
      }
    }
    if(!empty($uid_res)) {
      $nodes_ids = '';
      foreach ($uid_res as $uid) {
        $nodes_ids = '';
        $nids = '';
        $query = \Drupal::entityQuery('node');
        $result = $query
          ->accessCheck(TRUE)
          ->condition('uid', $uid)
          ->execute();

        $nodes_ids = isset($result) && !empty($result) ? array_values($result) : '';
        //print '<pre>';print_r($uid);
        //print '<pre>';print_r($nodes_ids);
        if (!empty($nodes_ids)) {
          $nids = implode(",", $nodes_ids);
          $status = 'Pending';
          self::insert_block_user_data($uid,$nids,$status);
        }
        else{
          $nids = 0;
          $status = 'NA';
          self::insert_block_user_data($uid,$nids,$status);
        }
      }
      //exit;
      //return $uid_res;
      
    }
    else {
      print "</br>";
      print "Users are not available to delete.";
      \Drupal::logger('custom_external_scripts')->info("Users are not available to delete. ".date("d-m-Y h:i:sa "));
    }

    // Node update as anonymous
    $nodes = self::get_user_node_ids();
    if (!empty($nodes)) {
      foreach ($nodes as $uid => $node_id) {
        $nid = explode(",", $node_id);
        self::update_node_author($uid, $nid);
      }
    }
    // Delete leavers user profile
    self::delete_user_profile($uid_res);

    // Delete contacts for leavers user profiles.
    self::delete_contacts();

    // Delete other contributors for leavers user profiles.
    self::delete_other_contribs();

    return new Response(
      'There are no more jobs to be performed.', 
      Response::HTTP_OK
    );
  }

  /*public function setvariables() {
    $config = \Drupal::service('config.factory')->getEditable('variable_get_set.api');
    $config->set('ldap_server', '10.247.131.30');
    $config->set('ldap_port', 3268);
    $config->set('ldap_basedn', 'OU=Employees,DC=corp,DC=capgemini,DC=com');
    $config->set('users_not_delete', 'S-GLPRODESEARCHKM3','S-GUATESEARCHKM30','ecmkm30','ecmkm20','SVC-CORP-SGDRESEARCH','S-GINTESEARCHKM30','SVC-CORP-ESCLOUDVIEW','S-GLOBALTESTKM20');
    $config->save();
  }*/

  public static function insert_block_user_data($uid,$nids,$status) {
    $table_name = 'ldap_blocked_user_logs';
    if ((\Drupal::database()->schema()->tableExists($table_name))) {
      $data = [
        'uid' => $uid,
        'nodes' => $nids,
        'status' => $status,
        'created' => \Drupal::time()->getRequestTime(),
      ];
      $insert_id = Database::getConnection()->insert('ldap_blocked_user_logs')
        ->fields($data)
        ->execute();
      \Drupal::logger('custom_external_scripts')->info('Record inserted with ID: @id', ['@id' => $insert_id]);
    }
  }

  public static function get_user_node_ids() {
    $node_id = [];
    $database = \Drupal::database();
    $query = $database->query("SELECT uid,nodes FROM ldap_blocked_user_logs where status = 'Pending' and nodes !=0 ");
    $result = $query->fetchAll();
    foreach ($result as $value) {
      $node_id[$value->uid] = $value->nodes;
    }
    return $node_id;
  }

  public static function update_node_author($uid, $nids) {
    $check = 0;
    $database = \Drupal::database();
    // update node revision for update and system date
    foreach ($nids as $nodevalue) {
      // first get vid from node_revision
      $vid = self::get_node_vid($nodevalue);
      \Drupal::logger('custom_external_scripts')->info('VID: @vid', ['@vid' => $vid]);
      //node count
      $node_count = self::get_node_revision_count($uid, $nodevalue, $vid);
      \Drupal::logger('custom_external_scripts')->info('Node count: @node_count', ['@node_count' => $node_count]);
      if ($node_count > 0) {
        $num_updated_rows = $database->update('node_revision')
          ->fields([
            'revision_uid' => 0,
            'revision_timestamp' => \Drupal::time()->getRequestTime(),
          ])
          ->condition('revision_uid', $uid, '=')
          ->condition('nid', $nodevalue, '=')
          ->condition('vid', $vid, '=')
          ->execute();
        \Drupal::logger('custom_external_scripts')->info('Node ": @nodevalue have been updated for uid: @uid', ['@nodevalue' => $nodevalue, '@uid' => $uid]);
        print '</br>';
        echo  'Node '.$nodevalue.' have been updated for uid '.$uid;
        print '</br>';
      }
      else {
        $timestamp_updated_rows = $database->update('node_revision')
          ->fields([
            'revision_timestamp' => \Drupal::time()->getRequestTime(),
          ])
          ->condition('nid', $nodevalue, '=')
          ->condition('vid', $vid, '=')
          ->execute();

        print '</br>';
        echo  'Row updated for node id '.$nodevalue;
        print '</br>';
      }
    }
    // get nids from node revision which were created by another user but updated by $uid
    $get_revision_nid = self::get_updated_nids($uid);
    // Update node_revision table
    if (!empty($get_revision_nid)) {
      foreach($get_revision_nid as $key => $values) {
        $num_updated_rows = $database->update('node_revision')
          ->fields([
            'revision_uid' => 0,
            'revision_timestamp' => \Drupal::time()->getRequestTime(),
          ])
          ->condition('revision_uid', $uid, '=')
          ->condition('nid', $values->nid, '=')
          ->condition('vid', $values->vid, '=')
          ->execute();

        print '</br>';
        echo  'Node ' . $values->nid . ' has been updated for vid ' . $values->vid . 'for uid '.$uid;
        print '</br>';	
      }
    }
    // update node table for creator and system date
    $database->update('node_field_data')
      ->fields([
        'uid' => 0,
        'changed' => \Drupal::time()->getRequestTime(),
      ])
      ->condition('nid', $nids, 'IN')
      ->condition('uid', $uid, '=')
      ->execute();

    $database->update('node__field_author')
      ->fields([
        'field_author_target_id' => 0,
      ])
      ->condition('entity_id', $nids, 'IN')
      ->condition('field_author_target_id', $uid, '=')
      ->execute();  
    
    \Drupal::logger('custom_external_scripts')->info('Author uid : @uid has been successfully updated for nodes', ['@uid' => $uid]);
    //error_log("\n Author uid (".$uid.") have been updated successfully for nodes", 3, LDAP_SUCCESS_LOG);
    $check = 1;

    if ($check == 1) {
      $database->update('ldap_blocked_user_logs')
        ->fields([
          'status' => 'Completed',
          'updated' => \Drupal::time()->getRequestTime(),
        ])
        ->condition('uid', $uid, '=')
        ->execute();
    }
  }

  /*
   * Get node revision user count
   */
  public static function get_node_vid($nid) {
    $vid = '';
    $database = \Drupal::database();
    $query = $database->query("SELECT vid FROM node_field_data where nid = ".$nid."");
    $result = $query->fetchAll();
    foreach ($result as $value) {
      $vid = $value->vid;
    }
    if(!empty($vid)) {
      \Drupal::logger('custom_external_scripts')->info('Node vid : @vid and node: @nid', ['@vid' => $vid, '@nid' => $nid]);
      //error_log("\n Node vid ".$vid." and node ".$nid, 3, LDAP_SUCCESS_LOG);
    }
    return $vid;
  }

  /*
   * Get node revision user count
   */
  public static function get_node_revision_count($uid, $nid, $vid) {
    $node_count = '';
    $database = \Drupal::database();
    $query = $database->query("SELECT count(nid) as nid_count FROM node_revision where revision_uid = ".$uid." and nid = ".$nid." and vid = ".$vid."");
    $ndresult = $query->fetchAll();
    foreach ($ndresult as $value) {
      $node_count = $value->nid_count;
    }
    if(!empty($node_count)) {
      \Drupal::logger('custom_external_scripts')->info('Node count ": @node_count for user id: @uid and node: @nid', ['@node_count' => $node_count, '@uid' => $uid, '@nid' => $nid]);
      //error_log("\n Node count ".$node_count." for user id ".$uid." and node ".$nid, 3, LDAP_SUCCESS_LOG);
    }
    return $node_count;
  }

  /*
   * Get node revision for updated nodes
   */
  public static function get_updated_nids($uid) {
    $updated_nids = [];
    $database = \Drupal::database();
    $query = $database->query("SELECT nid, vid FROM node_revision where revision_uid = ".$uid."");
    $updated_nids = $query->fetchAll();
    if(!empty($updated_nids)) {
      foreach ($updated_nids as $key => $values) {
        \Drupal::logger('custom_external_scripts')->info('Node nid ": @nid and vid: @vid for uid: @uid', ['@nid' => $values->nid, '@vid' => $values->vid, '@uid' => $uid]);
        //error_log("\n Node nid " . $values->nid . " and vid " . $values->vid . " for uid: " . $uid, 3, LDAP_SUCCESS_LOG);
      }
    }
    return $updated_nids;
  }

  // Delete users
  public static function delete_user_profile($uids) {
    $database = Database::getConnection();
    $uname = [];
    foreach($uids as $uid) {
      $query = $database->query("SELECT uid, name FROM users_field_data where uid = " . $uid);
      $result = $query->fetchAll();
    }
    foreach($result as $value) {
      $uname[$value->name] = $value->uid;
    }
    if (!empty($uids)) {
      $database->delete('users')
        ->condition('uid', $uids, 'IN')
        ->execute();
      $database->delete('users_field_data')
        ->condition('uid', $uids, 'IN')
        ->execute();
      $database->delete('user__roles')
        ->condition('entity_id', $uids, 'IN')
        ->execute();
      $database->delete('authmap')
        ->condition('uid', $uids, 'IN')
        ->execute();
  
      \Drupal::logger('custom_external_scripts')->info("Users deleted successfully ".date("d-m-Y h:i:sa ")."@uid", ['@uid' => $uids]);
      //error_log("\n users deleted successfully ".date("d-m-Y h:i:sa ").implode(" ,", $uids), 3, LDAP_SUCCESS_LOG);
  
      // Delete user profile data
  
      $userprofile_table_names = array('field_bio','field_name_first','field_name_last','field_base_location','field_country_user','field_skills','field_job_title','field_user_language','field_work_phone','field_mobile_phone','field_entity_sbu');
  
      foreach($userprofile_table_names as $table_name) {
        $field_data = 'user__'.$table_name;
        //$revision_field_data = 'field_revision_'.$table_name;
        $database->delete($field_data)
        ->condition('bundle', 'user', '=')
        ->condition('entity_id', $uids, 'IN')
        ->execute();
        /*db_delete($revision_field_data)
        ->condition('entity_type', 'user', '=')
        ->condition('entity_id', $uids, 'IN')
        ->execute();*/
      }
  
      // DB insert for entity_delete_log
      $i=0;
      foreach ($uname as $uname => $uid) {
        $i++;
        $log_result = $database->insert('entity_delete_log')
          ->fields([
            'entity_id' => $uid,
            'entity_type' => 'user',
            'entity_bundle' => 'user',
            'entity_title' => $uname,
            'author' => 1,
            'revisions' => 1,
            'created' => \Drupal::time()->getRequestTime(),
            'deleted' => \Drupal::time()->getRequestTime(),
            'uid' => 1,
          ])
          ->execute();
        if(!empty($log_result)) {
            print '</br>';
            print "(".$i.") User (".$uid."   =====>  ".$uname.") delete record has been added in entity delete log table.";
            print '</br>';
        }
  
        // update comment table data for adSync
        $comment_updated = $database->update('comment_field_data')
          ->fields([
              'uid' => 0,
            ])
          ->condition('uid', $uid, '=')
          ->execute();
        if(!empty($comment_updated)) {
          //error_log("\n users successfully updated in comment table ".date("d-m-Y h:i:sa "). $uid, 3, LDAP_SUCCESS_LOG);
          \Drupal::logger('custom_external_scripts')->info("users successfully updated in comment table ".date("d-m-Y h:i:sa "). "@uid", ['@uid' => $uids]);
        }
      }
    }
  }

  public static function delete_contacts() {
    $database = Database::getConnection();
    $query = $database->query("CREATE TABLE IF NOT EXISTS `log_contacts_fields_deleted` (
		  `nid` int(11) NOT NULL,
		  `node_type` varchar(255) NOT NULL,
		  `uid` int(11),
		  `entity_id` int(11),
		  `contact_value` varchar(255),		  
		  `date` varchar(20) DEFAULT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    $result = $query->fetchAll();

    $node_select = $database->query("SELECT * FROM node_field_data WHERE /*uid=0 AND */TYPE IN('asset','reference') /*AND FROM_UNIXTIME(CHANGED,'%Y') >= '2016'*/ /* AND nid IN (1090124)*/");
    $node_results = $node_select->fetchAll();
    foreach($node_results as $node_res) {
      $nid = $node_res->nid;
      $contact_field_select = $database->query("SELECT * FROM 
        paragraph__field_contact_topics fc, node__field_contacts fs, paragraph__field_contact_name fn
        WHERE
        fc.entity_id = fs.field_contacts_target_id AND
        fn.entity_id = fc.entity_id AND
        fn.entity_id = fs.field_contacts_target_id AND
        fs.entity_id = $node_res->nid");
      $contact_field_results = $contact_field_select->fetchAll();
      //echo "<pre>";print_r($contact_field_results);echo "<pre>";
      if(count($contact_field_results) > 0 ) {
        foreach($contact_field_results as $contact_field_res) {
          $contact_field_user_id = $contact_field_res->field_contact_name_target_id;
          $contact_entity_id = $contact_field_res->field_contacts_target_id;
          $field_contact_value = addslashes($contact_field_res->field_contact_topics_value);
          $contact_field_nid = $nid;
          $contact_field_node_type = $node_res->type;
    
          //echo $contact_field_user_id."<br>";
          \Drupal::logger('custom_external_scripts')->info("contact_field_user_id : @contact_field_user_id", ['@contact_field_user_id' => $contact_field_user_id]);
          //echo $contact_entity_id."<br>";
          \Drupal::logger('custom_external_scripts')->info("contact_entity_id : @contact_entity_id", ['@contact_entity_id' => $contact_entity_id]);

          $user_select = $database->query("SELECT * FROM users_field_data WHERE uid = $contact_field_user_id");
          $user_results = $user_select->fetchAll();
          //echo "<pre>";print_r($user_results);echo "</pre>";
          $user_count = count($user_results);
          //echo $user_count."<br>";
          if($user_count == 0) {
            /*echo "NID--->".$contact_field_nid."<---TYPE--->".$contact_field_node_type."<---UID--->".$contact_field_user_id."<br>";
            echo $contact_entity_id."<br>";*/

            \Drupal::logger('custom_external_scripts')->info("NID--->@contact_field_nid<---TYPE--->@contact_field_node_type<---UID--->@contact_field_user_id", ['@contact_field_nid' => $contact_field_nid, '@contact_field_node_type' => $contact_field_node_type, '@contact_field_user_id' => $contact_field_user_id]);

            \Drupal::logger('custom_external_scripts')->info("contact_entity_id : @contact_entity_id", ['@contact_entity_id' => $contact_entity_id]);

            $unique_contact_field = $database->query("SELECT DISTINCT(field_contact_name_target_id) FROM paragraph__field_contact_name WHERE entity_id = $contact_entity_id");
            $unique_contact_results = $unique_contact_field->fetchAll();
            //echo "<pre>";print_r($unique_contact_results);echo "<pre>";
            //echo "Count--->".count($unique_contact_results)."<br>";

            //\Drupal::logger('custom_external_scripts')->info("unique_contact_results : @unique_contact_results", ['@unique_contact_results' => count($unique_contact_results)]);

            if(count($unique_contact_results) > 1) {
              $delete_condition = "fn.*";
            } else {
              $delete_condition = "fc.*,fs.*,fn.*";
            }
            /*echo "<br>"."NID--->".$delete_condition."<br>";
            echo "<br>"."NID--->".$contact_field_nid."<br>";
            echo "NODE_TYPE--->".$contact_field_node_type."<br>";
            echo "ENTITY_ID--->".$contact_entity_id."<br>";
            echo "CONTACT_FIELD_VALUE--->".$field_contact_value ."<br>";			
            echo "USERID--->".$contact_field_user_id."<br><br><br>";*/

            \Drupal::logger('custom_external_scripts')->info("delete_condition--->@delete_condition<---NID--->@contact_field_nid<---NODE_TYPE--->@contact_field_node_type<---ENTITY_ID--->@contact_entity_id<---CONTACT_FIELD_VALUE--->@field_contact_value<---USERID--->@contact_field_user_id", ['@delete_condition' => $delete_condition, '@contact_field_nid' => $contact_field_nid, '@contact_field_node_type' => $contact_field_node_type, '@contact_entity_id' => $contact_entity_id, '@field_contact_value' => $field_contact_value, '@contact_field_user_id' => $contact_field_user_id]);

    
            $contact_field_delete = $database->query("DELETE $delete_condition FROM 
              paragraph__field_contact_topics fc,node__field_contacts fs,paragraph__field_contact_name fn
              WHERE
              fc.entity_id = fs.field_contacts_target_id AND
              fn.entity_id = fc.entity_id AND
              fn.entity_id = fs.field_contacts_target_id AND
              fs.entity_id = $node_res->nid  AND 
              fn.field_contact_name_target_id = $contact_field_user_id");
            $contact_delete = $contact_field_delete->fetchAll();
            //echo "<pre>";print_r($contact_delete);echo "<pre>";

            $table_name = 'log_contacts_fields_deleted';
            if ((\Drupal::database()->schema()->tableExists($table_name))) {
              $data = [
                'nid' => $node_res->nid,
                'node_type' => $contact_field_node_type,
                'uid' => $contact_field_user_id,
                'entity_id' => $contact_entity_id,
                'contact_value' => $field_contact_value,
                'date' => \Drupal::time()->getRequestTime(),
              ];
              $insert_id = Database::getConnection()->insert('log_contacts_fields_deleted')
                ->fields($data)
                ->execute();
              \Drupal::logger('custom_external_scripts')->info('Record inserted in log_contacts_fields_deleted with ID: @id', ['@id' => $insert_id]);
            }
          }
        }
      }
    }
  }

  public static function delete_other_contribs() {
    $database = Database::getConnection();
    $node_select = $database->query("SELECT * FROM node_field_data WHERE /*uid=0 AND */TYPE IN('asset','reference') /*AND FROM_UNIXTIME(CHANGED,'%Y') >= '2016'*/ /* AND nid IN (1090124)*/");
    $node_results = $node_select->fetchAll();
    foreach($node_results as $node_res) {
      $nid = $node_res->nid;
      $other_contrib_field_select = $database->query("SELECT * FROM 
        node__field_other_contributor fc
        WHERE
        fc.entity_id = $node_res->nid");
      $other_contrib_field_results = $other_contrib_field_select->fetchAll();
      if(count($other_contrib_field_results) > 0 ) {
        foreach($other_contrib_field_results as $other_contrib_field_res) {
          $other_contrib_field_user_id = $other_contrib_field_res->field_other_contributor_target_id;
          $other_contrib_field_nid = $other_contrib_field_res->entity_id;
          $other_contrib_node_type = $other_contrib_field_res->bundle;
    
          //echo $contact_field_user_id."<br>";
          //echo $contact_entity_id."<br>";

          \Drupal::logger('custom_external_scripts')->info("other_contrib_field_user_id--->@other_contrib_field_user_id<---other_contrib_field_nid--->@other_contrib_field_nid<---other_contrib_node_type--->@other_contrib_node_type<---NID--->@nid", ['@other_contrib_field_user_id' => $other_contrib_field_user_id, '@other_contrib_field_nid' => $other_contrib_field_nid, '@other_contrib_node_type' => $other_contrib_node_type, '@nid' => $nid]);

          $user_select = $database->query("SELECT * FROM users_field_data WHERE uid = $other_contrib_field_user_id");
          $user_results = $user_select->fetchAll();
          //echo "<pre>";print_r($user_results);echo "</pre>";
          $user_count = count($user_results);
          //echo $user_count."<br>";
          \Drupal::logger('custom_external_scripts')->info('User Count: @user_count', ['@user_count' => $user_count]);
          if($user_count == 0) {
            \Drupal::logger('custom_external_scripts')->info("To DELETE--->other_contrib_field_user_id--->@other_contrib_field_user_id<---other_contrib_field_nid--->@other_contrib_field_nid", ['@other_contrib_field_user_id' => $other_contrib_field_user_id, '@other_contrib_field_nid' => $other_contrib_field_nid]);

            $other_contrib_field_delete = $database->query("DELETE fc.* FROM 
              node__field_other_contributor fc
              WHERE
              fc.entity_id = $other_contrib_field_nid  AND 
              fc.field_other_contributor_target_id = $other_contrib_field_user_id");
            $other_contrib_delete = $other_contrib_field_delete->fetchAll();
            //echo "<pre>";print_r($other_contrib_delete);echo "<pre>";

            $table_name = 'log_contacts_fields_deleted';
            if ((\Drupal::database()->schema()->tableExists($table_name))) {
              $data = [
                'nid' => $other_contrib_field_nid,
                'node_type' => $other_contrib_node_type,
                'uid' => $other_contrib_field_user_id,
                'entity_id' => $other_contrib_field_nid,
                'contact_value' => 'other_contributors',
                'date' => \Drupal::time()->getRequestTime(),
              ];
              $insert_id = Database::getConnection()->insert('log_contacts_fields_deleted')
                ->fields($data)
                ->execute();
              \Drupal::logger('custom_external_scripts')->info('Record inserted in log_contacts_fields_deleted with ID: @id', ['@id' => $insert_id]);
            }
          }
        }
      }
    }
  }

  public static function batchFinished($success, $results, $operations) {
    if ($success) {
      \Drupal::messenger()->addMessage(t('Batch Completed successfully.'));
      \Drupal::messenger()->addMessage(t('Processed items: @results', ['@results' => implode(', ', $results)]));
    }
    else {
      \Drupal::messenger()->addMessage(t('Batch processing encountered errors.'), 'error');
    }
  }
}
