<?php

/*namespace Drupal\custom_external_scripts\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symphony\Component\DependencyInjection\ContainerInterface;

class CustomLogger extends ControllerBase {
  protected $fileLogger;

  public function __construct($fileLogger) {
    $this->fileLogger = $fileLogger;
  }

  public static function create(ContainerInterface $container) {
    return new static($container->get('custom_external_scripts.file_logger'));
  }

  public function logMessage() {
    try {
      throw new \Exception('This is a simulated error.');
    } catch(\Exception $e) {
      // Log the error using the custom file logger.

      $this->fileLogger->error('Error: {message}', ['message' => $e->getMessage()]);
    }
    return ['#markup' => 'Message logger to custom file.',];
  }
}*/
