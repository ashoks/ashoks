<?php
namespace Drupal\custom_external_scripts\Logger;

use Psr\Log\AbstractLogger;

class FileLogger extends AbstractLogger {
  protected $filePath;

  public function __construct($filePath) {
      $this->filepath = $filePath;
  }

  public function log($level, $message, array $context = []) {
    // Interpolate context vakues into the message.
    $message = $this->interpolate($message, $context);

    // Write the log entry to the file.
    file_put_contents($this->filePath, '[' . strtoupper($level) . '] ' . $message . PHP_EOL, FILE_APPEND);
  }

  protected function interpolate($message, array $context) {
    $replace = [];
    foreach ($context as $key => $val) {
      $replace['{' . $key . '}'] = $val;
    }
    return strtr($message, $replace);
  }
}
