<?php

namespace Drupal\custom_reference\Commands;

use Drush\Commands\DrushCommands;
use Drupal\Core\Database\Database;
use Drupal\Core\File\FileSystemInterface;

class CustomReferenceFileMigrationCommands extends DrushCommands {
  /**
   * Drush command to move files and update file_managed table based on usage.
   *
   * @command custom_reference:move-files-based-on-usage
   * @argument string $content_type
   *   The content type to filter (e.g., reference, asset, news, event, pages).
   * @description Move files based on their usage (asset or reference content types) and update file_managed table using the preprod database.
   * @bootstrap full
   */
  public function moveFilesBasedOnUsage($content_type = NULL) {
    // Connect to the preprod database.
    $preprod_connection = Database::getConnection('default', 'default');
    $this->logger()->notice('Files being moved based on usage ....');

    // Get all file IDs and their usage in nodes.
    $query = $preprod_connection->select('file_usage', 'fu')
      ->fields('fu', ['fid', 'id'])  // 'id' refers to the entity (node) ID in the file_usage table.
      ->condition('fu.type', 'paragraph') // Only get files used in paragraphs.
      ->execute();
    $count = 0;
    foreach ($query as $record) {
        $count++;
        $this->logger()->notice( $count . ' files processed ....');

      $fid = $record->fid;
      $paragraph_id = $record->id;
      $node_id = null;

      // Get the parent node ID from the paragraph data.
      $parent_node_query = $preprod_connection->select('paragraphs_item_field_data', 'p')
        ->fields('p', ['parent_id'])
        ->condition('p.id', $paragraph_id)
        ->execute()
        ->fetchField();

      if ($parent_node_query) {
        $node_id = $parent_node_query;
        // $this->logger()->success('parent node ' .$node_id .' found for paragraph '. $paragraph_id);

      } else {
        // $this->logger()->error('No parent node found for paragraph '. $paragraph_id);
      }

      // Get the content type of the node using this file from the preprod database.
      $node_query = $preprod_connection->select('node_field_data', 'n')
        ->fields('n', ['type'])
        ->condition('n.nid', $node_id)
        ->execute()
        ->fetchField();
      // Check if the content type matches the passed argument, if provided.
      if ($content_type && $node_query !== $content_type) {
        continue; // Skip files that do not match the provided content type.
      }
      // Determine whether the file belongs to the reference or asset folder.
      $source_directory = 'sites/default/files/';
      $destination_directory = 'sites/default/files/private/attachment/';
      $this->logger()->info(t('Processing content type: @type', ['@type' => $node_query]));
      $current_uri = $preprod_connection->select('file_managed', 'fm')
      ->fields('fm', ['uri'])
      ->condition('fm.fid', $fid)
      ->execute()
      ->fetchField();
      if ($node_query === 'reference') {
        $this->updateFileUri($fid, $preprod_connection, 'public://reference/', 'private://attachment/');
      }
      elseif ($node_query === 'asset') {
       $this->updateFileUri($fid, $preprod_connection, 'public://asset/', 'private://attachment/');
      }
      elseif ($node_query === 'news') {
        $this->updateFileUri($fid, $preprod_connection, 'public://news/', 'private://attachment/');
      }
      elseif ($node_query === 'event') {
        $this->updateFileUri($fid, $preprod_connection, 'public://event/', 'private://attachment/');
      }
      elseif ($node_query === 'pages') {
        $this->updateFileUri($fid, $preprod_connection, 'public://pages/', 'private://attachment/');
      }
    }
    moveFilesDirectory( 'sites/default/files/'.$content_type .'/', 'sites/default/files/private/attachment/');
  }
  

  /**
   * Update the file_managed table with the new file URI.
   *
   * @param int $fid
   *   The file ID.
   * @param \Drupal\Core\Database\Connection $preprod_connection
   *   The preprod database connection.
   * @param string $from
   *   The old URI pattern to replace.
   * @param string $to
   *   The new URI pattern.
   */
  private function updateFileUri($fid, $preprod_connection, $from, $to) {
    $current_uri = $preprod_connection->select('file_managed', 'fm')
      ->fields('fm', ['uri'])
      ->condition('fm.fid', $fid)
      ->execute()
      ->fetchField();

    $new_uri = str_replace($from, $to, $current_uri);

    $preprod_connection->update('file_managed')
      ->fields(['uri' => $new_uri])
      ->condition('fid', $fid)
      ->execute();
  }

}
