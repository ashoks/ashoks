<?php

namespace Drupal\custom_reference\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class CustomReferenceEmailIgnoreConfigForm extends ConfigFormBase {

  public function getFormId() {
    return 'custom_reference_config_form';
  }

  protected function getEditableConfigNames() {
    return ['custom_reference.settings'];
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('custom_reference.settings');

    $form['email_ignore'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Custom Email Ignore Emails'),
      '#default_value' => $config->get('email_ignore'),
      '#description' => $this->t('Enter comma separated email addresses to ignore for New Reference email.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('custom_reference.settings')
      ->set('email_ignore', $form_state->getValue('email_ignore'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
