<?php

namespace Drupal\custom_reference\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Implements a Reference Popup Form API.
 */
class ReferencePopupForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'reference_modal_Popup';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    $temp = '<div id="none-sbu-form-no"><div class="form-item form-type-select form-item-create-ref-no"><label for="edit-non-sbu">Please create the reference from THOR CRM. For THOR units, References have to be created through THOR CRM at <a href="https://capgemini.my.salesforce.com" target="_blank">https://capgemini.my.salesforce.com</a></label></div></div>';

    $form['markup'] = [
      '#type' => 'markup',
      '#markup' => $temp,
    ];

    // $form['submit'] = [
    //   '#type' => 'submit',
    //   '#value' => t('ok'),
    // ];

    $form['#prefix'] = '<div><div><div></div>';
    $form['#suffix'] = '</div></div>';

    $form['#attached']['library'][] = 'core/drupal.dialog.ajax';
    return $form;
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    // if (!$valid) {
    // $form_state->setErrorByName('community', $this->t('Invalid.'));
    // }
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $form_state->setRedirect('<front>');
  }

}
