<?php

namespace Drupal\custom_reference\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Implements a Community List Form API.
 */
class CommunityListForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'community_list_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $user = \Drupal::currentUser();
		$role = ['reference_manager_overall','administrator'];
    $query = \Drupal::database()->select('group_relationship_field_data', 'o');
    $query->join('groups_field_data', 'g', 'g.id = o.`gid`');
    $query->join('group__field_community_type', 't', 't.entity_id = o.`gid`');
    $query->join('user__roles', 'ur', 'ur.entity_id = o.`entity_id`');
    $query->fields('g', array('id', 'label'));
    $query->condition('o.type', '%group_membership%', 'LIKE');
		$query->condition('g.status', '1', '=');
    $query->condition('o.entity_id', $user->id(), '=');
    $query->condition('ur.roles_target_id', $role, 'IN');
    $query->condition('t.field_community_type_value', '3', '=');
    $result = $query->execute();
		if(isset($result) && !empty($result)){
      foreach($result as $res){
        $list_result[$res->label . " (" . $res->id . ")"] = $res->label . " (" . $res->id . ")";
      }
		}
		else{
			$list_result = [];
		}

    /*$list_result = [
      "Global Microsoft Alliance - Client References (1037850)" => "Global Microsoft Alliance - Client References (1037850)",
      "Global TMT - Client References (1037866)" => "Global TMT - Client References (1037866)",
      "KM 3.0 Dedicated Community For Testing - Client References (1043388)" => "KM 3.0 Dedicated Community For Testing - Client References (1043388)",
      "KM CRP Test (1043694)" => "KM CRP Test (1043694)",
      "Digital Services - Client References (1046548)" => "Digital Services - Client References (1046548)",
      "Business Transformation Services (BTS) - Client References (1047456)" => "Business Transformation Services (BTS) - Client References (1047456)",
      "Showcase Reference Community - ARCHIVED References (1049459)" => "Showcase Reference Community - ARCHIVED References (1049459)",
      "Legacy IGATE - ARCHIVED References (1049887)" => "Legacy IGATE - ARCHIVED References (1049887)",
    ];*/
    $form['community'] = [
      '#type' => 'select',
      '#title' => t('Select a community'),
      '#required' => TRUE,
      '#multiple' => FALSE,
      '#options' => $list_result,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Select'),
    ];

    // $form_state['oppID'] = $_GET['oppID'];
    $form['#prefix'] = '<div style="display:none;"><div id="communities-list-popup"><div id="communities-list-popup-wrapper"></div>';
    $form['#suffix'] = '</div></div>';

    $form['#attached']['library'][] = 'core/drupal.dialog.ajax';
    return $form;
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    /*$valid = false;
    if ($form_state->getValue('community')) {
    // filter community id.
    preg_match('/\(([0-9]+)\)/i', $form_state->getValue('community'), $matches);
    if ($matches[1]) {
    $crp = \Drupal::entityTypeManager()->getStorage('node')->load($matches[1]);
    // Check valid community.
    if ($crp) {
    $form_state->setValue('community_id', $crp->nid);
    $field_community_type = $crp->field_community_type[\Drupal\Core\Language\Language::LANGCODE_NOT_SPECIFIED][0]['value'];
    if ($crp->type == 'group' && $field_community_type == 3) {
    $valid = true;
    }
    }
    }
    }
    if (!$valid) {
    $form_state->setErrorByName('community', $this->t('The community is invalid.'));
    }*/
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    if ($form_state->getErrors()) {
      // Show errors in popup.
      $errors = $form_state->getErrors();
      $commands = [
        ajax_command_replace('#communities-list-popup-wrapper', '<div id="communities-list-popup-wrapper" style="color:red">' . $errors['community'] . '</div>'),
      ];
      $replace = ['#type' => 'ajax', '#commands' => $commands];

      return $replace;
    }
    else {
      $oppid = \Drupal::request()->query->get('oppID');
      // Redirect to create form with oppID and communityID parameters.
      $formvalues = $form_state->getValues();
      $commID = str_replace(')', '', explode(' (', $formvalues['community']));
      foreach ($commID as $cid) {
        if (is_numeric($cid)) {
          $community_id = $cid;
        }
      }
      if ($community_id && $oppid) {
        $path = Url::fromUri('internal:/node/add/reference', ['query' => ['community_id' => $community_id, 'oppID' => $oppid]], ['absolute' => 'true']);
        $response = new RedirectResponse($path->toString());
        $response->send();
        return;
        exit;
      }
    }
  }

}
