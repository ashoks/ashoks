<?php

namespace Drupal\custom_reference\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * ReferenceController class.
 */
class ReferenceController extends ControllerBase {

  /**
   * Handling autocomplete field data labels.
   */
  public function handledeluxeAutocomplete(Request $request) {
    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    $query = \Drupal::database()->select('users_field_data', 'ufd');
    $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
    $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
    $query->addField('f', 'field_name_first_value', 'firstname');
    $query->addField('l', 'field_name_last_value', 'lastname');
    $query->addField('ufd', 'uid', 'id');
    $query->addField('ufd', 'mail', 'email');
    $query->range(0, 10);
    $query->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q OR ufd.mail LIKE :q OR ufd.name LIKE :q", [':q' => '%' . $input . '%']);
    $results = $query->execute()->fetchAll();
    $valuesdelux = [];
    foreach ($results as $result) {
      $val = $result->firstname . ' ' . $result->lastname;
      $lable = $val . ' [' . $result->email . '] [' . $result->id . ']';
      $valuesdelux[$val . ' (' . $result->id . ')'] = $lable;
    }
    return new JsonResponse($valuesdelux);
  }

}
