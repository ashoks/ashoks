(function ($) {
  Drupal.behaviors.customrefJS = {
		attach: function (context, settings) {

      $("#edit-field-contract-value-0-value").keypress(function (e){
        var charCode = (e.which) ? e.which : e.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
          return false;
        }
      });

			var countFile = jQuery("#edit-group-attachments table tr.draggable").length;
			for(let i = 0; i <= countFile; i++) {
				var radioValue = $("input[name='field_files[" + i + "][subform][field_type_of_document]']:checked").val();
				if (radioValue == 0) {
					$("div[id^='edit-field-files-" + i + "-subform-field-attachment-wrapper']").show();
					$("div[id^='edit-field-files-" + i + "-subform-field-link-wrapper']").hide();
				}
				if (radioValue == 1) {
					$("div[id^='edit-field-files-" + i + "-subform-field-attachment-wrapper']").hide();
					$("div[id^='edit-field-files-" + i + "-subform-field-link-wrapper']").show();
				}
				$("input[name='field_files[" + i + "][subform][field_type_of_document]']").click(function () {
					var radioValue = $("input[name='field_files[" + i + "][subform][field_type_of_document]']:checked").val();
					if (radioValue == 0) {
						$("div[id^='edit-field-files-" + i + "-subform-field-attachment']").show();
						$("div[id^='edit-field-files-" + i + "-subform-field-link']").hide();
					}
					if (radioValue == 1) {
						$("div[id^='edit-field-files-" + i + "-subform-field-attachment']").hide();
						$("div[id^='edit-field-files-" + i + "-subform-field-link']").show();
					}
				});
			}
			var currency = $("#edit-field-currency").val();
			var contract_value = $("#edit-field-contract-value-0-value").val();

			if (((currency !== null || currency !== '') && currency !== "_none") && ((contract_value !== null || contract_value !== '') && contract_value > 0)) {
				setTimeout(function () { rerender_size_range_value(); }, 1000);
			} else {
				$("#edit-field-fake-deal-size-status").text("");
			}
			 $('select[name="field_currency"]').on('change', function (event) {

        var currency = $("#edit-field-currency").val();
        var contract_value = $("#edit-field-contract-value-0-value").val();
        if ((currency !== null && currency !== "_none") && (contract_value !== null && contract_value > 0)) {
          setTimeout(function () { rerender_size_range_value(); }, 1000);
        } else {
          $("#edit-field-fake-deal-size-status").text("");
        }

      });

      $('input[name^="field_contract_value"]').on('change', function (event) {
        var currency = $("#edit-field-currency").val();
        var contract_value = $("#edit-field-contract-value-0-value").val();
        if ((currency !== null && currency !== "_none") && (contract_value !== null && contract_value > 0)) {
          setTimeout(function () { rerender_size_range_value(); }, 1000);
        } else {
          $("#edit-field-fake-deal-size-status").text("");
        }
      });
		}
  }
  // code for reference form radio button green / yellow / red
  $(window).on('load', function () {
    $("label[for='edit-field-permission-status-green']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-yellow']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-yello']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-red']").attr('id', 'tooltip');
    $("label[for='edit-field-permission-status-green']").append('<span class="tooltiptext">Can be used externally directly without contacting the Account executive.</span>');
    $("label[for='edit-field-permission-status-yellow']").append('<span class="tooltiptext">Please contact reference owner prior to using the reference externally.</span>');
    $("label[for='edit-field-permission-status-yello']").append('<span class="tooltiptext">Please contact reference owner prior to using the reference externally.</span>');
    $("label[for='edit-field-permission-status-red']").append('<span class="tooltiptext">Capgemini must not share client name/logo and engagement information for any external purpose.</span>');
  });
})(jQuery);
(function ($) {
  $(document).ready(function () {
		
    if ($('#edit-field-enable-masking-value').is(":checked")) {
      $(".field--name-field-masking-client-names").show();
    } else {
      $(".field--name-field-masking-client-names").hide();
    }
    $('#edit-field-enable-masking-value').on('click', function (event) {
      if ($('#edit-field-enable-masking-value').is(":checked")) {
        $(".field--name-field-masking-client-names").show();
				$("#edit-field-masking-client-names-0-value").val('Confidential Client');
        $(".field--name-field-ultimate-parent-account").hide();
      } else {
        $(".field--name-field-masking-client-names").hide();
        $(".field--name-field-ultimate-parent-account").show();
      }
    });
    $('#edit-field-engagement-start-date-0-value-date').blur(function () {
        auto_populate_project_status();
    });
    $('#edit-field-engagement-end-date-0-value-date').blur(function () {
        auto_populate_project_status()
    });

    var auto_populate_project_status = function () {
    var start_date = new Date($('#edit-field-engagement-start-date-0-value-date').val());
    var end_date = new Date($('#edit-field-engagement-end-date-0-value-date').val());
    var current_date = new Date();
    var project_type = 0;
    current_date.setHours(0, 0, 0, 0);
    if (start_date < end_date) {
        if (current_date > end_date) {
            project_type = 3;
        } else if (current_date > start_date) {
            project_type = 2;
        } else if (current_date <= start_date) {
            project_type = 1;
        }
    } else {
        if(start_date.getTime() === end_date.getTime() && current_date > end_date) {
            project_type = 3;
        }
    }
    $('#edit-field-project-status').val(project_type);
    }
    var userid = drupalSettings.custom_reference.userid;
    if(userid != 0){
      var path = $(location).attr('href');
      
      var urlParams = new URLSearchParams(window.location.search);
      var oppid = encodeURIComponent(urlParams.get('oppID'));
      if((path.indexOf('/node/add/reference') > 1) && (path.indexOf('?community_id=') < 0) && (path.indexOf('oppID=') > 1)) {
        var ajaxSettings = {
          url: '/node/reference/community_modal_form?oppID=' + oppid,
          dialogType: 'modal',
          dialog: { width: 400 },
        };
        var myAjaxObject = Drupal.ajax(ajaxSettings);
        myAjaxObject.execute();
      }
    }
    $('#node-reference-form #edit-field-sector, #node-reference-edit-form #edit-field-sector').on('change', function () {
        $('#node-reference-form select[name="field_subsegment[]"], #node-reference-edit-form select[name="field_subsegment[]"]').empty();
    });
		$('.page-reference #edit-field-competitors-rf-wrapper label').addClass('form-label');
		$('#node-reference-edit-form #edit-field-competitors-rf-wrapper label').addClass('form-label');
		
		var params = new window.URLSearchParams(window.location.search);
		if(params.get('community_id') == null && params.get('oppID') != null){
			$('body').addClass('new-reference-creation');
		}
  });
})(jQuery);
// ########## Deal Size Logic Handling Starts ##########

  function rerender_size_range_value() {
    var currency = jQuery("#edit-field-currency").val();
    if (currency != "_none") {
      var contract_value = jQuery("#edit-field-contract-value-0-value").val() * 1000;
			render_deal_size_range(["AUD", "BRL", "CNY", "EUR", "GBP", "USD", "MXN"]);
      if (currency == "EUR") {
        //render_deal_size_range(["EUR"]);
        var select = get_deal_size_range(currency, contract_value);
        jQuery("#edit-field-fake-deal-size-status").val(select);
      } else {
        //render_deal_size_range([currency]);
        switch (currency) {
          case "AUD":
            var contract_value_eur =
              contract_value / 1.65; //Drupal.settings.cap_notify.eur_aud;

            break;

          case "BRL":
            var contract_value_eur =
              contract_value / 5.48;//Drupal.settings.cap_notify.eur_brl;
            break;

          case "CNY":
            var contract_value_eur =
              contract_value / 7.60;//Drupal.settings.cap_notify.eur_cny;
            break;

          case "GBP":
            var contract_value_eur =
              contract_value / 0.88;//Drupal.settings.cap_notify.eur_gbp;
            break;

          case "USD":
            var contract_value_eur =
              contract_value / 1.09; //Drupal.settings.cap_notify.eur_usd;
            break;

          case "MXN":
            var contract_value_eur =
              contract_value / 19.70; //Drupal.settings.cap_notify.eur_mxn;
            break;
        }
        jQuery('body.path-node #edit-field-fake-deal-size-status option').text(
          jQuery('#edit-field-fake-deal-size-status option[value="' + get_deal_size_range(currency, contract_value) + '"]').text() + '/ ' +
					jQuery('#edit-field-fake-deal-size-status option[value="' + get_deal_size_range('EUR', contract_value_eur) + '"]').text()
				)
      }
      if (jQuery(".field-name-field-contract-value-form input.form-text").val() == "") {
        jQuery("#edit-field-fake-deal-size-status").text("");
      }
    } else {
      jQuery("#edit-field-fake-deal-size-status").text("");
    }
  }


  
  function render_deal_size_range(currencys) {
    var list_option = "";
    var sign_currency = "";
    for (var i = 0, l = currencys.length; i < l; i++) {
      switch (currencys[i]) {
        case "AUD":
          sign_currency = "AU$";
          break;

        case "BRL":
          sign_currency = "R$";
          break;

        case "CNY":
          sign_currency = "¥";
          break;

        case "EUR":
          sign_currency = "€";
          break;

        case "GBP":
          sign_currency = "£";
          break; 

        case "USD":
          sign_currency = "$";
          break;

        case "MXN":
          sign_currency = "Mex$";
          break;
      }
      if (sign_currency != "") {
				
          list_option +=
          '<option value="' + currencys[i] + '_1">' + "0" + sign_currency + " - 0.5 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_2">' + "0.5" + sign_currency + " - 1 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_3">' + "1 M" + sign_currency + " - 5 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_4">' + "5 M" + sign_currency + " - 10 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_5">' + "10 M" + sign_currency + " - 20 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_6">' + "20 M" + sign_currency + " - 50 M" + sign_currency + "</option>" +
          '<option value="' + currencys[i] + '_7">' + "more than 50 M" + sign_currency + "</option>";
				
      } else {
        list_option = '<option value="_none">' + "- None -" + "</option>";
      }
    }
    jQuery("#edit-field-fake-deal-size-status").html(list_option);
  };
	function get_deal_size_range(currency, contract_value) {
    var select = "";
    switch (true) {
      case contract_value == "" || contract_value == "undefined":
        select = currency + "_1";
        break;

      case contract_value > 0 && contract_value < 500001:
        select = currency + "_1";
        break;

      case contract_value > 500000 && contract_value < 1000001:
        select = currency + "_2";
        break;

      case contract_value > 100000 && contract_value < 5000001:
        select = currency + "_3";
        break;

      case contract_value > 500000 && contract_value < 10000001:
        select = currency + "_4";
        break;

      case contract_value > 1000000 && contract_value < 20000001:
        select = currency + "_5";
        break;

      case contract_value > 20000000 && contract_value < 50000001:
        select = currency + "_6";
        break;

      case contract_value > 50000000:
        select = currency + "_7";
        break;

      default:
        select = "_none";
        break;
    }
    return select;
  };

  // ########## Deal Size Logic Handling Ends ##########