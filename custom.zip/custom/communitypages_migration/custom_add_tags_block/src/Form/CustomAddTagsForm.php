<?php

namespace Drupal\custom_add_tags_block\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\message\Entity\Message;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\TermInterface;

/**
 * Implementing a ajax form.
 */
class CustomAddTagsForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_add_tags_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node && $node instanceof NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();
      $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
    }
    $form['nid'] = [
      '#type' => 'hidden',
      '#value' => $nid ? $nid : NULL,
      '#prefix' => '',
    ];

    $form['field_tags'] = [
      '#type' => 'textfield',
      '#title' => $this->t(''),
      '#placeholder' => 'Type Keyword to Search',
      '#autocomplete_route_name' => 'custom_add_tags_block.autocomplete',
      '#prefix' => '<div class = "input-group select2-wrap">',
      '#suffix' => '</div>',
    ];

    $form['actions'] = [
      '#type' => 'button',
      '#value' => $this->t('Add'),
      '#attributes' => ['class' => ['btn', 'btn-lg', 'btn-primary', 'd-flex']],
      '#ajax' => [
        'callback' => '::setMessage',
      ],
    ];

    $form['#attributes']['class'][] = ('d-flex align-items-center');

    return $form;
  }

  /**
   * Setting the message in our form.
   */
  public function setMessage(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();

    $specialCheck = explode(",", trim($form_state->getValue('field_tags')));
    $specialCheckTrimmed = array_map('trim', $specialCheck);
    $term_value_exp = array_filter($specialCheckTrimmed);

    if (count($term_value_exp) == 0) {
      return $response;
    }
    elseif (count($term_value_exp) > 0) {
      $node = \Drupal::routeMatch()->getParameter('node');
      
      if ($node && $node instanceof NodeInterface) {
        // You can get nid and anything else you need from the node object.
        $nid = $node->id();
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
        $term_objects = $node->get('field_tags')->referencedEntities();

        $term_labels = [];
        $multiple_tids = [];
        $tags = '';
        foreach ($term_objects as $term_object) {
          // The id of the term.
          $term_object->id();
          // The term title.
          $term_object->label();
          // Build an array of term labels.
          $term_labels[] = $term_object->label();
          $tags .= $term_object->label() . ',';
        }
        $arrayTags = explode(",", $tags);

        // New code starts here.
        $vid = 'tags';
        $multiple_tids = [];
        $term_names = [];
        foreach ($term_value_exp as $key => $term_value) {

          if (in_array(strtolower($term_value), array_map("strtolower", $term_labels))) {
            unset($term_value_exp[$key]);
          }

          $storage = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
          $terms = $storage->loadByProperties([
            'name' => $term_value,
            'vid' => $vid,
          ]);

          if ($terms) {
            // Only use the first term returned;
            // there should only be one anyways if we do this right.
            $term = reset($terms);
          }
          else {
            $term = Term::create([
              'name' => $term_value,
              'vid' => $vid,
            ]);
            $term->save();
          }
          $tid = $term->id();
          $term_names[$tid] = $term_value;
          // All the term id which is created or
          // which has tid should be added in author table.
          $query = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
          $query->fields('gcf', ['field_author_target_id', 'deleted']);
          $query->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
          $query->condition('gcf.entity_id', $tid);
          $query->condition('gcf.node_id', $nid);
          $query->condition('gcf.deleted', 0);
          $result = $query->execute()->fetchAll();

          if (!$result) {
            // Now relate the user as author of the term.
            $conn = Database::getConnection();
            $conn->insert('taxonomy_term__field_author')
              ->fields([
                'bundle' => $vid,
                'deleted' => 0,
                'entity_id' => $tid,
                'revision_id' => $tid,
                'language' => "en",
                'delta' => 0,
                'field_author_target_id' => \Drupal::currentUser()->id(),
                'node_id' => $nid,
              ])->execute();

          }

          // Handling comma seperated case ends here.
          $existingTags = \Drupal::service('entity_type.manager')
            ->getStorage("taxonomy_term")
            ->loadTree("tags", $parent = 0, $max_depth = 1, $load_entities = FALSE);

          $termTagsId = [];
          $termTagsName = [];
          foreach ($existingTags as $key => $term) {
            $termTagsName[$term->tid] = $term->name;
          }
         
          // New code ends here.
          foreach ($arrayTags as $tag) {

            $categories_vocabulary = 'tags';
            if (!in_array($tag, $termTagsName)) {
              $multiple_tids[] = $tid;
            }
            else {
              $multiple_tids[] = array_search($tag, $termTagsName);
            }
          }

        }
        // $notify_data = [
          // 'node' => $node,
          // 'bundle' => 'node',
          // 'entity_bundle' => $term,
          // 'tags' => $tags,
        // ];

        // $gid = $node->field_community->target_id;
        // $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
        // $notify_data['group'] = $group;
        // $user_id_notified = [];
        // $notificationService = \Drupal::service('notifications_widget.logger');
        // $tokenService = \Drupal::service('token');
        // $current_user = \Drupal::entityTypeManager()->getStorage('user')->load(\Drupal::currentUser()->id());
        $user_added_tags = explode(', ', $form_state->getValue('field_tags'));
        foreach($user_added_tags as $user_added_tag) {
          $term_name = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $user_added_tag]);
          $term_data = reset($term_name);
          if ($term_data instanceof TermInterface) {
            $multiple_tids[] = $term_data->id();
          }
        }
        // $templates = ['ia_cf_tc', 'ia_cl_tc', 'ia_cm_tc', 'ia_cic_tc'];
        // foreach ($templates as $template) {
        //   $field_key = 'field_' . $template;
        //   $user_ids = [];

        //   switch ($template) {
        //     case 'ia_cf_tc':
        //       $user_ids = custom_notification_get_users_following_content('follow_content', $node->id());
        //       break;

        //     case 'ia_cl_tc':
        //     case 'ia_cm_tc':
        //       $group_member_data = custom_notification_get_group_members_with_roles($group);
        //       foreach ($group_member_data as $data) {
        //         if (($template !== 'ia_cl_tc' || custom_notification_group_based_validation($group_member_data, 'cl')) &&
        //               !in_array($data['user']->id(), $user_id_notified)) {
        //           $user_ids[$data['user']->id()] = $data['user'];
        //         }
        //       }
        //       break;

        //     case 'ia_cic_tc':
        //       if (!in_array($node->getOwnerId(), $user_id_notified)) {
        //         $user_ids[$node->getOwnerId()] = $node->getOwner();
        //       }
        //       break;
        //   }

        //   foreach ($user_ids as $uid => $user) {
        //     $queue = \Drupal::service('queue')->get('custom_notification_add_tag_notify_queue');
        //     $queue->createItem([
        //         'user' => $user,
        //         'field_key' => $field_key,
        //         'uid' => $uid,
        //         'user_id_notified' => $user_id_notified,
        //         'node' => $node,
        //         'entity' => $entity,
        //         'group' => $group,
        //         'template' => $template,
        //         'user_added_tags' => $user_added_tags,
        //     ]);
        //     $user_id_notified[] = $uid;
        //   }
        // }


        $queue = \Drupal::service('queue')->get('custom_notification_add_tag_notify_queue');
        $queue->createItem([
          'entity_id' => $node->id(),
          'templates' => ['ia_cf_tc', 'ia_cl_tc', 'ia_cm_tc', 'ia_cic_tc'],
          'action' => 'update',
          'user' => \Drupal::currentUser(),
          'current_user' => \Drupal::currentUser()->id(),
          'user_added_tags' => $user_added_tags
        ]);
        $queue = \Drupal::service('queue')->get('custom_notification_add_tag_notify_email_queue');
        $request = \Drupal::request();
        // Build the base site URL.
        $base_url = $request->getScheme() . '://' . $request->getHttpHost();

        $queue->createItem([
          'entity_id' => $node->id(),
          'templates' => ['em_cf_tc', 'em_cl_tc', 'em_cm_tc', 'em_cic_tc'],
          'action' => 'update',
          'user' => \Drupal::currentUser(),
          'current_user' => \Drupal::currentUser()->id(),
          'user_added_tags' => $user_added_tags,
          'site_url' => $base_url,
        ]);
        $node->set('field_tags', array_unique($multiple_tids));
        $node->save();
      }
    }

    // Render all the tags on ajax success.
    $user_id = \Drupal::currentUser()->id();
    $node = \Drupal::routeMatch()->getParameter('node');

    if ($node && $node instanceof NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();
      $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
      $field_group = $node->get('field_community')->getValue();
      $group_id = $field_group[0]['target_id'];
      $term_objects = $node->get('field_tags')->referencedEntities();

      $queryAllTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
      $queryAllTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
      $queryAllTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
      $queryAllTags->condition('gcf.node_id', $nid);
      $queryAllTags->condition('gcf.deleted', 0);
      $queryAllTags->groupBy('gcf.entity_id');
      $queryAllTags->orderBy('tfd.name', 'asc');
      $resultAllTags = $queryAllTags->execute()->fetchAll();

      $queryMyTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
      $queryMyTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
      $queryMyTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
      $queryMyTags->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
      $queryMyTags->condition('gcf.node_id', $nid);
      $queryMyTags->condition('gcf.deleted', 0);
      $queryMyTags->groupBy('gcf.entity_id');
      $queryMyTags->orderBy('tfd.name', 'asc');
      $resultMyTags = $queryMyTags->execute()->fetchAll();

      $testarray = [];

      foreach ($term_objects as $termobject) {
        $testarray[$termobject->id()] = $termobject->label();
      }

      $allTags = "";
      foreach ($resultAllTags as $value) {
        if (!empty($testarray[$value->entity_id])) {
          $allTags .= '
            <div id="alltag-' . $value->entity_id . '"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i>
            <a href="/community-tag-clouds/' . $value->entity_id . '/' . $group_id . '" hreflang="en">' . $testarray[$value->entity_id] . '</a>
                </div></div>';
        }
      }

      $myTags = "";
      foreach ($resultMyTags as $value) {
        if (!empty($testarray[$value->entity_id])) {
          $myTags .= '
          <div id="mytag-' . $value->entity_id . '" class="my-custom-tag"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i>
          <a href="/community-tag-clouds/' . $value->entity_id . '/' . $group_id . '" hreflang="en">
          ' . $testarray[$value->entity_id] . '</a><a id="remove-tag" class="use-ajax"  href="/removeusertags/' . $value->entity_id . '/' . $value->node_id . '">x</a>
        </div></div>';
        }
      }
    }

    $response->addCommand(
      new HtmlCommand(
        '.result_message',
          '<div class="row" style="display: block;">
          <div class="" style="margin-bottom: 1rem;">
            <div class="d-flex flex-column p-3 gap-3 list-group-item bg-surface-secondary">
            <div id="alltag" class="field--label control-label"><label class="h5 gray-accent-subtle-text">All Tags</label></div>
            <div class="d-flex flex-row flex-wrap gap-3 align-items-center">
' . $allTags . '
</div></div></div>
<div class="">
  <div class="d-flex flex-column p-3 gap-3 list-group-item bg-surface-secondary">
<div  id="mytag" class="field--label control-label"><label class="h5 gray-accent-subtle-text">My Tags</label></div>
<div class="d-flex flex-row flex-wrap gap-3 align-items-center">
 ' . $myTags . '
</div></div></div></div></div></div>'
      ),
    );
    $response->addCommand(new InvokeCommand('#edit-field-tags', 'val', ['']));
    return $response;
  }

  /**
   * Submitting the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
