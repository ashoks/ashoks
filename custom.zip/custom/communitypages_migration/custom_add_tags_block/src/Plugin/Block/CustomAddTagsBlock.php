<?php

namespace Drupal\custom_add_tags_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;

/**
 * Provides a "add tags form block".
 *
 * @Block(
 *   id = "custom_add_tags_form_block",
 *   admin_label = @Translation("Custom Add Tags Block")
 * )
 */
class CustomAddTagsBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $group = \Drupal::routeMatch()->getParameter('group');
    $gid = '';

    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      // $group_type = $group->getGroupType()->id();
      $gid = !empty($group->id()) ? $group->id() : NULL;

      // Creating session for Taxonomy term page.
      $_SESSION['taxonomy_term_gid'] = $gid;

      // $field_community_type = $group->get('field_community_type')->value;
    }
    $user_id = \Drupal::currentUser()->id();

    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name == 'entity.node.preview') {
      $node = \Drupal::routeMatch()->getParameter('node_preview');
      if (isset($node)) {
        if (!$node->isNew() && $node->in_preview && ($node->bundle() == 'news')) {
          $nid = $node->id();
        }
      }
      if ($node && (($node->bundle() == 'news') || ($node->bundle() == 'pages') || ($node->bundle() == 'asset')) || ($node->bundle() == 'reference')) {
        $request = \Drupal::request();
        $session = $request->getSession();
        // $user_tags = $node->get('field_tags')->referencedEntities();
        $term_objects = isset($node) ? $node->get('field_tags')->referencedEntities() : NULL;
        $queryAllTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
        $queryAllTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
        $queryAllTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
        $queryAllTags->condition('gcf.node_id', $node->id());
        $queryAllTags->condition('gcf.deleted', 0);
        $queryAllTags->groupBy('gcf.entity_id');
        $queryAllTags->orderBy('tfd.name', 'asc');
        $resultAllTags = $queryAllTags->execute()->fetchAll();

        $queryMyTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
        $queryMyTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
        $queryMyTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
        $queryMyTags->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
        $queryMyTags->condition('gcf.node_id', $node->id());
        $queryMyTags->condition('gcf.deleted', 0);
        $queryMyTags->groupBy('gcf.entity_id');
        $queryMyTags->orderBy('tfd.name', 'asc');
        $resultMyTags = $queryMyTags->execute()->fetchAll();
        
        $testarray = [];
        foreach ($term_objects as $termobject) {
          $testarray[$termobject->id()] = $termobject->label();
        }
        natcasesort($testarray);
        $currentTags = [];
        foreach ($resultMyTags as $value) {
          if (isset($value->entity_id)) {
            $currentTags[$value->entity_id] = $value->entity_id;
          }
        }
        $currentTags = array_unique($currentTags);

        $resultAllTagsLables = [];
        foreach ($resultAllTags as $tag) {
          if (!empty($testarray[$tag->entity_id])) {
            $resultAllTagsLables[$tag->entity_id] = $testarray[$tag->entity_id];
          }
        }
        natcasesort($resultAllTagsLables);
        
        $allTags = "";
        foreach ($resultAllTagsLables as $key => $value) {
          if (!empty($testarray[$key])) {
            if(!in_array($key, $currentTags)){
              $allTags .= '<div id="alltag-' . $key . '">
                <div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i>
                  <a href="/community-tag-clouds/' . $key . '/' . $group_id . '" hreflang="en">' . $testarray[$key] . '</a>
                </div>
              </div>';
              unset($testarray[$value->entity_id]);
            }
          }
        }
  
        $myTags = "";
        // after unsetting the array we are left with the value which should be visible to all tag and my tag both 
        foreach ($testarray as $key => $value) {
          if (isset($value)) {
            $allTags .= '<div id="mytag-' . $key . '" class="my-custom-tag"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i><a href="/community-tag-clouds/' . $key . '/' . $group_id . '" hreflang="en">' . $value . '</a><a id="remove-tag" class="use-ajax"  href="/removeusertags/' . $value->entity_id . '/' . $value->node_id . '">x</a></div></div>';
            $myTags .= '<div id="mytag-' . $key . '" class="my-custom-tag"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i><a href="/community-tag-clouds/' . $key . '/' . $group_id . '" hreflang="en">' . $value . '</a><a id="remove-tag" class="use-ajax"  href="/removeusertags/' . $value->entity_id . '/' . $value->node_id . '">x</a></div></div>';
          }
        }
        return [
          '#theme' => 'custom_add_tags_block',
          '#data' => $gid,
          '#user_id' => $user_id,
          '#myTags' => $myTags,
          '#allTags' => $allTags,
          '#addTagsForm' => \Drupal::formBuilder()->getForm('\Drupal\custom_add_tags_block\Form\CustomAddTagsForm'),
          '#cache' => [
            'max-age' => 0,
          ],
        ];
      }
    }
    else {
      $node = \Drupal::routeMatch()->getParameter('node');
    }

    if ($node && $node instanceof NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();

      $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
      $field_group = isset($node) ? $node->get('field_community')->getValue() : NULL;
      $group_id = !empty($field_group) ? $field_group[0]['target_id'] : NULL;
      $term_objects = isset($node) ? $node->get('field_tags')->referencedEntities() : NULL;

      $queryAllTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
      $queryAllTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
      $queryAllTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
      $queryAllTags->condition('gcf.node_id', $nid);
      $queryAllTags->condition('gcf.deleted', 0);
      $queryAllTags->groupBy('gcf.entity_id');
      $queryAllTags->orderBy('tfd.name', 'asc');
      $resultAllTags = $queryAllTags->execute()->fetchAll();

      $queryMyTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
      $queryMyTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
      $queryMyTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
      $queryMyTags->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
      $queryMyTags->condition('gcf.node_id', $nid);
      $queryMyTags->condition('gcf.deleted', 0);
      $queryMyTags->groupBy('gcf.entity_id');
      $queryMyTags->orderBy('tfd.name', 'asc');
      $resultMyTags = $queryMyTags->execute()->fetchAll();

      $testarray = [];
      foreach ($term_objects as $termobject) {
        $testarray[$termobject->id()] = $termobject->label();
      }

      $resultAllTagsLables = [];
      foreach ($resultAllTags as $tag) {
        if (!empty($testarray[$tag->entity_id])) {
          $resultAllTagsLables[$tag->entity_id] = $testarray[$tag->entity_id];
        }
      }
      natcasesort($resultAllTagsLables);
      $allTags = "";
      foreach ($resultAllTagsLables as $key => $value) {
        if (!empty($testarray[$key]) && !empty($group_id)) {
          $allTags .= '
          <div id="alltag-' . $key . '">
            <div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i>
              <a href="/community-tag-clouds/' . $key . '/' . $group_id . '" hreflang="en">' . $value . '</a>
            </div>
          </div>';
        }
      }
      $resultMyTagsLables = [];
      foreach ($resultMyTags as $tag) {
        if (!empty($testarray[$tag->entity_id])) {
          $resultMyTagsLables[$tag->entity_id] = $testarray[$tag->entity_id];
        }
      }
      natcasesort($resultMyTagsLables);
      $myTags = "";
      foreach ($resultMyTagsLables as $key => $value) {
        if (!empty($testarray[$key]) && !empty($group_id)) {
          $myTags .= '
          <div id="mytag-' . $key . '" class="my-custom-tag">
            <div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i>
              <a href="/community-tag-clouds/' . $key . '/' . $group_id . '" hreflang="en">
            ' . $value . '</a>
            <a id="remove-tag" class="use-ajax"  href="/removeusertags/' . $key . '/' . $nid . '">    x</a>
            </div>
          </div>';
        }
      }
    }

    // Return ['#type' => 'markup', '#markup' => 'User Features Link Block'];.
    return [
      '#theme' => 'custom_add_tags_block',
      '#data' => $gid,
      '#user_id' => $user_id,
      '#myTags' => $myTags,
      '#allTags' => $allTags,
      '#addTagsForm' => \Drupal::formBuilder()->getForm('\Drupal\custom_add_tags_block\Form\CustomAddTagsForm'),
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }

}
