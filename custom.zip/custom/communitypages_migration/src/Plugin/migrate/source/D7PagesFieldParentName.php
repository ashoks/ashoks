<?php

namespace Drupal\communitypages_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "communitypages_field_parent_name"
 * )
 */
class D7PagesFieldParentName extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('node', 'n')
      ->fields('n', [
        'nid',
        'vid',
        'type',
        'sticky',
        'translate',
        'language',
        'title',
      ])
      ->condition('n.type', 'book');

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'nid' => $this->t('NID'),
      'vid' => $this->t('Revision ID'),
      'type' => $this->t('Type of node'),
      'sticky' => $this->t('Deleted'),
      'translate' => $this->t('Delta'),
      'language' => $this->t('Language'),
      'title' => $this->t('Title'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $entity_id = $row->getSourceProperty('nid');

    $query_uid = $this->select('book', 'b')
      ->fields('b', ['bid'])
      ->condition('b.nid', $entity_id);
    $result_uid = $query_uid->execute()->fetchObject();
    $bid = $result_uid->bid;
    if ($bid == $entity_id) {
      $bid = -1;
    }
    $row->setSourceProperty('title', $bid);

    // $entity_id = $row->getSourceProperty('nid');
    // $revision_id = $row->getSourceProperty('vid');
    // $parent_name_value = $row->getSourceProperty('bid');
    // $row->setSourceProperty('title', $parent_name_value);
    // $bundle = $row->getSourceProperty('type');
    $row->setSourceProperty('type', 'pages');
    // $deleted = $row->getSourceProperty('sticky');
    $row->setSourceProperty('sticky', 0);
    // $delta = $row->getSourceProperty('translate');
    $row->setSourceProperty('translate', 0);
    // $language = $row->getSourceProperty('language');
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['nid' => ['type' => 'integer']];
  }

}
