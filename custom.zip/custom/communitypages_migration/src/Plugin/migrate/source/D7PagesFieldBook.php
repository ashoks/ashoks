<?php

namespace Drupal\communitypages_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;
use Drupal\Core\Database\Database;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "communitypages_field_book"
 * )
 */
class D7PagesFieldBook extends SqlBase {

  /**
   * {@inheritdoc}
   *  We will create 3 extra column pid, p1, p2
   *  ALTER TABLE `book` ADD `pid` INT(255) NULL DEFAULT '0' AFTER `bid`, ADD `p1` INT(255) NULL DEFAULT '0' AFTER `pid`, ADD `p2` INT(255) NULL DEFAULT '0' AFTER `p1`;
   *  TRUNCATE TABLE `drupal10`.`book`
   * 
   */
  public function query() {
    $query = $this->select('book', 'n')
      ->fields('n', [
        'mlid',
        'nid',
        'bid',
      ]);
    $query->innerJoin('menu_links', 'ml', 'ml.mlid = n.mlid');
    $query->addField('ml', 'plid');
    $query->addField('ml', 'has_children');
    $query->addField('ml', 'weight');
    $query->addField('ml', 'depth');
    $query->addField('ml', 'p1');
    $query->addField('ml', 'p2');
    $query->addField('ml', 'p3');
    $query->addField('ml', 'p4');
    $query->addField('ml', 'p5');
    $query->addField('ml', 'p6');
    $query->addField('ml', 'p7');
    $query->addField('ml', 'p8');
    $query->addField('ml', 'p9');

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'nid' => $this->t('NID'),
      'bid' => $this->t('BID'),
      'pid' => $this->t('PID'),
      'has_children' => $this->t('has_children'),
      'weight' => $this->t('weight'),
      'depth' => $this->t('depth'),
      'p1' => $this->t('P1'),
      'p2' => $this->t('P2'),
      'p3' => $this->t('P3'),
      'p4' => $this->t('P4'),
      'p5' => $this->t('P5'),
      'p6' => $this->t('P6'),
      'p7' => $this->t('P7'),
      'p8' => $this->t('P8'),
      'p9' => $this->t('P9'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $nid = $row->getSourceProperty('nid');
    $bid = $row->getSourceProperty('bid');
    $pid = $row->getSourceProperty('plid');
    $p1 = $row->getSourceProperty('p1');
    $p2 = $row->getSourceProperty('p2');
    $p3 = $row->getSourceProperty('p3');
    $p4 = $row->getSourceProperty('p4');
    $p5 = $row->getSourceProperty('p5');
    $p6 = $row->getSourceProperty('p6');
    $p7 = $row->getSourceProperty('p7');
    $p8 = $row->getSourceProperty('p8');
    $p9 = $row->getSourceProperty('p9');

    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    if ($nid == $bid) {
      $row->setSourceProperty('pid', 0);
      $row->setSourceProperty('p1', $bid);
      $row->setSourceProperty('p2', 0);
    } else{
      $p1_nid = $p2_nid = $p3_nid = $p4_nid = $p5_nid = $p6_nid = $p7_nid = $p8_nid = $p9_nid = 0;

      $parent_nid = $db->select('book', 'c')
      ->fields('c', ['nid'])
      ->condition('mlid', $pid)
      ->execute()->fetchAll();
      $row->setSourceProperty('pid', $parent_nid[0]->nid);

      if($p1 != 0){
        $p1_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p1)
        ->execute()->fetchAll();
        $p1_nid = $p1_nid_value[0]->nid;
      }
      $row->setSourceProperty('p1', $p1_nid);

      if($p2 != 0){
        $p2_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p2)
        ->execute()->fetchAll();
        $p2_nid = $p2_nid_value[0]->nid;
      }
      $row->setSourceProperty('p2', $p2_nid);

      if($p3 != 0){
        $p3_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p3)
        ->execute()->fetchAll();
        $p3_nid = $p3_nid_value[0]->nid;
      }
      $row->setSourceProperty('p3', $p3_nid);

      if($p4 != 0){
        $p4_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p4)
        ->execute()->fetchAll();
        $p4_nid = $p4_nid_value[0]->nid;
      }
      $row->setSourceProperty('p4', $p4_nid);

      if($p5 != 0){
        $p5_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p5)
        ->execute()->fetchAll();
        $p5_nid = $p5_nid_value[0]->nid;
      }
      $row->setSourceProperty('p5', $p5_nid);

      if($p6 != 0){
        $p6_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p6)
        ->execute()->fetchAll();
        $p6_nid = $p6_nid_value[0]->nid;
      }
      $row->setSourceProperty('p6', $p6_nid);

      if($p7 != 0){
        $p7_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p7)
        ->execute()->fetchAll();
        $p7_nid = $p7_nid_value[0]->nid;
      }
      $row->setSourceProperty('p7', $p7_nid);

      if($p8 != 0){
        $p8_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p8)
        ->execute()->fetchAll();
        $p8_nid = $p8_nid_value[0]->nid;
      }
      $row->setSourceProperty('p8', $p8_nid);

      if($p9 != 0){
        $p9_nid_value = $db->select('book', 'c')
        ->fields('c', ['nid'])
        ->condition('mlid', $p9)
        ->execute()->fetchAll();
        $p9_nid = $p9_nid_value[0]->nid;
      }
      $row->setSourceProperty('p9', $p9_nid);
    }

    Database::setActiveConnection();
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['nid' => ['type' => 'integer']];
  }

}
