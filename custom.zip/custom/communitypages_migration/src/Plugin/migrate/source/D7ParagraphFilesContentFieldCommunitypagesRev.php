<?php

namespace Drupal\communitypages_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * Communitypages_field_content_files_revision source.
 *
 * @MigrateSource(
 *   id = "communitypages_field_content_files_revision"
 * )
 */
class D7ParagraphFilesContentFieldCommunitypagesRev extends FieldableEntity {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('field_revision_field_files', 'f')
      ->fields('f')
      ->orderBy('f.entity_id')
      ->condition('f.bundle', 'book');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $row->setSourceProperty('language', 'en');
    $row->setSourceProperty('bundle', 'pages');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
      'id' => $this->t('id'),
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'delta' => $this->t('The delta'),
      'language' => $this->t('The language'),
      'field_files_value' => $this->t('field files value'),
      'field_files_revision_id' => $this->t('field files revision id'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    return $ids;
  }

}
