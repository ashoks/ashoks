(function ($, Drupal) {
  Drupal.behaviors.custom_glossary = {
    attach: function (context, settings) {
      // Use context to ensure that newly loaded content is handled.
      var $containers = $('.view-all-communities, .view-my-communities, .view-pending-request, .view-my-invitations', context);
      $containers.each(function () {
        var $container = $(this);
        $('.ajax-progress-throbber').hide();
        // Attach event listeners to links within the selected elements, including pager links.
        $container.find('a').on('click', function (event) {
          if ($(this).hasClass('glossary-letter-link')) {
            $('.ajax-progress-throbber').show();
            event.preventDefault();
            var $link = $(this);
            var url = $link.attr('href');
  
            // Use jQuery's AJAX method to fetch the page content.
            $.ajax({
              url: url,
              type: 'GET',
              success: function (response) {
                var sanitizedRes = DOMPurify.sanitize(response);
                // Parse the response to extract the content.
                var $response = $(sanitizedRes);
                var $newContent = $response.find('.view-all-communities, .view-my-communities,.view-pending-request, .view-my-invitations');
  
                if ($newContent.length) {
                  $container.html($newContent.html());
  
                  // Re-attach event listeners to the new content, including pager links.
                  Drupal.behaviors.custom_glossary.attach(context, settings);
                  $('a.ajaxify-tag-community').each(function () {
                    if ($(this).text() == "Update This Block") {
                       Drupal.ajax({ url: $(this).attr("href") }).execute();
                    }
                  }) 
                }
  
                // Update the browser's URL.
                history.pushState(null, '', url);
              },
              error: function (jqXHR, textStatus, errorThrown) {
                console.error('AJAX request failed:', textStatus, errorThrown);
              }
            });
          }
        });
      });
      
      $(document).ajaxStop(function (event, xhr, settings) {
        $('.ajax-progress-throbber').hide();
      });
      // Handle back and forward button navigation.
      $(window).on('popstate', function () {
        var url = location.href;
        $.ajax({
          url: url,
          type: 'GET',
          success: function (response) {
            var sanitizedRes = DOMPurify.sanitize(response);
            var $response = $(sanitizedRes);
            var $newContent = $response.find('.view-all-communities, .view-my-communities, .view-pending-request, .view-my-invitations');

            if ($newContent.length) {
              $containers.html($newContent.html());

              // Re-attach event listeners to the new content, including pager links.
              Drupal.behaviors.custom_glossary.attach(context, settings);
            }
          },
          error: function (jqXHR, textStatus, errorThrown) {
            console.error('AJAX request failed:', textStatus, errorThrown);
          }
        });
      });
    }
  };
})(jQuery, Drupal);
