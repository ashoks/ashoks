<?php

namespace Drupal\custom_glossary\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Glossary Block' block.
 *
 * @Block(
 *   id = "glossary_block",
 *   admin_label = @Translation("Glossary Block"),
 * )
 */
class GlossaryBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The current route match.
   *
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $routeMatch;

  /**
   * Constructs a new GlossaryBlock instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager service.
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *   The route match service.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entity_type_manager, RouteMatchInterface $route_match) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->routeMatch = $route_match;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('current_route_match')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $current_url = \Drupal::service('path.current')->getPath();
    $parts = explode('/', $current_url);
    $query_params = \Drupal::request()->query->all();
    // Get the TempStore service.
    if (isset($parts[1])) {
      $current_path = '';
      $query_params = [];
      if ($parts[1] != 'group') {
        if(($parts[1] == 'user' && $parts[3] == 'pending-request') || ($parts[1] == 'user' && $parts[3] == 'community-invites')){
          $tempstore = \Drupal::service('tempstore.private')->get('custom_glossary');
          $query_params = \Drupal::request()->query->all();
          $tempstore->set('original_url', $current_url);
          $tempstore->set('query_params', $query_params);
          $parts = explode('/', $current_url);
          array_pop($parts);
          array_shift($parts);
          $current_path = implode('/', $parts);
          $parts = explode('/', $current_path);
        }
        else{
          $tempstore = \Drupal::service('tempstore.private')->get('custom_glossary');
          $query_params = \Drupal::request()->query->all();
          $tempstore->set('original_url', $current_url);
          $tempstore->set('query_params', $query_params);
          $parts = explode('/', $current_url);
          $current_path = $parts[1];
        }
      }
      if ($parts[1] == 'group') {
        $tempstore = \Drupal::service('tempstore.private')->get('custom_glossary');
        $current_url = $tempstore->get('original_url');
        $query_params = $tempstore->get('query_params');

        $parts = explode('/', $current_url);
        $current_path = $parts[1];
      }
      $letters = range('A', 'Z');
      // Get the current URL path.
      $current_path_url = $current_url;

      $links = [];
      $groups = [];
      $group_ids = [];
      $group_storage = $this->entityTypeManager->getStorage('group');
      $split_my_communities_base_url  = explode('/', MY_COMMUNITIES_BASE_URL);		
      if (isset($split_my_communities_base_url[0])) {
        
      }
      if ($parts[1] == $split_my_communities_base_url[0]) {
        $query = \Drupal::database()->select('group_relationship_field_data', 'grfd')
          ->fields('grfd', ['gid'])
          ->condition('entity_id', \Drupal::currentUser()->id())
          ->condition('type', '%group_membership%', 'LIKE');
        $result = $query->execute();
        $group_ids = $result->fetchCol();
        if (isset($query_params['title'])) {
          $query = \Drupal::database()->select('groups_field_data', 'gfd')
            ->fields('gfd', ['label','id']);
          // $query->accessCheck(TRUE);
          $query->condition('id', $group_ids, 'IN');
          $query->condition('label', '%' . $query_params['title']. '%', 'LIKE');
          $result = $query->execute();
          $groups_all = $result->fetchAllAssoc('id');
          if ($groups_all) {
            $group_ids = array_keys($groups_all);
          }
        }
      }
      else {
        // Get all groups.
        if (isset($query_params['title'])) {
          $query = \Drupal::database()->select('groups_field_data', 'gfd')
            ->fields('gfd', ['label','id']);
          // $query->accessCheck(TRUE);
          $query->condition('label', '%' . $query_params['title']. '%', 'LIKE');
          $result = $query->execute();
          $groups_all = $result->fetchAllAssoc('id');
          if ($groups_all) {
            $group_ids = array_keys($groups_all);
          }
        }
        else {
          $query = $group_storage->getQuery();
          $query->accessCheck(TRUE);
          $group_ids = $query->execute();
        }
      }
      $route_name = \Drupal::routeMatch()->getRouteName();
      if($route_name == 'view.pending_request.page_1'){
        $query = \Drupal::database()->select('group_relationship_field_data', 'grfd');
        $query->leftJoin('group_relationship__grequest_status', 'grs', 'grfd.id = grs.entity_id');
        $query->fields('grfd', ['gid']);
        $query->condition('grfd.entity_id', \Drupal::currentUser()->id());
        $query->condition('grfd.plugin_id', 'group_membership_request', '=');
        $query->condition('grs.grequest_status_value', 'pending', '=');
        $result = $query->execute();
        $group_ids = $result->fetchCol();
      }
      elseif($route_name == 'view.my_invitations.page_1'){
        $query = \Drupal::database()->select('group_relationship_field_data', 'grfd');
        $query->leftJoin('group_relationship__invitation_status', 'gis', 'grfd.id = gis.entity_id');
        $query->fields('grfd', ['gid']);
        $query->condition('grfd.entity_id', \Drupal::currentUser()->id());
        $query->condition('grfd.plugin_id', 'group_invitation', '=');
        $query->condition('gis.invitation_status_value', '0', '=');
        $result = $query->execute();
        $group_ids = $result->fetchCol();
      }
      if ($group_ids) {
        $groups = $group_storage->loadMultiple($group_ids);
        // Collect the letters that have corresponding group titles.
        $group_letters = [];
        foreach ($groups as $group) {
          $first_letter = strtoupper($group->label()[0]);
          if (in_array($first_letter, $letters)) {
            $group_letters[$first_letter] = $first_letter;
          }
        }
        // Generate the links only for the letters that have groups.
        $link_attributes = [
          'class' => ['use-ajax', 'glossary-letter-link'],
          'data-once' => "ajax",
        ];
        if (isset($query_params['page'])) {
          $query_params['page'] = 0;
        }
        foreach ($letters as $letter) {
          if (isset($group_letters[$letter])) {
            $url = Url::fromUri('internal:/' . $current_path . '/' . strtoupper($letter), ['query' => $query_params]);
            $letter_url = '/' . $current_path . '/' . strtoupper($letter);
            $letter_link_attributes = $link_attributes;
            if ($current_path_url == $letter_url) {
              $letter_link_attributes['class'][] = 'active';
            }
            $links[] = [
              '#type' => 'link',
              '#title' => $letter,
              '#url' => $url,
              '#attributes' => $letter_link_attributes,
            ];

          }
          // Note: commented to hide letters which dont have results
          // as requested to match design and senequa search result.
          // else {
          // $links[] = [
          // '#markup' => $letter,
          // ];
          // }.
        }
        $all_url = '/' . $current_path . '/all';
        $all_link_attributes = $link_attributes;
        if ($current_path_url == $all_url) {
          $all_link_attributes['class'][] = 'active';
        }
        $links[] = [
          '#type' => 'link',
          '#title' => t('All'),
          '#url' => Url::fromUri('internal:/' . $current_path . '/all', ['query' => $query_params]),
          '#attributes' => $all_link_attributes,
        ];
        $attributes['class'][] = 'glossary-links';
        $attributes['class'][] = 'd-flex';
        return [
          '#attached' => [
            'library' => [
              'custom_glossary/custom_glossary.links'
            ],
          ],
          '#theme' => 'item_list',
          '#items' => $links,
          '#attributes' => $attributes,
          // Add the loading spinner HTML.
          '#suffix' => '<div id="ajax-loading-spinner" class="glossary-spinner ajax-progress ajax-progress-throbber" style="display: none;"></div>',
          '#cache' => [
            'max-age' => 0,
          ],
        ];
      }
    }
  }

  /**
   * Get CacheMaxAge.
   *
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
