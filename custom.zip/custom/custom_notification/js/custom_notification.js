(function ($) {
    Drupal.behaviors.custom_notification = {
      attach: function (context) {
        if (!$('.custom-notification-listing-form table th > input').hasClass('form-check-input')) {
          $('.custom-notification-listing-form table th > input').addClass('form-check-input');
        }
        $('.path-notification-settings .dialog-off-canvas-main-canvas footer.footer').removeClass('bg-secondary');
        $('.path-messages .dialog-off-canvas-main-canvas footer.footer').removeClass('bg-secondary');
        var notifyCollapseDivs = document.querySelectorAll('.notify-expand');
        notifyCollapseDivs.forEach(div => {
            div.addEventListener('click', function () {
                var accordionItems = document.querySelectorAll('.custom-notification-user-settings-form .accordion-collapse');
                accordionItems.forEach(item => {
                  // var parent = $(item).parent();
                  // parent.css('border','1px solid #212529');
                  if (item.classList.contains('collapse')) {
                    item.classList.remove('collapse');
                    item.classList.add('collapsing');
                    setTimeout(() => {
                        item.classList.remove('collapsing');
                        item.classList.add('show');
                    }, 350); // Bootstrap collapse transition duration
                }
                });
                var accordionButtons = document.querySelectorAll('.custom-notification-user-settings-form .accordion-button');
                accordionButtons.forEach(item => {
                  if (item.classList.contains('collapsed')) {
                    item.classList.remove('collapsed');
                    item.setAttribute('aria-expanded',TRUE);
                  }
                });
            });
        });
        var notifyCollapseDivs = document.querySelectorAll('.notify-collapse');
        notifyCollapseDivs.forEach(div => {
            div.addEventListener('click', function () {
                var accordionItems = document.querySelectorAll('.custom-notification-user-settings-form .accordion-collapse');
                accordionItems.forEach(item => {
                  // var parent = $(item).parent();
                  // parent.css('border','1px solid white');
                    if (item.classList.contains('show')) {
                        item.classList.remove('show');
                        item.classList.add('collapsing');
                        setTimeout(() => {
                            item.classList.remove('collapsing');
                            item.classList.add('collapse');
                        }, 350); // Bootstrap collapse transition duration
                    }
                });
                var accordionButtons = document.querySelectorAll('.custom-notification-user-settings-form .accordion-button');
                accordionButtons.forEach(item => {
                  if (!item.classList.contains('collapsed')) {
                    item.classList.add('collapsed');
                    item.setAttribute('aria-expanded',FALSE);
                  }
                });
            });
        });

      },
    };
})(jQuery);
