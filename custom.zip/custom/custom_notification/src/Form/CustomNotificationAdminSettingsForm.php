<?php

namespace Drupal\custom_notification\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure example settings for this site.
 */
class CustomNotificationAdminSettingsForm extends ConfigFormBase {

  /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'custom_notification.admin_settings';

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_notification_admin_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);
    $content_type = 'notification_user_preference';
    // Define the field storage configuration.
    $types = CustomNotificationUserSettingsForm::getNotificationGroups();
    $sub_types = CustomNotificationUserSettingsForm::getNotificationSubTypes();
    $notification_type = CustomNotificationUserSettingsForm::getNotificationType();

    $field_details = [];
    foreach ($notification_type as $type_key => $type_text) {
      foreach ($sub_types as $notification_group_id => $actions_array) {
        foreach ($actions_array as $action_id => $action_text) {
          // Add fields here programmatically.
          $field_info = [
            'field_name' => 'field_' . $type_key . '_' . $notification_group_id . '_' . $action_id,
            'type' => 'boolean',
            'label' => $type_text . ' - ' . $types[$notification_group_id] . ' - ' . $action_text,
            'description' => $type_text . ' - ' . $types[$notification_group_id] . ' - ' . $action_text,
            'settings' => [],
          ];
          $options[$field_info['field_name']] = $field_info['description'];
        }
      }
    }
    $config = $this->config(static::SETTINGS);
    $form['notification_greyed_items'] = [
      '#type' => 'checkboxes',
      '#options' => $options,
      '#title' => $this->t('Fields to be greyed out.'),
      '#default_value' => ($config->get('notification_greyed_items')) ? $config->get('notification_greyed_items') : 0,
    ];
    $form['notification_default_values'] = [
      '#type' => 'checkboxes',
      '#options' => $options,
      '#default_value' => ($config->get('notification_default_values')) ? $config->get('notification_default_values') : 0,
      '#title' => $this->t('Default values.'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Retrieve the configuration.
    $this->config(static::SETTINGS)
      // Set the submitted configuration setting.
      ->set('notification_greyed_items', $form_state->getValue('notification_greyed_items'))
      // You can set multiple configurations at once by making
      // multiple calls to set().
      ->set('notification_default_values', $form_state->getValue('notification_default_values'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
