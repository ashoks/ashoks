<?php

namespace Drupal\custom_notification\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Pager\PagerManager;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Drupal\Core\Utility\TableSort;
use Drupal\user\Entity\User;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 *
 */
class CustomNotificationListingForm extends FormBase {
  /**
   * @var \Drupal\Core\Pager\PagerManager
   */
  protected $pagerManager;

  /**
   * Constructs a new CustomNotificationForm.
   *
   * @param \Drupal\Core\Pager\PagerManager $pager_manager
   *   The pager manager service.
   */
  public function __construct(PagerManager $pager_manager) {
    $this->pagerManager = $pager_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('pager.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_notification_listing_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['#title'] = $this->t('Notifications');
    $header = [
      'message' => [
        'data' => $this->t('Notification'),
        'field' => 'message',
      ],
      'issuer' => [
        'data' => $this->t('Issuer'),
        'field' => 'issuer',
      ],
      'date' => [
        'data' => $this->t('Date'),
        'field' => 'date',
        'sort' => 'desc',
      ],
    ];

    $form['#cache'] = ['max-age' => 0];

    $form['actions'] = [
      '#type' => 'actions',
      '#weight' => 100,
    ];
    $form['actions']['operation'] = [
      '#type' => 'select',
      '#title' => $this->t(''),
      '#options' => [
        'read' => $this->t('Mark as Read'),
        'unread' => $this->t('Mark as Unread'),
        'clear' => $this->t('Delete'),
      ],
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Apply'),
    ];

    $form['table'] = [
      '#type' => 'fieldset',
      '#collapsible' => FALSE,
      '#weight' => 500,
    ];
    $form['table']['top_pager'] = [
      '#type' => 'pager',
      '#weight' => 0,
    ];

    $form['table']['notifications'] = [
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => [],
      '#empty' => $this->t('No notifications available.'),
    ];

    $form['#attached']['library'][] = 'custom_notification/settings_form';

    $connection = \Drupal::database();

    // Get logged user session.
    $uid = \Drupal::currentUser()->id();
    $notificationType = 0;
    $totalCount = 0;
    $unreadCount = 0;
    $notificationList = [];

    $clerallQuery = $connection->select('notifications_clear_all', 'nca');
    $clerallQuery->fields('nca');
    $clerallQuery->condition('nca.uid', $uid);
    $clerallQuery->orderBy('nca.id', 'DESC');
    $ncaRes = $clerallQuery->execute()->fetchObject();
    $ncaResAll = $clerallQuery->execute()->fetchAll();

    $cleared_items = [];
    foreach ($ncaResAll as $k => $notify_obj) {
      $cleared_items[] = $notify_obj->notification_id;
    }
    $startingNotiId = $ncaRes->notification_id ?? 0;

    $query = $connection->select('notifications', 'n');
    $query->fields(
          'n', [
            'id',
            'message',
            'created',
            'entity_uid',
            'uid',
          ]
      );

    // $query->condition('n.id', $startingNotiId, '>');
    $query->condition('n.entity_uid', $uid);
    $query->condition('n.uid', $uid, '<>');
    $notificationType = 1;
    $query->orderBy('n.created', 'DESC');
    $res = $query->execute();
    while ($notification = $res->fetchObject()) {
      if (!empty($notification->message)) {
        $nasQuery = $connection->select('notifications_actions', 'nas');
        $nasQuery->fields('nas');
        $nasQuery->condition('nas.uid', $uid);
        $nasQuery->condition('nas.notification_id', $notification->id);
        $nasRes = $nasQuery->execute()->fetchObject();

        $nasId = $nasRes->id ?? '';
        $status = $nasRes->status ?? 0;
        $status_class = '';
        if ($status) {
          if ($nasRes->status == 1) {
            $status_class = 'read';
          }
          elseif ($nasRes->status == 2) {
            $status_class = 'delete';
          }
        }
        else {
          $status_class = 'unread';
        }
        if ($status == 2) {
          continue;
        }
        $notificationList[] = [
          'id'      => $notification->id,
          'nas_id'  => $nasId,
          'message' => $notification->message,
          'status'  => $status,
          'status_class' => $status_class,
          'created' => $notification->created,
          'uid' => $notification->uid,
          'entity_uid' => $notification->entity_uid,
        ];
        if (!in_array($notification->id, $cleared_items)) {
          if ($status == 0) {
            $unreadCount++;
          }
        }

        $totalCount++;
      }
    }
    $notification_list = [];
    foreach ($notificationList as $id => $data) {
      if (!in_array($data['id'], $cleared_items)) {
        $new_html = ($data['status_class'] == 'unread') ? '<span class="marker">new</span>' : '';
        $attributes = "data-id='" . $data['id'] . "' data-nas-id = '" . $data['nas_id'] . "' data-read-status = '" . $data['status_class'] . "'";
        $user_id = $data['uid'];
        $user = User::load($user_id);
        if ($user) {
          $url = Url::fromUri('internal:/user/' . $user_id . '/profile');
          $link = Link::fromTextAndUrl($user->getDisplayName(), $url)->toRenderable();
          // Add the tooltip/popup with user details
          // $user_details = $this->buildUserTooltip($user);
          $link['#attributes']['class'][] = 'username';
          // $link['#attributes']['data-tooltip-content'] = $user_details;
          $issuer = \Drupal::service('renderer')->render($link);
        }
        else {
          $issuer = '';
        }
        $notification_list[] = [
          'id' => $data['id'],
          'message' => Markup::create('<div class="' . $data['status_class'] . ' d-flex gap-1" ' . $attributes . '><div class="notification-msg">' . $data['message'] . $new_html . '</div></div>'),
        // \Drupal::entityTypeManager()->getStorage('user')->load($data['uid'])->getDisplayName(),
          'issuer' => $issuer,
          'date' => $this->format_notification_time($data['created']),
        ];
      }
    }

    // Initialize TableSort with the header.
    $table_sort = new TableSort($header);

    $order = TableSort::getOrder($header, \Drupal::request());
    $sort = TableSort::getSort($header, \Drupal::request());
    $php_sort = $sort == 'desc' ? SORT_DESC : SORT_ASC;
    // Sorting the notification list manually based on the sort field and order.
    usort($notification_list, function ($a, $b) use ($sort, $order) {
      // Extract the timestamp from the date text.
      $a_timestamp = strtotime($a[$order['sql']]);
      $b_timestamp = strtotime($b[$order['sql']]);

      // Sort based on the extracted timestamps.
      if ($sort === 'asc') {
          return ($a_timestamp < $b_timestamp) ? -1 : 1;
      }
      else {
          return ($a_timestamp > $b_timestamp) ? -1 : 1;
      }
    });

    if ($notification_list) {
      $request = \Drupal::request();
      TableSort::getContextFromRequest($header, $request);

      $items_per_page = 25;
      $current_page = $this->pagerManager->createPager(count($notification_list), $items_per_page)->getCurrentPage();
      $offset = $current_page * $items_per_page;
      $paged_notifications = array_slice($notification_list, $offset, $items_per_page);

      // $search_keyword = $form_state->getValue('search_keyword');
      //   if (!empty($search_keyword)) {
      //     $notifications = array_filter($notifications, function ($notification) use ($search_keyword) {
      //       return stripos($notification['message'], $search_keyword) !== false;
      //     });
      //   }
      //   $form['filter'] = [
      //     '#type' => 'fieldset',
      //     '#title' => $this->t('Filters'),
      //     "#collapsible" => FALSE,
      //     "#collapsed" => FALSE,
      //   ];
      //   $form['filter']['search_keyword'] = [
      //     '#type' => 'textfield',
      //     '#title' => $this->t('Search by Notification Message'),
      //     '#default_value' => $search_keyword,
      //   ];
      foreach ($paged_notifications as $notification) {
        $form['table']['notifications']['#options'][$notification['id']] = [
          'message' => $notification['message'],
          'issuer' => $notification['issuer'],
          'date' => $notification['date'],
        ];
      }
      $form['table']['pager'] = [
        '#type' => 'pager',
      ];
    }
    return $form;
  }

  /**
   * Format the notification timestamp.
   *
   * @param int $timestamp
   *   The timestamp of the notification.
   *
   * @return string
   *   The formatted timestamp.
   */
  public function format_notification_time($timestamp) {
    $current_time = \Drupal::time()->getRequestTime();
    $time_difference = $current_time - $timestamp;

    if ($time_difference < 60) {
      // Less than 60 seconds ago.
      return t('@seconds sec ago', ['@seconds' => $time_difference]);
    }
    elseif ($time_difference < 3600) {
      // Less than 60 minutes ago.
      $minutes = floor($time_difference / 60);
      return t('@minutes min ago', ['@minutes' => $minutes]);
    }
    else {
      // More than 60 minutes ago.
      if (date('Y-m-d', $timestamp) === date('Y-m-d', $current_time)) {
        // Notifications of today, display with "Time".
        return \Drupal::service('date.formatter')->format($timestamp, 'custom', 'g:i a');
      }
      elseif (date('Y', $timestamp) === date('Y', $current_time)) {
        // Notifications of the current year, display with "Month/Day".
        return \Drupal::service('date.formatter')->format($timestamp, 'custom', 'M j');
      }
      else {
        // Notifications of previous years, display with "MM/DD/YY".
        return \Drupal::service('date.formatter')->format($timestamp, 'custom', 'n/j/y');
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if ($form_state->getValue('operation') == 'clear' && empty(array_filter($form_state->getValue('notifications')))) {
      $form_state->setErrorByName('notifications', $this->t('You must select at least one notification to clear.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $selected_notifications = array_filter($form_state->getValue('notifications'));
    $operation = $form_state->getValue('operation');

    if ($operation == 'clear') {
      // Clear all notifications.
      $column_data = [];
      foreach ($selected_notifications as $id) {

        $connection = \Drupal::database();
        $query = $connection
          ->select('notifications_clear_all', 'na')
          ->fields('na', ['notification_id'])
          ->condition('notification_id', $id)
          ->execute();
        $result = $query->fetchAll();
        if (!$result) {
          // Add it to clear table.
          $column_data[] = [
            'notification_id' => $id,
            'created' => time(),
            'uid' => \Drupal::currentUser()->id(),
          ];

          // $num_updated = $connection->update('notifications_actions')
          // ->condition('notification_id', $id)
          // ->fields(['status' => 2])
          // ->execute();
        }

      }

      $connection = \Drupal::database();
      $query = $connection->insert('notifications_clear_all')->fields(['notification_id', 'created', 'uid']);
      foreach ($column_data as $record) {
        $query->values($record);
      }
      $query->execute();

      // Store record in private temp store.
      $store = \Drupal::service('tempstore.private')->get('custom_notification');
      $store->set('notifications_clear_all_data', $column_data);
      $store->set('operation', 'clear');

      // Create custom route /messages/undo/action with destination url as /messages/inbox
      // In custom route /messages/undo/action fetch stored record in private temp store and delete the records from notifications_clear_all table
      // Display a message with count of records restored. Message should say "Restored 1 notification",1 should be replaced with count.
      //
      \Drupal::messenger()->addMessage($this->t('Marked notification(s) deleted.'));
      // messages/undo/action?destination=messages/inbox.
      \Drupal::messenger()->addMessage($this->t('This action can be <a class="text-decoration-none" href="/messages/undo/action?destination=messages/inbox">undone.</a>'));

      // Remove data from notification_actions
      // $connection = \Drupal::database();
    }
    else {
      $count = 0;
      $columns = [];
      foreach ($selected_notifications as $id) {
        $count++;
        $connection = \Drupal::database();
        $query = $connection
          ->select('notifications_actions', 'na')
          ->fields('na', ['id'])
          ->condition('id', $id)
          ->execute();
        $result = $query->fetchAll();
        $column_data = [
          'notification_id' => $id,
          'id' => $id,
          'uid' => \Drupal::currentUser()->id(),
          'status' => 1,
          'created' => time(),
        ];
        $columns[] = $column_data;
        if ($operation == 'read') {
          // Perform the "mark as read" action for the selected notifications.
          if (isset($result[0])) {
            // \Drupal::messenger()->addMessage($this->t('Selected notification(s) already marked as read.'));
          }
          else {
            $connection = \Drupal::database();
            $connection->insert('notifications_actions')
              ->fields($column_data)
              ->execute();
            // Change Status to 1 as Read.
          }
        }
        elseif ($operation == 'unread') {
          if (isset($result[0])) {

            $connection = \Drupal::database();
            $connection->delete('notifications_actions')
              ->condition('id', $id)
              ->execute();
            // Perform the "mark as unread" action for the selected notifications.
            // \Drupal::messenger()->addMessage($this->t('Notification marked as unread.'));.
          }
          else {
            // \Drupal::messenger()->addMessage($this->t('Notification already marked as unread.'));
          }
        }
      }
      $store = \Drupal::service('tempstore.private')->get('custom_notification');
      $store->set('operation', $operation);
      $store->set('notifications_' . $operation . '_all_data', $columns);
      if ($count >= 1) {
        \Drupal::messenger()->addMessage($this->t('Marked @count notification(s) as @operation.', ['@count' => $count, '@operation' => $operation]));
        \Drupal::messenger()->addMessage($this->t('This action can be <a class="text-decoration-none" href="/messages/undo/action?destination=messages/inbox">undone.</a>'));
      }

    }
  }

}
