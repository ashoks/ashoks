<?php

namespace Drupal\custom_notification\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Config\ConfigFactory;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 *
 */
class CustomNotificationUserSettingsForm extends FormBase {

  /**
   * The configuration.
   *
   * @var \Drupal\Core\Config\ConfigFactory
   *  The config.
   */
  protected $config;

  /**
   * The Current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   *  The current user.
   */
  protected $currentUser;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * Constructs a new key form base.
   *
   * @param \Drupal\Core\Config\ConfigFactory $config
   *   The configuration.
   * @param \Drupal\Core\Session\AccountProxyInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Entity\EntityTypeManager $entity_type_manager
   *   The entity Type Manager.
   */
  public function __construct(ConfigFactory $config, AccountProxyInterface $current_user, $entity_type_manager) {
    $this->config = $config;
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('current_user'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_notification_user_settings_form';
  }

  /**
   * Gets the roles to display in this form.
   */
  public static function getNotificationType() {
    return [
      'ia' => t('In-app'),
      'em' => t('Email'),
    ];
  }

  /**
   *
   */
  public static function getNotificationGroups() {
    return [
    // - cl
      'cl' => 'Communities I Am A Leader/Moderator/Reference Manager Of',
    // Crj.
      'crj' => 'Communities I have Requested to Join',
    // Cij.
      'cij' => 'Communities I am Invited to Join',
    // Cm.
      'cm' => 'Communities I am a Member of',
      // 'cmf' => 'Communities I am Following',.
    // Cf.
      'cf' => 'Content I am Following',
    // Cic.
      'cic' => 'Content I have Created',
    // Ca.
      'asn' => 'Administration Specific Notifications',
    ];

  }

  /**
   *
   */
  public static function getNotificationSubTypes() {
    return [
      'cl' => [
        'ec' => t('Edits a Community'),
        'rm' => t('Requests to become a Member'),
        'ai' => t('Accepts invitation to join the Community'),
        'di' => t('Declines invitation to join the Community'),
        'jc' => t('Joins the Community'),
        'cc' => t('Creates Content'),
        'uc' => t('Updates Content'),
        'rc' => t('Rates Content'),
        'tc' => t('Tags Content'),
        'arc' => t('Adds a Comment or Replies to a Comment'),
        // 'ric' => t('Reports about inappropriate Content'),
      ],
      'crj' => [
        'amr' => t('Accepts my membership request'),
        'rmr' => t('Rejects my membership request'),
      ],
      'cij' => [
        'imc' => t('Invites me to become a member of a Community'),
      ],
      'cm' => [
        'jc' => t('Joins the Community'),
        'cc' => t('Creates Content'),
        'uc' => t('Updates Content'),
        'rc' => t('Rates Content'),
        'tc' => t('Tags Content'),
        'arc' => t('Adds a Comment or Replies to a Comment'),
      ],
      // 'cmf' => [
      //   'jc' => t('Joins the Community'),
      //   'cc' => t('Creates Content'),
      //   'uc' => t('Updates Content'),
      //   'rc' => t('Rates Content'),
      //   'tc' => t('Tags Content'),
      //   'arc' => t('Adds a Comment or Replies to a Comment'),
      // ],
      'cf' => [
        'uc' => t('Updates Content'),
        'rc' => t('Rates Content'),
        'tc' => t('Tags Content'),
        'arc' => t('Adds a Comment or Replies to a Comment'),
      ],
      'cic' => [
        'uc' => t('Updates Content'),
        'rc' => t('Rates Content'),
        'tc' => t('Tags Content'),
        'arc' => t('Adds a Comment or Replies to a Comment'),
        'da' => t('Downloads an Attachment'),
        // 'ric' => t('Reports about inappropriate Content'),
      ],
      'asn' => [
        'cc' => t('Creates a Community'),
        // 'ric' => t('Reports about inappropriate Content'),
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $settings = $config = $this->config->getEditable('custom_notification.admin_settings');
    $notification_greyed_items = $settings->get('notification_greyed_items');
    $notification_default_values = $settings->get('notification_default_values');
    $uid = \Drupal::currentUser()->id();
    $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
    if ($uid) {
      $required_fields = [
        'field_ia_cl_rm',
        'field_ia_crj_amr',
        'field_ia_crj_rmr',
        'field_ia_cij_imc',
        'field_ia_asn_cc',
      ];
      // Load the user's `notification_user_preference` Content type.
      $preferences = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['uid' => $uid, 'type' => 'notification_user_preference']);
      // If no preferences exist for the user, create a new one.
      if (empty($preferences)) {
        $preference = \Drupal::entityTypeManager()->getStorage('node')->create([
          'uid' => $user->id(),
          'type' => 'notification_user_preference',
          'title' => 'Notification settings for ' . $user->getDisplayName(),
        ]);
      }
      else {
        // Load the first (and should be only) existing preference.
        $preference = reset($preferences);
      }

      // Ensure the required fields are selected.
      $count = 0;
      foreach ($required_fields as $field) {
        if (!$preference->{$field}->value && $notification_default_values[$field]) {
          $count++;
          $preference->set($field, TRUE);
        }
      }

      if ($count) {
        // Save the updated or newly created preferences.
        $preference->save();
      }
    }
    $form['description']['#type'] = 'markup';
    $form['description']['#markup'] = t('<div class="ko-header bg-surface-secondary border-bottom-subtel"><h1 class="h4 mb-0">Notification Settings</h1>
    </div><div class="bg-surface-primary card border-subtle br-4 p-3"><p>For each type of notification, you can ask for being notified within the PRISM platform and / or for getting an e-mail notification. Every time the word content is used below, it means community page, asset, reference or news. You cannot get notifications for events.</p></div>');
    $notification_names = [];
    $form['expand_collapse'] = [
      '#type' => 'markup',
      '#markup' => t('<div class="cani-notify-collapse-all"><span class="notify-expand">Expand All</span> | <span class="notify-collapse">Collapse All</span></div>'),
    ];
    $form['#attached']['library'][] = 'custom_notification/settings_form';
    $group_settings = [];
    $notification_groups = $this->getNotificationGroups();
    $content_type = 'notification_user_preference';
    $data = self::checkCurrentUserNodeQuery($content_type);
    $node = '';
    if (!empty($data['query'])) {
      $node_storage = $data['node_storage'];
      $node_id = reset($data['query']);
      $node = $node_storage->load($node_id);
    }
    $items = $this->getNotificationSubTypes();
    $groups = $this->getNotificationGroups();
    $rows = [];
    $form['#prefix'] = '<div id="notification-form-wrapper d-flex flex-column notification">';
    $form['#suffix'] = '</div>';
    // $form['submit'] = [
    //   '#type' => 'submit',
    //   '#value' => $this->t('Submit'),
    // ];
    foreach ($items as $k => $v) {
      $header = [
        'item' => $this->t('Notify me when someone…'),
        'ia' => $this->t('In-App'),
        'em' => $this->t('Email'),
      ];
      // For Non Admins, do not show Administration Specific Notifications.
      if ($k == 'asn') {
        if (\Drupal::currentUser()->hasRole('administrator')) {
          $form = self::buildTable($k, $v, $groups, $header, $notification_default_values, $notification_greyed_items, $node, $form);
        }
      }
      else {
        $form = self::buildTable($k, $v, $groups, $header, $notification_default_values, $notification_greyed_items, $node, $form);
      }
    }
    return $form;
  }

  /**
   * Define a function to handle common form element creation.
   */
  protected function buildTable($k, $v, $groups, $header, $notification_default_values, $notification_greyed_items, $node, &$form) {
    $form['collapsible_' . $k] = [
      '#type' => 'details',
      '#title' => t($groups[$k]),
      '#description' => (!in_array($k, ['cm','cf','cic'])) ? t('Greyed out marks in boxes below cannot be disabled.') : '',
      '#open' => TRUE,
    ];

    $form['collapsible_' . $k]['table_' . $k] = [
      '#type' => 'table',
      '#header' => $header,
    ];

    foreach ($v as $k2 => $v2) {
      $form['collapsible_' . $k]['table_' . $k]['table_' . $k2]['item'] = [
        '#prefix' => '<div>',
        '#markup' => $v2,
        '#suffix' => '</div>',
      ];

      $fields = ['field_ia_' . $k . '_' . $k2, 'field_em_' . $k . '_' . $k2];
      foreach ($fields as $field_name) {
        $default_admin_value = ($notification_default_values[$field_name] === 0) ? FALSE : TRUE;
        $form['collapsible_' . $k]['table_' . $k]['table_' . $k2][$field_name] = [
          '#type' => 'checkbox',
          '#default_value' => ($node && $node->{$field_name}->value) ? $node->{$field_name}->value : $default_admin_value,
          '#disabled' => ($notification_greyed_items[$field_name] === 0) ? FALSE : TRUE,
          '#ajax' => [
            'callback' => '::ajaxSubmitCallback',
            'event' => 'change',
          ],
        ];
      }
    }

    return $form;
  }

  /**
   * {@inheritdoc}-
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $data = $form_state->getValues();
    $content_type = 'notification_user_preference';
    $field_names_enabled = [];
    $field_names_disabled = [];
    foreach ($data as $k => $v) {
      if (strpos($k, 'table_') !== FALSE) {
        $parts = explode('table_', $k);
        $group = $parts[1];
        foreach ($v as $k1 => $v1) {
          $parts_2 = explode('table_', $k1);
          $sub_type = $parts_2[1];
          $type = 'ia';
          if ($v1['field_ia_' . $group . '_' . $sub_type]) {
            $type = 'ia';
            $field_names_enabled[] = 'field_' . $type . '_' . $group . '_' . $sub_type;
          }
          else {
            $field_names_disabled[] = 'field_' . $type . '_' . $group . '_' . $sub_type;
          }
          $type = 'em';
          if ($v1['field_em_' . $group . '_' . $sub_type]) {
            // Tick mark.
            $field_names_enabled[] = 'field_' . $type . '_' . $group . '_' . $sub_type;
          }
          else {
            $field_names_disabled[] = 'field_' . $type . '_' . $group . '_' . $sub_type;
          }
        }
      }
    }
    $currentUser = $this->currentUser;
    $response_data = self::checkCurrentUserNodeQuery($content_type, $currentUser);
    $node = '';
    if (!empty($response_data['query'])) {
      $node_storage = $response_data['node_storage'];
      $node_id = reset($response_data['query']);
      $node = $node_storage->load($node_id);
      foreach ($field_names_enabled as $name) {
        $node->set($name, 1);
      }
      foreach ($field_names_disabled as $name) {
        $node->set($name, 0);
      }
      $node->save();
    }
    else {
      $node_metadata = [
      // Change this to your Content type machine name.
        'type' => $content_type,
        'title' => 'Notification Settings for user ' . $currentUser->getDisplayName(),
        'uid' => $currentUser->id(),
      // 1 means published, 0 means unpublished
        'status' => 1,
      ];
      foreach ($field_names_enabled as $name) {
        $node_metadata[$name] = 1;
      }
      foreach ($field_names_disabled as $name) {
        $node_metadata[$name] = 0;
      }
      $node = $this->entityTypeManager->getStorage('node')->create($node_metadata);
      $node->save();
    }

    $this->messenger()->addStatus($this->t('The changes have been saved.'));
  }

  /**
   *
   */
  public static function checkCurrentUserNodeQuery($content_type, AccountProxyInterface $currentUser = NULL, $user_id = NULL) {
    if (!$user_id) {
      if (!$currentUser) {
        $currentUser = \Drupal::currentUser();
      }
    }
    $user_id = ($user_id) ? $user_id : $currentUser->id();
    $node_storage = \Drupal::entityTypeManager()->getStorage('node');
    $query = $node_storage->getQuery()
      ->condition('uid', $user_id)
      ->condition('type', $content_type)
      ->accessCheck(FALSE)
      ->range(0, 1)
      ->execute();
    return ['query' => $query, 'node_storage' => $node_storage];
  }

  /**
   * AJAX callback to handle checkbox change event.
   */
  public function ajaxSubmitCallback(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    // Call the submit handler.
    $this->submitForm($form, $form_state);

    // Optionally, you can return a message to indicate the checkbox change was processed.
    $response->addCommand(new ReplaceCommand('#notification-form-wrapper', $form));
    return $response;
  }

}