<?php

namespace Drupal\custom_notification\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 *
 */
class CustomNotificationSetDefaultSettingsForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_notification_set_default_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Define the required fields.
    $required_fields = [
      'field_ia_cl_rm' => $this->t('Request to become a member'),
      'field_ia_crj_amr' => $this->t('Accepts my membership request'),
      'field_ia_crj_rmr' => $this->t('Rejects my membership request'),
      'field_ia_cij_imc' => $this->t('Invites me to become a member'),
      'field_ia_asn_cc' => $this->t('Creates a Community'),

    ];

    // Build the form.
    foreach ($required_fields as $field => $label) {
      $form[$field] = [
        '#type' => 'checkbox',
        '#title' => $label,
        '#default_value' => TRUE,
        '#disabled' => TRUE,
      ];
    }

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save and Update Preferences'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Define the required fields.
    $required_fields = [
      'field_ia_cl_rm',
      'field_ia_crj_amr',
      'field_ia_crj_rmr',
      'field_ia_cij_imc',
      'field_ia_asn_cc',
    ];

    // Start the batch process to update user preferences.
    $this->startBatchProcess($required_fields);
  }

  /**
   * Starts the batch process to update user preferences.
   */
  protected function startBatchProcess(array $required_fields) {
    $batch = [
      'title' => t('Updating user notification preferences...'),
      'finished' => get_called_class() . '::batchFinishedCallback',
    ];

    // Define the batch size (number of users to load at a time).
    $batch_size = 10;

    // Query the user IDs in chunks instead of loading all at once.
    $query = \Drupal::entityQuery('user')
    // Load only active users (adjust condition as needed)
      ->condition('status', 1)
      ->sort('uid', 'ASC')
      ->accessCheck(FALSE);
    $result = $query->execute();

    // Chunk the user IDs to process in batches.
    $user_ids = array_chunk($result, $batch_size);
    // Add operations for each user, but load users in chunks.
    foreach ($user_ids as $chunk) {
      // Load users in a batch, but process each user individually.
      $users = \Drupal::entityTypeManager()->getStorage('user')->loadMultiple($chunk);
      foreach ($users as $user) {
        $data = [
        // Pass one user at a time.
          'user' => $user,
          'required_fields' => $required_fields,
        ];
        $data['total_count'] = count($result);

        $batch['operations'][] = [get_called_class() . '::batchUpdateUserPreferences', [$data]];
      }
    }
    batch_set($batch);
  }

  /**
   * Batch process to update user preferences.
   */
  public static function batchUpdateUserPreferences(array $data, &$context) {
    $context['sandbox']['current_user'] = isset($context['sandbox']['current_user']) ? $context['sandbox']['current_user'] + 1 : 0;
    $user = $data['user'];
    $required_fields = $data['required_fields'];
    if ($user) {
      // Load the user's `notification_user_preference` content type.
      $preferences = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['uid' => $user->id(), 'type' => 'notification_user_preference']);

      // If no preferences exist for the user, create a new one.
      if (empty($preferences)) {
        $preference = \Drupal::entityTypeManager()->getStorage('node')->create([
          'uid' => $user->id(),
          'type' => 'notification_user_preference',
          'title' => 'Notification settings for ' . $user->getDisplayName(),
        ]);
      }
      else {
        // Load the first (and should be only) existing preference.
        $preference = reset($preferences);
      }

      // Ensure the required fields are selected.
      foreach ($required_fields as $field) {
        $preference->set($field, TRUE);
      }

      // Save the updated or newly created preferences.
      $preference->save();
    }

    // Update the progress.
    $context['sandbox']['progress'] = $context['sandbox']['current_user'] + 1;
    $total_users = $data['total_users'];

    if ($context['sandbox']['progress'] >= $total_users) {
      $context['finished'] = 1;
    }
    else {
      $context['finished'] = $context['sandbox']['progress'] / $total_users;
    }
  }

  /**
   * Batch finished callback.
   */
  public static function batchFinishedCallback($success, $results, $operations) {
    if ($success) {
      \Drupal::messenger()->addStatus(t('User notification preferences have been updated successfully.'));
    }
    else {
      \Drupal::messenger()->addError(t('An error occurred while updating user notification preferences.'));
    }
  }

}
