<?php

namespace Drupal\custom_notification\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class CustomNotificationController.
 *
 * Handles the redirection for community invites.
 */
class CustomNotificationController extends ControllerBase {

  /**
   * Redirects to the current user's community invites page.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   A redirect response to the user's community invites page.
   */
  public function redirectToUserCommunityInvites() {
    // Get the current user ID.
    $current_user = $this->currentUser();
    $uid = $current_user->id();

    // Build the URL for the user.
    $url = "/user/{$uid}/community-invites/all";

    // Redirect to the constructed URL.
    return new RedirectResponse($url);
  }

}
