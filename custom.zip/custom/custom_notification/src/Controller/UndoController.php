<?php

namespace Drupal\custom_notification\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 *
 */
class UndoController extends ControllerBase {

  protected $tempStoreFactory;

  public function __construct(PrivateTempStoreFactory $temp_store_factory) {
    $this->tempStoreFactory = $temp_store_factory;
  }

  /**
   *
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('tempstore.private')
    );
  }

  /**
   *
   */
  public function undoAction() {
    $store = $this->tempStoreFactory->get('custom_notification');
    $records = $store->get('notifications_clear_all_data');

    if ($records) {
      $connection = \Drupal::database();
      // Delete the restored entries from the notifications_clear_all table.
      $ids = array_column($records, 'notification_id');
      $connection->delete('notifications_clear_all')
        ->condition('notification_id', $ids, 'IN')
        ->execute();
      $store->delete('notifications_clear_all_data');

      $count = count($records);
      \Drupal::messenger()->addMessage($this->t('Restored @count notification(s)', ['@count' => $count]));
    }
    else {
      \Drupal::messenger()->addMessage($this->t('No notifications to restore.'));
    }

    return new RedirectResponse('/messages/inbox');
  }

}
