<?php

namespace Drupal\custom_notification\Installer;

use Drupal\custom_notification\Form\CustomNotificationUserSettingsForm;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\node\Entity\NodeType;

/**
 *
 */
class CustomNotificationFieldsInstaller {

  /**
   * Creates fields for the content type.
   */
  public static function createFields() {
    // Define the content type and the fields.
    $content_type = 'notification_user_preference';

    // Check if the content type exists.
    if (!NodeType::load($content_type)) {
      \Drupal::logger('custom_fields')->error('Content type %type does not exist.', ['%type' => $content_type]);
      return;
    }
    self::bulkUpdatefields('create');

  }

  /**
   *
   */
  protected static function fieldUpdate($action, $field_info, $content_type) {
    if ($action == 'create') {
      // @todo check if field exists
      FieldStorageConfig::create([
        'field_name' => $field_info['field_name'],
        'entity_type' => 'node',
        'type' => $field_info['type'],
        'settings' => $field_info['settings'],
      ])->save();
      FieldConfig::create([
        'field_storage' => FieldStorageConfig::loadByName('node', $field_info['field_name']),
        'bundle' => $content_type,
        'label' => $field_info['label'],
        'description' => $field_info['description'],
        'required' => FALSE,
      ])->save();
    }
    if ($action == 'delete') {
      $field_name = $field_info['field_name'];
      if ($field = FieldConfig::loadByName('node', 'notification_user_preference', $field_name)) {
        $field->delete();
      }
      if ($field_storage = FieldStorageConfig::loadByName('node', $field_name)) {
        $field_storage->delete();
      }
    }

  }

  /**
   * Implements bulk update fields.
   */
  public static function bulkUpdatefields($action) {
    $content_type = 'notification_user_preference';
    // Define the field storage configuration.
    $types = CustomNotificationUserSettingsForm::getNotificationGroups();
    $sub_types = CustomNotificationUserSettingsForm::getNotificationSubTypes();
    $notification_type = CustomNotificationUserSettingsForm::getNotificationType();

    $field_details = [];
    foreach ($notification_type as $type_key => $type_text) {
      foreach ($sub_types as $notification_group_id => $actions_array) {
        foreach ($actions_array as $action_id => $action_text) {
          // Add fields here programmatically.
          $field_info = [
            'field_name' => 'field_' . $type_key . '_' . $notification_group_id . '_' . $action_id,
            'type' => 'boolean',
            'label' => $type_text . ' - ' . $types[$notification_group_id] . ' - ' . $action_text,
            'description' => $type_text . ' - ' . $types[$notification_group_id] . ' - ' . $action_text,
            'settings' => [],
          ];
          $field_config = FieldConfig::loadByName('node', $content_type, $field_info['field_name']);
          if ($field_config) {
            self::fieldUpdate($action, $field_info, $content_type);
          }

        }
      }
    }

  }

  /**
   * Deletes the fields.
   */
  public static function deleteFields() {
    // Define the fields to delete.
    // @todo check if data exists
    self::bulkUpdatefields('delete');

  }

}
