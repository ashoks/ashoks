<?php

namespace Drupal\custom_notification\EventSubscriber;

use Drupal\node\Entity\Node;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 *
 */
class FileDownloadSubscriber implements EventSubscriberInterface {
  protected $logger;

  public function __construct(LoggerInterface $logger) {
    $this->logger = $logger;
  }

  /**
   *
   */
  public static function getSubscribedEvents() {
    $events[KernelEvents::REQUEST][] = ['onKernelRequest'];
    return $events;
  }

  /**
   *
   */
  public function onKernelRequest(RequestEvent $event) {
    $request = $event->getRequest();
    $current_path = $request->getPathInfo();

    // Check if the path indicates a file download
    // change to relevant folder name as per the setting in field_attachment.
    $folder_name = 'attachment';
    $field_name = 'field_attachment';
    // $paragraph_field_names = ['field_files','field_content_files'];
    if (strpos($current_path, '/system/files/' . $folder_name) === 0) {
      // Determine if the file is being viewed or downloaded
      // $action = $this->isDownloadRequest($request) ? 'downloaded' : 'viewed';
      // Log the file download or perform any other tracking logic.
      $file = $this->getFileEntityFromPath($current_path);
      // @todo edge case, what if file name are same. need to test that scenario
      if ($file) {
        $node = $this->getNodeFromParagraphFile($file, $field_name);
        $notificationService = \Drupal::service('notifications_widget.logger');
        $tokenService = \Drupal::service('token');
        if ($node) {
          $user = \Drupal::entityTypeManager()->getStorage('user')->load(\Drupal::currentUser()->id());
          if ($node->field_community->target_id) {
            $gid = $node->field_community->target_id;
            if ($gid) {
              $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
              $group_member_data = custom_notification_get_group_members_with_roles($group);
              $user_id_notified = [];
              // ia_cic_da.
              $process_arguments = [
                'template' => 'ia_cic_da',
                'group_type' => 'cic',
                'group_member_data' => $group_member_data,
                'user_id_notified' => $user_id_notified,
                'entity' => $node,
                'node_owner' => $node->getOwner(),
                'group' => $group,
                // 'notificationService' => $notificationService,
                // 'tokenService' => $tokenService,
                'nid' => $node->id(),
                'notify_data' => NULL,
                'action' => 'viewed',
                'is_comment' => NULL,
                'is_group' => NULL,
                'file_uri' => $current_path,
              ];
              $user_id_notified = custom_notification_process_templates($process_arguments);
            }
          }
        }
      }
    }
  }

  /**
   *
   */
  protected function getFileEntityFromPath($path) {
    $private_path = '/system/files/';
    $file_uri = '';
    if (strpos($path, $private_path) === 0) {
      $file_uri = 'private://' . substr($path, strlen($private_path));
    }
    $uri = rawurldecode($file_uri);
    if ($uri) {
      $query = \Drupal::database()->select('file_managed', 'f')
        ->fields('f', ['fid'])
        ->condition('uri', $uri)
        ->execute();
      $fid = $query->fetchField();

      if ($fid) {
        $file = \Drupal::entityTypeManager()->getStorage('file')->load($fid);
        return $file;
      }
    }
    return NULL;
  }

  /**
   *
   */
  protected function getNodeFromFile($file, $field_name) {
    $node = NULL;
    $query = \Drupal::entityTypeManager()->getStorage('node')
      ->getQuery()
      ->condition($field_name, $file->id())
      ->range(0, 1)
      ->accessCheck(FALSE);
    $result = $query->execute();
    if (!is_null($result)) {
      $nid = end($result);
      if (is_numeric($nid)) {
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
      }
      return $node;
    }
    return NULL;
  }

  /**
   *
   */
  protected function getNodeFromParagraphFile($file, $field_name) {
    // Load all paragraphs that reference this file.
    $paragraph_storage = \Drupal::entityTypeManager()->getStorage('paragraph');
    $paragraph_ids = $paragraph_storage->getQuery()
      ->condition($field_name . '.target_id', $file->id())
      ->accessCheck(FALSE);
    $result = $paragraph_ids->execute();
    $node = NULL;
    foreach ($result as $paragraph_id) {
      $paragraph = $paragraph_storage->load($paragraph_id);
      if ($paragraph) {
        // Check for the parent node.
        $parent_entities = $paragraph->getParentEntity();
        if (is_object($parent_entities)) {
          $node = $parent_entities;
        }
        if (is_array($parent_entities)) {
          // @todo to find out a way to decide if we have multiple parent entities ie. node for single file
          foreach ($parent_entities as $parent_entity) {
            if ($parent_entity instanceof Node) {
              $node = $parent_entity;
            }
          }
        }

      }
    }

    return $node;
  }

  // Protected function isDownloadRequest($request) {
  //   $content_disposition = $request->headers->get('content-disposition');
  //   return (strpos($content_disposition, 'attachment') !== false);
  // }.
}
