<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications for new published nodes.
 *
 * @QueueWorker(
 *   id = "custom_notification_individual_user_notify_queue",
 *   title = @Translation("Custom Notification Indiividual User Notify Queue Worker"),
 * )
 */
class CustomNotificationIndividualUserNotify extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($queue_data) {
    // Load the node entity using the node ID from the $data array.
    $start_time = custom_notification_note_statistics('start', '');
    $site_url = $queue_data['site_url'];
    if (($queue_data['process_arguments']['template'] == 'ia_crj_amr' ) ||
        ($queue_data['process_arguments']['template'] == 'ia_crj_rmr' )) {
          $process_arguments = $queue_data['process_arguments'];
          $user_id = $process_arguments['entity']->get('uid')->getValue('')[0]['target_id'];
          $template_keys  = explode('_', $process_arguments['template']);
         $message_notify = self::createNotificationMessage(
              $process_arguments['template'], 
              $user_id, 
              $process_arguments['entity'], 
              $process_arguments['node_owner'], 
              $process_arguments['group'], 
              \Drupal::service('token'), 
              $process_arguments['nid'], 
              $process_arguments['is_comment'], 
              $process_arguments['is_group'], 
              $template_keys,
              $site_url,
              NULL
            );
      $notificationService = \Drupal::service('notifications_widget.logger');
      $notificationService->logNotification($message_notify, 'create', $queue_data['process_arguments']['entity'], $user_id, NULL);

      $email_template = str_replace('ia', 'em', $process_arguments['template']);
          $email_field_key = 'field_' . $email_template;
          $template_keys = explode('_', $email_template);
          $notification_node_status = custom_notification_get_notification_settings($user_id, $email_template);
          if ($notification_node_status) {
            $email_message_notify = self::createNotificationMessage(
              $email_template, 
              $user_id, 
              $process_arguments['entity'], 
              $process_arguments['node_owner'], 
              $process_arguments['group'], 
              \Drupal::service('token'), 
              $process_arguments['nid'], 
              $process_arguments['is_comment'], 
              $process_arguments['is_group'], 
              $template_keys,
              $site_url,
              NULL
            );
            $process_arguments['user_id_notified'][] = $user_id;
            if ($email_message_notify) {
                self::sendEmailNotification($email_message_notify, $user_id, $email_template, $process_arguments['notify_data'], $site_url, NULL);
            } else {
              \Drupal::logger('custom_notification')->notice('Email template for message template having machine name ' . $email_template . ' is missing');
            }
         }
    }
    else {
      $user_id = $queue_data['user_id'];
      $user = $queue_data['user'];
      if (!is_null($user)) {
        $current_user = $queue_data['current_user']; // who accepted
        if ($queue_data['validation']) {
          $process_arguments = $queue_data['process_arguments'];
          $user_id_who_invited = (isset($process_arguments['entity']->get('uid')->getValue()[0])) ? $process_arguments['entity']->get('uid')->getValue()[0]['target_id'] : '';
            $template_keys = explode('_', $process_arguments['template']);
            $ai_di_status = TRUE;
            //closed group
            if (($process_arguments['template'] == 'ia_cl_ai' || $process_arguments['template'] == 'ia_cl_di')) {
              if ($user_id_who_invited  != $user_id) {
                //do not send email if user did not invite
                $ai_di_status = FALSE;
              }
            }
            if ($ai_di_status) { 
              //ia_crj_amr 
              $email_template = str_replace('ia', 'em', $process_arguments['template']);
              $notification_node_status = custom_notification_get_notification_settings($user->id(), $email_template);
              $field_key = 'field_' . $email_template;
              if ($notification_node_status) {         
                $message_notify = self::createNotificationMessage(
                  $process_arguments['template'], 
                  $user_id, 
                  $process_arguments['entity'], 
                  $process_arguments['node_owner'], 
                  $process_arguments['group'], 
                  \Drupal::service('token'), 
                  $process_arguments['nid'], 
                  $process_arguments['is_comment'], 
                  $process_arguments['is_group'], 
                  $template_keys,
                  $site_url,
                  $current_user
                );
                $recipient_uid = $user_id;
                $operator_uid = null;
                if (isset($message_notify['recipient_uid'])) {
                  $recipient_uid = $message_notify['recipient_uid'];
                }
                if (isset($message_notify['operator_uid'])) {
                  $operator_uid = $message_notify['operator_uid'];
                }
                $notificationService = \Drupal::service('notifications_widget.logger');
                $notificationService->logNotification($message_notify, $process_arguments['action'], $process_arguments['entity'], $recipient_uid, $operator_uid);
              }

              // Email notification
              $email_template = str_replace('ia', 'em', $process_arguments['template']);
              $email_field_key = 'field_' . $email_template;
              $template_keys = explode('_', $email_template);
              $notification_node_status = custom_notification_get_notification_settings($user->id(), $email_template);
              if ($notification_node_status) {
                $email_message_notify = self::createNotificationMessage(
                  $email_template, 
                  $user_id, 
                  $process_arguments['entity'], 
                  $process_arguments['node_owner'], 
                  $process_arguments['group'], 
                  \Drupal::service('token'), 
                  $process_arguments['nid'], 
                  $process_arguments['is_comment'], 
                  $process_arguments['is_group'], 
                  $template_keys,
                  $site_url,
                  $current_user
                );
                $process_arguments['user_id_notified'][] = $user_id;
                if ($email_message_notify) {
                    self::sendEmailNotification($email_message_notify, $user_id, $email_template, $process_arguments['notify_data'], $site_url, $current_user);
                } else {
                  \Drupal::logger('custom_notification')->notice('Email template for message template having machine name ' . $email_template . ' is missing');
                }
              }
            }
        }
      }
      
    }


    custom_notification_note_statistics('end', 'custom_notification_individual_user_notify_queue', $start_time);

  }

  /**
    * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $user_id, $entity, $node_owner, $group, $tokenService, $nid, $is_comment, $is_group, $template_keys, $site_url, $current_user = NULL) {
    $message = Message::create(['template' => $template, 'uid' => $user_id]);
    $tokenService = ($tokenService) ? $tokenService : \Drupal::token();
    $content_data = [];
    $bundle = '';
    $body = '';
    $content_link = '';
    if ($message->getTemplate()) {
      $message_template = $message->getTemplate();
      $body = '';
      if ($message_template->get('text')[0]['value']) {
        $body = str_replace('[site:url]', $site_url, $message_template->get('text')[0]['value']);
      }
      $description = '';
      if ($message_template->get('description')) {
        $description = str_replace('[site:url]', $site_url, $message_template->get('description'));
      }
      $bundle = 'node';
      $node = null;
      if ($entity->getEntityTypeId() != 'node') {
        if ($nid && is_numeric($nid)) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
        }
      }
      $content_data = [
        'node' => ($node) ? $node : $entity,
        'user' => $node_owner,
        'group' => $group,
        'vote' => ($entity->getEntityTypeId() == 'vote') ? $entity : NULL
      ]; 
      $node_type = $node ? $node->bundle() : NULL;
      if ($node_type === 'pages') {
          $node_type = 'page';
      }
      $content_link = "/{$node_type}/{$nid}";

      $user = (object) null;
      $recipient_uid = null;
      $operator_uid = null;
      if ($is_group) {
        if (in_array($template_keys[2], ['rm'])) {
          // $uid = \Drupal::currentUser()->id();
          // $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
          $user = \Drupal::entityTypeManager()->getStorage('user')->load($current_user);
          $operator_uid = $current_user;
        }
        //ai and di --> closed group --> moderator sends request to user
        //rmr and amr --> secret group request send kar sakta --> user sends request and moderator accepts/declines
        else if (in_array($template_keys[2], ['jc','ai','di','rmr','amr'])) {
          $uid  = $entity->get('entity_id')->getValue()[0]['target_id'];
          $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
          
          if ($template_keys[2] == 'jc') {
            $group_type = $group->getGroupType()->id();
            $uid =  \Drupal::currentUser()->id();
            $operator_uid = $uid;
          }
          else if (in_array($template_keys[2],['amr','rmr','ai','di'])) {
            //if secret_group - member requests and admin accepts membership i.e. ai - so member is notified
            $group_type = $group->getGroupType()->id();
            if ($group_type == 'secret_group' && ($template_keys[2] == 'amr' || $template_keys[2] == 'rmr')) {
                //member is recipient uid
                $recipient_uid =  $entity->get('uid')->getValue()[0]['target_id'];
            }
            if ($group_type == 'closed_group' && ($template_keys[2] == 'ai' || $template_keys[2] == 'di')) {
              $recipient_uid = $user_id;//$entity->get('uid')->getValue()[0]['target_id'];
              $operator_uid = $entity->get('entity_id')->getValue()[0]['target_id'];
            }
            //if closed_group - admin invites and member accepts membership i.e. ai - so admin is notified
            // $recipient_uid = $uid;
            // $operator_uid = \Drupal::currentUser()->id();
          }
        }
        else {
          $user =  $group->getRevisionUser();
        }
        $group_id = $group->id();
        $content_link = ($template == 'ia_cl_rm') ? "/community/{$group_id}/members-pending" : "/community/{$group_id}";
        $content_data = [
          'user' => $user,
          'group' => $group,
          'group_relationship' => $entity
        ];
        $bundle = 'group';
        return [
          'bundle' => $bundle,
          'content_link' => $content_link,
          'id' => $entity->id(),
          'content' => $tokenService->replace($body, $content_data),
          'description' => $tokenService->replace($description, $content_data),
          'recipient_uid' => $recipient_uid,
          'operator_uid' => $operator_uid,
        ];
      } elseif ($is_comment) {
        $node_type = $entity->getCommentedEntity()->bundle();
        $content_link = "/{$node_type}/{$nid}#comment-" . $entity->id();
        $content_data = [
          'node' => $entity->getCommentedEntity(),
          'user' => $entity->getOwner(),
          'group' => $group,
          'comment' => $entity
        ];
        $bundle = 'comment';
        return [
          'bundle' => $bundle,
          'content_link' => $content_link,
          'id' => $entity->id(),
          'content' => $tokenService->replace($body, $content_data),
          'description' => $tokenService->replace($description, $content_data)
        ];
      }
    }
    return [
      'bundle' => $bundle,
      'content_link' => $content_link,
      'id' => $entity->id(),
      'content' => $tokenService->replace($body, $content_data),
      'description' => $tokenService->replace($description, $content_data)
    ];  
  }

  protected static function sendEmailNotification($message_notify, $user_id, $email_template, $notify_data, $site_url,$current_user = NULL,) {
    $user = \Drupal::entityTypeManager()->getStorage('user')->load($user_id);
    if ($user) {
      $mailManager = \Drupal::service('plugin.manager.mail');
      if ($user) {
        $params = [];
        $to = $user->getEmail();
        //body
        $params['message'] = $message_notify['content'];
        //subject
        $params['title'] = $message_notify['description'];
        $params['module'] = 'custom_notification';
        $langcode = \Drupal::currentUser()->getPreferredLangcode();
        $send = true;
        $result = $mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);
        if ($result['result'] != true) {
          \Drupal::messenger()->addError(t('There was a problem sending your email notification using template @field_template_key to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
          return;
        }
    
        \Drupal::logger('custom_notification')->notice(t('An email notification @field_template_key has been sent to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
      }
    }    
  }
}
