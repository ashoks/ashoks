<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_comment_queue",
 *   title = @Translation("Custom Notification Standard Comment Queue Worker"),
 * )
 */
class CustomNotificationCommentQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
        $action = $data['action'];
        $entity = \Drupal::entityTypeManager()->getStorage('comment')->load($data['entity_id']);
        if ($entity) {
          $node = $entity->getCommentedEntity();
          $gid = $node->field_community->target_id;
          $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
          $action = $data['action'];
          if (isset($node->field_community) && $node->field_community->target_id) {
            $user_id_notified = [];
            $notificationService = \Drupal::service('notifications_widget.logger');
            $tokenService = \Drupal::service('token');
            $group_member_data = custom_notification_get_group_members_with_roles($group);
            $templates = ['ia_cl_arc','ia_cic_arc','ia_cm_arc','ia_cf_arc'];
            foreach($templates as $template ) {
              $field_key = 'field_'. $template;
              switch ($template) {
                case 'ia_cl_arc':
                case 'ia_cm_arc':
                  foreach($group_member_data as $data) {
                    $template_key = explode('_', $template);
                    $status = custom_notification_group_based_validation($data, $template_key[1]);
                    if ($status) {
                      $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                      if ($notification_node_status) {
                        if (!in_array($data['user'], $user_id_notified)) {
                          if ($entity->getOwnerId() != $data['user']) {
                            $message_notify = self::createNotificationMessage($template, $data['user'], $entity, $node, $group, $action);
                            $user_id_notified[] = $data['user'];
                          }            
                        }
                      }
                    }
                  }
                break;
                case 'ia_cic_arc':
                  if (!in_array($node->getOwnerId(), $user_id_notified)) {
                    $notification_node_status = custom_notification_get_notification_settings($node->getOwnerId(), $template);
                    if ($notification_node_status) {
                      $message_notify = self::createNotificationMessage($template, $entity->getOwnerId(), $entity, $node, $group, $action);
                      $user_id_notified[] = $node->getOwnerId();            
                    }
                  }
                  break;
                case 'ia_cf_arc':
                  $user_ids = custom_notification_get_users_following_content('follow_content', $node->id());
                  if (!is_null($user_ids)) {
                    foreach ($user_ids as $uid => $user) {
                      $notification_node_status = custom_notification_get_notification_settings($uid, $template);
                      if ($notification_node_status) {
                        if (!in_array($uid, $user_id_notified)) {
                          $message_notify = self::createNotificationMessage($template, $uid, $entity, $node, $group, $action);  
                          $user_id_notified[] = $uid;            
                        }
                      }      
                    }
                  }
                  break;
              }
            }
          }
        }
    }
    custom_notification_note_statistics('end', 'custom_notification_comment_queue', $start_time);

  }

  /**
   * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $user_id, $entity, $node, $group, $action) {
    $message = Message::create(['template' => $template, 'uid' => $user_id]);
    $content_data = [];
    $bundle = '';
    $body = '';
    $content_link = '';
    $recipient_uid = ($template == 'ia_cic_arc') ? $node->getOwnerId() : $user_id;//@2 - second this one//done
    $operator_uid = $entity->getOwnerId();
    if ($message->getTemplate() && $node) {
      $message_template = $message->getTemplate();
      $body = $message_template->get('text')[0]['value'];
      $description = $message_template->get('description');
      $bundle = 'comment';
      $nid  = $node->id();
      $node_type = $node ? $node->bundle() : NULL;
      if ($node_type === 'pages') {
          $node_type = 'page';
      }
      $node_type = ($node_type == 'pages') ? 'page' : $node_type;
      $content_link = "/{$node_type}/{$nid}#comment-". $entity->id();
      $content_data = [
        'node' => ($node) ? $node : $entity,
        'user' => $entity->getOwner(), //@1 First Place is this//done
        'group' => $group,
        'comment' => ($entity->getEntityTypeId() == 'comment') ? $entity : NULL,
      ];
    }
    $tokenService = \Drupal::token();
    $message_notify = [
      'bundle' => $bundle,
      'content_link' => $content_link,
      'id' => $entity->id(),
      'content' => $tokenService->replace($body, $content_data),
      'description' => $tokenService->replace($description, $content_data)
    ];  
    $notificationService = \Drupal::service('notifications_widget.logger');
    $notificationService->logNotification($message_notify, 'create', $entity, $recipient_uid, $operator_uid);
  }

}