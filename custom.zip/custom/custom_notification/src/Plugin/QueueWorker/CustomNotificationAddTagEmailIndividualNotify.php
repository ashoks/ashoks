<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_add_tag_email_individual_queue",
 *   title = @Translation("Custom Notification Standard Add Tag Email Individual Queue Worker"),
 *  cron = {"time" = 60}
 * )
 */
class CustomNotificationAddTagEmailIndividualNotify extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    self::createNotificationMessage($data['template'], $data['user_id'], $data['entity'], $data['group'], $data['action'], $data['user_added_tags'], $data['current_user'], $data['site_url']);
    custom_notification_note_statistics('end', 'custom_notification_add_tag_email_individual_queue', $start_time);

  }


  /**
   * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $user_id, $entity, $group, $action, $user_added_tags, $current_user, $site_url) {
    $notification_node_status = custom_notification_get_notification_settings($user_id, $template);
    $email_template = str_replace('ia', 'em', $template);
    $field_key = 'field_'. $email_template;
    if ($notification_node_status) {
      $message = Message::create(['template' => $template, 'uid' => $user_id]);
      $content_data = [];
      $bundle = '';
      $body = '';
      $content_link = '';
      $recipient_uid = $user_id;
      $operator_uid =  $current_user;
      //Email Notification
      $message = Message::create(['template' => $email_template, 'uid' => $user_id]);
      if ($message->getTemplate()) {
        $message_template = $message->getTemplate();
        $body = '';
        if ($message_template->get('text')[0]['value']) {
          $body = str_replace('[site:url]', $site_url, $message_template->get('text')[0]['value']);
        }
        $description = '';
        if ($message_template->get('description')) {
          $description = str_replace('[site:url]', $site_url, $message_template->get('description'));
        }
        $bundle = 'node';
        $nid  = $entity->id();
        $user = \Drupal::entityTypeManager()->getStorage('user')->load($current_user);
        $node_type = $entity ? $entity->bundle() : NULL;
        if ($node_type === 'pages') {
            $node_type = 'page';
        }
        $content_link = "/{$node_type}/{$nid}";
        $content_data = [
          'node' => $entity,
          'user' => $user, //@1 First Place is this//done
          'group' => $group,
        ];
        $tokenService = \Drupal::token();
        $message_notify = [
          'bundle' => $bundle,
          'content_link' => $content_link,
          'id' => $entity->id(),
          'content' => $tokenService->replace($body, $content_data),
          'description' => $tokenService->replace($description, $content_data)
        ];  
        $message_notify['content'] = html_entity_decode($message_notify['content']);
        $message_notify['description'] = html_entity_decode($message_notify['description']);
        // $message_notify['content'] = str_replace('[tags]', $user_added_tags, $message_notify['content']);
        $mailManager = \Drupal::service('plugin.manager.mail');
        $params = [];
        $query = Database::getConnection()
        ->select('users_field_data', 'u')
        ->fields('u', ['mail'])
        ->condition('u.uid', $user_id, '=');
        $email = $query->execute()->fetchField();
        $to = $email;
        //body
        $params['message'] = $message_notify['content'];
        //subject
        $params['title'] = $message_notify['description'];
        $params['module'] = 'custom_notification';
        $langcode = 'en';//\Drupal::currentUser()->getPreferredLangcode();
        $send = true;
        $result = $mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);
        if ($result['result'] != true) {
          //\Drupal::messenger()->addError(t('There was a problem sending your email notification using template @field_template_key to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
          return;
        }
        //\Drupal::logger('custom_notification')->notice(t('An email notification @field_template_key has been sent to @email.', ['@email' => $to, '@field_template_key' => $email_template]));

      }
    }
  }
}
