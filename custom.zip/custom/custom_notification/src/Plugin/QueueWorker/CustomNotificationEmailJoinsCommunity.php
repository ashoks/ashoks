<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_joins_community_email",
 *   title = @Translation("Custom Notification Joins Community Email"),
 * )
 */
class CustomNotificationEmailJoinsCommunity extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
      $entity = \Drupal::entityTypeManager()->getStorage('group_relationship')->load($data['entity_id']); 
      $site_url = $data['site_url'];
      if ($entity) {
        $membership_data = custom_notification_get_membership_request_status($entity);
        if (isset($membership_data['group'])) {
          if (!in_array($membership_data['type'], ['group_node','group_invitation'])) {
            $group_type = $membership_data['group']->getGroupType()->id();
            $group_member_data = custom_notification_get_group_members_with_roles($membership_data['group']);
            $user_id_notified = [];
            //Joins the community for public community
            //if its community member and secret group, also the user who has joined matches with user to whom it is to be notified
            //then dont send it to that user.
            //cl_jc, cm_jc,cf_jc
            if ($group_member_data && ($group_type == 'secret_group' || $group_type == 'public_group')) {
              $queue = \Drupal::service('queue')->get('custom_notification_joins_community_email_individual');
              foreach($data['templates'] as $template) {  
                foreach($group_member_data as $key => $data) {
                  $template_key = explode('_', $template);
                  $field_key = 'field_' . $template;
                  $status = custom_notification_group_based_validation($data, $template_key[1]);
                  if ($status) {
                    $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                    if ($notification_node_status) {
                      $entity_id = $entity->get('entity_id')->getValue()[0]['target_id'];
                      $user_id_who_joined = $entity_id;
                      if ($data['user'] != $entity_id) {
                        if (!in_array($data['user'], $user_id_notified)) {
                          $queue->createItem([
                            'user_id' => $data['user'],
                            'template' => $template,
                            'entity' => $entity,
                            'group' => $membership_data['group'],
                            'user_id_who_joined' => $user_id_who_joined,
                            'site_url' => $site_url
                          ]);
                          $user_id_notified[] = $data['user']; 
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    custom_notification_note_statistics('end', 'custom_notification_joins_community_email', $start_time);

  }

}
