<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_edits_community_email",
 *   title = @Translation("Custom Notification Email Edits Community"),
 * )
 */
class CustomNotificationEmailEditsCommunity extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
      $site_url = $data['site_url'];
      $group = \Drupal::entityTypeManager()->getStorage('group')->load($data['entity_id']);
      if ($group) {
        // $membership_data = custom_notification_get_membership_request_status($entity);
        $group_type = $group->getGroupType()->id();
        $group_member_data = custom_notification_get_group_members_with_roles($group);
        $user_id_notified = [];
        if ($group_member_data) {
        foreach($data['templates'] as $template) {
          foreach($group_member_data as $key => $data) {
            $template_key = explode('_', $template);
                $status = custom_notification_group_based_validation($data, $template_key[1]);
                if ($status) {
                  $field_key = 'field_'. $template;  
                  $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                  if ($notification_node_status) {
                    if (!in_array($data['user'], $user_id_notified)) {
                        if ($data['user'] != $group->getRevisionUser()->id()) {
                        // self::createNotificationMessage($template, $data['user'], $group, 'update');
                        $queue = \Drupal::queue('custom_notification_edits_community_email_individual');
                          $queue->createItem([
                              'template' => $template,
                              'uid' => $group->getRevisionUser()->id(),
                              'group' => $group,
                              'recipient_uid' => $data['user'],
                              'site_url' => $site_url,
                              'test_parameter' => $user_id_notified,
                          ]);
                        }
                        $user_id_notified[] = $data['user'];
                    }
                  }
                }
            }
          }
        }
      }
    }
    custom_notification_note_statistics('end', 'custom_notification_edits_community_email', $start_time);

  }

//   /**
//    * Creates a notification message.
//    */
//   protected static function createNotificationMessage($template, $uid, $group, $action) {
//     $message = Message::create(['template' => $template, 'uid' => $uid]);
//     if ($message_template = $message->getTemplate()) {
//       $body = $message_template->get('text')[0]['value'];
//       $group_id = $group->id();
//       $tokenService = \Drupal::service('token');
//       $notificationService = \Drupal::service('notifications_widget.logger');
//       $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
//       $message_notify = [
//         'bundle' => 'group',
//         'content_link' => "/community/{$group_id}",
//         'id' => $group->id(),
//         'content' => $tokenService->replace($body, [
//           'user' => $user,
//           'group' => $group,
//         ]),
//       ];
      
//       // Correct notification service usage.
//       $notificationService = \Drupal::service('notifications_widget.logger');
//       $notificationService->logNotification($message_notify, $action, $group, $uid, $group->getRevisionUser()->id());
//     }
//   }

}
