<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_rate_email_queue",
 *   title = @Translation("Custom Notification Standard Rate Email Queue Worker"),
 * )
 */
class CustomNotificationRateEmailQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['node_id']) && isset($data['entity_id'])) {
      $site_url = $data['site_url'];
      $node = \Drupal::entityTypeManager()->getStorage('node')->load($data['node_id']);
      $entity = \Drupal::entityTypeManager()->getStorage('vote')->load($data['entity_id']);
      $queue = \Drupal::service('queue')->get('custom_notification_rate_email_individual_queue');
      if ($node && $entity && isset($node->field_community) && $node->field_community->target_id) {
        $notify_data = [
          'vote' => $entity,
          'node' => $node,
          'group_relationship' => NULL,
          'entity_bundle' => $entity,
          'bundle' => 'vote',
          'site_url' => $site_url
        ];

        $gid = $node->field_community->target_id;
        $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
        $notify_data['group'] = $group;
        
        $user_id_notified = [];
        $templates = ['em_cf_rc', 'em_cl_rc', 'em_cm_rc', 'em_cic_rc'];
        foreach ($templates as $template) {
          $field_key = 'field_' . $template;

          switch ($template) {
            case 'em_cl_rc':
            case 'em_cm_rc':
              $group_member_data = custom_notification_get_group_members_with_roles($group);
              foreach ($group_member_data as $gdata) {
                $template_key = explode('_', $template);
                $status = custom_notification_group_based_validation($gdata, $template_key[1]);
                if ($status) {
                  $notification_node_status = custom_notification_get_notification_settings($gdata['user'], $template);
                  if ($notification_node_status) {
                    if (!in_array($gdata['user'], $user_id_notified)) {
                      if ($entity->getOwnerId() != $gdata['user']) {
                        // self::createNotificationMessage($template, $data['user'], $entity, $node, $group, $user_id_notified);
                        $queue->createItem([
                          'template' => $template,
                          'user_id' => $gdata['user'],
                          'node' => $node,
                          'entity' => $entity,
                          'group' => $group,
                          'site_url' => $site_url
                        ]);
                        $user_id_notified[] = $gdata['user'];
                      }
                    }
                  }
                }
              }
              break;
            case 'em_cic_rc':
              if (!in_array($node->getOwnerId(), $user_id_notified)) {
                $notification_node_status = custom_notification_get_notification_settings($node->getOwnerId(), $template);
                if ($notification_node_status) {
                  // self::createNotificationMessage($template, $node->getOwnerId(), $entity, $node, $group, $user_id_notified);
                  $queue->createItem([
                    'template' => $template,
                    'user_id' => $node->getOwnerId(),
                    'node' => $node,
                    'entity' => $entity,
                    'group' => $group,
                    'site_url' => $site_url
                  ]);
                  $user_id_notified[] = $entity->getOwnerId();

                }
              }
              break;
              case 'em_cf_rc':
                $user_ids = custom_notification_get_users_following_content('follow_content', $node->id());
                if (!is_null($user_ids)) {
                  foreach ($user_ids as $uid => $user) {
                    if (!in_array($user->id(), $user_id_notified)) {
                      if ($entity->getOwnerId() != $user->id()) {
                        $notification_node_status = custom_notification_get_notification_settings($uid, $template);
                        if ($notification_node_status) {
                          // self::createNotificationMessage($template, $uid, $entity, $node, $group, $user_id_notified);
                          $queue->createItem([
                            'template' => $template,
                            'node' => $node,
                            'user_id' => $uid,
                            'entity' => $entity,
                            'group' => $group,
                            'site_url' => $site_url
                          ]);
                          $user_id_notified[] = $user->id();
                        }
                      }
                    }
                  }
                }
                break; 
          }
        }
      }
    }
    custom_notification_note_statistics('end', 'custom_notification_rate_email_queue', $start_time);

  }
}
