<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_node_email_queue",
 *   title = @Translation("Custom Notification Standard Node Email Queue Worker"),
 * )
 */
class CustomNotificationNodeEmailQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
      $site_url = $data['site_url'];
      $action = $data['action'];
      $entity = \Drupal::entityTypeManager()->getStorage('node')->load($data['entity_id']);
      $recipient_uid = NULL;
      $operator_uid = NULL; 
      if (isset($entity->field_community) && $entity->field_community->target_id) {
        $gid = $entity->field_community->target_id;
        $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);  
        $notify_data = [
          'group' => $entity,
          'node' => $entity,
          'group_relationship' => NULL,
          'entity_bundle' => $entity,
          'bundle' => 'node',
        ];        
        $user_id_notified = [];
        $templates = $data['templates'];
        $notificationService = \Drupal::service('notifications_widget.logger');
        $tokenService = \Drupal::service('token');
        $templates = $data['templates'];
        $nid = $entity->id();
        if ($action == 'update') {
          //@todo : one edge case that needs to be handled, if a node is updated
          //and by the time the cron runs someone else updates it 
          //then in that cron it will take latest revision user not the one who actually updated it.
          $revision_user = $entity->getRevisionUser();
          $both_follower_creator = [];
          foreach ($templates as $template) {
            $field_key = 'field_' . $template;
            switch ($template) {
              case 'em_cl_uc':
              case 'em_cm_uc':   
                $group_member_data = custom_notification_get_group_members_with_roles($group);
                foreach(array_chunk($group_member_data, 10000) as $group_member_sub_data) {
                  foreach($group_member_sub_data as $data) {
                      $template_key = explode('_', $template);
                      $status = custom_notification_group_based_validation($data, $template_key[1]);
                      if (!in_array($data['user'], $user_id_notified)) {
                        if ($revision_user->id() != $data['user']) {
                          if ($status) {
                            $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                            if ($notification_node_status) {
                              $queue = \Drupal::service('queue')->get('custom_notification_node_email_individual_queue');
                                $queue->createItem([
                                  'template' => $template,
                                  'user_id' => $data['user'],
                                  'entity' => $entity,
                                  'group' => $group,
                                  'action' => $action,
                                  'site_url' => $site_url,
                                ]);
                                $user_id_notified[] = $data['user'];            
                            }
                          }
                        }
                      }                  
                    unset($group_member_sub_data, $data);
                  }
                }
                break;
              case 'em_cic_uc': 
                if (!in_array($entity->getOwnerId(), $user_id_notified)) {
                  $notification_node_status = custom_notification_get_notification_settings($entity->getOwnerId(), $template);
                  //get notification status
                  //get entity owner
                  $notification_node_status_follower = custom_notification_get_notification_settings($entity->getOwnerId(), 'em_cf_uc');
                  $send_mail = true;
                  if ($notification_node_status_follower && $notification_node_status && $both_follower_creator ) {
                    $send_mail = false;
                  }
                  if (!$both_follower_creator  && $notification_node_status_follower && $notification_node_status) {
                    $both_follower_creator[$entity->getOwnerId()] = TRUE;
                  }
                  if ($revision_user->id() != $entity->getOwnerId()) {
                    if ($notification_node_status && $send_mail) {
                      $queue = \Drupal::service('queue')->get('custom_notification_node_email_individual_queue');
                      $queue->createItem([
                        'template' => $template,
                        'user_id' => $entity->getOwnerId(),
                        'entity' => $entity,
                        'group' => $group,
                        'action' => $action,
                        'site_url' => $site_url,
                      ]);
                      $user_id_notified[] = $entity->getOwnerId();
                      unset($notification_node);            
                    }
                  }
                }
                break;
              case 'em_cf_uc':
                $user_ids = custom_notification_get_users_following_content('follow_content', $entity->id());
                if (!is_null($user_ids)) {
                  foreach (array_chunk($user_ids, 1000) as  $sub_user_ids) {
                    foreach ($sub_user_ids as $uid => $user ) {
                      if (!is_null($user)) {
                        if ($revision_user->id() != $user->id()) {
                          $notification_node_status = custom_notification_get_notification_settings($user->id(), $template);
                          $notification_node_status_cic = custom_notification_get_notification_settings($entity->getOwnerId(), 'em_cic_uc');
                          $send_mail = true;
                          if ($user->id() == $entity->getOwnerId()) {
                            if ($notification_node_status_cic && $notification_node_status && $both_follower_creator ) {
                              $send_mail = false;
                            }
                            if (!$both_follower_creator  && $notification_node_status_cic && $notification_node_status) {
                              $both_follower_creator[$entity->getOwnerId()] = TRUE;
                            }
                          }
                          if ($notification_node_status && $send_mail) {
                            if (!in_array($user->id(), $user_id_notified)) { 
                              $queue = \Drupal::service('queue')->get('custom_notification_node_email_individual_queue');
                              $queue->createItem([
                                'template' => $template,
                                'user_id' => $user->id(),
                                'entity' => $entity,
                                'group' => $group,
                                'action' => $action,
                                'site_url' => $site_url,
                              ]);
                              $user_id_notified[] = $uid;            
                            }
                          }
                        }
                      }
                      unset($notification_node, $uid, $user);
                    }
                    unset($sub_user_ids);
                  }
                }
               break; 
            }
          }
        }
        else {
          foreach ($templates as $template) {
            $field_key = 'field_' . $template;
            $group_member_data = custom_notification_get_group_members_with_roles($group);
            foreach(array_chunk($group_member_data, 1000) as $group_member_sub_data) {
              foreach ($group_member_sub_data as $data) {
                  $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                  if ($notification_node_status) {
                    if (!in_array($data['user'], $user_id_notified)) {
                      if ($entity->getOwnerId() != $data['user']) {
                        $queue = \Drupal::service('queue')->get('custom_notification_node_email_individual_queue');
                        $queue->createItem([
                          'template' => $template,
                          'user_id' => $data['user'],
                          'entity' => $entity,
                          'group' => $group,
                          'action' => $action,
                          'site_url' => $site_url,
                        ]);
                        $user_id_notified[] = $data['user'];
                      }        
                    }
                  }
                  unset($notification_node);
              }
              unset($group_member_sub_data, $data);
            }
          }
        }
     }
    }
    custom_notification_note_statistics('end', 'custom_notification_node_email_queue', $start_time);

  }
}
