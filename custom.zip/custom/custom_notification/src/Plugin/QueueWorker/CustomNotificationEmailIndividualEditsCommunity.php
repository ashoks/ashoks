<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_edits_community_email_individual",
 *   title = @Translation("Custom Notification Email Edits Individual Community"),
 * )
 */
class CustomNotificationEmailIndividualEditsCommunity extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    self::createNotificationMessage($data['template'], $data['uid'], $data['group'],'update', $data['recipient_uid'], $data['site_url']);
    custom_notification_note_statistics('end', 'custom_notification_edits_community_email_individual', $start_time);
  }

  /**
   * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $uid, $group, $action, $recipient_uid, $site_url) {
    $email_template = str_replace('ia', 'em', $template);
    $field_key = 'field_'. $email_template;
    $notification_node_status = custom_notification_get_notification_settings($recipient_uid, $email_template);
    if ($notification_node_status) {
    $message = Message::create(['template' => $template, 'uid' => $uid]);
      if ($message_template = $message->getTemplate()) {
        $body = '';
        if ($message_template->get('text')[0]['value']) {
          $body = str_replace('[site:url]', $site_url, $message_template->get('text')[0]['value']);
        }
        $description = '';
        if ($message_template->get('description')) {
          $description = str_replace('[site:url]', $site_url, $message_template->get('description'));
        }
        $group_id = $group->id();
        $tokenService = \Drupal::service('token');
        $notificationService = \Drupal::service('notifications_widget.logger');
        $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
        $message_notify = [
          'bundle' => 'group',
          'content_link' => "/community/{$group_id}",
          'id' => $group->id(),
          'content' => $tokenService->replace($body, [
            'user' => ($user->getDisplayName()) ? $user : NULL,
            'group' => $group,
          ]),
          'description' => $tokenService->replace($description, [
            'user' => ($user->getDisplayName()) ? $user : NULL,
            'group' => $group,
          ]),
        ];
        $message_notify['content'] = html_entity_decode($message_notify['content']);
        $message_notify['description'] = html_entity_decode($message_notify['description']);

        // Correct notification service usage.
        $email_template = str_replace('ia', 'em', $template);

        // Retrieve the email address of the recipient.
        $query = \Drupal::database()->select('users_field_data', 'u')
          ->fields('u', ['mail'])
          ->condition('u.uid', $recipient_uid, '=');
        $email = $query->execute()->fetchField();
        $to = $email;
        // Email parameters.
        $params = [
          'message' => $message_notify['content'],
          'title' => $message_notify['description'],
          'module' => 'custom_notification',
        ];

        // Send the email.
        $langcode = 'en';
        $send = true;
        $mailManager = \Drupal::service('plugin.manager.mail');
        $result = $mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);
      //   if ($result['result'] !== true) {
          // Log error if the email sending fails.
          // \Drupal::logger('custom_notification')->error(t('There was a problem sending your email notification using template @field_template_key to @email.', [
          //   '@email' => $to,
          //   '@field_template_key' => $email_template,
          // ]));
      //   }

      }
    }
  }

}
