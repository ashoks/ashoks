<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications for new published nodes.
 *
 * @QueueWorker(
 *   id = "custom_notification_follow_notify_queue",
 *   title = @Translation("Custom Notification Follow Queue Worker"),
 *   cron = {"time" = 60}
 * )
 */
class CustomNotificationFollowNotify extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($queue_data) {
    $start_time = custom_notification_note_statistics('start', '');
    // Load the node entity using the node ID from the $data array.
    $user = $queue_data['user'];
      if (!is_null($user)) {
      $field_key = $queue_data['field_key'];
      $user_id_notified = $queue_data['user_id_notified'];
      $uid = $queue_data['uid'];
      $node = $queue_data['node'];
      $entity = $queue_data['entity'];
      $group = $queue_data['group'];
      $tokenService = \Drupal::service('token');
      $template = $queue_data['template'];
      if ($field_key == 'field_ia_cf_arc') {
        if ($notification_node_status) { 
          $notification_node_status = custom_notification_get_notification_settings($user->id(), 'ia_cf_arc'); 
          if (isset($notification_node->{$field_key}) && $notification_node->{$field_key}->value) {
              $message = Message::create(['template' => $template, 'uid' => $user->id()]);
              if ($message_template = $message->getTemplate() && !in_array($uid, $user_id_notified)) {  
                $body = $message_template->get('text')[0]['value'];  
                $nid = $node->id();   
                $message_notify = [
                    'bundle' => 'comment',
                    'content_link' => "/node/{$nid}#comment-". $entity->id(),
                    'id' => $entity->id(),
                    'content' => $tokenService->replace($body, [
                    'user' => $entity->getOwner(),
                    'node' => $node,
                    'group' => $group,
                    'comment' => $entity,
                    ]),
                ];
                $notificationService = \Drupal::service('notifications_widget.logger');
                $notificationService->logNotification($message_notify, 'create', $entity, $uid);
              }
            }
            $email_template = str_replace('ia', 'em', $template);
            $email_field_key = 'field_' . $email_template;
            if (isset($notification_node->{$email_field_key}) && $notification_node->{$email_field_key}->value) {
              $email_message_notify = self::createNotificationMessage($email_template, $uid, $entity, $node_owner, $group, $tokenService, $node->id(), true, false, $template_keys);
              self::sendEmailNotification($email_message_notify, $uid, $email_template, $notify_data);
            }
          }      
      }
      if ($field_key == 'field_ia_cf_uc') {
          $notification_node_status = custom_notification_get_notification_settings($user->id(), 'ia_cf_uc'); 
          if ($notification_node_status) {
            $message = Message::create(['template' => $template, 'uid' => $user->id()]);
            if ($message_template = $message->getTemplate()) {  
                  $body = $message_template->get('text')[0]['value'];  
                  $nid = $entity->id();   
                  $message_notify = [
                  'bundle' => 'node',
                  'content_link' => "/node/{$nid}",
                  'id' => $entity->id(),
                  'content' => $tokenService->replace($body, [
                      'user' => $revision_user,
                      'node' => $entity,
                      'group' => $group,
                  ]),
                  ];
                  $user_id_notified[] = $uid;
                  $notificationService = \Drupal::service('notifications_widget.logger');
                  $notificationService->logNotification($message_notify, 'update', $entity, $uid);
            }
            $template_keys = explode('_', $template);
            $email_template = str_replace('ia', 'em', $template);
            $email_field_key = 'field_' . $email_template;
            $node_owner = $entity->getRevisionUser();
            if ($notification_node->{$email_field_key} && $notification_node->{$email_field_key}->value) {
              $email_message_notify = self::createNotificationMessage($email_template, $uid, $entity, $node_owner, $group, $tokenService, $nid, NULL, NULL, $template_keys);
              $user_id_notified[] = $uid;
              self::sendEmailNotification($email_message_notify, $uid, $email_template, $notify_data);
            }
          }
        }
        custom_notification_note_statistics('end', 'custom_notification_follow_notify_queue', $start_time);  
      }
    }
  


        
  /**
    * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $user_id, $entity, $node_owner, $group, $tokenService, $nid, $is_comment, $is_group, $template_keys) {
    $message = Message::create(['template' => $template, 'uid' => $user_id]);
    $content_data = [];
    $bundle = '';
    $body = '';
    $content_link = '';
    if ($message->getTemplate()) {
      $message_template = $message->getTemplate();
      $body = $message_template->get('text')[0]['value'];
      $description = $message_template->get('description');
      $bundle = 'node';
      $content_link = "/node/{$nid}";
      $node = null;
      if ($entity->getEntityTypeId() != 'node') {
        if ($nid && is_numeric($nid)) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
        }
      }
      $content_data = [
        'node' => ($node) ? $node : $entity,
        'user' => $node_owner,
        'group' => $group,
        'vote' => ($entity->getEntityTypeId() == 'vote') ? $entity : NULL
      ];
      $user = (object) null;
      $recipient_uid = null;
      $operator_uid = null;
      if ($is_group) {
        if (in_array($template_keys[2], ['rm'])) {
          $uid = \Drupal::currentUser()->id();
          $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
        }
        else if (in_array($template_keys[2], ['jc','ai','di','rmr','amr'])) {
          $uid  = $entity->get('entity_id')->getValue()[0]['target_id'];
          $user = \Drupal::entityTypeManager()->getStorage('user')->load($uid);
          
          if ($template_keys[2] == 'jc') {
            $group_type = $group->getGroupType()->id();
            $uid =  \Drupal::currentUser()->id();
            $operator_uid = $uid;
          }
          else if (in_array($template_keys[2],['amr','rmr','ai','di'])) {
            //if secret_group - member requests and admin accepts membership i.e. ai - so member is notified
            $group_type = $group->getGroupType()->id();
            if ($group_type == 'secret_group' && ($template_keys[2] == 'amr' || $template_keys[2] == 'rmr')) {
                //member is recipient uid
                $recipient_uid =  $entity->get('uid')->getValue()[0]['target_id'];
            }
            if ($group_type == 'closed_group' && ($template_keys[2] == 'ai' || $template_keys[2] == 'di')) {
              $recipient_uid = $user_id;//$entity->get('uid')->getValue()[0]['target_id'];
              $operator_uid = $entity->get('entity_id')->getValue()[0]['target_id'];
            }
            //if closed_group - admin invites and member accepts membership i.e. ai - so admin is notified
            // $recipient_uid = $uid;
            // $operator_uid = \Drupal::currentUser()->id();
          }
        }
        else {
          $user =  $group->getRevisionUser();
        }
        $group_id = $group->id();
        $content_link = "/community/{$group_id}";
        $content_data = [
          'user' => $user,
          'group' => $group,
          'group_relationship' => $entity
        ];
        $bundle = 'group';
        return [
          'bundle' => $bundle,
          'content_link' => $content_link,
          'id' => $entity->id(),
          'content' => $tokenService->replace($body, $content_data),
          'description' => $tokenService->replace($description, $content_data),
          'recipient_uid' => $recipient_uid,
          'operator_uid' => $operator_uid,
        ];
      } elseif ($is_comment) {
        $content_link = "/node/{$nid}#comment-" . $entity->id();
        $content_data = [
          'node' => $entity->getCommentedEntity(),
          'user' => $entity->getOwner(),
          'group' => $group,
          'comment' => $entity
        ];
        $bundle = 'comment';
        return [
          'bundle' => $bundle,
          'content_link' => $content_link,
          'id' => $entity->id(),
          'content' => $tokenService->replace($body, $content_data),
          'description' => $tokenService->replace($description, $content_data)
        ];
      }
    }
    return [
      'bundle' => $bundle,
      'content_link' => $content_link,
      'id' => $entity->id(),
      'content' => $tokenService->replace($body, $content_data),
      'description' => $tokenService->replace($description, $content_data)
    ];  
  }

  protected static function sendEmailNotification($message_notify, $user_id, $email_template, $notify_data) {
    $user = \Drupal::entityTypeManager()->getStorage('user')->load($user_id);
    if ($user && ($user->id() != \Drupal::currentUser()->id())) {
      $mailManager = \Drupal::service('plugin.manager.mail');
      if ($user) {
        $params = [];
        $to = $user->getEmail();
        //body
        $params['message'] = $message_notify['content'];
        //subject
        $params['title'] = $message_notify['description'];
        $params['module'] = 'custom_notification';
        $langcode = \Drupal::currentUser()->getPreferredLangcode();
        $send = true;
        $result = $mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);
        if ($result['result'] != true) {
          \Drupal::messenger()->addError(t('There was a problem sending your email notification using template @field_template_key to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
          return;
        }
    
        \Drupal::logger('custom_notification')->notice(t('An email notification @field_template_key has been sent to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
      }
    }
    else {
      if ($email_template == 'em_crj_amr') {
          $mailManager = \Drupal::service('plugin.manager.mail');
          if ($user) {
            $params = [];
            $to = $user->getEmail();
            //body
            $params['message'] = $message_notify['content'];
            //subject
            $params['title'] = $message_notify['description'];
            $params['module'] = 'custom_notification';
            $langcode = \Drupal::currentUser()->getPreferredLangcode();
            $send = true;
            $result = $mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);
            if ($result['result'] != true) {
              \Drupal::messenger()->addError(t('There was a problem sending your email notification using template @field_template_key to @email.', ['@email' => $to, '@field_template_key' => $email_template]));
              return;
            }
            \Drupal::logger('custom_notification')->notice(t('An email notification @field_template_key has been sent to @email.', ['@email' => $to, '@field_template_key' => $email_template]));    
          }
      }
    }
  }
}
