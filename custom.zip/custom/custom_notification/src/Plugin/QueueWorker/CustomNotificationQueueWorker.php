<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_queue",
 *   title = @Translation("Custom Notification Standard Queue Worker"),
 *   cron = {"time" = 60}
 * )
 */
class CustomNotificationQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['node_id']) && isset($data['entity_id'])) {
      $node = \Drupal::entityTypeManager()->getStorage('node')->load($data['node_id']);
      $entity = \Drupal::entityTypeManager()->getStorage('vote')->load($data['entity_id']);

      if ($node && $entity && isset($node->field_community) && $node->field_community->target_id) {
        $notify_data = [
          'vote' => $entity,
          'node' => $node,
          'group_relationship' => NULL,
          'entity_bundle' => $entity,
          'bundle' => 'vote',
        ];

        $gid = $node->field_community->target_id;
        $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
        $notify_data['group'] = $group;
        
        $user_id_notified = [];
        $templates = ['ia_cf_rc', 'ia_cl_rc', 'ia_cm_rc', 'ia_cic_rc'];
        foreach ($templates as $template) {
          $field_key = 'field_' . $template;

          switch ($template) {
            case 'ia_cf_rc':
              $user_ids = custom_notification_get_users_following_content('follow_content', $node->id());
              foreach ($user_ids as $uid => $user) {
                $notification_node_status = custom_notification_get_notification_settings($uid, $template);
                if ($notification_node_status) {
                  self::createNotificationMessage($template, $uid, $entity, $node, $group, $user_id_notified);
                }
              }
              break;

            case 'ia_cl_rc':
            case 'ia_cm_rc':
              $group_member_data = custom_notification_get_group_members_with_roles($group);
              foreach ($group_member_data as $data) {
                if (($template !== 'ia_cl_rc' || custom_notification_group_based_validation($group_member_data, 'cl')) &&
                    !in_array($data['user'], $user_id_notified)) {
                  $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                  if ($notification_node_status) {
                    self::createNotificationMessage($template, $data['user'], $entity, $node, $group, $user_id_notified);
                  }
                }
              }
              break;

            case 'ia_cic_rc':
              if (!in_array($node->getOwnerId(), $user_id_notified)) {
                $notification_node_status = custom_notification_get_notification_settings($node->getOwnerId(), $template);
                if ($notification_node_status) {
                  self::createNotificationMessage($template, $node->getOwnerId(), $entity, $node, $group, $user_id_notified);
                }
              }
              break;
          }
        }
      }
    }
    custom_notification_note_statistics('end', 'custom_notification__queue', $start_time);

  }

  /**
   * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $uid, $entity, $node, $group, &$user_id_notified) {
    $message = Message::create(['template' => $template, 'uid' => $uid]);
    if ($message_template = $message->getTemplate()) {
      $body = $message_template->get('text')[0]['value'];
      $nid = $node->id();
      $tokenService = \Drupal::token();

      $message_notify = [
        'bundle' => 'vote',
        'content_link' => "/node/{$nid}",
        'id' => $entity->id(),
        'content' => $tokenService->replace($body, [
          'user' => $entity->getOwner()->id(),
          'node' => $node,
          'group' => $group,
          'vote' => $entity,
        ]),
      ];
      $user_id_notified[] = $uid;
      
      // Correct notification service usage.
      $notificationService = \Drupal::service('notifications_widget.logger');
      $notificationService->logNotification($message_notify, 'create', $entity, $uid);
    }
  }

}
