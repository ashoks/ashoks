<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_node_queue",
 *   title = @Translation("Custom Notification Standard Node Queue Worker"),
 * )
 */
class CustomNotificationNodeQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
        $action = $data['action'];
        $entity = \Drupal::entityTypeManager()->getStorage('node')->load($data['entity_id']);
        $recipient_uid = NULL;
        $operator_uid = NULL; 
        if (isset($entity->field_community) && $entity->field_community->target_id) {
          $gid = $entity->field_community->target_id;
          $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
            $notify_data = [
              'group' => $entity,
              'node' => $entity,
              'group_relationship' => NULL,
              'entity_bundle' => $entity,
              'bundle' => 'node',
            ];        
            $user_id_notified = [];
            $templates = $data['templates'];
            $notificationService = \Drupal::service('notifications_widget.logger');
            $tokenService = \Drupal::service('token');
            $templates = $data['templates'];
            $nid = $entity->id();
            $action = $data['action'];
            if ($action == 'update') {
              $revision_user = $entity->getRevisionUser();
              foreach ($templates as $template) {
                $field_key = 'field_' . $template;
                switch ($template) {
                  case 'ia_cl_uc':
                  case 'ia_cm_uc':   
                    $group_member_data = custom_notification_get_group_members_with_roles($group);
                    foreach ($group_member_data as $data) {
                      $template_key = explode('_', $template);
                      $status = custom_notification_group_based_validation($data, $template_key[1]);
                      if ($status) {
                        $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                        if ($notification_node_status) {
                          if (!in_array($data['user'], $user_id_notified)) {  
                            $message_notify = self::createNotificationMessage($template, $data['user'], $entity, $entity, $group, $action);
                            $user_id_notified[] = $data['user'];            
                          }
                        }
                      }
                    }
                   break;
                  case 'ia_cic_uc':
                    if (!in_array($entity->getOwnerId(), $user_id_notified)) {
                      $notification_node_status = custom_notification_get_notification_settings($entity->getOwnerId(), $template);
                      if ($notification_node_status) {
                          $message_notify = self::createNotificationMessage($template, $entity->getOwnerId(), $entity, $entity, $group, $action);
                          $user_id_notified[] = $entity->getOwnerId();            
                      }
                    }
                  case 'ia_cf_uc':
                    $user_ids = custom_notification_get_users_following_content('follow_content', $entity->id());
                    if (!is_null($user_ids)) {
                      foreach ($user_ids as $user) {
                        if (!is_null($user)) {
                        $notification_node_status = custom_notification_get_notification_settings($user->id(), $template);
                        if ($notification_node_status) {
                          if (!in_array($user->id(), $user_id_notified)) {  
                                $message_notify = self::createNotificationMessage($template, $user->id(), $entity, $entity, $group, $action);
                                $user_id_notified[] = $user->id();            
                              }
                          }      
                        }
                      }
                    }
                }                
              }
            }
            else {
              //on create node send in app notification.
              foreach ($templates as $template) {
                $field_key = 'field_' . $template;
                $group_member_data = custom_notification_get_group_members_with_roles($group);
                foreach(array_chunk($group_member_data, 1000) as $group_member_sub_data) {
                  foreach ($group_member_sub_data as $data) {
                      $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                      if ($notification_node_status) {
                        if (!in_array($data['user'], $user_id_notified)) {
                          if ($entity->getOwnerId() != $data['user']) {
                            $message_notify = self::createNotificationMessage($template, $data['user'], $entity, $entity, $group, $action);
                            $user_id_notified[] = $data['user'];            
                          }        
                        }
                      }
                      unset($notification_node);
                  }
                  unset($group_member_sub_data, $data);
                }
              }
            }
        }
    }
    custom_notification_note_statistics('end', 'custom_notification_node_queue', $start_time);

  }

  /**
   * Creates a notification message.
   */
  protected static function createNotificationMessage($template, $user_id, $entity, $node, $group, $action) {
    $message = Message::create(['template' => $template, 'uid' => $user_id]);
    $content_data = [];
    $bundle = '';
    $body = '';
    $content_link = '';
    $recipient_uid = $user_id;//@2 - second this one//done
    $operator_uid = ($action == 'update') ? $entity->getRevisionUser()->id() : $entity->getOwner()->id();
    if ($message->getTemplate()) {
      $message_template = $message->getTemplate();
      $body = $message_template->get('text')[0]['value'];
      $description = $message_template->get('description');
      $bundle = 'node';
      $node_type = $node ? $node->bundle() : NULL;
      if ($node_type === 'pages') {
        $node_type = 'page';
      }
      $nid  = $node->id();
      $content_link = "/{$node_type}/{$nid}";
      if ($entity->getEntityTypeId() != 'node') {
        if ($nid && is_numeric($nid)) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
        }
      }
      $content_data = [
        'node' => ($node) ? $node : $entity,
        'user' => ($action == 'update') ? $entity->getRevisionUser() : $entity->getOwner(),//@1 First Place is this//done
        'group' => $group,
        'vote' => ($entity->getEntityTypeId() == 'vote') ? $entity : NULL
      ];
    }
    $tokenService = \Drupal::token();
    $message_notify = [
      'bundle' => $bundle,
      'content_link' => $content_link,
      'id' => $entity->id(),
      'content' => $tokenService->replace($body, $content_data),
      'description' => $tokenService->replace($description, $content_data)
    ];  
    $notificationService = \Drupal::service('notifications_widget.logger');
    $notificationService->logNotification($message_notify, 'create', $entity, $recipient_uid, $operator_uid);
  }

}
