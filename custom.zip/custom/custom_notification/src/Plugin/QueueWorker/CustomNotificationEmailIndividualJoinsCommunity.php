<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;
use Drupal\Core\Mail\MailManagerInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Utility\Token;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_joins_community_email_individual",
 *   title = @Translation("Custom Notification Joins Community Email"),
 * )
 */
class CustomNotificationEmailIndividualJoinsCommunity extends QueueWorkerBase implements ContainerFactoryPluginInterface {

  /**
   * The mail manager service.
   *
   * @var \Drupal\Core\Mail\MailManagerInterface
   */
  protected $mailManager;

  /**
   * The token service.
   *
   * @var \Drupal\Core\Utility\Token
   */
  protected $tokenService;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a CustomNotificationEmailIndividualJoinsCommunity object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Mail\MailManagerInterface $mail_manager
   *   The mail manager service.
   * @param \Drupal\Core\Utility\Token $token_service
   *   The token service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager service.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    MailManagerInterface $mail_manager,
    Token $token_service,
    EntityTypeManagerInterface $entity_type_manager,
    Connection $database
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);

    $this->mailManager = $mail_manager;
    $this->tokenService = $token_service;
    $this->entityTypeManager = $entity_type_manager;
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('plugin.manager.mail'),
      $container->get('token'),
      $container->get('entity_type.manager'),
      $container->get('database')
    );
  }

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    $start_time = custom_notification_note_statistics('start', '');
    $this->createNotificationMessage($data['template'], $data['user_id'], $data['entity'], $data['group'], $data['user_id_who_joined'], $data['site_url']);
    custom_notification_note_statistics('end', 'custom_notification_joins_community_email_individual', $start_time);

  }

    /**
   * Creates a notification message.
   */
  protected function createNotificationMessage($template, $uid, $entity, $group, $user_id_who_joined, $site_url) {
    $email_template = str_replace('ia', 'em', $template);
    $field_key = 'field_'. $email_template;
    $notification_node_status = custom_notification_get_notification_settings($uid, $email_template);
    if ($notification_node_status) {
      $message = Message::create(['template' => $template, 'uid' => $uid]);
      if ($message_template = $message->getTemplate()) {
        $body = '';
        if ($message_template->get('text')[0]['value']) {
          $body = str_replace('[site:url]', $site_url, $message_template->get('text')[0]['value']);
        }
        $description = '';
        if ($message_template->get('description')) {
          $description = str_replace('[site:url]', $site_url, $message_template->get('description'));
        }
        $group_id = $group->id();
        $user = $this->entityTypeManager->getStorage('user')->load($user_id_who_joined);

        $message_notify = [
          'bundle' => 'group_relationship',
          'content_link' => "/community/{$group_id}",
          'id' => $entity->id(),
          'content' => $this->tokenService->replace($body, [
            'user' => $user,
            'group' => $group,
            'group_relationship' => $entity,
          ]),
          'description' => $this->tokenService->replace($description, [
            'user' => $user,
            'group' => $group,
            'group_relationship' => $entity,
          ]),
        ];
        $message_notify['content'] = html_entity_decode($message_notify['content']);
        $message_notify['description'] = html_entity_decode($message_notify['description']);

        $email_template = str_replace('ia', 'em', $template);

        // Retrieve the email address of the recipient.
        $query = $this->database->select('users_field_data', 'u')
          ->fields('u', ['mail'])
          ->condition('u.uid', $uid, '=');
        $email = $query->execute()->fetchField();
        $to = $email;

        // Email parameters.
        $params = [
          'message' => $message_notify['content'],
          'title' => $message_notify['description'],
          'module' => 'custom_notification',
        ];

        // Send the email.
        $langcode = 'en';
        $send = true;
        $result = $this->mailManager->mail('custom_notification', $email_template, $to, $langcode, $params, NULL, $send);

        if ($result['result'] !== true) {
          // Log error if the email sending fails.
          \Drupal::logger('custom_notification')->error(t('There was a problem sending your email notification using template @field_template_key to @email.', [
            '@email' => $to,
            '@field_template_key' => $email_template,
          ]));
        }
      }
    }
  }

}
