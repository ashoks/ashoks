<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_comment_email_queue",
 *   title = @Translation("Custom Notification Standard Comment Email Queue Worker"),
 * )
 */
class CustomNotificationCommentEmailQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $start_time = custom_notification_note_statistics('start', '');
    if (isset($data['entity_id'])) {
      $site_url = $data['site_url'];
      $action = $data['action'];
      $entity = \Drupal::entityTypeManager()->getStorage('comment')->load($data['entity_id']);
      if ($entity) {
        $node = $entity->getCommentedEntity();
        $gid = $node->field_community->target_id;
        $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
        $action = $data['action'];
        if (isset($node->field_community) && $node->field_community->target_id) {
          $user_id_notified = [];
          $notificationService = \Drupal::service('notifications_widget.logger');
          $tokenService = \Drupal::service('token');
          $group_member_data = custom_notification_get_group_members_with_roles($group);
          $templates = $data['templates'];
          $queue = \Drupal::service('queue')->get('custom_notification_comment_email_individual_queue');
          foreach($templates as $template ) {
            $field_key = 'field_'. $template;
            switch ($template) {
              case 'em_cl_arc':
              case 'em_cm_arc':
                  foreach($group_member_data as $data) {
                    $template_key = explode('_', $template);
                    $status = custom_notification_group_based_validation($data, $template_key[1]);
                    if ($status) {
                      $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                      if ($notification_node_status) {
                        //Passing null is deprecated. need to fix that
                        if (!in_array($data['user'], $user_id_notified)) {  
                          if ($entity->getOwnerId() != $data['user']) {
                            $queue->createItem([
                              'template' => $template,
                              'user_id' => $data['user'],
                              'entity' => $entity,
                              'group' => $group,
                              'action' => $action,
                              'site_url' => $site_url
                            ]);
                            $user_id_notified[] = $data['user'];  
                          }  
                        }
                      }
                    }
                  }
              break;
               case 'em_cic_arc':
                if (!in_array($node->getOwnerId(), $user_id_notified)) {
                  if ($node->getOwnerId() != $entity->getOwnerId()) {
                     $notification_node_status = custom_notification_get_notification_settings($node->getOwnerId(), $template);
                     if ($notification_node_status) {
                      $queue->createItem([
                        'template' => $template,
                        'user_id' => $node->getOwnerId(),
                        'entity' => $entity,
                        'group' => $group,
                        'action' => $action,
                        'site_url' => $site_url
                      ]);
                     $user_id_notified[] = $node->getOwnerId();            
                    }
                  }
                }
                break;
              case 'em_cf_arc':
                $user_ids = custom_notification_get_users_following_content('follow_content', $node->id());
                if (!is_null($user_ids)) {
                  foreach ($user_ids as $uid => $user) {
                    $notification_node_status = custom_notification_get_notification_settings($uid, $template);
                    if ($entity->getOwnerId()  != $uid) {
                      if ($notification_node_status) {
                        if (!in_array($uid, $user_id_notified)) {  
                          $queue->createItem([
                            'template' => $template,
                            'user_id' => $uid,
                            'entity' => $entity,
                            'group' => $group,
                            'action' => $action,
                            'site_url' => $site_url,
                          ]);
                          $user_id_notified[] = $uid;            
                        }
                      }      
                    }
                  }
                }
                break;
            }
          }
        }
      }
    }
    custom_notification_note_statistics('end', 'custom_notification_comment_email_queue', $start_time);

  }
}