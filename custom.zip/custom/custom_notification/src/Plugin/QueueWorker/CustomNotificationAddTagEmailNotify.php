<?php

namespace Drupal\custom_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_notification_add_tag_notify_email_queue",
 *   title = @Translation("Custom Notification Standard Add Tag Email Queue Worker"),
 * )
 */
class CustomNotificationAddTagEmailNotify extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    $start_time = custom_notification_note_statistics('start', '');
    // Process the data passed to the queue.
    if (isset($data['entity_id'])) {
        $site_url = $data['site_url'];
        $action = $data['action'];
        $user_added_tags = $data['user_added_tags'];
        $entity = \Drupal::entityTypeManager()->getStorage('node')->load($data['entity_id']);
        $gid = $entity->field_community->target_id;
        $group = \Drupal::entityTypeManager()->getStorage('group')->load($gid);
        $recipient_uid = NULL;
        if (isset($entity->field_community) && $entity->field_community->target_id) {
            $notify_data = [
              'group' => $group,
              'node' => $entity,
              'group_relationship' => NULL,
              'entity_bundle' => $entity,
              'bundle' => 'node',
            ];        
            $user_id_notified = [];
            $templates = $data['templates'];
            $notificationService = \Drupal::service('notifications_widget.logger');
            $tokenService = \Drupal::service('token');
            $templates = $data['templates'];
            $current_user = $data['current_user'];
            $nid = $entity->id();
            $action = $data['action'];
            $queue = \Drupal::service('queue')->get('custom_notification_add_tag_email_individual_queue');
            if ($action == 'update') {
              foreach ($templates as $template) {
                $field_key = 'field_' . $template;
                switch ($template) {
                  case 'em_cl_tc':
                  case 'em_cm_tc':   
                    $group_member_data = custom_notification_get_group_members_with_roles($group);
                    foreach ($group_member_data as $data) {
                        $template_key = explode('_', $template);
                        $status = custom_notification_group_based_validation($data, $template_key[1]);
                        if ($status) {
                          $notification_node_status = custom_notification_get_notification_settings($data['user'], $template);
                          if ($notification_node_status) {
                            if (!in_array($data['user'], $user_id_notified)) {  
                              if ($data['user'] != $current_user) {
                                $queue->createItem([
                                  'template' => $template,
                                  'user_id' => $data['user'],
                                  'entity' => $entity,
                                  'group' => $group,
                                  'action' => $action,
                                  'user_added_tags' => $user_added_tags,
                                  'current_user' => $current_user,
                                  'site_url' => $site_url,
                                ]);
                              }                             
                              $user_id_notified[] = $data['user'];            
                            }
                          }
                        }
                    }
                   break;
                  case 'em_cic_tc': 
                    if (!in_array($entity->getOwnerId(), $user_id_notified)) {
                      $notification_node_status = custom_notification_get_notification_settings($entity->getOwnerId(), $template);
                      if ($notification_node_status) {
                        if ($entity->getOwnerId() != $current_user) {
                          $queue->createItem([
                            'template' => $template,
                            'user_id' => $entity->getOwnerId(),
                            'entity' => $entity,
                            'group' => $group,
                            'action' => $action,
                            'user_added_tags' => $user_added_tags,
                            'current_user' => $current_user,
                            'site_url' => $site_url,
                          ]);
                        }
                        $user_id_notified[] = $entity->getOwnerId();            
                      }
                    }
                  case 'em_cf_tc':
                    $user_ids = custom_notification_get_users_following_content('follow_content', $entity->id());
                    if (!is_null($user_ids)) {
                      foreach ($user_ids as $uid => $user) {
                        $notification_node_status = custom_notification_get_notification_settings($uid, $template);
                        if ($notification_node_status) {
                            if (!in_array($uid, $user_id_notified)) {  
                              $queue->createItem([
                                'template' => $template,
                                'user_id' => $uid,
                                'entity' => $entity,
                                'group' => $group,
                                'action' => $action,
                                'user_added_tags' => $user_added_tags,
                                'current_user' => $current_user,
                                'site_url' => $site_url,
                              ]);
                              $user_id_notified[] = $uid;            
                            }
                        }      
                      }
                    }
                }                
              }
            }
        }
    }
    custom_notification_note_statistics('end', 'custom_notification_add_tag_notify_email_queue', $start_time);

  }
}
