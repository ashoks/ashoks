<?php

namespace Drupal\custom_notification\Services;

use Drupal\Core\Mail\MailManagerInterface;
use Drupal\Core\Logger\LoggerChannelTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Utility\Token;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\notifications_widget\Services\NotificationsWidgetServiceInterface;

/**
 * Provides notification services for sending app and email notifications.
 */
class NotificationService {
  use LoggerChannelTrait;

  /**
   * Mail manager for sending emails.
   *
   * @var \Drupal\Core\Mail\MailManagerInterface
   */
  protected $mailManager;

  /**
   * Entity type manager for loading entities.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Token service for replacing tokens in templates.
   *
   * @var \Drupal\Core\Utility\Token
   */
  protected $token;

  /**
   * Current user session.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $currentUser;

  /**
   * Notifications logger service.
   *
   * @var \Drupal\notifications_widget\Services\NotificationsWidgetServiceInterface
   */
  protected $notificationsLogger;

  /**
   * Logger instance.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * Constructor for the NotificationService class.
   *
   * @param \Drupal\Core\Mail\MailManagerInterface $mailManager
   *   The mail manager service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager service.
   * @param \Drupal\Core\Utility\Token $token
   *   The token service.
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user service.
   * @param \Drupal\notifications_widget\Services\NotificationsWidgetServiceInterface $notificationsLogger
   *   The notifications logger service.
   */
  public function __construct(
    MailManagerInterface $mailManager,
    EntityTypeManagerInterface $entityTypeManager,
    Token $token,
    AccountProxyInterface $currentUser,
    NotificationsWidgetServiceInterface $notificationsLogger
  ) {
    $this->mailManager = $mailManager;
    $this->entityTypeManager = $entityTypeManager;
    $this->token = $token;
    $this->currentUser = $currentUser;
    $this->notificationsLogger = $notificationsLogger;
    $this->logger = $this->getLogger('custom_notification');
  }

  /**
   * Sends an app notification.
   *
   * @param object $file
   *   The file entity to include in the notification.
   * @param object $entity
   *   The associated entity (e.g., node).
   * @param object $author
   *   The author receiving the notification.
   * @param string $template_key
   *   The template key for the message entity.
   */
  public function sendAppNotification($file, $entity, $author, $template_key) {
    // Create a message entity.
    $message = $this->entityTypeManager->getStorage('message')->create([
      'template' => $template_key,
      'uid' => $author->id(),
    ]);

    // Prepare notification data.
    $message_notify = [
      'bundle' => 'group',
      'group' => $entity,
      'id' => $entity->id(),
    ];

    // Load the current user account.
    $currentUserAccount = $this->entityTypeManager->getStorage('user')->load($this->currentUser->id());

    if ($message->getTemplate()) {
      // Replace tokens in the notification body.
      $body = $this->token->replace($message->getTemplate()->get('text')[0]['value'], [
        'user' => $currentUserAccount,
        'group' => $entity,
        'file' => $file,
      ]);

      $message_notify['content'] = $body;
      // Sets the URL to which the notification will redirect
      $message_notify['content_link'] = "/".strtolower($entity->type->entity->label())."/".$entity->id();
      // Check the user's notification preferences.
      $preferences = $this->entityTypeManager->getStorage('node')->loadByProperties([
        'uid' => $author->id(),
        'type' => 'notification_user_preference',
      ]);

      if (!empty($preferences)) {
        $preference = reset($preferences);

        // Log the notification if preferences allow.
        if ($preference->get('field_ia_cic_da')->value == 1) {
          $this->notificationsLogger->logNotification($message_notify, 'create', $entity, $author->id());
        }
      }
    }
  }

  /**
   * Sends an email notification.
   *
   * @param object $file
   *   The file entity to include in the email.
   * @param object $entity
   *   The associated entity (e.g., node).
   * @param object $author
   *   The author receiving the email.
   * @param string $template_key
   *   The template key for the message entity.
   */
  public function sendEmailNotification($file, $entity, $author, $template_key) {
    // Load the current user account.
    $currentUserAccount = $this->entityTypeManager->getStorage('user')->load($this->currentUser->id());

    // Create a message entity.
    $message = $this->entityTypeManager->getStorage('message')->create([
      'template' => $template_key,
      'uid' => $author->id(),
    ]);
    
    if ($message->getTemplate()) {
      // Replace tokens in the email body and subject.
      $body = $this->token->replace(html_entity_decode($message->getTemplate()->get('text')[0]['value']), [
        'user' => $currentUserAccount,
        'node' => $entity,
        'file' => $file,
      ]);
      $description = $this->token->replace(html_entity_decode($message->getTemplate()->get('description')), [
        'user' => $currentUserAccount,
        'node' => $entity,
        'file' => $file,
      ]);
      
      // Prepare email parameters.
      $to = $author->getEmail();
      $params = [
        'message' => $body,
        'title' => $description,
        'module' => 'custom_notification',
      ];
      $langcode = $this->currentUser->getPreferredLangcode();
      $send = true;

      // Check the user's email notification preferences.
      $preferences = $this->entityTypeManager->getStorage('node')->loadByProperties([
        'uid' => $author->id(),
        'type' => 'notification_user_preference',
      ]);

      if (!empty($preferences)) {
        $preference = reset($preferences);

        if ($preference->get('field_em_cic_da')->value == 1) {
          // Send the email.
          $result = $this->mailManager->mail('custom_notification', 'custom_notification_em_asn_cc', $to, $langcode, $params, NULL, $send);
          $this->logger->notice(t('info email. @template_key @to @params', [
            '@template_key' => $template_key,
            '@to' => $to,
            '@params' => print_r($params, true),
          ]));
          // Log email results.
          if ($result['result'] !== true) {
            $this->logger->notice(t('An email notification failed using template @template_key to @to.', [
              '@template_key' => $template_key,
              '@to' => $to,
              '@params' => print_r($params, true),
            ]));
            return;
          }
        }
      }
    }
  }
}
