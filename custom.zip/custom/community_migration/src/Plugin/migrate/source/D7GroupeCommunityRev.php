<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_content_field_data_com_rev source.
 *
 * @MigrateSource(
 *   id = "group_content_field_data_com_rev"
 * )
 */
class D7GroupeCommunityRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    #Change 2 : Adding filter for data which actually has been removed from new Prism like wiki, poll etc.
      $query = $this->select('og_membership', 'n')
      ->fields('n', array(
      'id',
      'type',
      'etid',
      'entity_type',
      'gid',
      'group_type',
      'state',
      'created',
      'field_name',
      'language'
      ))
      ->condition('n.entity_type', 'node')
      
      ->condition('nd.type', 'group', '<>')
      ->condition('nd.type', 'notification', '<>')
      ->condition('nd.type', 'engagement', '<>')
      ->condition('nd.type', 'node_gallery_gallery', '<>')
      ->condition('nd.type', 'node_gallery_item', '<>')
      ->condition('nd.type', 'poll', '<>')
      ->condition('nd.type', 'webform', '<>')
      ->condition('nd.type', 'wiki', '<>');

      $query->leftJoin('node', 'nd', 'nd.nid = n.etid');
      $query->addField('nd', 'nid');
    
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $type = $row->getSourceProperty('entity_type');
    $gid = $row->getSourceProperty('gid');
    $etid = $row->getSourceProperty('etid');

     
    $row->setSourceProperty('group_type', 1);


    // get the type of uid using $etid from table node
    $query_uid = $this->select('node', 'nd')
    ->fields('nd', array(
    'uid',
    'title',
    'changed',
    'vid'
    ))
    ->condition('nd.nid', $etid);
    $result_uid = $query_uid->execute()->fetchObject();

    $uid = $result_uid->uid;
    $label = $result_uid->title;
    $changed = $result_uid->changed;
    $node_vid = $result_uid->vid;

    $row->setSourceProperty('field_name', $label);
    $row->setSourceProperty('entity_type', $changed);
   
    
   
    $row->setSourceProperty('state', 0);
    
    $row->setSourceProperty('type', 'event');
    $row->setSourceProperty('entity_type', $node_vid);

    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);

  }

  /**
   * {@inheritdoc}
   */
  public function fields() {


    return array(

    'id' => $this->t('id'),
    'type' => $this->t('type'),
    'etid' => $this->t('etid'),
    'entity_type' => $this->t('entity_type'),
    'gid' => $this->t('gid'),
    'group_type' => $this->t('group_type'),
    'state' => $this->t('state'),
    'created' => $this->t('created'),
    'field_name' => $this->t('field_name'),
    'language' => $this->t('langcode')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['etid']['type'] = 'integer';
    return $ids;
  }
   
}
