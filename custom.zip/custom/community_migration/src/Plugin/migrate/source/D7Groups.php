<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * master_groups source.
 *
 * @MigrateSource(
 *   id = "master_groups"
 * )
 */
class D7Groups extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('field_data_field_og_subscribe_settings', 'n')
      ->fields('n', array(
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_og_subscribe_settings_value'
      ));
      // ->condition('n.type', 'asset', '=')
      // ->condition('n.type', 'event', '=')
      // ->condition('n.type', 'pages', '=')
      // ->condition('n.type', 'reference', '=')
      // ->condition('n.type', 'news', '=');
      // $query->innerJoin('users', 'u', 'u.uid = n.uid');
      // $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      // $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      // $query->addField('fdfn', 'field_name_first_value');
      // $query->addField('fdln', 'field_name_last_value');
      // $query->addField('u', 'mail');
      // $query->addField('u', 'name');
      // $query->addField('u', 'uid');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     
     $field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('field_og_subscribe_settings_value', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('field_og_subscribe_settings_value', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('field_og_subscribe_settings_value', 'secret_group');
     }
     
    // Generate UUID 
    $uuid_service = \Drupal::service('uuid');
    $uuid = $uuid_service->generate();
    $row->setSourceProperty('delta', $uuid);



    // Group Language changed from und to en 
    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity Revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The UUID alias'),
      'field_og_subscribe_settings_value' => $this->t('Group type in D7')

    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['entity_id']['type'] = 'integer';
    return $ids;
  }
   
}