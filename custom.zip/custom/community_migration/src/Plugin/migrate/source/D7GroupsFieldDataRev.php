<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_field_revision source.
 *
 * @MigrateSource(
 *   id = "group_field_revision"
 * )
 */
class D7GroupsFieldDataRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node_revision', 'nr')
      ->fields('nr', array(
      'nid',
      'vid',
      'uid',
      'title',
      'log',
      'timestamp',
      'status',
      'comment',
      'promote',
      'sticky'
      ));
      // ->condition('nr.type', 'group');
      $query->leftJoin('field_data_field_og_subscribe_settings', 'fds', 'nr.nid = fds.entity_id');
      // $query->addField('fds', 'entity_id');
      // $query->innerJoin('node', 'nd', 'fds.entity_id = nr.nid');
      // SELECT om.* FROM `node_revision` as om INNER JOIN field_data_field_og_subscribe_settings as fds on fds.entity_id = om.nid;
      
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $nid = $row->getSourceProperty('nid');
    // get the type of uid using $etid from table node
    $query_uid = $this->select('node', 'nd')
    ->fields('nd', array(
    'type',
    'created',
    'changed'
    ))
    ->condition('nd.nid', $nid);
    // ->condition('nd.type', 'group');

    $result_uid = $query_uid->execute()->fetchObject();

    // $type = $result_uid->type;
    $created = $result_uid->created;

    $row->setSourceProperty('log', $created);
    $row->setSourceProperty('promote', 1);
    $row->setSourceProperty('comment', "en");
 
     return parent::prepareRow($row);
   
    
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('vid'),
      'uid' => $this->t('uid'),
      'title' => $this->t('title'),
      'log' => $this->t('log'),
      'timestamp' => $this->t('timestamp'),
      'status' => $this->t('status'),
      'comment' => $this->t('comment'),
      'promote' => $this->t('promote'),
      'sticky' => $this->t('sticky')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['vid']['type'] = 'integer';
    return $ids;
  }
   
}