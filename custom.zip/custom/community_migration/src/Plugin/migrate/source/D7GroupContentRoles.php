<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_content_roles source.
 *
 * @MigrateSource(
 *   id = "group_content_roles"
 * )
 */
class D7GroupContentRoles extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {

   $query = $this->select('og_users_roles', 'ogr')
      ->fields('ogr', array(
      'id',
      'uid',
      'rid',
      'gid',
      'group_type'
      ));

      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $gid = $row->getSourceProperty('gid');
    $uid = $row->getSourceProperty('uid');
    $rid = $row->getSourceProperty('rid');

    $queryuvid = $this->select('og_membership', 'n')
      ->fields('n', array(
      'id'
      ))
      ->condition('n.gid', $gid)
      ->condition('n.etid', $uid)
      ->condition('n.entity_type', 'user');

    $resultuvid = $queryuvid->execute()->fetchObject();

    if (empty($resultuvid)) {
      return FALSE;
    }

    $row->setSourceProperty('uid', $resultuvid->id);

    // Get the group type from field_data_field_og_subscribe_settings

    $query_group = $this->select('field_data_field_og_subscribe_settings', 'fds')
    ->fields('fds', array(
    'field_og_subscribe_settings_value'
    ))
    ->condition('fds.entity_id', $gid);
    $result_group = $query_group->execute()->fetchObject();

    $group_type = $result_group->field_og_subscribe_settings_value;

    if (!empty($group_type) && $group_type == "anyone") {
        $custom_gtype = 'public_group';
    }

    if (!empty($group_type) && $group_type == "invitation") {
        $custom_gtype = 'closed_group';
    }

    if (!empty($group_type) && $group_type == "approval") {
        $custom_gtype = 'secret_group';
    }
 
    $cg_type = $custom_gtype.'-group_membership';
    $row->setSourceProperty('rid', $cg_type);

    $query_rol = $this->select('og_role', 'rol')
    ->fields('rol', array(
    'name'
    ))
    ->condition('rol.rid', $rid)
    ->condition('rol.gid', $gid);

    $result_rol = $query_rol->execute()->fetchObject();

    $role_name = $result_rol->name;

    if($role_name == 'moderator'){

        $groupRole = $custom_gtype.'-moderator';

    }

    
    if($role_name == 'administrator member'){

        $groupRole = $custom_gtype.'-group_admin';

    }


    
    if($role_name == 'Reference Manager'){

        $groupRole = $custom_gtype.'-group_manager';

    }


    $row->setSourceProperty('group_type', $groupRole);
    $row->setSourceProperty('gid', 0);
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
    'id' => $this->t('id'),
    'uid' => $this->t('user id'),
    'rid' => $this->t('role id'),
    'gid' => $this->t('group id'),
    'group_type' => $this->t('group type')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    
    return $ids;
  }
   
}