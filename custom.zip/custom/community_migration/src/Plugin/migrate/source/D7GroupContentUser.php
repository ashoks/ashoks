<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_content_user source.
 *
 * @MigrateSource(
 *   id = "group_content_user"
 * )
 */
class D7GroupContentUser extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    
    $query = $this->select('og_membership', 'n')
      ->fields('n', array(
      'id',
      'type',
      'etid',
      'entity_type',
      'gid',
      'group_type',
      'state',
      'created',
      'field_name',
      'language'
      ))
      ->condition('n.entity_type', 'user');
  
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {    

    $type = $row->getSourceProperty('entity_type');
    $gid = $row->getSourceProperty('gid');
    $etid = $row->getSourceProperty('etid');
   
    $row->setSourceProperty('group_type', 1);

    // get the type of uid using $etid from table node
    $query_uid = $this->select('users', 'nd')
    ->fields('nd', array(
    'uid',
    'name',
    'created'
    ))
    ->condition('nd.uid', $etid);
    $result_uid = $query_uid->execute()->fetchObject();
    $uid = $result_uid->uid;
    if (empty($uid)) {
        return FALSE;
    }
    
    $label = $result_uid->name;
    $changed = $result_uid->created;
    $row->setSourceProperty('field_name', $label);
    $row->setSourceProperty('entity_type', $changed);
    // $row->setSourceProperty('state', $uid);
     // Generate UUID 
     $uuid_service = \Drupal::service('uuid');
     $uuid = $uuid_service->generate();
     $row->setSourceProperty('state', $uuid);
     

    // Get the group type from field_data_field_og_subscribe_settings

    $query_group = $this->select('field_data_field_og_subscribe_settings', 'fds')
    ->fields('fds', array(
    'field_og_subscribe_settings_value'
    ))
    ->condition('fds.entity_id', $gid);
    $result_group = $query_group->execute()->fetchObject();
    $group_type = $result_group->field_og_subscribe_settings_value;

    if (!empty($group_type) && $group_type == "anyone") {
        $custom_gtype = 'public_group';
    }

    if (!empty($group_type) && $group_type == "invitation") {
        $custom_gtype = 'closed_group';
    }

    if (!empty($group_type) && $group_type == "approval") {
        $custom_gtype = 'secret_group';
    }
 
    
    $cg_type = $custom_gtype.'-group_membership';

    $row->setSourceProperty('type', $cg_type);

    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);


  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
    'id' => $this->t('id'),
    'type' => $this->t('type'),
    'etid' => $this->t('etid'),
    'entity_type' => $this->t('entity_type'),
    'gid' => $this->t('gid'),
    'group_type' => $this->t('group_type'),
    'state' => $this->t('state'),
    'created' => $this->t('created'),
    'field_name' => $this->t('field_name'),
    'language' => $this->t('langcode')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    return $ids;
  }
   
}