<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * groups_author source.
 *
 * @MigrateSource(
 *   id = "groups_author"
 * )
 */
class D7GroupsAuthor extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'type',
      'language',
      'title',
      'uid',
      'status',
      'created',
      'changed',
      'promote'
      ))
      ->condition('n.type', 'group');

      // ->condition('n.type', 'event', '=')
      // ->condition('n.type', 'pages', '=')
      // ->condition('n.type', 'reference', '=')
      // ->condition('n.type', 'news', '=');
      $query->leftJoin('field_data_field_og_subscribe_settings', 'fds', 'fds.entity_id = n.nid');

      // $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      // $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      // $query->condition('fdf.field_data_field_default_display', 'asset');
      // $query->addField('fdln', 'field_name_last_value');
      // $query->addField('u', 'mail');
      // $query->addField('u', 'name');

      $query->addField('fds', 'field_og_subscribe_settings_value');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     
     $field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('type', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('type', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('type', 'secret_group');
     }
 
    // Group Language changed from und to en 
    $row->setSourceProperty('status', 0);
    $row->setSourceProperty('promote', 0);
    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity Revision'),
      'type' => $this->t('Type'),
      'language' => $this->t('Language'),
      'title' => $this->t('Title'),
      'uid' => $this->t('User ID'),
      'status' => $this->t('Status'),
      'created' => $this->t('Created'),
      'changed'  => $this->t('Changed'),
      'promote' => $this->t('Promote')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}