<?php

namespace Drupal\custom_group_menu\Plugin\Condition;

use Drupal\Core\Condition\ConditionPluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Group Status Based' condition.
 *
 * @Condition(
 *   id = "group_status_based_access",
 *   label = @Translation("Group Status Based Group Condition"),
 * )
 */
class GroupStatusBasedAccess extends ConditionPluginBase implements ContainerFactoryPluginInterface {

  /**
   * The current path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected $currentPath;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * Constructs a GroupBasedAccess condition plugin.
   *
   * @param \Drupal\Core\Path\CurrentPathStack $current_path
   *   The current path.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager object.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param array $plugin_definition
   *   The plugin implementation definition.
   */
  public function __construct(CurrentPathStack $current_path, EntityTypeManagerInterface $entity_type_manager, array $configuration, $plugin_id, array $plugin_definition) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentPath = $current_path;
    $this->entityTypeManager = $entity_type_manager;

  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $container->get('path.current'),
      $container->get('entity_type.manager'),
      $configuration,
      $plugin_id,
      $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return ['group_status' => []] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);
    $form['negate']['#access'] = FALSE;
    $form['group_status'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Published'),
      '#default_value' => ($this->configuration['group_status']) ?? [],
      '#options' => [
        'Yes' => 'Yes',
        'No' => 'No',
      ],
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $this->configusration['group_status'] = $form_state->getValue('group_status');

    parent::submitConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function summary() {
    return $this->t('Performed Group Status based access');
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate() {
    $path = $this->currentPath->getPath();
    // @todo need to check why group context is not visible.
    $gid = custom_group_menu_get_group_id_from_page();
    if ($gid) {
      $group = $this->entityTypeManager->getStorage('group')->load($gid);
      if ($group) {
        $group_status_value = $group->get('status')->value;
        $configuration_status_yes = $this->configuration['group_status']['Yes'] === 'Yes';
        $configuration_status_no = $this->configuration['group_status']['No'] === 'No';
        if ($group_status_value && $configuration_status_yes) {
          return TRUE;
        }
        if ($group_status_value  && $configuration_status_no) {
          return FALSE;
        }
      }
    }
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    $contexts = parent::getCacheContexts();
    $contexts[] = 'url.path';
    return $contexts;
  }

}
