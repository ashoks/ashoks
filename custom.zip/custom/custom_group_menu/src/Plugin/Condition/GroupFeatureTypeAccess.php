<?php

namespace Drupal\custom_group_menu\Plugin\Condition;

use Drupal\Core\Condition\ConditionPluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Group Feature Type Access' condition.
 *
 * @Condition(
 *   id = "group_feature_type_access",
 *   label = @Translation("Feature Type Group Condition"),
 * )
 */
class GroupFeatureTypeAccess extends ConditionPluginBase implements ContainerFactoryPluginInterface {

  /**
   * The current path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected $currentPath;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * Constructs a GroupBasedAccess condition plugin.
   *
   * @param \Drupal\Core\Path\CurrentPathStack $current_path
   *   The current path.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager object.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param array $plugin_definition
   *   The plugin implementation definition.
   */
  public function __construct(CurrentPathStack $current_path, EntityTypeManagerInterface $entity_type_manager, array $configuration, $plugin_id, array $plugin_definition) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentPath = $current_path;
    $this->entityTypeManager = $entity_type_manager;

  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $container->get('path.current'),
      $container->get('entity_type.manager'),
      $configuration,
      $plugin_id,
      $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return ['feature_type_reference' => '', 'feature_type_asset' => ''] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);
    $form['negate']['#access'] = FALSE;
    $form['feature_type_reference'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Reference'),
      '#default_value' => ($this->configuration['feature_type_reference']) ?? '',
    ];
    $form['feature_type_asset'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Asset'),
      '#default_value' => ($this->configuration['feature_type_asset']) ?? '',
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $this->configuration['feature_type_reference'] = $form_state->getValue('feature_type_reference');
    $this->configuration['feature_type_asset'] = $form_state->getValue('feature_type_asset');

    parent::submitConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function summary() {
    return $this->t('Performed Group based access');
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate() {
    $path = $this->currentPath->getPath();
    // @todo need to check why group context is not visible.
    $gid = custom_group_menu_get_group_id_from_page();
    if ($gid) {
      $group = $this->entityTypeManager->getStorage('group')->load($gid);
      if ($community_type = $group->field_community_type->value) {
        if (!$this->configuration['feature_type_reference'] && !$this->configuration['feature_type_asset']) {
          return TRUE;
        }
        elseif ($this->configuration['feature_type_reference'] && $community_type == 3) {
          return TRUE;
        }
        elseif ($this->configuration['feature_type_asset'] && !$community_type) {
          return TRUE;
        }
        else {
          return FALSE;
        }
      }
    }
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    $contexts = parent::getCacheContexts();
    $contexts[] = 'url.path';
    return $contexts;
  }

}
