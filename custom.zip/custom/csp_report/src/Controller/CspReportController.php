<?php

namespace Drupal\csp_report\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

class CspReportController {
  public function report(Request $request) {
    $data = json_decode($request->getContent(), TRUE);
    \Drupal::logger('csp_violation')->notice('CSP Violation: @data', ['@data' => print_r($data, TRUE)]);
    return new JsonResponse(NULL, 204);
  }
}
