Manipulate Asset
==========
Custom asset module is specifically created for assets knowledge object.

Author/Maintainers
======================
- Shefali Joshi - Capgemini It Team
