<?php

namespace Drupal\custom_community\EventSubscriber;

use Drupal\Core\Routing\CurrentRouteMatch;
use Drupal\Core\Session\AccountProxy;
use Drupal\group\Entity\Group;
use Drupal\user\Entity\User;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Drupal\Core\Cache\CacheableRedirectResponse;

/**
 * Class RedirectSubscriber.
 */
class CustomRedirectSubscriber implements EventSubscriberInterface {

  /**
   * The current route.
   *
   * @var \Drupal\Core\Routing\CurrentRouteMatch
   */
  protected $currentRoute;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountProxy
   */
  protected $currentUser;

  /**
   * Redirectsubscriber construct.
   *
   * @param \Drupal\Core\Routing\CurrentRouteMatch $route_match
   *   The current route.
   * @param \Drupal\Core\Session\AccountProxy $current_user
   *   The current user.
   */
  public function __construct(CurrentRouteMatch $route_match, AccountProxy $current_user) {
    $this->currentRoute = $route_match;
    $this->currentUser = $current_user;
  }

  /**
   * Get the request events.
   *
   * @return mixed
   *   Returns request events.
   */

  /**
   * This method is called when the KernelEvents::REQUEST event is dispatched.
   *
   * @param \Symfony\Component\HttpKernel\Event\RequestEvent $event
   *   The event.
   */
  public function customGroupLandingPage(RequestEvent $event) {
    $routeMatch = $this->currentRoute->getRouteName();
    $current_path = \Drupal::request()->getRequestUri();
    $current_qs = \Drupal::request()->getQueryString();
    $grp_exp = explode('/',$current_path);
    $grp_exp_arr = array_filter($grp_exp);
    $grp_gid = array_key_exists(2,$grp_exp_arr)?$grp_exp_arr[2]: null;
    $group = $this->currentRoute->getParameter('group');
    $dis_default = '';
    if ((($current_path == "/community/" . $grp_gid)||($current_path =="/group/". $grp_gid)) && empty($current_qs)) {
          $gid = $grp_gid;
          $query = \Drupal::database()->select('group__field_default_display', 'gd');
          $query->fields('gd', ['field_default_display_value']);
          $query->condition('gd.entity_id', $gid,'=');
          $dresult = $query->execute()->fetchObject();
          $dis_default = !empty($dresult) ? $dresult->field_default_display_value : '';        
      
    }
    if(isset($group) && !empty($group)){
        if(($group == $grp_gid) && ($current_path == "/community/" . $group)){
          $query = \Drupal::database()->select('groups', 'g');
          $query->fields('g', ['id']);
          $query->condition('g.id', $group,'=');
          $result = $query->execute()->fetchObject();       
          if(!empty($result)){
            $query = \Drupal::database()->select('group__field_default_display', 'gd');
            $query->fields('gd', ['field_default_display_value']);
            $query->condition('gd.entity_id', $group,'=');
            $dresult = $query->execute()->fetchObject();
            $gid = $group;
            $dis_default = !empty($dresult) ? $dresult->field_default_display_value : '';
          }
        }
    }
    // Community Default Display Redirect Code.
    if (strpos($dis_default, 'node') !== false || $routeMatch == "view.group_information.page_group_about") {
      if ($group instanceof Group) {
        /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
        $dd_value = $group->get('field_default_display')->value;
      }
      $dd_value = $dis_default;
      $current_path = \Drupal::request()->getRequestUri();
      $current_url = "/community/" . $gid;
      $current_grp_url ="/group/". $gid;
    if(($current_path == $current_url) || ($current_path == $current_grp_url)){  
      if (strpos($dd_value, 'node')) {
        $dest_url = "/community/" . $gid . "/home";
        // Redirect.
        $event->setResponse(new CacheableRedirectResponse($dest_url));
      }
      else {
        $dest_url = "/community/" . $gid;
        // Redirect.
        $event->setResponse(new CacheableRedirectResponse($dest_url));
      }
    }
  }

    // Assign reference manager / moderator role if leader role is assigned starts ############.
    if ($routeMatch == "view.group_manage_members.page_group_manage_members") {
      // All.
      $group_roles_target_id = \Drupal::request()->query->get('group_roles_target_id');
      // 1
      $group_status = \Drupal::request()->query->get('status');
      // Group Details Starts Here ###############.
      $group = _social_group_get_current_group();
      $gid = $group->id();
      $group_type = $group->getGroupType()->id();
      // Group Details Ends Here ###############.

    
      if ($group_status == 1 && $group_roles_target_id == "All" && $_SESSION['assign_role'] == 1) {
        if ($_SESSION['assign_community_type'] == 3) {
          if ($_SESSION['assign_user_role'] == $group_type . "-group_admin") {
            // Assign Reference Manager Role Here Also $_SESSION['assign_users'] ###############.
            foreach ($_SESSION['assign_users'] as $user) {
              $account = User::load($user);
              $membership = $group->getMember($account);
              $membership->getGroupRelationship()->set('group_roles', [0 => ['target_id' => $group_type . "-group_admin"], 1 => ['target_id' => $group_type . "-group_manager"]]);
              $membership->getGroupRelationship()->save();
            }
          }
        }
        else {
          if ($_SESSION['assign_user_role'] == $group_type . "-group_admin") {
            // Assign Moderator Role Here Also  $_SESSION['assign_users']###############.
            foreach ($_SESSION['assign_users'] as $user) {
              $account = User::load($user);
              $membership = $group->getMember($account);
              $membership->getGroupRelationship()->set('group_roles', [0 => ['target_id' => $group_type . "-group_admin"], 1 => ['target_id' => $group_type . "-moderator"]]);
              $membership->getGroupRelationship()->save();
            }
          }
        }
      }
      $_SESSION['assign_role'] = 0;
    }
    // Assign reference manager / moderator role if leader role is assigned ends ############.
    // After edit save user will be redirected to profile, if user editing from user profile.
    if ($routeMatch == "view.assets.assets_overview" || $routeMatch == "view.news.news_overview" || $routeMatch == "view.events.events_overview" || $routeMatch == "view.reference.reference_overview") {
      return;
    }

    $path = explode("/", $current_path);
    $pathSecond = $path[2] ?? NULL;
    $cPath = $path[1] . "/" . $pathSecond;
    $martchPath = "/user/" . $pathSecond;
    if (($current_path == $martchPath) && (!\Drupal::currentUser()->isAnonymous())) {
      // ?check_logged_in=1
      $explode_str = (strpos($pathSecond, "?") !== FALSE)?explode("?", $pathSecond): null;
      
      if($explode_str){
        $dest_url = "/user/" . $explode_str[0] . "/profile?". $explode_str[1]; 
        $event->setResponse(new CacheableRedirectResponse($dest_url));
      }

    }

   
  }

 public static function getSubscribedEvents() {
    $events[KernelEvents::REQUEST][] = ['customGroupLandingPage', 1000];
    return $events;
  }

}
