<?php

namespace Drupal\custom_community\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 *
 * Provides a custom group delete form.
 */

class GroupDeleteForm extends ConfirmFormBase {

  /**
   * The Group entity.
   *
   * @var \Drupal\group\Entity\Group
   */

  protected $group;

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL) {
    $this->group = $group;
    $form_state->set('group_id', $group->id());
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_confirm_community_delete_form';
  }

  /**
   * {@inheritdoc}
   */
  public function getQuestion() {
    return $this->t('Are you sure you want to perform this action on the group: %group?', [
      '%group' => $this->group->label(),
    ]);
  }

  /**
   * {@inheritdoc}
   */

public function getCancelUrl() {
 $group_id = $this->group->id();
 return Url::fromUri("internal:/community/{$group_id}/edit");
 }


  /**
   * {@inheritdoc}
   */
  public function getDescription() {
    return $this->t('This action cannot be undone.');
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText() {
    return $this->t('Confirm');
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelText() {
    return $this->t('Cancel');
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $group_id = $form_state->get('group_id');
    $group = Group::load($group_id);
    $group_label = $group->label();
    $queue = \Drupal::service('queue')->get('custom_community_delete_queue');
    $queue->createItem([
      'entity_id' => $group_id,
      'action' => 'remove_secondary_community',
      'type'  =>  'group'
    ]);
    $queue->createItem([
      'entity_id' => $group_id,
      'action' => 'group_delete',
      'type'  =>  'group'
    ]);
    exec('/var/www/html/web/vendor/bin/drush queue:run custom_community_delete_queue');
    exec('php /var/www/html/web/vendor/drush/drush/drush.php queue:run custom_community_delete_queue');
    $success_msg = "The " . ucfirst('community') . " " . $group_label . " has been deleted.";
    \Drupal::messenger()->addStatus($success_msg);
    (new RedirectResponse('/communities/all'))->send();
    exit();
  }
}
