<?php

namespace Drupal\custom_community\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\GroupRelationship;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\Core\Batch\BatchBuilder;

/**
 * Provides a form for deleting manipulate asset.
 *
 * @ingroup Custom Community Module
 */
class CustomCommunityDeleteForm extends FormBase {

public function getFormId() {
    // Here we set a unique form id
    return 'custom_community_delete_confirm';
    }
/**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $current_path = \Drupal::service('path.current')->getPath();
    $group_path = explode('/',$current_path);
    $grp_id = $group_path[2];
    $url = '/community/'.$grp_id;
    $form['title']['#markup'] = '<p><strong>' . t('Are you sure you want to delete this community?') . '</strong></p>';
    $form['description']['#markup'] = '<p style="color: red;">' . t('Note: The community and all the related knowledge objects, including the community description, community pages, news, events will be deleted and cannot be recovered. DAILY.connect conversations (if any) will not be deleted and will still be accessible through DAILY.connect.') . '</p>';
    $form['description']['#weight'] = -10;
    $form['title']['#weight'] = -12;
    $form['actions']['delete'] = array( '#type' => 'submit', '#value' => $this->t('Delete'), '#button_type' => 'primary', );
    $form['actions']['cancel'] = array(
        '#type' => 'button',
        '#value' => t('Cancel'),
        '#weight' => 20,
        '#attributes' => array('onClick' => 'window.location = "'.$url.'"; event.preventDefault();'),
        );
    return $form;    

  }

  /**
* {@inheritdoc}
*/
public function submitForm(array &$form, FormStateInterface $form_state) {
    $current_path = \Drupal::service('path.current')->getPath();
    $group_path = explode('/',$current_path);
    $grp_id = $group_path[2];
    $group = \Drupal\group\Entity\Group::load($grp_id);

    $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->fields('nfd', array('nid'));
      $query->innerJoin('group_relationship_field_data', 'gcfd', 'gcfd.`entity_id` = nfd.`nid`');
      $query->condition('gcfd.gid', $grp_id);
      $result = $query->execute()->fetchAll();
      $node_column =  array_column($result, 'nid');
      $node_chunks = array_chunk($node_column, 10);
      $operations = [];
      foreach($node_chunks as $nid){
        $operations[] = [get_called_class() . '::batchProcessNodeDelete', [$nid]];
      }
      
      $group_relation = $group->getRelationships();
      $group_rel_chunks = array_chunk($group_relation, 2);
      foreach ($group_rel_chunks as $relationship) {
        $operations[] = [get_called_class() . '::batchProcessGroupRelationshipDelete', [$relationship]]; 
      }
      $operations[] = [get_called_class() . '::batchProcessGroupDelete', [$group]]; 
    
    $batch = [
    'operations' => $operations,
    ];
      batch_set($batch);
  
    $request = \Drupal::request();
    $destination = $request->query->get('destination');
   if (!is_null($destination)) {
      $redirect_params['destination'] = $destination;
     $request->query->remove('destination');
    } 
    $form_state->setRedirectUrl(URL::fromUserInput('/'));

  }

  public static function batchProcessNodeDelete(array $nid)  {
    foreach($nid as $node_id){
      $node = \Drupal\node\Entity\Node::load($node_id);
      $node->delete();
    }
  }

  public static function batchProcessGroupRelationshipDelete(array $relationship) {
    foreach($relationship as $rel){
      $rel->delete();
    }
  }

  public static function batchProcessGroupDelete($group) {
   $group->delete();
  }
  

}





