(function ($, Drupal, drupalSettings) {
  // Js Notification settings Page
  emailNotificationSet = function () {
    $('.in-app-notif').each(function () {
      if ($(this).find('a').hasClass('action-flag')) {
        $(this).closest('tr').find('.mail-notif').addClass('disabled');
      }
    });
  }
  emailNotificationSet();
  $(document).on('click', '.notification-cb-click', function () {
    emailNotificationSet();
  });
  Drupal.behaviors.customJS = {
    attach: function (context, settings) {

    // if ($("div.autocomplete-deluxe-container  span").length > 0) {
      if ($("#autocomplete-deluxe-input").val()) {
        // disabled the checkbox if the parent community has no value
        $("input#edit-field-inherit-members-value").attr("disabled", false);
      } else {
        // disabled the checkbox if the parent community has no value
        $("input#edit-field-inherit-members-value").attr("disabled", true);
      }

        $("input[name^=field_og_group_ref]").on("autocompleteselect", function (event, ui) {

            // if ($("div.autocomplete-deluxe-container  span").length > 0) {
            if (ui.item.value) {
              // disabled the checkbox if the parent community has no value
              $("input#edit-field-inherit-members-value").attr("disabled", false);
            } else {
              // disabled the checkbox if the parent community has no value
              $("input#edit-field-inherit-members-value").attr("disabled", true);
            }

        });

      $("input[name='field_community_type']").on("click", function () {

        var reference_community = $(
          'input[name="field_community_type"]:checked'
        ).val();

        if (reference_community != 3) {
          $('#edit-default-route option[value="view.group_references.page_group_references"]').remove();
          $('#edit-default-route-an option[value="view.group_references.page_group_references"]').remove();
          $('#edit-default-route option[value="view.group_assets.page_group_assets"]').remove();
          $('#edit-default-route-an option[value="view.group_assets.page_group_assets"]').remove();

          $('#edit-default-route').append(` < option value = "view.group_assets.page_group_assets" > Asset < / option > `);
          $('#edit-default-route-an').append(` < option value = "view.group_assets.page_group_assets" > Asset < / option > `);
        } else {
          $('#edit-default-route option[value="view.group_assets.page_group_assets"]').remove();
          $('#edit-default-route-an option[value="view.group_assets.page_group_assets"]').remove();
          $('#edit-default-route').append(` < option value = "view.group_references.page_group_references" > Reference < / option > `);
          $('#edit-default-route-an').append(` < option value = "view.group_references.page_group_references" > Reference < / option > `);
        }
      });

      $("#edit-default-display-selection").change(function () {
        var selection_value = jQuery("#edit-default-display-selection").find(":selected").val();
        jQuery("#edit-field-default-display-0-value").val(selection_value);
      });
      $("input[name=field_community_type]").change(function () {
        var radiovalue = $(this).val();
        if (radiovalue == 1 || radiovalue == 2 || radiovalue == 0) {
          $('#edit-default-display-selection option[value="asset"]').remove();
          $('#edit-default-display-selection option[value="reference"]').remove();
          $('#edit-default-display-selection').append('<option value="asset">Assets</option>');
          $('#edit-default-display-selection').val('asset');
          $('#edit-field-default-display-0-value').val('asset');
        } else if (radiovalue == 3) {
          $('#edit-default-display-selection option[value="asset"]').remove();
          $('#edit-default-display-selection option[value="reference"]').remove();
          $('#edit-default-display-selection').append('<option value="reference">References</option>');
          $('#edit-default-display-selection').val('reference');
          $('#edit-field-default-display-0-value').val('reference');
        }
      });
      $('.join-community').on('contextmenu', function(e) {
        e.preventDefault(); // Prevent the default right-click menu
      });
    },
  };

jQuery(window).on("load", function () {
  var prevInput = jQuery("#autocomplete-deluxe-input").val();
  if (prevInput) {
    jQuery("input#edit-field-inherit-members-value").attr("disabled", false);
  } else {
    jQuery("input#edit-field-inherit-members-value").attr("disabled", true);
  }

  // When page loads handle the landing tab select dropdown
  var reference_community = jQuery(
    "input[name='field_community_type']:checked"
  ).val();

  jQuery('#edit-default-route option[value="view.albums.page_group_albums_overview"]').remove();
  jQuery('#edit-default-route option[value="view.group_members.page_group_members"]').remove();
  jQuery('#edit-default-route option[value="view.group_topics.page_group_topics"]').remove();
  jQuery('#edit-default-route option[value="view.group_information.page_group_about"]').remove();
  jQuery('#edit-default-route option[value="social_group.stream"]').remove();
  jQuery('#edit-default-route option[value="entity.group.version_history"]').remove();
  jQuery('#edit-default-route option[value="layout_builder_ui:layout_builder.overrides.group.view"]').remove();
  jQuery('#edit-default-route option[value="layout_builder.overrides.group.view"]').remove();
  jQuery('#edit-default-route-an option[value="layout_builder.overrides.group.view"]').remove();

  jQuery('#edit-default-route-an option[value="view.albums.page_group_albums_overview"]').remove();
  jQuery('#edit-default-route-an option[value="view.group_members.page_group_members"]').remove();
  jQuery('#edit-default-route-an option[value="view.group_topics.page_group_topics"]').remove();
  jQuery('#edit-default-route-an option[value="view.group_information.page_group_about"]').remove();
  jQuery('#edit-default-route-an option[value="social_group.stream"]').remove();
  jQuery('#edit-default-route-an option[value="entity.group.version_history"]').remove();
  jQuery('#edit-default-route-an option[value="layout_builder_ui:layout_builder.overrides.group.view"]').remove();

  if (reference_community != 3) {
    jQuery('#edit-default-route option[value="view.group_references.page_group_references"]').remove();
    jQuery('#edit-default-route-an option[value="view.group_references.page_group_references"]').remove();
    // jQuery('#edit-default-route').append(`<option value="view.group_assets.page_group_assets">Asset</option>`);
    // jQuery('#edit-default-route-an').append(`<option value="view.group_assets.page_group_assets">Asset</option>`);
  } else {
    jQuery('#edit-default-route option[value="view.group_assets.page_group_assets"]').remove();
    jQuery('#edit-default-route-an option[value="view.group_assets.page_group_assets"]').remove();
    // jQuery('#edit-default-route').append(`<option value="view.group_references.page_group_references">Reference</option>`);
    // jQuery('#edit-default-route-an').append(`<option value="view.group_references.page_group_references">Reference</option>`);
  }

  $('.notification-bell a').removeAttr('data-toggle');
  $('.notification-bell a').removeAttr('aria-expanded');
  $('.notification-bell a').removeAttr('aria-haspopup');
	//Disable inherit checkbox
	if ($('.page-edit-community .field--name-field-og-group-ref .autocomplete-deluxe-item-delete').length == 0) {
		$('.page-edit-community #edit-field-inherit-members-value').prop("disabled", true);
	}
	else{
		$('.page-edit-community #edit-field-inherit-members-value').prop("disabled", false);
	}
	$('.page-edit-community .field--name-field-og-group-ref input#autocomplete-deluxe-input').focusin(function() {
		if ($('.page-edit-community .field--name-field-og-group-ref .autocomplete-deluxe-item-delete').length == 0) {
			$('.page-edit-community #edit-field-inherit-members-value').prop("disabled", true);
			$('.page-edit-community #edit-field-inherit-members-value').prop("checked", false);
		}
		else {
			$('.page-edit-community #edit-field-inherit-members-value').prop("disabled", false);
		}
	});
});

})(jQuery, Drupal, drupalSettings);
