(function($, Drupal, drupalSettings) {
  Drupal.behaviors.yourbehavior = {
    attach: function (context, settings) {
//      alert('123');
       var redirecturl = drupalSettings.communitypage;
       var currenturl = jQuery(location).attr('href');
       if(jQuery(location).attr('href') == currenturl){ 
        jQuery(location).attr('href',redirecturl); 
      }
      // You can init map here.
    }
  };
})(jQuery, Drupal, drupalSettings);
