(function ($) {
    $("#block-socialinviteactionsblock a:contains('View invites')").remove();
    $("ul li a:contains('Invite users')").remove();
})(jQuery);
