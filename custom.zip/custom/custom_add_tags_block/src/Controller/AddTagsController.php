<?php

namespace Drupal\custom_add_tags_block\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Defines a route controller for watches autocomplete form elements.
 */
class AddTagsController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
          $container->get('entity_type.manager')
      );
  }

  /**
   * Handler for autocomplete request.
   */
  public function renderTags(Request $request) {

    $results = [];
    $values = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($values);
    }

    $input = Xss::filter($input);
    $query = \Drupal::database()->select('taxonomy_term_field_data', 'ttfd');
    $query->addField('ttfd', 'name', 'name');
    $query->addField('ttfd', 'tid', 'tid');
    $query->condition('ttfd.vid', 'tags');
    $query->condition('ttfd.name', '%' . $input . '%', 'LIKE');
    $query->groupBy('ttfd.name');
    $query->range(0, 10);
    $existingTags = $query->execute()->fetchAll();

    $termTagsName = [];

    foreach ($existingTags as $key => $term) {
      $termTagsName = [$term->name];
      $values[] = [
        'label' => implode(' ', $termTagsName),
      ];
    }
    return new JsonResponse($values);
  }

  /**
   * Function to remove user tags.
   */
  public function removeUserTags($term_id, $entity_id) {
    $response = new AjaxResponse();
    $deletedTerm = \Drupal::database()->delete('taxonomy_term__field_author')
      ->condition('entity_id ', $term_id)
      ->condition('field_author_target_id ', \Drupal::currentUser()->id())
      ->condition('node_id ', $entity_id)
      ->execute();

    $deletedTagTerm = \Drupal::database()->delete('node__field_tags')
      ->condition('field_tags_target_id ', $term_id)
      ->condition('entity_id ', $entity_id)
      ->execute();

    if ($deletedTerm && $deletedTagTerm) {
      \Drupal::service('cache.data')->invalidateAll();
      \Drupal::service('cache.entity')->invalidateAll();
    }

    // Render all the tags on ajax success.
    $user_id = \Drupal::currentUser()->id();
    $node = \Drupal::routeMatch()->getParameter('node');

    // If ($node && $node instanceof NodeInterface) {
    // You can get nid and anything else you need from the node object.
    $nid = $entity_id;
    $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
    $field_group = $node->get('field_community')->getValue();
    $group_id = $field_group[0]['target_id'];
    $term_objects = $node->get('field_tags')->referencedEntities();

    $queryAllTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
    $queryAllTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
    $queryAllTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
    $queryAllTags->condition('gcf.node_id', $nid);
    $queryAllTags->condition('gcf.deleted', 0);
    $queryAllTags->groupBy('gcf.entity_id');
    $queryAllTags->orderBy('tfd.name', 'asc');
    $resultAllTags = $queryAllTags->execute()->fetchAll();

    $queryMyTags = \Drupal::database()->select('taxonomy_term__field_author', 'gcf');
    $queryMyTags->leftJoin('taxonomy_term_field_data', 'tfd', 'tfd.tid = gcf.entity_id');
    $queryMyTags->fields('gcf', ['entity_id', 'node_id', 'field_author_target_id', 'deleted']);
    $queryMyTags->condition('gcf.field_author_target_id', \Drupal::currentUser()->id());
    $queryMyTags->condition('gcf.node_id', $nid);
    $queryMyTags->condition('gcf.deleted', 0);
    $queryMyTags->groupBy('gcf.entity_id');
    $queryMyTags->orderBy('tfd.name', 'asc');
    $resultMyTags = $queryMyTags->execute()->fetchAll();

    $testarray = [];

    foreach ($term_objects as $termobject) {
      $testarray[$termobject->id()] = $termobject->label();

    }

    $allTags = "";
    foreach ($resultAllTags as $value) {
      if (!empty($testarray[$value->entity_id])) {
        $allTags .= '<div id="alltag-' . $value->entity_id . '"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i><a href="/community-tag-clouds/' . $value->entity_id . '/' . $group_id . '" hreflang="en">' . $testarray[$value->entity_id] . '</a></div></div>';
      }
    }

    $myTags = "";
    foreach ($resultMyTags as $value) {
      if (!empty($testarray[$value->entity_id])) {
        $myTags .= '<div id="mytag-' . $value->entity_id . '" class="my-custom-tag"><div class="badge default d-flex align-items-center gap-2"><i class="material-symbols-outlined md-4">shoppingmode</i><a href="/community-tag-clouds/' . $value->entity_id . '/' . $group_id . '" hreflang="en">' . $testarray[$value->entity_id] . '</a><a id="remove-tag" class="use-ajax"  href="/removeusertags/' . $value->entity_id . '/' . $value->node_id . '">x</a></div></div>';
      }
    }

    if (empty($myTags)) {
      $myTags = '<p>No tags are available currently.</p>';
    }

    if (empty($allTags)) {
      $allTags = '<p>No tags are available currently.</p>';
    }

    $response->addCommand(
      new HtmlCommand(
        '.result_message',
          '<div class="row" style="display: block;">
            <div class="" style="margin-bottom: 1rem;">
              <div class="d-flex flex-column p-3 gap-3 list-group-item bg-surface-secondary">
          <div id="alltag" class="field--label control-label"><label class="h5 gray-accent-subtle-text">All Tags</label></div>
        <div class="d-flex flex-row flex-wrap gap-3 align-items-center">
        ' . $allTags . '
        </div></div></div>
        <div class="">
        <div class="d-flex flex-column p-3 gap-3 list-group-item bg-surface-secondary">
        <div  id="mytag" class="field--label control-label"><label class="h5 gray-accent-subtle-text">My Tags</label></div>
      <div class="d-flex flex-row flex-wrap gap-3 align-items-center">
         ' . $myTags . '
        </div></div></div></div></div></div>'
            ),
        );
    return $response;
  }

}
