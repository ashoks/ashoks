<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "asset_field_body_revision"
 * )
 */
class D7AssetFieldBodyRev extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'body_value',
      'body_summary',
      'body_format',
    ];

    return $this->select('field_revision_body', 'a')
      ->fields('a', $fields)
      ->condition('deleted', 0);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'body_value' => $this->t('body value'),
      'body_summary' => $this->t('body summary'),
      'body_format' => $this->t('body format'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {

    return ['revision_id' => ['type' => 'integer']];

  }

}
