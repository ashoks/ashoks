<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * Asset_field_sector source.
 *
 * @MigrateSource(
 *   id = "asset_field_sector"
 * )
 */
class D7AssetFieldSector extends FieldableEntity {

  /**
   * {@inheritdoc}
   */
  public function query() {
    // Add id column with unique key and Auto Increment in both old and new table, to map each row uniquely.
    $query = $this->select('field_data_field_sector', 'c')
      ->fields('c', [
        'id',
        'bundle',
        'deleted',
        'entity_id',
        'revision_id',
        'language',
        'delta',
        'field_sector_tid',
      ]);
    $query->innerJoin('taxonomy_term_data', 't', 't.tid = c.field_sector_tid');
    $query->addField('t', 'name');
    $query->condition('bundle', 'asset');

    return $query;
  }

  // /**
  //  * {@inheritdoc}
  //  */
  public function prepareRow(Row $row) {
    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');
    $tname = $row->getSourceProperty('name');
    $vid = 'groupsector';
    $parent_tid = 0;
    $depth = 1; // for sector
    $load_entities = null;
    $child_terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid, $parent_tid, $depth, $load_entities);
    $term_id = NULL;
    foreach($child_terms as $sector){
      if($tname == $sector->name && $sector->depth == 0){
        $term_id = $sector->tid;
      }
    }
    if(isset($term_id) && $term_id != NULL){
      $row->setSourceProperty('field_sector_tid', $term_id);
    }
    else{
        return false;
    }
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
      'id' => $this->t('Row ID'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'field_sector_tid' => $this->t('Field Sector Tid'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    // $ids['delta']['type'] = 'integer';
    return $ids;
  }

}
