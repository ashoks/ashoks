<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * asset_field_tags_user source.
 *
 * @MigrateSource(
 *   id = "asset_field_tags_user"
 * )
 */
class D7AssetFieldTagsUser extends FieldableEntity {

  /**
   * {@inheritdoc}
   */
  public function query() {
    // Add id column with unique key and Auto Increment in both old and new table, to map each row uniquely.
    $query = $this->select('community_tags', 'c')
      ->fields('c', [
        'id',
        'bundle',
        'tid',
        'nid',
        'uid',
        'date',
      ]);
    $query->condition('bundle', 'tags');

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // $language = $row->getSourceProperty('language');
    // if (empty($language)) {
    //   return FALSE;
    // }
    // $row->setSourceProperty('language', 'en');
    // $tname = $row->getSourceProperty('name');

    // $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
    //   ->loadByProperties(['name' => $tname, 'vid' => 'tags']);
    // if ($term != FALSE && !empty($tname)) {
    //   $term = reset($term);
    //   $term_id = $term->id();
    //   $row->setSourceProperty('field_tags_tid', $term_id);
    // }
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
      'id' => $this->t('Row ID'),
      'bundle' => $this->t('The bundle this is associated with'),
      'tid' => $this->t('Taxonomy ID'),
      'nid' => $this->t('Node ID'),
      'uid' => $this->t('Field User ID'),
      'date' => $this->t('Date'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    return $ids;
  }

}
