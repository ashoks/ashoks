<?php

namespace Drupal\custom_status_management\Form;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Render\Markup;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class CustomTaxonomyManagementForm.
 *
 * @package Drupal\custom_status_management\Form
 */
class CustomStatusManagementForm extends FormBase {


  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private temp store.
   *
   * @var \Drupal\Core\TempStore\PrivateTempStoreFactory
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The Database.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected Connection $database;

  /**
   * The Current Path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected CurrentPathStack $currentPath;

  /**
   * Object constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $private_temp_store
   *   The private temp store object.
   * @param \Drupal\Core\Database\Connection $database
   *   The private temp store object.
   * @param \Drupal\Core\Path\CurrentPathStack $current_path
   *   The current path object.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, PrivateTempStoreFactory $private_temp_store, Connection $database, CurrentPathStack $current_path) {
    $this->entityTypeManager = $entity_type_manager;
    $this->tempStore = $private_temp_store;
    $this->database = $database;
    $this->currentPath = $current_path;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('entity_type.manager'),
      $container->get('tempstore.private'),
      $container->get('database'),
      $container->get('path.current')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_status_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    if ($form_state->has('page') && $form_state->get('page') == 2) {
   //   return self::formPageTwo($form, $form_state);
    }
    // Get the current page URL.
    $current_url = \Drupal::request()->getSchemeAndHttpHost() . \Drupal::request()->getRequestUri();
    $show_submitter_data = TRUE;
  // Check if the HTTP_REFERER is set in the server variables.
    if (isset($_SERVER['HTTP_REFERER'])) {
      $referrer = $_SERVER['HTTP_REFERER'];
      // Compare the current URL with the referrer.
      if ($current_url === $referrer) {
        $show_submitter_data = TRUE;
      } else {
        $show_submitter_data = FALSE;
      }
    } else {
      $show_submitter_data = FALSE;
    }
    // if Referer is same as current url
    // show_submitter_data = true
    // If referer does not exist
    // show_submitter_data - false
    // if referer is not same as current url
    // show_submitter_data - false
    $form_state->set('page', 1);
    $current_path = $this->currentPath->getPath();
    $path_args = explode('/', $current_path);
    $statusSegent = ($path_args[4]) ? $path_args[4] : "live";
    $store = $this->tempStore->get('manage_content_status');
    $gid = $store->get('content_status_gid');
    if ($statusSegent == "live") {
      $segmentStatus = 0;
      $store->set('type', 'live');
    }
    elseif ($statusSegent == "gold") {
      $segmentStatus = 1;
      $store->set('type', 'gold');
    }
    elseif ($statusSegent == "archive") {
      $segmentStatus = 2;
      $store->set('type', 'archive');
    }

    // $form['title'] = [
    //   '#type' => 'label',
    //   '#title' => Markup::create("<h4 class='title'>Apply '" . ucfirst($statusSegent) . "' Status</h4>"),
    // ];

    // /* Custom Filter */
    // $form['submitter'] = [
    //   '#type' => 'textfield',
    //   '#title' => $this->t('Submitter'),
    //   '#weight' => '0',
    //   '#prefix' => '<div class="filter_wrap">',
    //   '#default_value' => ($show_submitter_data) ? $store->get('submitter') : '',
    // ];
    // $option = ['label' => 'Title', 'created' => 'Created on', 'changed' => 'Updated on'];
    // $updated_option = array_flip($option);
    // $form['sort_by'] = [
    //   '#type' => 'select',
    //   '#title' => t('Sorted by'),
    //   '#options' => ['label' => 'Title', 'created' => 'Created on', 'changed' => 'Updated on'],
    //   '#default_value' => (isset($updated_option[$store->get('sort_by')])) ? $updated_option[$store->get('sort_by')] : '' ,
    // ];
    // $option = ['ASC' => 'ASC', 'DESC' => 'DESC'];
    // $updated_option = array_flip($option);
    // $form['sort_order'] = [
    //   '#type' => 'select',
    //   '#title' => t('Order'),
    //   '#options' => ['ASC' => 'ASC', 'DESC' => 'DESC'],
    //   '#default_value' => (isset($updated_option[$store->get('sort_order')])) ? $updated_option[$store->get('sort_order')] : '' ,
    // ];

    // $form['submit'] = [
    //   '#type' => 'submit',
    //   '#value' => $this->t('Search'),
    //   '#button_type' => 'primary',
    //   '#submit' => ['::submitFilter'],
    //   '#suffix' => '</div>',
    // ];

    /* End of Custom Filter */
    $gid = $store->get('content_status_gid');
    $group = Group::load($gid);
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;

      // Find all the assets asociated with group.
      $limit = 20;
      $string = "group_node-asset";
      // Reference.
      if ($field_community_type == 3) {
        $status_field_name = 'field_status_rf';
        $string = $group_type . '-' . 'd55fd521a981751028e';
        $query = $this->database->select('group_relationship_field_data', 'gcf');
        $query->join('node__' . $status_field_name, 's', 'gcf.entity_id = s.entity_id');
        $query->join('node__field_author', 'fds', 'gcf.entity_id = fds.entity_id');
        $query->join('node_field_data', 'nfd', 'nfd.nid = fds.entity_id');
        $query->fields('nfd', ['title','created']);
        $query->fields('gcf', ['uid', 'gid', 'entity_id', 'type', 'label','changed']);
        $query->condition('gcf.gid', $gid);
        $query->condition('s.' . $status_field_name . '_value', $segmentStatus, '<>');
        $type = "%" . $query->escapeLike($string) . "%";
        $query->condition('gcf.type', $type, 'LIKE');
        $store = $this->tempStore->get('manage_content_status');
        if ($store) {
          $gid = $store->get('content_status_gid');
          if ($show_submitter_data) {
            $submitter_strg = $store->get('submitter');
            // Run a query to search by user id.
            $users = $this->getUsers($submitter_strg);
            
            if ($users) {
              $query->condition('fds.field_author_target_id', $users, 'IN');
            }
          }
          if ($store->get('sort_by')) {
            $option = ['label' => 'Title', 'created' => 'Created on', 'changed' => 'Updated on'];
            $updated_option = array_flip($option);
            //dd($updated_option[$store->get('sort_by')]);
            if (isset($updated_option[$store->get('sort_by')]) && $updated_option[$store->get('sort_by')] == 'label') {
              $query->orderBy('nfd.title', strtolower($store->get('sort_order')));
            }
            else if (isset($updated_option[$store->get('sort_by')])) {
              $query->orderBy('nfd.' . $updated_option[$store->get('sort_by')], strtolower($store->get('sort_order')));
            }
          }
        }
      }
      else {
        $status_field_name = 'field_status';
        $query = $this->database->select('group_relationship_field_data', 'gcf');
        $query->join('node__' . $status_field_name, 's', 'gcf.entity_id = s.entity_id');
        $query->join('node__field_author', 'fds', 'gcf.entity_id = fds.entity_id');
        $query->join('node_field_data', 'nfd', 'nfd.nid = fds.entity_id');
        $query->fields('nfd', ['title','created']);
        $query->fields('gcf', ['uid', 'gid', 'entity_id', 'type', 'label','changed']);
        $query->condition('gcf.gid', $gid);
        $query->condition('s.' . $status_field_name . '_value', $segmentStatus, '<>');
        $query->condition('gcf.type', "%" . $query->escapeLike($string) . "%", 'LIKE');

        $submitter_strg = $store->get('submitter');
        if ($show_submitter_data && $submitter_strg !== '') {          
          $users = $this->getUsers($submitter_strg);          
          if ($users) {
            $query->condition('fds.field_author_target_id', $users, 'IN');
          }
        }
        if ($store->get('sort_by')) {
          $option = ['label' => 'Title', 'created' => 'Created on', 'changed' => 'Updated on'];
          $updated_option = array_flip($option);
          //dd($updated_option[$store->get('sort_by')]);
          if (isset($updated_option[$store->get('sort_by')]) && $updated_option[$store->get('sort_by')] == 'label') {
            $query->orderBy('nfd.title', strtolower($store->get('sort_order')));
          }
          else if (isset($updated_option[$store->get('sort_by')])) {
            $query->orderBy('nfd.' . $updated_option[$store->get('sort_by')], strtolower($store->get('sort_order')));
          }
        }
      }

      // For the pagination
      // we need to extend pagerselectextender
      // limit in the query.
      $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(20);
      $result = $pager->execute()->fetchAll();
      $communityTax[] = "";
      $results = [];
      foreach ($result as $res) {
        // Asset id.
        $nid = $res->entity_id;
        // Find the dummy submitter value.
        $query_ds = $this->database->select('node__field_author', 'nfds');
        $query_ds->fields('nfds', ['entity_id', 'field_author_target_id']);
        $query_ds->join('node_field_data', 'nfd', 'nfd.nid = nfds.entity_id');
		    $query_ds->fields('nfd', ['created']);
        $query_ds->condition('nfds.entity_id', $nid);
        $query_ds->orderBy('nfd.created', 'DESC');
        $result_ds = $query_ds->execute()->fetchAll();
        foreach ($result_ds as $resd) {
          $author = explode("[", $resd->field_author_target_id);
        }
        $author_account = '';
        if (isset($author[0]) && is_numeric($author[0])) {
          $author_account = $this->entityTypeManager->getStorage('user')->load($author[0]);
        }

        $node = $this->entityTypeManager->getStorage('node')->load($nid);
        $results[$node->id()]['nid'] = $nid;
        $results[$node->id()]['title'] = $node->getTitle();
        $results[$node->id()]['type'] = $node->getType();
        $results[$node->id()]['submitter'] = $author_account->getDisplayName();
        $results[$node->id()]['created_on'] = date('Y-m-d h:i:s', $res->created);
        $results[$node->id()]['updated_on'] = date('Y-m-d h:i:s', $node->getChangedTime());
      }
    }

    if ($statusSegent == 'gold') {
      $statusSegent = 'Live Gold';
    }
    $header = [
      'name' => t('Name'),
      'type' => t('Type'),
      'submitter' => t('Submitter'),
      'created_on' => t('Created On'),
      'updated_on' => t('Updated On'),
    ];

    $options = [];

    foreach ($results as $data) {


      $link_object = Link::createFromRoute($data['title'], 'entity.node.canonical', ['node' => $data['nid']], $options);
  
      $options[$data['nid']] = [
        'name' => $link_object,
        'type' => ucfirst($data['type']),
        'submitter' => $data['submitter'],
        'created_on' => $data['created_on'],
        'updated_on' => $data['updated_on'],
      ];
    }

    $form['table'] = [
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => $options,
      '#empty' => $this->t('Your Community does not include any item to which you could apply the status you have selected.'),
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];
    if ($results) {
      if (count($results) > 0) {

        $form['actions']['next'] = [
          '#type' => 'submit',
          '#button_type' => 'primary',
          '#value' => $this->t('Submit'),
        // Custom submission handler for page 1.
          '#submit' => ['::submitPageOne'],
        ];

      }
    }
    $form['pager'] = ['#type' => 'pager'];
    return $form;
  }

  /**
   * Function for getUsers().
   */
  public function getUsers($submitter_strg) {
    $query = $this->database->select('users_field_data', 'ufd');
    //$user_query->fields('ufd', ['uid', 'name']);
    //$user_query->condition('ufd.name', '%' . $submitter_strg . '%', 'LIKE');
    $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
    $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
    $query->addField('f', 'field_name_first_value', 'firstname');
    $query->addField('l', 'field_name_last_value', 'lastname');
    $query->addField('ufd', 'uid', 'id');
    $query->addField('ufd', 'mail', 'email');
    $query->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q OR ufd.mail LIKE :q", [':q' => '%' . $submitter_strg . '%']);
    $user_result = $query->execute()->fetchAll();
    $users = [];
    foreach ($user_result as $user) {
      $users[] = $user->id;
    }
    return $users;
  }

  /**
   * Submit handler for next page.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function submitPageOne(array &$form, FormStateInterface $form_state) {
    $values = $form_state->cleanValues()->getValues();
    $count = 0;
    foreach ($values['table'] as $value) {
      if ($value != 0) {
        $count++;
      }
    }
    $form_state
      ->set('page_values', [
        'count' => $count,
      ])
      ->set('page', 2)
      ->setRebuild(TRUE);
  }

  /**
   * Form for confirmation.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The render array defining the elements of the form.
   */
  public function formPageTwo(array &$form, FormStateInterface $form_state) {
    $page_value = $form_state->getStorage();
    $values = $form_state->cleanValues()->getValues();
    $store = $this->tempStore->get('manage_content_status');
    $options = [];
    if ($page_value['page_values']['count'] > 1) {
      $form_title = '<h3>Apply ' . ucfirst($store->get('type')) . ' Status</h3><br> You have selected the following ' . $page_value['page_values']['count'] . ' items:';
    }
    elseif ($page_value['page_values']['count'] <= 1) {
      $form_title = '<h3>Apply ' . ucfirst($store->get('type')) . ' Status</h3><br> You have selected the following ' . $page_value['page_values']['count'] . ' item:';
    }
    $form['description'] = [
      '#type' => 'item',
      '#title' => $form_title,
    ];
    $header = [
      'name' => t('Content Title'),
    ];
    foreach ($values['table'] as $result) {
      $node = $this->entityTypeManager->getStorage('node')->load($result);
      if ($node) {
        $link_object = Link::createFromRoute($node->get('title')->value, 'entity.node.canonical', ['node' => $result], $options);
        $options[$result] = [
          'name' => $link_object,
          'type' => $node->getType(),
          'id' => $result,
        ];
      }
    }
    $form['#attributes']['class'][] = 'status-change-form';
    $form['table'] = [
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => $options,
    ];
    $form['back'] = [
      '#type' => 'submit',
      '#value' => $this->t('Cancel'),
      '#submit' => ['::pageTwoBack'],
      '#prefix' => '<div class="Status_form_action_buttons">',
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Submit'),
      '#suffix' => '</div>',
    ];
    return $form;
  }

  /**
   * Submit handler for back button.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function pageTwoBack(array &$form, FormStateInterface $form_state) {
    $form_state
      ->setValues($form_state->get('page_values'))
      ->set('page', 1)
      ->setRebuild(TRUE);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    \Drupal::logger('debug')->debug(print_r($form_state->getValues(), TRUE));

   // $form['table']['#needs_validation'] = FALSE;
   // dump($form_state->getValues());

    //$form['table']['#needs_validation'] = FALSE;
   // return;
  
    //submitter
    //dump($form);
    //$form['submitter']['#needs_validation'] = FALSE;
   // dump($form['submitter']);
   //  exit;
  //['#needs_validation'] = FALSE;
   // \Drupal::logger('debug')->debug(print_r($form_state->getValues(), TRUE));
  }



  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    \Drupal::messenger()->addMessage($this->t('Item ID @id has been updated to status: @status', ['@id' => $store->get('type'), '@status' => $store->get('type')]));
    //\Drupal::logger('debug')->debug(print_r($form_state->getValues(), TRUE));
    //exit;
    $content_id = $form_state->getValue('table');
    $store = $this->tempStore->get('manage_content_status');
    if ($store->get('type') == "live") {
      $segmentStatus = 0;
    }
    elseif ($store->get('type') == "gold") {
      $segmentStatus = 1;
    }
    elseif ($store->get('type') == "archive") {
      $segmentStatus = 2;
    }
    foreach ($content_id as $key => $nid) {
      $node = NULL;
      if (is_numeric($nid)) {
        $node = $this->entityTypeManager->getStorage('node')->load($nid);
      }
      $status_field_name = ($node->bundle() == 'reference') ? 'field_status_rf' : 'field_status';
      // Update the status of all the content type asset / reference.
      $query_1 = $this->database->update('node__' . $status_field_name)
        ->fields([$status_field_name . '_value' => $segmentStatus])
        ->condition('entity_id', $key)
        ->execute();

      // Update the status of all the content type asset / reference.
      $query_2 = $this->database->update('node_revision__' . $status_field_name)
        ->fields([$status_field_name . '_value' => $segmentStatus])
        ->condition('entity_id', $key)
        ->execute();
    }

    if ($query_1 && $query_2) {
      $status_changed = ucwords($store->get('type'));
      $this->messenger()->addMessage($this->t('Content status changed to @status_changed.', ['@status_changed' => $status_changed]));
      $form_state->setRedirect('custom_status_management.' . $store->get('type'), [
        'group' => $store->get('content_status_gid'),
      ]);
			\Drupal::entityTypeManager()->getStorage('node')->resetCache([$nid]);
    }
  }

  /**
   * Submit handler for Search.
   */
  public function submitFilter(array &$form, FormStateInterface $form_state) {
    
    unset($form['table']);
    $values = $form_state->cleanValues()->getValues();
    if (isset($values['submitter'])) {
      $store = $this->tempStore->get('manage_content_status');
      $store->set('submitter', $values['submitter']);
    }
    if (isset($values['sort_by'])) {
      $store = $this->tempStore->get('manage_content_status');
      if ($form_state->getValue('sort_by')) {
        $updated_option = ['label' => 'Title', 'created' => 'Created on', 'changed' => 'Updated on'];
        // $updated_option = array_flip($option);
        $store->set('sort_by', $updated_option[$form_state->getValue('sort_by')]);
      }
    }
    if (isset($values['sort_order'])) {
      $store = $this->tempStore->get('manage_content_status');
      if ($form_state->getValue('sort_order')) {
        $option = ['ASC' => 'ASC', 'DESC' => 'DESC'];
        $store->set('sort_order', $option[$form_state->getValue('sort_order')]);
      }
    }
    $store = $this->tempStore->get('manage_content_status');
    $store->set('form_submitted', true);
  }

}
