<?php

namespace Drupal\custom_status_management\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\custom_status_management\Controller
 */
class CustomStatusDisplayController extends ControllerBase {
  /**
   * The Private temp store.
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The Database.
   */
  protected Connection $database;

  /**
   * The Current Path.
   */
  protected CurrentPathStack $currentPath;

  /**
   * CustomDisplayStatusController constructor.
   */
  public function __construct(PrivateTempStoreFactory $private_temp_store, Connection $database) {
    $this->tempStore = $private_temp_store;
    $this->database = $database;

  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('tempstore.private'),
      $container->get('database')
    );
  }

  /**
   * Clear Cache via sql.
   */
  public function clearCacheViaSql() {
    $this->database->truncate('cache_bootstrap')->execute();
    $this->database->truncate('cache_config')->execute();
    $this->database->truncate('cache_container')->execute();
    $this->database->truncate('cache_data')->execute();
    $this->database->truncate('cache_default')->execute();
    $this->database->truncate('cache_discovery')->execute();
    $this->database->truncate('cache_dynamic_page_cache')->execute();
    $this->database->truncate('cache_entity')->execute();
    $this->database->truncate('cache_menu')->execute();
    $this->database->truncate('cache_render')->execute();
    $this->database->truncate('cachetags')->execute();
    $this->database->truncate('cache_toolbar')->execute();
    return TRUE;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function archive($group) {

    $this->clearCacheViaSql();
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $statusSegent = ($path_args[4]) ? $path_args[4] : "live";
    $store = $this->tempStore->get('manage_content_status');
    $store->set('content_status_gid', $group);
    $store->set('content_status_type', $statusSegent);
    $form['content_status_form'] = \Drupal::formBuilder()->getForm('Drupal\custom_status_management\Form\CustomStatusManagementForm');

    return $form;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function live($group) {
    $this->clearCacheViaSql();
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $statusSegent = ($path_args[4]) ? $path_args[4] : "live";
    $store = $this->tempStore->get('manage_content_status');
    $store->set('content_status_gid', $group);
    $store->set('content_status_type', $statusSegent);
    $form['content_status_form'] = \Drupal::formBuilder()->getForm('Drupal\custom_status_management\Form\CustomStatusManagementForm');

    return $form;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function gold($group) {
    $this->clearCacheViaSql();
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $statusSegent = ($path_args[4]) ? $path_args[4] : "live";
    $store = $this->tempStore->get('manage_content_status');
    $store->set('content_status_gid', $group);
    $store->set('content_status_type', $statusSegent);
    $form['content_status_form'] = \Drupal::formBuilder()->getForm('Drupal\custom_status_management\Form\CustomStatusManagementForm');

    return $form;
  }

}
