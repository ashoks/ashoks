Manipulate user custom_autocomplete_form_views_exposed_form_alter
==========
Custom autocomplete module is specifically created for autocomplete username filter object.

Author/Maintainers
======================
- Govind Singh - Capgemini It Team
