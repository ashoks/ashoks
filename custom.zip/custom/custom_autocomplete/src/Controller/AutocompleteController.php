<?php
namespace Drupal\custom_autocomplete\Controller;
use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
/**
 * Defines a route controller for entity autocomplete form elements.
 */
class AutocompleteController extends ControllerBase {
 
 /**
 * Handler for autocomplete request.
 */
 public function handleAutocomplete(Request $request) {
 
 $results = [];
 $input = $request->query->get('q');
 $group_id = $request->query->get('group_id');
 $inputLength = strlen($input);
 
 // Get the typed string from the URL, if it exists.
 if (!$input || ($inputLength < 3)) {
 return new JsonResponse($results);
 }
 
 $string = 'group_membership';
 $input = Xss::filter($input);
 // $query->addExpression("CONCAT(
 // f.field_name_first_value, ' ', l.field_name_last_value)", 'full_name');
 $query = \Drupal::database()->select('users_field_data', 'ufd');
 $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
 $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
 $query->addField('f', 'field_name_first_value', 'firstname');
 $query->addField('l', 'field_name_last_value', 'lastname');
 $query->addField('ufd', 'uid', 'id');
 $query->addField('ufd', 'name', 'uname');
 if ($group_id) {
 $query->join('group_relationship_field_data', 'gcf', 'ufd.uid = gcf.entity_id');
 $query->addField('gcf', 'uid', 'gid', 'entity_id');
 $query->condition('gcf.gid', $group_id);
 $query->condition('gcf.type', "%" . $query->escapeLike($string) . "%", 'LIKE');
 }
 $orGroup = $query->orConditionGroup()
 ->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q", [':q' => '%' . $input . '%'])
 ->condition('f.field_name_first_value','%'.$input.'%', 'LIKE')
 ->condition('l.field_name_last_value','%'.$input.'%', 'LIKE')
 ->condition('name', '%' . $input . '%', 'LIKE')
 ->condition('mail', '%' . $input . '%', 'LIKE');
 $query->condition($orGroup);
 $query->orderBy('lastname', 'ASC');
 $query->orderBy('firstname', 'ASC');
 $results = $query->execute()->fetchAll();
 $matches = [];
 
 foreach ($results as $result) {
 $label = [];
 $label[] = $result->firstname . " " . $result->lastname;
 $key = $result->firstname . "," . $result->lastname;
 $account = User::load($result->id);
 $email = $account->getEmail();
 $matches[] = [
 'value' => implode(', ', $label) . ' [' . $email . '] [' . $result->id . ']',
 'label' => implode(', ', $label) . ' [' . $email . '] [' . $result->id . ']',
 ];
 } 
 return new JsonResponse($matches);
 } 
}
