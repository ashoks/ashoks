Software License Agreement
==========================

Copyright (c) 2023. All rights reserved.

Licensed under the terms of [MIT license](https://opensource.org/licenses/MIT).
