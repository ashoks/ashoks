/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'az', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Məsləhətli başlıq',
	cssClassInputLabel: 'Üslub klassları',
	edit: 'DİV eıementini redaktə et',
	inlineStyleInputLabel: 'Sözlərin üslubları',
	langDirLTRLabel: 'Soldan sağa (LTR)',
	langDirLabel: 'Yaziların istiqaməti',
	langDirRTLLabel: 'Sağdan sola (RTL)',
	languageCodeInputLabel: 'Dilin kodu',
	remove: 'DİV elementini sil',
	styleSelectLabel: 'Üslub',
	title: 'DİV ilə əhatələməni yarat',
	toolbar: 'DİV ilə əhatələməni yarat'
} );
