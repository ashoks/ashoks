/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'ja', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Title属性',
	cssClassInputLabel: 'スタイルシートクラス',
	edit: 'Divコンテナを編集',
	inlineStyleInputLabel: 'インラインスタイル',
	langDirLTRLabel: '左から右 (LTR)',
	langDirLabel: '文字表記の方向',
	langDirRTLLabel: '右から左 (RTL)',
	languageCodeInputLabel: ' 言語コード',
	remove: 'Divコンテナを削除',
	styleSelectLabel: 'スタイル',
	title: 'Divコンテナを作成',
	toolbar: 'Divコンテナを作成'
} );
