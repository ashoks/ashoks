<?php

namespace Drupal\custom_group_recent_activity_block\Plugin\Block;

use Drupal\node\NodeInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\GroupInterface;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\content_moderation\Entity\ContentModerationState;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Provides a 'CustomGroupRecentActivityBlock' block.
 *
 * @Block(
 *  id = "custom_group_recent_activity_block",
 *  admin_label = @Translation("Custom Group Recent Activity Block"),
 * )
 */
class CustomGroupRecentActivityBlock extends BlockBase
{

  /**
 * Gets current Group entity from the route.
 *
 * @param \Drupal\node\NodeInterface|null $node
 *   (optional) The node object or NULL.
 *
 * @return \Drupal\group\Entity\GroupInterface|null
 *   Returns the group object.
 */


public function _social_group_get_current_group($node = NULL) {
  $cache = &drupal_static(__FUNCTION__, []);
  // For the same $node input, within the same request the return is always
  // the same.
  $group = NULL;
  $nid = $route_param = NULL;
  if (is_null($node)) {
    $nid = -1;
  }
  elseif ($node instanceof NodeInterface) {
    $nid = $node->id();
  }
 
  // If we have a cache key and it has a value, we're done early.
  if (!is_null($nid) && isset($cache[$nid]) && $cache[$nid] != FALSE) {
    // Translate FALSE (so isset works) back to NULL.
    return $cache[$nid] ?: NULL;
  }
 
  if (\Drupal::routeMatch() != NULL && !empty(\Drupal::routeMatch()->getParameter('group'))) {
    $route_param = \Drupal::routeMatch()->getParameter('group');
  }
  elseif (\Drupal::routeMatch() != NULL && !empty(\Drupal::routeMatch()->getParameter('gid'))) {
    $route_param = \Drupal::routeMatch()->getParameter('gid');
  }
  $group = $route_param;
 
  if (!is_object($group) && !is_null($group)) {
    $group = \Drupal::entityTypeManager()
      ->getStorage('group')
      ->load($group);
  }
  else {
    $node = is_object($node) ? $node : \Drupal::routeMatch()
      ->getParameter('node');
    if (is_object($node)) {
      $node_entity = [
        'target_type' => 'node',
        'target_id' => $node->id(),
      ];
 
      $node = isset($node_entity) && $node_entity['target_type'] == 'node' && $node_entity['target_id'] != NULL ? \Drupal::entityTypeManager()
      ->getStorage('node')
      ->load($node_entity['target_id']) : NULL;
       if ($node->hasField('field_community')) { 
        $gid_from_entity = $node_entity !== NULL && !empty($node) ? $node->get('field_community')->getValue()[0]['target_id'] : NULL;
        if ($node_entity !== NULL && !empty($node) && $gid_from_entity != NULL) {
          $group = \Drupal::entityTypeManager()
            ->getStorage('group')
            ->load($gid_from_entity);
        }
      }
 
 
    }
  }
 
  // If we have a cache key we store the value.
  if (!is_null($nid)) {
    // Translate NULL to FALSE so that isset works.
    $cache[$nid] = $group ?? FALSE;
  }
 
  return $group;
}

  /**
   * Implements \Drupal\block\BlockBase::blockBuild().
   *
   * {@inheritdoc}
   */
  public function build() {
    // Clear cache for the block.
    \Drupal::service('cache.render')->invalidateAll();
    
      $group = $this->_social_group_get_current_group();
    
      $total = 0;
     
      $gid = $field_community_type = '';

      if ($group instanceof GroupInterface) {
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
        $field_community_type = $group->get('field_community_type')->value;
      }

      if(empty($gid)){
        $route_name = \Drupal::routeMatch()->getRouteName();
        if($route_name == 'node.add'){
            $gid = \Drupal::request()->get('community_id');
        }

        if(empty($gid)){
          $gid = getCustomGroupId();
        }
        
        $group = ($gid)?\Drupal\group\Entity\Group::load($gid):null;
        if ($group instanceof GroupInterface) {
          $group_type = $group->getGroupType()->id();
          $gid = $group->id();
          $field_community_type = $group->get('field_community_type')->value;
        }
      }

      if($field_community_type == 3){
        $type_ko = "reference";
        $gnode_type = 'group_node:reference';
        $gnode_type_news = 'group_node:news';
        $gnode_type_event = 'group_node:event';
        $gnode_type_page = 'group_node:pages';
  
        $gnode_types = [
        $gnode_type,
        $gnode_type_news,
        $gnode_type_event,
        $gnode_type_page
        ];
      // Only data related to reference count will be fetched here
        $query_ref = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
        FROM (
        SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
        FROM {node_field_data} 
        UNION ALL 
        SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
        FROM {comment_field_data}
        ) c 
        WHERE entity_id IN (
        SELECT entity_id 
        FROM {group_relationship_field_data} 
        WHERE gid = :gid AND plugin_id IN (:gnode_types[])
        ) 
        GROUP BY id 
        ORDER BY changed DESC 
        LIMIT 100";
  
        $total_result = \Drupal::database()->query($query_ref, [
        ':gid' => $gid,
        ':gnode_types[]' => $gnode_types,
        ])->fetchAll();

      // Only data related to reference will be fetched here
        $query_ref = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
        FROM (
        SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
        FROM {node_field_data} 
        UNION ALL 
        SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
        FROM {comment_field_data}
        ) c 
        WHERE entity_id IN (
        SELECT entity_id 
        FROM {group_relationship_field_data} 
        WHERE gid = :gid AND plugin_id IN (:gnode_types[])
        ) 
        GROUP BY id 
        ORDER BY changed DESC 
        LIMIT 5";
  
        $result = \Drupal::database()->query($query_ref, [
        ':gid' => $gid,
        ':gnode_types[]' => $gnode_types,
        ])->fetchAll();
      } 
      else {      
        $type_ko = "asset";
        $gnode_type = 'group_node:asset';
        $gnode_type_news = 'group_node:news';
        $gnode_type_event = 'group_node:event';
        $gnode_type_page = 'group_node:pages';
  
        $gnode_types = [
        $gnode_type,
        $gnode_type_news,
        $gnode_type_event,
        $gnode_type_page
        ];
        // Only data related to asset count will be fetched here
        $query_asset = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
        FROM (
        SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
        FROM {node_field_data} 
        UNION ALL 
        SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
        FROM {comment_field_data}
        ) c 
        WHERE entity_id IN (
        SELECT entity_id 
        FROM {group_relationship_field_data} 
        WHERE gid = :gid AND plugin_id IN (:gnode_types[])
        ) 
        GROUP BY id 
        ORDER BY changed DESC 
        LIMIT 100";
  
      $total_result = \Drupal::database()->query($query_asset, [
      ':gid' => $gid,
      ':gnode_types[]' => $gnode_types,
      ])->fetchAll();     
      
      // Only data related to asset will be fetched here
      $query_asset = "SELECT id, ntype, entity_id, MAX(changed) AS changed 
        FROM (
        SELECT nid AS id, nid AS entity_id, type AS ntype, changed 
        FROM {node_field_data} 
        UNION ALL 
        SELECT cid AS id, entity_id AS entity_id, comment_type AS ntype, changed 
        FROM {comment_field_data}
        ) c 
        WHERE entity_id IN (
        SELECT entity_id 
        FROM {group_relationship_field_data} 
        WHERE gid = :gid AND plugin_id IN (:gnode_types[])
        ) 
        GROUP BY id 
        ORDER BY changed DESC 
        LIMIT 5";
  
      $result = \Drupal::database()->query($query_asset, [
      ':gid' => $gid,
      ':gnode_types[]' => $gnode_types,
      ])->fetchAll();      
      }

    $merged_array_data = [];
    foreach($result as $key => $value){
      $node_type = $value->ntype;
      $node_comment_id = $value->id;
      if($node_type == "asset" || $node_type == "reference" || $node_type == "news" || $node_type == "event" || $node_type == "pages")
      {

        $query = \Drupal::database()->select('node_field_data', 'nfd');
        $query->fields('nfd', array('nid', 'title', 'type', 'uid', 'changed'));
        $query->fields('gcfd', array('gid', 'label'));
        $query->innerJoin('group_relationship_field_data', 'gcfd', 'nfd.nid = gcfd.entity_id');
        $query->condition('nfd.nid', $node_comment_id);
        $query->condition('gcfd.gid', $gid);
        $merged_array_data[] = $query->execute()->fetchObject();

      }

      if($node_type == "comment")
      {

        $query_c = \Drupal::database()->select('comment_field_data', 'cfd');
        $query_c->fields('cfd', array('cid', 'comment_type', 'uid', 'entity_id', 'changed'));
        $query_c->fields('gcfd', array('gid', 'label'));
        $query_c->fields('nfd', array('nid', 'title', 'type', 'uid', 'changed'));
        $query_c->innerJoin('group_relationship_field_data', 'gcfd', 'cfd.entity_id = gcfd.entity_id');
        $query_c->innerJoin('node_field_data', 'nfd', 'cfd.entity_id = nfd.nid');
        $query_c->condition('cfd.cid', $node_comment_id);
        $query_c->condition('gcfd.gid', $gid);
        $merged_array_data[] = $query_c->execute()->fetchObject();
      }
    }

    // $merged_array_data = array_merge($result_node, $result_comment);

    $html_array_markup = [];    
    $uid = $user_email = $file_uri = $full_name = $group_label = $merged_array_rev_data_uid = $merged_array_comment_data_uid = '';
    // Lets catch the first 5 data
    $merged_array_data = array_filter($merged_array_data);
    foreach($merged_array_data as $key => $data){
      switch($data->type){
        case 'asset':
          $merged_array_data[$key]->type_ko = 'asset';
          break;
        case 'reference':
          $merged_array_data[$key]->type_ko = 'reference';
          break;
        case 'news':
          $merged_array_data[$key]->type_ko = 'news';
          break;
        case 'pages':
          $merged_array_data[$key]->type_ko = 'page';
          break;
        case 'event':
          $merged_array_data[$key]->type_ko = 'event';
          break;
      }

      if($data->nid){
        if(isset($data->cid) && !empty($data->cid)){
          $comment_query = \Drupal::database()->select('comment_field_data', 'cfd');
          $comment_query->fields('cfd', array('uid'));
          $comment_query->condition('cfd.cid', $data->cid);
          $merged_array_comment_data_uid = $comment_query->execute()->fetchObject();
        }
        else{
          $rev_query = \Drupal::database()->select('node_field_revision', 'nfr');
          $rev_query->fields('nfr', array('nid'));
          $rev_query->condition('nfr.nid', $data->nid);
          $merged_array_rev_data = $rev_query->countQuery()->execute()->fetchField();
          if($merged_array_rev_data != NULL){
            $merged_array_data[$key]->node_created_or_updated_status = $merged_array_rev_data;
            if($merged_array_rev_data > 1){
              $rev_query = \Drupal::database()->select('node_field_revision', 'nfr');
              $rev_query->fields('nfr', array('uid'));
              $rev_query->condition('nfr.nid', $data->nid);
              $rev_query->addExpression('MAX("changed")', 'changed');
              $merged_array_rev_data_uid = $rev_query->execute()->fetchObject();
            }
          }
        }
        if(is_object($merged_array_rev_data_uid)){
          $node_obj = \Drupal::entityTypeManager()->getStorage('node')->load($data->nid);
          $uid = ($node_obj->revision_uid->getValue()[0]['target_id']) ? $node_obj->revision_uid->getValue()[0]['target_id'] : '';
        }
        elseif(is_object($merged_array_comment_data_uid)) {
          $uid = $merged_array_comment_data_uid->uid;
        }
        else{
          $uid = $data->uid;
        }
      }

      if($uid) {
        $user = User::load($uid);
        $user_email = ($user instanceof \Drupal\user\UserInterface) ? $user->getEmail() : null;
        $merged_array_data[$key]->user_email = $user_email;

        $uid_picture_id_query = \Drupal::database()->select('user__user_picture', 'ufp');
        $uid_picture_id_query->fields('ufp', array('entity_id', 'user_picture_target_id'));
        $uid_picture_id_query->condition('ufp.entity_id', $uid, '=');
        $uid_picture_id_result = $uid_picture_id_query->execute()->fetchObject();

        // get the file path from user_picture_target_id
        if(isset($uid_picture_id_result->user_picture_target_id)){
          $query = \Drupal::database()->select('file_managed', 't')
          ->fields('t', ['fid', 'uri'])
          ->condition('t.fid', $uid_picture_id_result->user_picture_target_id);
          $result = $query->execute()->fetchObject();
          $file_uri = isset($result->uri) ? $result->uri : null;
          $merged_array_data[$key]->file_uri = $file_uri;
        }

        $user_name_query = \Drupal::database()->select('user__field_name_first', 'f');
        $user_name_query->innerJoin('user__field_name_last', 'l', 'l.entity_id = f.entity_id');
        $user_name_query->fields('f', ['field_name_first_value']);
        $user_name_query->fields('l', ['field_name_last_value']);
        $user_name_query->condition('f.entity_id', $uid);
        $result_uid = $user_name_query->execute()->fetchAll();
  
        if($result_uid != NULL && isset($result_uid[0])){
        $full_name = $result_uid[0]->field_name_first_value . ' ' .  $result_uid[0]->field_name_last_value;

        $merged_array_data[$key]->full_name = $full_name;
        }
        else{
          $merged_array_data[$key]->full_name = 'Anonymous';
        }
      }

      // Fetch group id and label
      $group = Group::load($gid);
      if ($group instanceof GroupInterface) {
        $group_label = $group->label();
      }
      $merged_array_data[$key]->group_label = $group_label;

      // Handle KO create / update case here
      if(isset($data->nid) && ($data->type == "asset" || $data->type == "news" || $data->type == "event" || $data->type == "pages" || $data->type == "reference" )){
        $node_id = $data->nid;
      }

      // Handle Comment create / update case here for all KOs
      if(isset($data->cid) && $data->comment_type == "comment" ){
        $node_id = $data->entity_id;

      }
      $node = Node::load($node_id);
      if ($node instanceof NodeInterface) {
        $node_label = $node->label();
      }
      $merged_array_data[$key]->node_id = $node_id;
      $merged_array_data[$key]->node_label = $node_label;
    }
    $total = count($total_result);

    return [
      '#theme' => 'custom_group_recent_activity_block',
      '#data' => !empty($gid)?$gid:null,
      '#merged_array_data' => $merged_array_data,
      '#total' => $total,
      '#cache' => [
        'max-age' => 0,
      ],
    ];     
  }

 /**
 * Prepares variables for group global id.
 */
public function getCustomGroupId(){
  $current_path = \Drupal::service('path.current')->getPath();
  $route_name = \Drupal::routeMatch()->getRouteName();
   
  $group = \Drupal::routeMatch()->getParameter('group');
  if ($group instanceof GroupInterface) {
    /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
    $group_type = $group->getGroupType()->id();
    $gid = $group->id();
    $field_community_type = $group->get('field_community_type')->value;
   
  }

   $group = \Drupal::routeMatch()->getParameter('gid');
   if ($group instanceof GroupInterface) {
     /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
     $group_type = $group->getGroupType()->id();
     $gid = $group->id();
     $field_community_type = $group->get('field_community_type')->value;
    
   }

  if($route_name == "custom_block.custom_yammer_display"){
    // $node = \Drupal::routeMatch()->getParameter('node');
    $current_path = \Drupal::service('path.current')->getPath();
    $gid = explode("/",$current_path)[2];
  }

   if(empty($gid)){
     $gid = \Drupal::request()->get('og_group_ref');
   }

   
   if(empty($gid)){
   $node = \Drupal::routeMatch()->getParameter('node');
   if ($node instanceof NodeInterface) {
     $group = $node->get('groups')->getValue();
     $gid = $group[0]['target_id'];
   }
  }

  if(empty($gid)){
    // $node = \Drupal::routeMatch()->getParameter('node');
    $current_path = \Drupal::service('path.current')->getPath();
    $nid = explode("/",$current_path)[2];
    $node = Node::load($nid);
    if ($node instanceof NodeInterface) {
      $group = $node->get('groups')->getValue();
      $gid = $group[0]['target_id'];
    }
   }
   if($gid == null){
    $current_uri = \Drupal::request()->getRequestUri();
    preg_match_all('!\d+!', $current_uri, $matches);
    $gid = $matches[0][0];
   }

  return $gid;
}

  protected function blockAccess(AccountInterface $account){
    $gid = '';
    $current_user = \Drupal::currentUser();
    $user_roles = $current_user->getRoles();
    $route_name = \Drupal::routeMatch()->getRouteName();
    if(in_array('administrator', $user_roles)){
      return AccessResult::allowed();
    }
    else{
      $gid = \Drupal::request()->get('community_id');
      if($gid){
        $group = isset($gid) && !empty($gid) ? Group::load($gid) : NULL;
      }
      elseif(empty($gid) && $route_name == 'view.publish_references.page_1') {
        $current_path = \Drupal::service('path.current')->getPath();
         $gid = explode("/",$current_path)[3];
         $group = isset($gid) && !empty($gid) ? Group::load($gid) : NULL;
      }   
      else {
        $group = $this->_social_group_get_current_group();
      }
      if ($group) {
        $membership = ($group) ? $group->getMember(\Drupal::currentUser()) : NULL;
        $group_type = ($group) ? $group->getGroupType()->id() : NULL;
        if($group_type == NULL){
          if($route_name == 'entity.node.canonical'){
            $current_path = \Drupal::service('path.current')->getPath();
            $current_uri = \Drupal::request()->getRequestUri();
            $group_display_path = explode("/",$current_uri);
            if($group_display_path[3] == 'home'){
              $gid = $group_display_path[2];
              $group = isset($gid) && !empty($gid) ? Group::load($gid) : NULL;
              $membership = ($group) ? $group->getMember(\Drupal::currentUser()) : NULL;
              $group_type = ($group) ? $group->getGroupType()->id() : NULL;
            }
          }
        }
      if($group_type != 'public_group'){
        if($membership){
          return AccessResult::allowed();
        }
        else{
          return AccessResult::forbidden();
        }
      }
      else{
        return AccessResult::allowed();
      }
    }
      else {
        return AccessResult::neutral();
      }
    }
  }

  public function getCacheMaxAge() {
    return 0;
  }
}
