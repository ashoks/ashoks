<?php

namespace Drupal\custom_table_form\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class CustomTaxonomyController.
 *
 * @package Drupal\custom_taxonomy_management\Controller
 */
class CustomStatusController extends ControllerBase {

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Manage Content Status'),
    ];
  }

}
