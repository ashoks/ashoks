<?php

namespace Drupal\custom_table_form\Form;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Render\Markup;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

class ExampleForm extends FormBase {

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The Private temp store.
   *
   * @var \Drupal\Core\TempStore\PrivateTempStoreFactory
   */
  protected PrivateTempStoreFactory $tempStore;

  /**
   * The Database.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected Connection $database;

  /**
   * The Current Path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected CurrentPathStack $currentPath;

  /**
   * Object constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager object.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $private_temp_store
   *   The private temp store object.
   * @param \Drupal\Core\Database\Connection $database
   *   The private temp store object.
   * @param \Drupal\Core\Path\CurrentPathStack $current_path
   *   The current path object.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, PrivateTempStoreFactory $private_temp_store, Connection $database, CurrentPathStack $current_path) {
    $this->entityTypeManager = $entity_type_manager;
    $this->tempStore = $private_temp_store;
    $this->database = $database;
    $this->currentPath = $current_path;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('entity_type.manager'),
      $container->get('tempstore.private'),
      $container->get('database'),
      $container->get('path.current')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_table_form_example_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $header = [
      'name' => t('Name'),
      'type' => t('Type'),
      'submitter' => t('Submitter'),
      'created_on' => t('Created On'),
      'updated_on' => t('Updated On'),
    ];

  
    $link_object = Link::createFromRoute('Schema SEMBA Phases & Streams', 'entity.node.canonical', ['node' => '166549'], $options);
    $options[166549] = [
      'name' => $link_object,
      'type' => 'asset',
      'submitter' => "",
      'created_on' => '2008-10-10 05:06:51',
      'updated_on' => '2008-10-10 05:06:51',
    ];

    $form['table'] = [
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => $options,
      '#empty' => $this->t('Your Community does not include any item to which you could apply the status you have selected.'),
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];
    
    return $form;

    // // Define a sample list of items for demonstration.
    // $items = [
    //   ['id' => 1, 'name' => 'Item 1'],
    //   ['id' => 2, 'name' => 'Item 2'],
    // ];

    // // Define the form table.
    // $form['items'] = [
    //   '#type' => 'table',
    //   '#header' => [
    //     $this->t('Item'),
    //     $this->t('Current Status'),
    //     $this->t('Update Status'),
    //   ],
    //   '#empty' => $this->t('No items found.'),
    // ];

    // // Add rows to the table.
    // foreach ($items as $item) {
    //   $form['items'][$item['id']]['item'] = [
    //     '#type' => 'markup',
    //     '#markup' => $item['name'],
    //   ];

    //   $form['items'][$item['id']]['current_status'] = [
    //     '#type' => 'markup',
    //     '#markup' => 'Active', // Example status, typically fetched from item data.
    //   ];

    //   $form['items'][$item['id']]['update_status'] = [
    //     '#type' => 'select',
    //     '#options' => [
    //       'active' => $this->t('Active'),
    //       'inactive' => $this->t('Inactive'),
    //     ],
    //     '#default_value' => 'active',
    //   ];
    // }

    // // Add a submit button to the form.
    // $form['submit'] = [
    //   '#type' => 'submit',
    //   '#value' => $this->t('Save'),
    // ];

    // return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Handle form submission.
    //$values = $form_state->getValue('items');
 //   foreach ($values as $item_id => $item_data) {
      $new_status = $item_data['update_status'];
      \Drupal::messenger()->addMessage($this->t('Item ID @id has been updated to status: @status', ['@id' => $item_id, '@status' => $new_status]));
   // }
  }
}
