<?php

namespace Drupal\custom_community\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\path_alias\Entity\PathAlias;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\Entity\Node;
use Drupal\path_alias\AliasRepositoryInterface;
use Drupal\pathauto\PathautoGeneratorInterface;
use Drupal\path_alias\AliasManagerInterface;
/**
 * Notifications controller.
 */
class CustomCommunityController extends ControllerBase {

  /**
   * Method to List Sub Segment.
   */
  public function customCommunityListSubsegmentSegment() {

    return "Test";
  }


  /**
   * Method to List Sub Segment.
   */
  public function handleChangedDatefromUpdatedOnTable() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeChangedDate = $db->select('field_data_field_user_node_update_date', 'c')
      ->fields('c', ['entity_id', 'revision_id', 'field_user_node_update_date_value'])
      ->condition('entity_type', 'node')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeChangedDate as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->entity_id;
      $node_vid = $dt->revision_id;
      $field_user_node_update_date_value = $dt->field_user_node_update_date_value;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'changed' => $field_user_node_update_date_value,
      ]);
      $query->condition('nid', $node_id);
      $query->condition('vid', $node_vid);
      $query->execute();
      
      $i++;

      dump("Script updating changed date " . $i . " for Node ID " . $node_id);
    }
  }

  // Custom Script for correcting the sector / industry / industry segment Starts

  /**
   * Method to handle Sector On Table.
   */
  public function handleSectorOnTable() {
      // Load the taxonomy tree using values.
      $tree = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree(
      'groupsector', // The taxonomy term vocabulary machine name.
      0,                 // The "tid" of parent using "0" to get all.
      1,                 // Get only 1st level.
      TRUE               // Get full load of taxonomy term entity.
      );

      $results = [];

      foreach ($tree as $term) {
      $results[] = $term->id();

      // Fetch all the data from sector table of 3rd level
        // Switch to external database.
        Database::setActiveConnection('migrate');
        $db = Database::getConnection();

        $nodeRevData = $db->select('field_data_field_sector', 'v')
        ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
        ->condition('field_sector_tid', $term->id())
        ->execute()->fetchAll();

        foreach ($nodeRevData as $vdt) {

          // Switch back to default database.
          Database::setActiveConnection();
    
          $bundle = $vdt->bundle;
          $deleted = $vdt->deleted;
          $entity_id = $vdt->entity_id;
          $revision_id = $vdt->revision_id;
          $language = $vdt->language;
          $delta = $vdt->delta;
          $field_sector_tid = $vdt->field_sector_tid;
          // Count if does not exist then only insert
          $query_node_custom = \Drupal::database()->select('node__field_sector', 'n')
          ->condition('entity_id', $entity_id)
          ->condition('revision_id', $revision_id)
          ->condition('field_sector_target_id', $field_sector_tid)
          ->countQuery();
          $node_exist = $query_node_custom->execute()->fetchField();
          if($node_exist == 0){
          $queryv = \Drupal::database()->insert('node__field_sector')
          ->fields([
            'bundle' => $bundle,
            'deleted' => $deleted,
            'entity_id' => $entity_id,
            'revision_id' => $revision_id,
            'langcode' => $language,
            'delta' => $delta,
            'field_sector_target_id' => $field_sector_tid,
          ])->execute();
          dump($queryv);
          }

        }
        
      }

      return [];
  }

  /**
   * Method to handle Sector Rev On Table.
   */
  public function handleSectorRevOnTable() {
    // Load the taxonomy tree using values.
    $tree = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree(
    'groupsector', // The taxonomy term vocabulary machine name.
    0,                 // The "tid" of parent using "0" to get all.
    1,                 // Get only 1st level.
    TRUE               // Get full load of taxonomy term entity.
    );

    $results = [];

    foreach ($tree as $term) {
    $results[] = $term->id();

    // Fetch all the data from sector table of 3rd level
      // Switch to external database.
      Database::setActiveConnection('migrate');
      $db = Database::getConnection();

      $nodeRevData = $db->select('field_revision_field_sector', 'v')
      ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
      ->condition('field_sector_tid', $term->id())
      ->execute()->fetchAll();

      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();
  
        $bundle = $vdt->bundle;
        $deleted = $vdt->deleted;
        $entity_id = $vdt->entity_id;
        $revision_id = $vdt->revision_id;
        $language = $vdt->language;
        $delta = $vdt->delta;
        $field_sector_tid = $vdt->field_sector_tid;
         // Count if does not exist then only insert
         $query_node_custom = \Drupal::database()->select('node_revision__field_sector', 'n')
         ->condition('entity_id', $entity_id)
         ->condition('revision_id', $revision_id)
         ->condition('field_sector_target_id', $field_sector_tid)
         ->countQuery();
         $node_exist = $query_node_custom->execute()->fetchField();
         if($node_exist == 0){
        $queryv = \Drupal::database()->insert('node_revision__field_sector')
        ->fields([
          'bundle' => $bundle,
          'deleted' => $deleted,
          'entity_id' => $entity_id,
          'revision_id' => $revision_id,
          'langcode' => $language,
          'delta' => $delta,
          'field_sector_target_id' => $field_sector_tid,
        ])->execute();
        dump($queryv);
         }

      }
      
    }

    return [];
}


  /**
   * Method to handle Segment On Table.
   */
  public function handleSegmentOnTable() {
  // All last taxonomy id for saving in segment table
  $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
  $tree = $manager->loadTree(
  'groupsector', // The taxonomy term vocabulary machine name.
  0,                 // The "tid" of parent using "0" to get all.
  2,                 // Get terms from 1st and 2nd levels.
  TRUE               // Get full load of taxonomy term entity.
  );

  $results = [];

  foreach ($tree as $term) {
  if (!empty($manager->loadParents($term->id()))) {
  $results[] = $term->id();
  // Fetch all the data from sector table of 3rd level
        // Switch to external database.
        Database::setActiveConnection('migrate');
        $db = Database::getConnection();

        $nodeRevData = $db->select('field_data_field_sector', 'v')
        ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
        ->condition('field_sector_tid', $term->id())
        ->execute()->fetchAll();

        foreach ($nodeRevData as $vdt) {

          // Switch back to default database.
          Database::setActiveConnection();
    
          $bundle = $vdt->bundle;
          $deleted = $vdt->deleted;
          $entity_id = $vdt->entity_id;
          $revision_id = $vdt->revision_id;
          $language = $vdt->language;
          $delta = $vdt->delta;
          $field_sector_tid = $vdt->field_sector_tid;
          // Count if does not exist then only insert
          $query_node_custom = \Drupal::database()->select('node__field_segment', 'n')
          ->condition('entity_id', $entity_id)
          ->condition('revision_id', $revision_id)
          ->condition('field_segment_target_id', $field_sector_tid)
          ->countQuery();
          $node_exist = $query_node_custom->execute()->fetchField();
          if($node_exist == 0){
          $queryv = \Drupal::database()->insert('node__field_segment')
          ->fields([
            'bundle' => $bundle,
            'deleted' => $deleted,
            'entity_id' => $entity_id,
            'revision_id' => $revision_id,
            'langcode' => $language,
            'delta' => $delta,
            'field_segment_target_id' => $field_sector_tid,
          ])->execute();
          dump($queryv);
          }

        }
  }
  }

  return [];
}

  /**
   * Method to handle Segment Rev On Table.
   */
  public function handleSegmentRevOnTable() {
    // All last taxonomy id for saving in segment table
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $tree = $manager->loadTree(
    'groupsector', // The taxonomy term vocabulary machine name.
    0,                 // The "tid" of parent using "0" to get all.
    2,                 // Get terms from 1st and 2nd levels.
    TRUE               // Get full load of taxonomy term entity.
    );
  
    $results = [];
  
    foreach ($tree as $term) {
    if (!empty($manager->loadParents($term->id()))) {
    $results[] = $term->id();
    // Fetch all the data from sector table of 3rd level
          // Switch to external database.
          Database::setActiveConnection('migrate');
          $db = Database::getConnection();
  
          $nodeRevData = $db->select('field_revision_field_sector', 'v')
          ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
          ->condition('field_sector_tid', $term->id())
          ->execute()->fetchAll();
  
          foreach ($nodeRevData as $vdt) {
  
            // Switch back to default database.
            Database::setActiveConnection();
      
            $bundle = $vdt->bundle;
            $deleted = $vdt->deleted;
            $entity_id = $vdt->entity_id;
            $revision_id = $vdt->revision_id;
            $language = $vdt->language;
            $delta = $vdt->delta;
            $field_sector_tid = $vdt->field_sector_tid;
             // Count if does not exist then only insert
             $query_node_custom = \Drupal::database()->select('node_revision__field_segment', 'n')
             ->condition('entity_id', $entity_id)
             ->condition('revision_id', $revision_id)
             ->condition('field_segment_target_id', $field_sector_tid)
             ->countQuery();
             $node_exist = $query_node_custom->execute()->fetchField();
             if($node_exist == 0){
  
            $queryv = \Drupal::database()->insert('node_revision__field_segment')
            ->fields([
              'bundle' => $bundle,
              'deleted' => $deleted,
              'entity_id' => $entity_id,
              'revision_id' => $revision_id,
              'langcode' => $language,
              'delta' => $delta,
              'field_segment_target_id' => $field_sector_tid,
            ])->execute();
            dump($queryv);
             }
  
          }
    }
    }
  
    return [];
  }
  
  
   /**
   * Method to handle Segment On Table.
   */
  public function handleOfferOnTable() {
    // All last taxonomy id for saving in segment table
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $tree = $manager->loadTree(
    'entry_portfolio', // The taxonomy term vocabulary machine name.
    0,                 // The "tid" of parent using "0" to get all.
    2,                 // Get terms from 1st and 2nd levels.
    TRUE               // Get full load of taxonomy term entity.
    );
  
    $results = [];
  
    foreach ($tree as $term) {
    if (!empty($manager->loadParents($term->id()))) {
    $results[] = $term->id();
    // Fetch all the data from sector table of 3rd level
    // Switch to external database.
    Database::setActiveConnection('migrate');
    $db = Database::getConnection();

    $nodeRevData = $db->select('field_data_field_entry_portfolio', 'v')
    ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_entry_portfolio_tid'])
    ->condition('field_entry_portfolio_tid', $term->id())
    ->execute()->fetchAll();

    foreach ($nodeRevData as $vdt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $bundle = $vdt->bundle;
      $deleted = $vdt->deleted;
      $entity_id = $vdt->entity_id;
      $revision_id = $vdt->revision_id;
      $language = $vdt->language;
      $delta = $vdt->delta;
      $field_offer_tid_value = $vdt->field_entry_portfolio_tid;
      // Count if does not exist then only insert
      $query_node_custom = \Drupal::database()->select('node__field_offer', 'n')
      ->condition('entity_id', $entity_id)
      ->condition('revision_id', $revision_id)
      ->condition('field_offer_target_id', $field_offer_tid_value)
      ->countQuery();
      $node_exist = $query_node_custom->execute()->fetchField();
      if($node_exist == 0){
      $queryv = \Drupal::database()->insert('node__field_offer')
      ->fields([
        'bundle' => $bundle,
        'deleted' => $deleted,
        'entity_id' => $entity_id,
        'revision_id' => $revision_id,
        'langcode' => $language,
        'delta' => $delta,
        'field_offer_target_id' => $field_offer_tid_value,
      ])->execute();
      dump($queryv);
      }

    }
}
}

return [];
}

/**
 * Method to handle Segment Rev On Table.
 */
public function handleOfferRevOnTable() {
  // All last taxonomy id for saving in segment table
  $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
  $tree = $manager->loadTree(
  'entry_portfolio', // The taxonomy term vocabulary machine name.
  0,                 // The "tid" of parent using "0" to get all.
  2,                 // Get terms from 1st and 2nd levels.
  TRUE               // Get full load of taxonomy term entity.
  );

  $results = [];

  foreach ($tree as $term) {
  if (!empty($manager->loadParents($term->id()))) {
  $results[] = $term->id();
  // Fetch all the data from sector table of 3rd level
        // Switch to external database.
        Database::setActiveConnection('migrate');
        $db = Database::getConnection();

        $nodeRevData = $db->select('field_revision_field_entry_portfolio', 'v')
        ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_entry_portfolio_tid'])
        ->condition('field_entry_portfolio_tid', $term->id())
        ->execute()->fetchAll();

        foreach ($nodeRevData as $vdt) {

          // Switch back to default database.
          Database::setActiveConnection();
    
          $bundle = $vdt->bundle;
          $deleted = $vdt->deleted;
          $entity_id = $vdt->entity_id;
          $revision_id = $vdt->revision_id;
          $language = $vdt->language;
          $delta = $vdt->delta;
          $field_offer_tid_value = $vdt->field_entry_portfolio_tid;
            // Count if does not exist then only insert
            $query_node_custom = \Drupal::database()->select('node_revision__field_offer', 'n')
            ->condition('entity_id', $entity_id)
            ->condition('revision_id', $revision_id)
            ->condition('field_offer_target_id', $field_offer_tid_value)
            ->countQuery();
            $node_exist = $query_node_custom->execute()->fetchField();
            if($node_exist == 0){

          $queryv = \Drupal::database()->insert('node_revision__field_offer')
          ->fields([
            'bundle' => $bundle,
            'deleted' => $deleted,
            'entity_id' => $entity_id,
            'revision_id' => $revision_id,
            'langcode' => $language,
            'delta' => $delta,
            'field_offer_target_id' => $field_offer_tid_value,
          ])->execute();
          dump($queryv);
            }

        }
  }
  }

  return [];
} 
 /**
   * Method to handle Sub Segment On Table.
   */
  public function handleSubSegmentOnTable() {
  // All last taxonomy id for saving in subsegment table
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $tree = $manager->loadTree(
    'groupsector',
    0,
    NULL,
    TRUE 
    );
    $results = [];
    foreach ($tree as $term) {
      if (empty($manager->loadChildren($term->id()))) {
        $results[] = $term->id();
        // Fetch all the data from sector table of 3rd level
        // Switch to external database.
        Database::setActiveConnection('migrate');
        $db = Database::getConnection();

        $nodeRevData = $db->select('field_data_field_sector', 'v')
        ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
        ->condition('field_sector_tid', $term->id())
        ->execute()->fetchAll();

        foreach ($nodeRevData as $vdt) {

          // Switch back to default database.
          Database::setActiveConnection();
    
          $bundle = $vdt->bundle;
          $deleted = $vdt->deleted;
          $entity_id = $vdt->entity_id;
          $revision_id = $vdt->revision_id;
          $language = $vdt->language;
          $delta = $vdt->delta;
          $field_sector_tid = $vdt->field_sector_tid;

           // Count if does not exist then only insert
           $query_node_custom = \Drupal::database()->select('node__field_subsegment', 'n')
           ->condition('entity_id', $entity_id)
           ->condition('revision_id', $revision_id)
           ->condition('field_subsegment_target_id', $field_sector_tid)
           ->countQuery();
           $node_exist = $query_node_custom->execute()->fetchField();
           if($node_exist == 0){

          $queryv = \Drupal::database()->insert('node__field_subsegment')
          ->fields([
            'bundle' => $bundle,
            'deleted' => $deleted,
            'entity_id' => $entity_id,
            'revision_id' => $revision_id,
            'langcode' => $language,
            'delta' => $delta,
            'field_subsegment_target_id' => $field_sector_tid,
          ])->execute();

          dump($queryv);
           }

        }

      }
    }
    return [];
  }

 /**
   * Method to handle SubSegment Rev On Table.
   */
  public function handleSubSegmentRevOnTable() {
    // All last taxonomy id for saving in subsegment table
      $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
      $tree = $manager->loadTree(
      'groupsector',
      0,
      NULL,
      TRUE 
      );
      $results = [];
      foreach ($tree as $term) {
        if (empty($manager->loadChildren($term->id()))) {
          $results[] = $term->id();
          // Fetch all the data from sector table of 3rd level
          // Switch to external database.
          Database::setActiveConnection('migrate');
          $db = Database::getConnection();
  
          $nodeRevData = $db->select('field_revision_field_sector', 'v')
          ->fields('v', ['bundle', 'deleted', 'entity_id', 'revision_id', 'language', 'delta', 'field_sector_tid'])
          ->condition('field_sector_tid', $term->id())
          ->execute()->fetchAll();
  
          foreach ($nodeRevData as $vdt) {
  
            // Switch back to default database.
            Database::setActiveConnection();
      
            $bundle = $vdt->bundle;
            $deleted = $vdt->deleted;
            $entity_id = $vdt->entity_id;
            $revision_id = $vdt->revision_id;
            $language = $vdt->language;
            $delta = $vdt->delta;
            $field_sector_tid = $vdt->field_sector_tid;

            // Count if does not exist then only insert
            $query_node_custom = \Drupal::database()->select('node_revision__field_subsegment', 'n')
            ->condition('entity_id', $entity_id)
            ->condition('revision_id', $revision_id)
            ->condition('field_subsegment_target_id', $field_sector_tid)
            ->countQuery();
            $node_exist = $query_node_custom->execute()->fetchField();
            if($node_exist == 0){
            $queryv = \Drupal::database()->insert('node_revision__field_subsegment')
            ->fields([
              'bundle' => $bundle,
              'deleted' => $deleted,
              'entity_id' => $entity_id,
              'revision_id' => $revision_id,
              'langcode' => $language,
              'delta' => $delta,
              'field_subsegment_target_id' => $field_sector_tid,
            ])->execute();

            dump($queryv);
            }
  
          }
  
        }
      }


      return [];
    
    }

    // Custom Script for correcting the sector / industry / industry segment Ends

  /**
   * Method to handle Community Folder Taxonomy Term changed date.
   */
  public function handleCommunityFolderCreationDate() {
    $results = [];
    // Switch to external database.
    Database::setActiveConnection('migrate');
    $db = Database::getConnection();

    $comm_folder_create_date = $db->select('field_data_field_term_creation_date', 'v')
    ->fields('v', ['bundle', 'entity_id', 'revision_id', 'field_term_creation_date_value'])
    ->condition('bundle', 'community_folders')
    ->execute()->fetchAll();

    foreach ($comm_folder_create_date as $vdt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $bundle = $vdt->bundle;
      $entity_id = $vdt->entity_id;
      $revision_id = $vdt->revision_id;
      $field_term_creation_date_value = $vdt->field_term_creation_date_value;

      // Count if exists then only update
      $query_node_custom = \Drupal::database()->select('taxonomy_term_field_data', 'n')
      ->condition('tid', $entity_id)
      ->condition('revision_id', $revision_id)
      ->countQuery();
      $term_exist = $query_node_custom->execute()->fetchField();
      if($term_exist > 0){
      $queryv = \Drupal::database()->update('taxonomy_term_field_data')
      ->fields([
        'changed' => $field_term_creation_date_value,
      ])->condition('tid', $entity_id)->execute();

      dump($queryv);
      }
    }
    return [];  
  }  

  /**
   * Method to handle Community Folder Taxonomy Term changed date - Revision.
   */
  public function handleCommunityFolderCreationDateRevision() {
    $results = [];
    // Switch to external database.
    Database::setActiveConnection('migrate');
    $db = Database::getConnection();

    $comm_folder_create_date = $db->select('field_data_field_term_creation_date', 'v')
    ->fields('v', ['bundle', 'entity_id', 'revision_id', 'field_term_creation_date_value'])
    ->condition('bundle', 'community_folders')
    ->execute()->fetchAll();

    foreach ($comm_folder_create_date as $vdt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $bundle = $vdt->bundle;
      $entity_id = $vdt->entity_id;
      $revision_id = $vdt->revision_id;
      $field_term_creation_date_value = $vdt->field_term_creation_date_value;

      // Count if exists then only update
      $query_node_custom = \Drupal::database()->select('taxonomy_term_field_revision', 'n')
      ->condition('tid', $entity_id)
      ->condition('revision_id', $revision_id)
      ->countQuery();
      $term_exist = $query_node_custom->execute()->fetchField();
      if($term_exist > 0){
      $queryv = \Drupal::database()->update('taxonomy_term_field_revision')
      ->fields([
        'changed' => $field_term_creation_date_value,
      ])->condition('tid', $entity_id)->execute();

      dump($queryv);
      }
    }
    return [];  
  }  

  /**
   * Method to List Sub Segment.
   */
  public function handleChangedDateRevfromUpdatedOnTable() {
    // Switch to external database.
    Database::setActiveConnection('migrate');
    $db = Database::getConnection();

    $nodeRevData = $db->select('field_revision_field_user_node_update_date', 'v')
      ->fields('v', ['entity_id', 'revision_id', 'field_user_node_update_date_value'])
      ->condition('entity_type', 'node')
      ->execute()->fetchAll();

    $j = 0;
    foreach ($nodeRevData as $vdt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $nodev_id = $vdt->entity_id;
      $nodev_vid = $vdt->revision_id;
      $field_user_node_update_date_value = $vdt->field_user_node_update_date_value;

      // Update node_field_revision status.
      $queryv = \Drupal::database()->update('node_field_revision');
      $queryv->fields([
        'changed' => $field_user_node_update_date_value,
      ]);
      $queryv->condition('nid', $nodev_id);
      $queryv->condition('vid', $nodev_vid);
      $queryv->execute();

      $queryv1 = \Drupal::database()->update('node_revision');
      $queryv1->fields([
        'revision_timestamp' => $field_user_node_update_date_value,
      ]);
      $queryv1->condition('nid', $nodev_id);
      $queryv1->condition('vid', $nodev_vid);
      $queryv1->execute();

      $j++;

      dump("Script updating changed date revision " . $j . " for Node ID " . $nodev_id);

    }

    

  }



  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateKoStatusAsset() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeData = $db->select('node', 'c')
      ->fields('c', ['nid', 'vid', 'status'])
      ->condition('type', 'asset')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeData as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->nid;
      $node_vid = $dt->vid;
      $node_status = $dt->status;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'status' => $node_status,
      ]);
      $query->condition('nid', $node_id);
      $query->execute();

      // Switch to external database.
      Database::setActiveConnection('migrate');

      // Get the connection.
      $db = Database::getConnection();

      $nodeRevData = $db->select('node_revision', 'v')
        ->fields('v', ['nid', 'vid', 'status'])
        ->condition('nid', $node_id)
        ->execute()->fetchAll();

      $j = 0;
      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();

        $nodev_id = $vdt->nid;
        $nodev_vid = $vdt->vid;
        $nodev_status = $vdt->status;

        // Update node_field_revision status.
        $queryv = \Drupal::database()->update('node_field_revision');
        $queryv->fields([
          'status' => $nodev_status,
        ]);
        $queryv->condition('nid', $nodev_id);
        $queryv->condition('vid', $nodev_vid);
        $queryv->execute();

        $j++;

      }

      dump("Script updating status " . $i . " for Node ID " . $node_id);
      $i++;
    }

  }

  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateKoStatusReference() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeData = $db->select('node', 'c')
      ->fields('c', ['nid', 'vid', 'status'])
      ->condition('type', 'reference')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeData as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->nid;
      $node_vid = $dt->vid;
      $node_status = $dt->status;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'status' => $node_status,
      ]);
      $query->condition('nid', $node_id);
      $query->execute();

      // Switch to external database.
      Database::setActiveConnection('migrate');

      // Get the connection.
      $db = Database::getConnection();

      $nodeRevData = $db->select('node_revision', 'v')
        ->fields('v', ['nid', 'vid', 'status'])
        ->condition('nid', $node_id)
        ->execute()->fetchAll();

      $j = 0;
      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();

        $nodev_id = $vdt->nid;
        $nodev_vid = $vdt->vid;
        $nodev_status = $vdt->status;

        // Update node_field_revision status.
        $queryv = \Drupal::database()->update('node_field_revision');
        $queryv->fields([
          'status' => $nodev_status,
        ]);
        $queryv->condition('nid', $nodev_id);
        $queryv->condition('vid', $nodev_vid);
        $queryv->execute();

        $j++;

      }

      dump("Script updating status " . $i . " for Node ID " . $node_id);
      $i++;
    }

  }

  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateKoStatusNews() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeData = $db->select('node', 'c')
      ->fields('c', ['nid', 'vid', 'status'])
      ->condition('type', 'news')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeData as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->nid;
      $node_vid = $dt->vid;
      $node_status = $dt->status;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'status' => $node_status,
      ]);
      $query->condition('nid', $node_id);
      $query->execute();

      // Switch to external database.
      Database::setActiveConnection('migrate');

      // Get the connection.
      $db = Database::getConnection();

      $nodeRevData = $db->select('node_revision', 'v')
        ->fields('v', ['nid', 'vid', 'status'])
        ->condition('nid', $node_id)
        ->execute()->fetchAll();

      $j = 0;
      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();

        $nodev_id = $vdt->nid;
        $nodev_vid = $vdt->vid;
        $nodev_status = $vdt->status;

        // Update node_field_revision status.
        $queryv = \Drupal::database()->update('node_field_revision');
        $queryv->fields([
          'status' => $nodev_status,
        ]);
        $queryv->condition('nid', $nodev_id);
        $queryv->condition('vid', $nodev_vid);
        $queryv->execute();

        $j++;

      }

      dump("Script updating status " . $i . " for Node ID " . $node_id);
      $i++;
    }

  }

  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateKoStatusEvent() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeData = $db->select('node', 'c')
      ->fields('c', ['nid', 'vid', 'status'])
      ->condition('type', 'event')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeData as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->nid;
      $node_vid = $dt->vid;
      $node_status = $dt->status;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'status' => $node_status,
      ]);
      $query->condition('nid', $node_id);
      $query->execute();

      // Switch to external database.
      Database::setActiveConnection('migrate');

      // Get the connection.
      $db = Database::getConnection();

      $nodeRevData = $db->select('node_revision', 'v')
        ->fields('v', ['nid', 'vid', 'status'])
        ->condition('nid', $node_id)
        ->execute()->fetchAll();

      $j = 0;
      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();

        $nodev_id = $vdt->nid;
        $nodev_vid = $vdt->vid;
        $nodev_status = $vdt->status;

        // Update node_field_revision status.
        $queryv = \Drupal::database()->update('node_field_revision');
        $queryv->fields([
          'status' => $nodev_status,
        ]);
        $queryv->condition('nid', $nodev_id);
        $queryv->condition('vid', $nodev_vid);
        $queryv->execute();

        $j++;

      }

      dump("Script updating status " . $i . " for Node ID " . $node_id);
      $i++;
    }

  }

  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateKoStatusBook() {
    // Here load all the node for KO and call the method.
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get the connection.
    $db = Database::getConnection();

    $nodeData = $db->select('node', 'c')
      ->fields('c', ['nid', 'vid', 'status'])
      ->condition('type', 'book')
      ->execute()->fetchAll();

    $i = 0;

    foreach ($nodeData as $dt) {

      // Switch back to default database.
      Database::setActiveConnection();

      $node_id = $dt->nid;
      $node_vid = $dt->vid;
      $node_status = $dt->status;

      // Update node_field_data status.
      $query = \Drupal::database()->update('node_field_data');
      $query->fields([
        'status' => $node_status,
      ]);
      $query->condition('nid', $node_id);
      $query->execute();

      dump("Script updating status " . $i);
      $i++;

      // Switch to external database.
      Database::setActiveConnection('migrate');

      // Get the connection.
      $db = Database::getConnection();

      $nodeRevData = $db->select('node_revision', 'v')
        ->fields('v', ['nid', 'vid', 'status'])
        ->condition('nid', $node_id)
        ->execute()->fetchAll();

      $j = 0;
      foreach ($nodeRevData as $vdt) {

        // Switch back to default database.
        Database::setActiveConnection();

        $nodev_id = $vdt->nid;
        $nodev_vid = $vdt->vid;
        $nodev_status = $vdt->status;

        // Update node_field_revision status.
        $queryv = \Drupal::database()->update('node_field_revision');
        $queryv->fields([
          'status' => $nodev_status,
        ]);
        $queryv->condition('nid', $nodev_id);
        $queryv->condition('vid', $nodev_vid);
        $queryv->execute();

        $j++;

      }

      dump("Script updating status " . $i . " for Node ID " . $node_id);
      $i++;
    }

  }

  /**
   * Method to Update Content Moderation State.
   */
  public function handleCommunityUpdateCms() {
    // Here load all the group and call the method.
    $a = [];
    // Switch to external database.
    Database::setActiveConnection('migrate');

    // Get a connection going.
    $db = Database::getConnection();

    $oldGroupsData = $db->select('node', 'c')
      ->fields('c', ['nid', 'status'])
      ->condition('c.type', 'group')
      ->execute();
    $record = $oldGroupsData->fetchAll();

    Database::setActiveConnection();

    foreach ($record as $grp) {
      $status = $grp->status;
      $group = Group::load($grp->nid);

      if ($group instanceof GroupInterface) {

        if ($status == 0) {
          $group->setUnpublished()->save();
        }
        else {
          $group->setPublished()->save();
        }
      }

    }
    return ["Successfully Updated Moderation State !"];
  }

  /**
   * Method to List Update Community Url Alias fix.
   */
  public function handleCommunityUpdateQueryStringAlias() {
    // /community/update/alias/querystring?group_id=1073689
    $group_id = \Drupal::request()->get('group_id');
    $a = [];

    if (isset($group_id)) {
      $group = Group::load($group_id);
      if ($group instanceof GroupInterface) {
        dump("Alias creation Started for Community " . $group_id);
        $this->check_for_redirect_tabs($group_id);
        $this->check_for_redirect_group_comm_tabs($group_id);
      }
    }
    return $a;
  }

  /**
   * Method to List Sub Segment.
   */
  public function handleCommunityUpdateAlias() {
    // Here load all the group and call the method.
    $a = [];
    $groupsData = \Drupal::database()->select('groups', 'c')
      ->fields('c', ['id'])
      ->execute();
    foreach ($groupsData as $grp) {
      $group = Group::load($grp->id);
      if ($group instanceof GroupInterface) {
        $this->check_for_redirect_tabs($grp->id);
        $this->check_for_redirect_group_comm_tabs($grp->id);
      }
    }
    return $a;
  }

  /**
   * Redirect to Tabs as per Group Settings.
   */
  public function check_for_redirect_tabs($grp_id) {

    // die($grp_id);
    $group = Group::load($grp_id);
    $field_default_display = $group->get('field_default_display')->value;

    if (isset($field_default_display)) {
      $field_default_display = $group->get('field_default_display')->value;
    }
    else {
      $field_default_display = "viva_engage";

    }

    $field_community_type = $group->get('field_community_type')->value;
    $alias_remove_path_array = ['/group/' . $group->id() . '/viva_engage', '/group/' . $group->id() . '/assets', '/group/' . $group->id() . '/references', '/group/' . $group->id() . '/news', '/group/' . $group->id() . '/events','/node/'.$group->id()];
    // Remove all alias for community pages for the community
    // Community Page Option list.
    $community_pages_list = book_options_from_gid($group->id());
    if (!empty($community_pages_list)) {
      foreach ($community_pages_list as $key => $val) {
        $alias_remove_path_array[] = '/node/' . $val->nid;
      }
    }
    // dump($alias_remove_path_array); exit;.
    $path_alias_storage = \Drupal::entityTypeManager()->getStorage('path_alias');

    foreach ($alias_remove_path_array as $path) {
      // Load all path alias for this node.
      $alias_objects = $path_alias_storage->loadByProperties([
        'path' => $path,
      ]);

      // Delete all alias.
      foreach ($alias_objects as $alias_object) {
        $alias_object->delete();
      }
    }

      $path_alias_repository = \Drupal::service('path_alias.repository');
      $path_alias_path = '/community/'.$group->id().'/leave';
      if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
        $path_alias = \Drupal\path_alias\Entity\PathAlias::create([
          'path' => '/group/'.$group->id().'/leave',
          'alias' => $path_alias_path,
        ]);
        $path_alias->save();
      }

      $path_alias_path = '/community/'.$group->id().'/request-membership';
      if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
        $path_alias = \Drupal\path_alias\Entity\PathAlias::create([
          'path' => '/group/'.$group->id().'/request-membership',
          'alias' => $path_alias_path,
        ]);
        $path_alias->save();
      }

      $path_alias_path = '/community/'.$group->id().'/join';
      if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
        $path_alias = \Drupal\path_alias\Entity\PathAlias::create([
          'path' => '/group/'.$group->id().'/join',
          'alias' => $path_alias_path,
        ]);
        $path_alias->save();
      }


    if ($field_default_display == "viva_engage"  || $field_default_display == "conversation") {
      $path_alias = PathAlias::create([
        'path' => '/community/' . $group->id() . '/daily_connect',
        'alias' => '/community/' . $group->id(),
      ]);
      $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/assets',
      //   'alias' => '/community/' . $group->id() . '/assets',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/references',
      //   'alias' => '/community/' . $group->id() . '/references',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/news',
      //   'alias' => '/community/' . $group->id() . '/news',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/events',
      //   'alias' => '/community/' . $group->id() . '/events',
      // ]);
      // $path_alias->save();

    }
    elseif ($field_default_display == 'asset') {
      $path_alias = PathAlias::create([
        'path' => '/community/' . $group->id() . '/assets',
        'alias' => '/community/' . $group->id(),
      ]);
      $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/viva_engage',
      //   'alias' => '/community/' . $group->id() . '/daily_connect',
      // ]);
      // $path_alias->save();
    }
    elseif ($field_default_display == 'reference') {
      $path_alias = PathAlias::create([
        'path' => '/community/' . $group->id() . '/references',
        'alias' => '/community/' . $group->id(),
      ]);
      $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/viva_engage',
      //   'alias' => '/community/' . $group->id() . '/daily_connect',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/news',
      //   'alias' => '/community/' . $group->id() . '/news',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/events',
      //   'alias' => '/community/' . $group->id() . '/events',
      // ]);
      // $path_alias->save();
    }
    elseif (strpos($field_default_display, 'node')) {
      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/viva_engage',
      //   'alias' => '/community/' . $group->id() . '/daily_connect',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/assets',
      //   'alias' => '/community/' . $group->id() . '/assets',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/references',
      //   'alias' => '/community/' . $group->id() . '/references',
      // ]);
      // $path_alias->save();

      $path_alias = PathAlias::create([
        'path' => $field_default_display,
        'alias' => '/community/' . $group->id() . '/home',
      ]);
      $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/news',
      //   'alias' => '/community/' . $group->id() . '/news',
      // ]);
      // $path_alias->save();

      // $path_alias = PathAlias::create([
      //   'path' => '/group/' . $group->id() . '/events',
      //   'alias' => '/community/' . $group->id() . '/events',
      // ]);
      // $path_alias->save();

      // Create all Alias except the default display selected community page.
      $idRaw = explode('/', $field_default_display);
      if (!empty($community_pages_list)) {
        foreach ($community_pages_list as $key => $val) {
          if ($val->nid != $idRaw[2]) {
            $path_alias = PathAlias::create([
              'path' => '/node/' . $val->nid,
              'alias' => '/page/' . $val->nid,
            ]);
            $path_alias->save();
          }
        }
      }

    }
    dump("Alias creation Completed for Community " . $grp_id);
  }

  /**
   * Method to handle default tab.
   */
  // Public function redirectNode($nid) {
  // $url = Url::fromRoute("entity.node.canonical", ['node' => 3]);
  //   $redirect = new RedirectResponse($url->toString());
  //   $redirect->send();
  // }

  /**
   * Handler for autocomplete request.
   */
  public function handlecommunityAutocomplete(Request $request) {
    $results = [];
    $input = $request->query->get('q');

    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    // $query->addExpression("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value)", 'full_name');
    $query = \Drupal::database()->select('users_field_data', 'ufd');
    $query->join('user__field_name_first', 'f', 'ufd.uid = f.entity_id');
    $query->join('user__field_name_last', 'l', 'ufd.uid = l.entity_id');
    $query->addField('f', 'field_name_first_value', 'firstname');
    $query->addField('l', 'field_name_last_value', 'lastname');
    $query->addField('ufd', 'uid', 'id');
    $query->addField('ufd', 'mail', 'email');
    $query->where("CONCAT(f.field_name_first_value, ' ', l.field_name_last_value) LIKE :q OR ufd.mail LIKE :q", [':q' => '%' . $input . '%']);
    $results = $query->execute()->fetchAll();
    $values = [];
    foreach ($results as $result) {
      $label = [
        $result->firstname . ' ' . $result->lastname, '[' . $result->email . ']', '[' . $result->id . ']',
      ];
      $values[] = [
        'label' => implode(' ', $label),
      ];
    }
    return new JsonResponse($values);
  }
 /**
   * Handler for Asset alias Update.
   */
  public function handleAssetUpdateAlias() {
    $nids = \Drupal::entityTypeManager()
     ->getStorage('node')
     ->getQuery()
     ->accessCheck(TRUE)
     ->condition('type', 'asset')
     ->execute();    
   // Here load all the nodes which type asset and update their alias.
    foreach ($nids as $nid) {    
     $internal_path = '/node/' . $nid;
     $alias = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);     
     if ($alias === $internal_path) {
     $path_alias_repository = \Drupal::service('path_alias.repository');
     $node = Node::load($nid);
     $node_bundle = $node->bundle();
     $path_alias_path = '/'.$node_bundle.'/' . $nid;
     if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
       $path_alias = PathAlias::create([
         'path' => '/node/' . $nid,
         'alias' => $path_alias_path,
       ]);
       $path_alias->save();
     }     
     }
    }
    return [];
  }	
  /**
   *
   */
  public function check_for_redirect_group_comm_tabs($grp_id) {
    $group = Group::load($grp_id);
    $field_default_display = $group->get('field_default_display')->value;

    if (isset($field_default_display)) {
      $field_default_display = $group->get('field_default_display')->value;
    }
    else {
      $field_default_display = "yammer";

    }

    $path_alias_repository = \Drupal::service('path_alias.repository');

    // Handling the community/* route issue.
    $path_alias_path = '/community/' . $grp_id;
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id,
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    $path_alias_path = '/community/' . $grp_id . '/status/live';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/status/live',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    $path_alias_path = '/community/' . $grp_id . '/edit';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/edit',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    $path_alias_path = '/community/' . $grp_id . '/admin/taxonomy/community_taxonomy';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/admin/taxonomy/community_taxonomy',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    // $path_alias_path = '/community/' . $grp_id . '/membership';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/membership',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    $path_alias_path = '/community/' . $grp_id . '/status/gold';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/status/gold',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    $path_alias_path = '/community/' . $grp_id . '/status/archive';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/status/archive',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    $path_alias_path = '/community/' . $grp_id . '/manage-content';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/manage-content',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    // $path_alias_path = '/community/' . $grp_id . '/node/statistic/view';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/node/statistic/view',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/invitation-overview';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/invitation-overview',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    $path_alias_path = '/community/' . $grp_id . '/members';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/members',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    // $path_alias_path = '/community/' . $grp_id . '/manage-content/delete-content';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/manage-content/delete-content',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    $path_alias_path = '/community/' . $grp_id . '/members-pending';
    if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
      $path_alias = PathAlias::create([
        'path' => '/group/' . $grp_id . '/members-pending',
        'alias' => $path_alias_path,
      ]);
      $path_alias->save();
    }

    // $path_alias_path = '/community/' . $grp_id . '/join-community';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/join-community',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/membership-request';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/membership-request',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/leave-community';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/leave-community',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/content/add/group_membership';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/content/add/group_membership',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/cancel-request';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/cancel-request',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/stream';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/stream',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $path_alias_path = '/community/' . $grp_id . '/delete';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/delete',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

    // $string = "yammer";
    // $field = 'path';
    // $query = \Drupal::database()->update('path_alias');
    // $query->condition('path', "%" . $string . "%", 'LIKE');
    // $query->expression($field, 'replace(' . $field . ', :yammer, :viva_engage)', [
    //   ':yammer' => 'yammer',
    //   ':viva_engage' => 'viva_engage',
    // ]);
    // $result = $query->execute();

    // $query = \Drupal::database()->update('path_alias_revision');
    // $query->condition('path', "%" . $string . "%", 'LIKE');
    // $query->expression($field, 'replace(' . $field . ', :yammer, :viva_engage)', [
    //   ':yammer' => 'yammer',
    //   ':viva_engage' => 'viva_engage',
    // ]);
    // $res = $query->execute();

    // if (strpos($field_default_display, 'node')) {
    //   $path_alias = PathAlias::create([
    //     'path' => $field_default_display,
    //     'alias' => '/community/' . $group->id() . '/home',
    //   ]);
    //   $path_alias->save();

    //   // Remove all alias for community pages for the community
    //   // Community Page Option list.
    //   $community_pages_list = book_options_from_gid($group->id());
    //   if (!empty($community_pages_list)) {
    //     foreach ($community_pages_list as $key => $val) {
    //       $alias_remove_path_array[] = '/node/' . $val->nid;
    //     }
    //   }
    //   // Create all Alias except the default display selected community page.
    //   $idRaw = explode('/', $field_default_display);
    //   if (!empty($community_pages_list)) {
    //     foreach ($community_pages_list as $key => $val) {
    //       if ($val->nid != $idRaw[2]) {
    //         $path_alias = PathAlias::create([
    //           'path' => '/node/' . $val->nid,
    //           'alias' => '/page/' . $val->nid,
    //         ]);
    //         $path_alias->save();
    //       }
    //     }
    //   }

    // }

    // $path_alias_path = '/community/' . $grp_id . '/references-quality-control';
    // if (!($path_alias_repository->lookupByAlias($path_alias_path, 'en'))) {
    //   $path_alias = PathAlias::create([
    //     'path' => '/group/' . $grp_id . '/references-quality-control',
    //     'alias' => $path_alias_path,
    //   ]);
    //   $path_alias->save();
    // }

  }

}
