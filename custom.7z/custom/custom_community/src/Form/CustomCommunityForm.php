<?php

namespace Drupal\custom_asset\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for Activity edit forms.
 *
 * @ingroup manipulate_asset
 */
class CustomCommunityForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    /** @var \Drupal\manipulate_asset\Entity\Activity $entity */
    $form = parent::buildForm($form, $form_state);
    return $form;
  }

}
