<?php

namespace Drupal\custom_community\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;

/**
 * Implementing a ajax form.
 */
class CustomTaxonomyTermForm extends ConfirmFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'taxonomy_term_community_taxonomy_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    /**
     * @file
     * The block for group, which controls the output of Drupal 7.
     */

    define("TAGS_VID", 6);
    define("ENGLISH_TID", 29);
    define("CATEGORY_TID", 5);
    define("STRATEGIC_BUSINESS_UNIT_TID", 19);
    define("COUNTRY_TID", 2);
    define("SERVICE_OFFER_TID", 20);
    define("SECTOR_TID", 8);
    define("TLI_PRACTICE_TID", 277);
    define("TECHNOLOGY_TID", 278);
    // System Tag.
    define("SYSTEM_TAG_VID", 6);
    // Community Folder.
    define("COMMUNITY_FOLDER_TID", 275);
    // Community Folder.
    define("COMMUNITY_FOLDER_NAME", 'community_folders');
    // Community Taxonomy.
    define("COMMUNITY_TAXONOMY_TID", 276);
    // Community Taxonomy.
    define("COMMUNITY_TAXONOMY_NAME", 'community_taxonomy');
    // Max number of community taxonomy for each community.
    define("COMMUNITY_TAXONOMY_MAX", 6);
    // print_r("testing route");
    // die();
    // Retrieve an array which contains the path pieces.
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    // Array ( [0] => [1] => group [2] => 10 [3] => admin [4] => taxonomy [5] => community_taxonomy [6] => add )
    // Entity type = group $variables['build_info']['args'][0];.
    $entity_type = $gid = $path_args[1];
    // $variables['build_info']['args'][1];
    $gid = $path_args[2];
    // $variables['build_info']['args'][2];
    $vob = $path_args[5];

    if ($vob === 'community_folders') {
      $root = taxonomy_term_load_multiple_by_name('cap_com_folder_' . $gid, COMMUNITY_FOLDER_NAME);
      $parent = "";

      foreach ($root as $term) {
        $parent = $term->id();
      }
      if ($parent == "") {
        // Create the taxonomy term.
        $root_term = Term::create([
          'name' => 'cap_com_folder_' . $gid,
          'vid' => $vob,
          'parent' => [],
          'field_gid' => $gid,
        ]);

        // Save the taxonomy term.
        $root_term->save();
        $parent = $root_term->id();
      }
    }

    if ($vob === 'community_taxonomy') {
      $root = taxonomy_term_load_multiple_by_name('cap_com_tax_' . $gid, COMMUNITY_TAXONOMY_NAME);
      $parent = "";

      foreach ($root as $term) {
        $parent = $term->id();
      }
      if ($parent == "") {
        // Create the taxonomy term.
        $root_term = Term::create([
          'name' => 'cap_com_tax_' . $gid,
          'vid' => $vob,
          'parent' => [],
          'field_gid' => $gid,
        ]);

        // Save the taxonomy term.
        $root_term->save();

        $parent = $root_term->id();
      }
    }

    // $root = taxonomy_term_load_multiple_by_name('cap_com_tax_1037821', COMMUNITY_TAXONOMY_NAME);
    // $termId = \Drupal::entityQuery("taxonomy_term")->condition("vid", COMMUNITY_TAXONOMY_NAME)->condition("name", 'cap_com_tax_1037821')->execute();
    // Echo "<pre/>-------";
    // print_r($parent);
    // die;
    // If (isset($root) && count($root) > 0)
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => t('Name'),
      '#size' => 60,
      '#maxlength' => 128,
      '#required' => TRUE,
    ];

    if ($vob == COMMUNITY_TAXONOMY_NAME) {
      $form['field_type'] = [
        '#type' => 'radios',
        '#title' => t('Type'),
        '#options' => [
          '0' => 'Single value',
          '1' => 'Multiple value',
        ],
        '#default_value' => 0,
        '#required' => TRUE,
      ];
      $form['field_values'] = [
        '#type' => 'textarea',
        '#title' => t('Values'),
        '#required' => TRUE,
        '#rows' => 3,
        '#description' => t('Use comma as a separator between values.'),
      ];
    }

    $form['vid'] = [
      '#type' => 'hidden',
      '#value' => $vob,
    ];
    $form['pid'] = [
      '#type' => 'hidden',
      '#value' => $parent,
    ];

    $form['gid'] = [
      '#type' => 'hidden',
      '#value' => $gid,
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = ['#type' => 'submit', '#value' => t('Save'), '#vid' => $vob, '#gid' => $gid];
    // $form['actions']['cancel'] = array(
    //   '#type' => 'submit',
    //   '#value' => t('Cancel'),
    //   '#weight' => -5,
    //   '#access' => TRUE,
    //   '#url' => 'group/' . $gid . '/admin/taxonomy/' . $vob,
    //   '#submit' => array('cap_groups_add_term_cancel'),
    //   '#limit_validation_errors' => array()
    // );
    return $form;
  }

  /**
   * Returns the question to ask the user.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup
   *   The form question. The page title will be set to this value.
   */
  public function getQuestion() {
    return t('Do you want to delete this node?');
  }

  /**
   * Returns the route to go to if the user cancels the action.
   *
   * @return \Drupal\Core\Url
   *   A URL object.
   */
  public function getCancelUrl() {
    $gid = $_SESSION['gid'];
    // Return \Drupal\Core\Url::fromRoute('view.mass_operation.page_group_manage_content', ['gid' => $gid]);.
    unset($_SESSION['content_id']);
    unset($_SESSION['action_item']);
    unset($_SESSION['gid']);
  }

  /**
   * Submitting the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $name = $form_state->getValue('name');
    $vocabulary = $form_state->getValue('vid');
    $parent = $form_state->getValue('pid');
    $gid = $form_state->getValue('gid');

    if ($form['actions']['submit']['#vid'] === COMMUNITY_TAXONOMY_NAME) {
      $field_values = $form_state->getValue('field_values');
      $field_type = $form_state->getValue('field_type');

      // Create the taxonomy term.
      $term = Term::create([
        'name' => $name,
        'vid' => $vocabulary,
        'parent' => $parent,
        'field_gid' => $gid,
        'field_values' => $field_values,
        'field_type' => $field_type,
      ]);

      // Save the taxonomy term.
      $term->save();

      $term_child_arr = ($field_values) ? explode(',', $field_values) : [];
      if (count($term_child_arr) > 0) {
        $i = 0;
        foreach ($term_child_arr as $child_name) {
          // Create the taxonomy term.
          $child = Term::create([
            'name' => trim($child_name),
            'vid' => $vocabulary,
            'parent' => $term->id(),
            'field_gid' => $gid,
            'weight' => $i++,
          ]);

          // Save the taxonomy term.
          $child->save();
        }
      }
    }
    else {
      global $user;
      $author_id = \Drupal::currentUser()->id();
      $now = DrupalDateTime::createFromTimestamp(time());
      $now->setTimezone(new \DateTimeZone('UTC'));

      // Create the taxonomy term.
      $term = Term::create([
        'name' => $name,
        'vid' => $vocabulary,
        'parent' => $parent,
        'field_gid' => $gid,
        'field_author' => $author_id,
        'field_term_creation_date' => $now->getTimestamp(),
      ]);

      // Save the taxonomy term.
      $term->save();
    }

    \Drupal::messenger()->addMessage('"' . $name . '"' . ' has been created successfully.');

    $gid = $form['actions']['submit']['#gid'];
    if (is_numeric($gid)) {
      if ($form['actions']['submit']['#vid'] === COMMUNITY_FOLDER_NAME) {
        // cache_clear_all('community_folder_' . $gid, 'cache', TRUE);.
        \Drupal::service('cache.render')->invalidateAll();
      }
    }
  }

}
