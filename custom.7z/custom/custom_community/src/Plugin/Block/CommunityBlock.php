<?php

namespace Drupal\custom_community\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;
use Drupal\Core\Entity;
use Drupal\user\Entity\User;

/**
 * Community Details block.
 *
 * @Block(
 *   id = "community_details_block",
 *   admin_label = "Custom community details Block"
 * )
 */
class CommunityBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $group_bundle_details = $this->custom_get_group();
    $group = $group_bundle_details['group'];
    $user = User::load(\Drupal::currentUser()->id());
    $gid='';
    $group_details = [];
    $members_count = 0;
    $group_image_targetId = '';
    $com_logo = '';
    $com_type = 0;
    $field_default_display = '';

    if($group instanceof GroupInterface && !empty($group)) {
      $route_name = \Drupal::routeMatch()->getRouteName();
      $group_details['gid'] = !empty($group->id()) ? $group->id() : '';
      $group_details['route_name'] = !empty($route_name) ? $route_name : '';
      $group_details['full_url'] = $_SERVER['REQUEST_URI'];
      $group_details['label'] = !empty($group->label()) ? $group->label() : '';
      $group_details['description'] = !empty($group->get('field_group_description')->getValue()) ? $group->get('field_group_description')->getValue()[0]['value'] : '';
      $group_memberships = \Drupal::service('group.membership_loader')->loadByGroup($group);
      $members_count = count($group_memberships);
      $group_details['members_count'] = $members_count;
      $type = !empty($group->get('type')->getValue()) ? $group->get('type')->getValue()[0]['target_id'] : '';
      $group_details['type'] = $type;
      $com_type = ($group->get('field_community_type')) && !empty($group->get('field_community_type')->getValue()) ? $group->get('field_community_type')->getValue()[0]['value'] : '';
      $group_details['com_type'] = $com_type;
      $group_image_targetId = ($group->get('field_group_logo')) && !empty($group->get('field_group_logo')->getValue()) && array_key_exists('target_id', $group->get('field_group_logo')->getValue()[0]) ? $group->get('field_group_logo')->getValue()[0]['target_id'] : '';
      $logo_file = isset($group_image_targetId) && !empty($group_image_targetId) ? File::load($group_image_targetId) : NULL;
      $logo_uri = !empty($logo_file) ? $logo_file->get('uri')->getValue()[0]['value'] : '';
      $com_logo = !empty($logo_uri) ? str_replace('public://', '/sites/default/files/', $logo_uri) : '/themes/custom/capgemini_b5/images/default img.svg';
      $group_details['com_logo'] = $com_logo;
      $group_details['com_publish_status'] = ($group) && !empty($group->get('status')->getValue()) ? !empty($group->get('status')->getValue()[0]['value']) : 0;

      $membership_roles = ($group) ? $group->getMember(\Drupal::currentUser()) : NULL;
      $group_details['is_member'] = isset($membership_roles) && !empty($membership_roles) ? TRUE : FALSE;
      // Get the roles of the owner.
      $roles = ($membership_roles) ? $membership_roles->getRoles() : NULL;
      $group_type = ($group) ? $group->getGroupType()->id() : NULL;
      $field_default_display = ($group->hasField('field_default_display')) ? $group->hasField('field_default_display') : NULL;
      if (isset($roles[$group_type . '-moderator']) || isset($roles[$group_type . '-group_manager'])) {
        $group_details['user_is_moderator'] = TRUE;
      }
      elseif ((isset($roles[$group_type . '-group_manager']) && isset($roles[$group_type . '-group_admin'])) || (isset($roles[$group_type . '-moderator']) && isset($roles[$group_type . '-group_admin']))) {
        $group_details['user_is_moderator'] = TRUE;
      }
      else {
        $group_details['user_is_moderator'] = FALSE;
      }
    }
    $current_viva_uri = \Drupal::request()->getRequestUri();
    if (isset($group_details['gid']) && $current_viva_uri == '/community/' . $group_details['gid'] . '/daily_connect') {
      $group_details['vivaTab'] = 'active';
      $group_details['vivaName'] = 'class=is-active';
    }
    elseif ($field_default_display && $group->get('field_default_display')->getValue()[0]['value'] == 'viva_engage' && $current_viva_uri == '/community/' . $group_details['gid']) {
      $group_details['vivaTab'] = 'active';
      $group_details['vivaName'] = 'class=is-active';
    }
    else {
      $group_details['vivaTab'] = $group_details['vivaName'] = '';
    }

    $get_curr_user_grequest = get_curr_user_grequest($group, $user);
    $get_curr_user_grequest_field = get_curr_user_grequest_field($group, $user);

    $group_details['newsTab'] = $group_bundle_details['newsTab'];
    $group_details['newsName'] = $group_bundle_details['newsName'];
    $group_details['eventTab'] = $group_bundle_details['eventTab'];
    $group_details['eventName'] = $group_bundle_details['eventName'];
    $group_details['assetTab'] = $group_bundle_details['assetTab'];
    $group_details['assetName'] = $group_bundle_details['assetName'];
    $group_details['refTab'] = $group_bundle_details['refTab'];
    $group_details['refName'] = $group_bundle_details['refName'];
    $group_details['member_status'] = $get_curr_user_grequest;
    $group_details['member_status_field'] = $get_curr_user_grequest_field;
    $group_details['showTab'] = $group_bundle_details['showTab'];

    return [
      '#theme' => 'community_details_block',
      '#data' => $group_details,
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }

  /**
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }

  public function custom_get_group() {
    $group_bundle_details = [];
    $newsTab = "";
    $newsName = "";
    $eventTab = "";
    $eventName = "";
    $assetTab = "";
    $assetName = "";
    $refTab = "";
    $refName = "";
    $group = "";
    $matches = [];
    $gid="";
    $showTab = "yes";
    $parameters = \Drupal::routeMatch()->getParameters()->all(); 
    # Get gid for Mass operation in Header #
    $route_name = \Drupal::routeMatch()->getRouteName();
    $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
    $store->get('old_gid'); 
    if (!empty($parameters) && !empty($parameters['view_id'])) {
      if($parameters['view_id'] == 'capgemini_browsing_widget_news') {
        $newsTab = "active";
        $newsName = 'class=is-active';
      }
      elseif($parameters['view_id'] == 'capgemini_browsing_widget_event') {
        $eventTab = "active";
        $eventName = 'class=is-active';
      }
      elseif($parameters['view_id'] == 'capgemini_browsing_widget_asset_block') {
        $assetTab = "active";
        $assetName = 'class=is-active';
      }
      elseif($parameters['view_id'] == 'capgemini_browsing_widget_reference') {
        $refTab = "active";
        $refName = 'class=is-active';
      }
    }
    # Community Header block enabled code on Mass Operation's Action Pages. Start #
    if($route_name == 'views_bulk_operations.execute_configurable' || $route_name == 'views_bulk_operations.confirm') {
      $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
      $groupid= $store->get('group_key');
      $group = Group::load($groupid);
    }
    else {
    $groupid = "";
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
    }
    else {
      $group_from_route = \Drupal::routeMatch()->getParameter('group');
      $group = isset($group_from_route) ? $group_from_route : "";
      if(!empty($parameters) && !empty($parameters['view_id']) && $parameters['view_id'] == 'publish_references') {
        $current_uri = \Drupal::request()->getRequestUri();
        $uri = explode('/', $current_uri);
        $group = !empty($uri[3]) ? Group::load($uri[3]) : '';
      }
    }
  }
  # Community Header block enabled code on Mass Operation's Action Pages. End #
    if (empty($group)) {
      $nid = \Drupal::routeMatch()->getRawParameter('node');
      $node = (is_numeric($nid))?Node::load($nid): null;

      if (!empty($node) && !empty($node->get('type')->getValue())) {
        if($node->get('type')->getValue()[0]['target_id'] == 'news') {
          $newsTab = "active";
          $newsName = 'class=is-active';
        }
        elseif($node->get('type')->getValue()[0]['target_id'] == 'event') {
          $eventTab = "active";
          $eventName = 'class=is-active';
        }
        elseif($node->get('type')->getValue()[0]['target_id'] == 'asset') {
          $assetTab = "active";
          $assetName = 'class=is-active';
        }
        elseif($node->get('type')->getValue()[0]['target_id'] == 'reference') {
          $refTab = "active";
          $refName = 'class=is-active';
        }
      }
       
      if (!empty($node) and $node->hasField('field_community')) {
        $gid = !empty($node) && !empty($node->get('field_community')) && !empty($node->get('field_community')->getValue()[0]['target_id']) ? $node->get('field_community')->getValue()[0]['target_id']: "";
      }
      if (empty($gid)) {
        $key = \Drupal::request()->query->get('community_id');
        if(isset($key)) {
          $gid = $key;
          $node_type_from_route = \Drupal::routeMatch()->getParameter('node_type');
          if(!empty($node_type_from_route)) {
            if ($node_type_from_route->get('type') == 'news') {
              $newsTab = "active";
              $newsName = 'class=is-active';
            }
            elseif($node_type_from_route->get('type') == 'event') {
              $eventTab = "active";
              $eventName = 'class=is-active';
            }
            elseif($node_type_from_route->get('type') == 'asset') {
              $assetTab = "active";
              $assetName = 'class=is-active';
            }
            elseif($node_type_from_route->get('type') == 'reference') {
              $refTab = "active";
              $refName = 'class=is-active';
            }
          }
        }
        else {
          $current_uri = \Drupal::request()->getRequestUri();
          $ref_create_url = str_contains($current_uri, 'oppID=');
          preg_match_all('!\d+!', $current_uri, $matches);
          if ($ref_create_url == true) {
            $gid = NULL;
          }
          else {
            $gid = isset($matches) && !empty($matches[0][0]) && (str_contains($current_uri, 'group/') || str_contains($current_uri, 'community/')) ? $matches[0][0] : '';
          }
        }
      }

      // Handle adv_id query string for search functionality starts
      if(empty($gid)){
        $current_uri = \Drupal::request()->getRequestUri();
        $adv_search_create_url = str_contains($current_uri, 'adv_gid=');
        preg_match_all('!\d+!', $current_uri, $matches);
        if($adv_search_create_url == true){
					$gid = isset($matches) && !empty($matches[0][0]) && (str_contains($current_uri, 'group/') || str_contains($current_uri, 'community/') || str_contains($current_uri, 'advanced_search_')) ? $matches[0][0] : '';
				}
        $showTab = isset($matches) && !empty($matches[0][0]) && (str_contains($current_uri, 'advanced_search_')) ? 'no' : 'yes';
      }

    if(isset($gid) && !empty($gid)) {
      // Handle adv_id query string for search functionality ends
      if(empty($gid)){
        $current_path = \Drupal::service('path.current')->getPath();
        $path = explode('/', $current_path);
        if (isset($path['1']) && isset($path['2']) && $path['1'] =='status' && $path['2'] =='unpublished'){
          $gid = $path['3'];
        }
      }
    }	    
    if ( $store->get('old_gid') > 0 && ($current_path == '/group/views-bulk-operations/configure/mass_operation/page_1' || $current_path = '/group/views-bulk-operations/confirm/mass_operation/page_1')) {
      $group = Group::load($store->get('old_gid'));
        if ($group instanceof GroupInterface) {
          $gid = $group->id();
        }
    }
    if(isset($gid) && !empty($gid)) {
        $group = Group::load($gid);
      }
    }
    $group_bundle_details['group'] = $group;
    $group_bundle_details['newsTab'] = $newsTab;
    $group_bundle_details['newsName'] = $newsName;
    $group_bundle_details['eventTab'] = $eventTab;
    $group_bundle_details['eventName'] = $eventName;
    $group_bundle_details['assetTab'] = $assetTab;
    $group_bundle_details['assetName'] = $assetName;
    $group_bundle_details['refTab'] = $refTab;
    $group_bundle_details['refName'] = $refName;
    $group_bundle_details['showTab'] = $showTab;
    return $group_bundle_details;
  }
}
