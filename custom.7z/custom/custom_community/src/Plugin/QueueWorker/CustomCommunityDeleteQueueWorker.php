<?php

namespace Drupal\custom_community\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\group\Entity\Group;
use Drupal\taxonomy\Entity\Term;
use Drupal\message\Entity\Message;
use Drupal\Core\Database\Database;
use Drupal\node\NodeInterface;

/**
 * A queue worker that processes notifications.
 *
 * @QueueWorker(
 *   id = "custom_community_delete_queue",
 *   title = @Translation("Custom Community Node Delete Queue"),
 *   cron = {"time" = 60}
 * )
 */
class CustomCommunityDeleteQueueWorker extends QueueWorkerBase {

  /**
   * Processes a single item in the queue.
   */
  public function processItem($data) {
    // Process the data passed to the queue.
    $action = $data['action'];

    switch($action) {
      case 'delete_community_folder':
        $term_id = $data['term_id'];
        $term = Term::load($term_id);
        if ($term) {
            $term->delete();
        }
        \Drupal::logger('custom_community')->notice('custom_community:delete_community_folder Group Deleted @term_id', ['@term_id' => $term_id]);

        break;
      case 'node_delete': // Handle node delete case
        $nid = $data['entity_id'];
        $group_id = $data['group_id'];
        // Check if node exists with the given nid.
        $can_delete = TRUE;
        $values = \Drupal::entityQuery('node')->condition('nid', $nid)->accessCheck(TRUE)->execute();
        $node_exists = !empty($values);
        \Drupal::logger('custom_community')->notice('custom_community:node_delete Node Start Deletion @nid', ['@term_id' => $nid]);

        if($node_exists) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
          // Reference case handled differently because of the secondary communities.
          if($node->type->getValue()[0]['target_id'] == 'reference' ) {
            $field_community_id = $node->field_community->getValue()[0]['target_id'];
            if($field_community_id != $group_id) {
              $can_delete = FALSE;
            }
          }
          if ($can_delete) { // Delete if there is no secondary community exist.
            $node->delete();
            \Drupal::logger('custom_community')->notice('custom_community:Community Node Deleted @nid', ['@nid' => $nid]);
          }
        }
      break;
      case 'group_delete':
        $group_id = $data['entity_id'];
        $group = Group::load($group_id);
        $this->assign_group_node_to_queue($group_id);
        $this->assign_community_folder_to_delete_to_queue($group_id);

        foreach ($group->getRelationships() as $relationship) {
          $relationship->delete();
        }
        \Drupal::logger('custom_community')->notice('custom_community:group_delete Group Deleted @group_id', ['@group_id' => $group_id]);

        $group->delete();
      break;
      case 'add_all_nid_to_queue':
        $all_nid = $data['all_nid'];
        $group_id = $data['group_id'];
        for($i=0; $i<count($all_nid); $i++) {
          $nid = $all_nid[$i];
          $queue = \Drupal::service('queue')->get('custom_community_delete_queue');
          $queue->createItem([
            'action' => 'node_delete',
            'entity_id'  =>  $nid,
            'group_id'  =>  $group_id,
            'type'  => 'node'
          ]);
        }
      break;
      case 'remove_secondary_community':
        $group_id = $data['entity_id'];
        $secondary_reference_nodes_by_group_ids = \Drupal::entityTypeManager()
        ->getStorage('node')
        ->loadByProperties([
          'type' => ['reference'],
          'field_second_communities' => $group_id
        ]);
        if(count($secondary_reference_nodes_by_group_ids) > 0) {
          foreach($secondary_reference_nodes_by_group_ids as $ref_nid => $ref_node) {
            $values = \Drupal::entityQuery('node')->condition('nid', $ref_nid)->accessCheck(TRUE)->execute();
            $node_exists = !empty($values);
            \Drupal::logger('custom_community')->notice('custom_community:node_delete Node Start Deletion @nid', ['@term_id' => $nid]);
            $can_delete = TRUE;
            if($node_exists) {
              $node = \Drupal::entityTypeManager()->getStorage('node')->load($ref_nid);
              // Reference case handled differently because of the secondary communities.
              if($node->type->getValue()[0]['target_id'] == 'reference' ) {
                $field_community_id = $node->field_community->getValue()[0]['target_id'];
                if($field_community_id != $group_id) {
                  $can_delete = FALSE;
                }
              }
              if ($can_delete) { // Delete if there is no secondary community exist.
                $node->delete();
                \Drupal::logger('custom_community')->notice('custom_community:Community Node Reference @nid', ['@nid' => $ref_nid]);
              }
            }
          }
        }
      break;
    }
  }

  /**
   * Add all nodes of Group in the one Queue
   */
  public function assign_group_node_to_queue($group_id) {
    $database = Database::getConnection();
    $query = $database->select('group_relationship_field_data', 'g')
    ->fields('g')  // Select all columns from the table
    ->condition('g.type', '%node%', 'LIKE')  // WHERE type LIKE '%node%'
    ->condition('g.gid', $group_id)  // WHERE type LIKE '%node%'
    ->orderBy('g.type', 'DESC')  // ORDER BY type DESC
    ->execute();
  // Fetch results
    $results = $query->fetchAll();
    $node_ids = [];
    foreach ($results as $node) {
      // Check if the group content is associated with a node.
      $nid = $node->entity_id;
      $status = 2;  // Set to 2 for published, 0 for unpublished
      $node_ids[] = $nid;
      $database->update('node_field_data')
        ->fields(['status' => $status])  // Set the status field
        ->condition('nid', $nid)  // Apply the condition for the node ID
        ->execute();
      // Remove Community Relation Ship from revision and data table
      $query = $database->delete('node_revision__field_community');
      $query->condition('entity_id', $nid);
      $query->execute();
      $query = $database->delete('node__field_community');
      $query->condition('entity_id', $nid);
      $query->execute();
    }
    $queue = \Drupal::service('queue')->get('custom_community_delete_queue');

    // GET REFERENCE NIDS
    $query = $database->select('node__field_community', 'com')
    ->fields('com')  // Select all columns from the table
    ->condition('com.bundle', 'reference', 'LIKE')  // WHERE type LIKE '%node%'
    ->condition('com.field_community_target_id', $group_id)  // WHERE type LIKE '%node%'
    ->execute();
  // Fetch results
    $results = $query->fetchAll();
    if(count($results) > 0) {
      foreach ($results as $node) {
        // Check if the group content is associated with a node.
        $nid = $node->entity_id;
        $status = 2;  // Set to 2 for published, 0 for unpublished
        $node_ids[] = $nid;
      }
    }


    \Drupal::logger('custom_community')->notice('custom_community:add_all_nid_to_queue All Nodes @nodes', ['@nodes' => serialize($node_ids)]);

    $queue->createItem([
      'action' => 'add_all_nid_to_queue',
      'all_nid'  =>  $node_ids,
      'type' => 'assign_all',
      'group_id' => $group_id
    ]);
  }
  /**
   *assign all folder tid to queue to delete
   */
  public function assign_community_folder_to_delete_to_queue($group_id) {
    $main_community_folder_name = 'cap_com_folder_'.$group_id;
    $termStorage = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $terms = $termStorage->loadByProperties([
      'name' => $main_community_folder_name,
      'vid' => 'community_folders',
    ]);
    $all_terms = [];
    $queue = \Drupal::service('queue')->get('custom_community_delete_queue');
    if(count($terms) > 0) {
      foreach ($terms as $parentTerm) {
        $parentTermId = $parentTerm->id();
        $all_terms = $this->get_all_child_terms($parentTermId);
      }
      if(count($all_terms) > 0) {
        foreach($all_terms as $tid=>$obj) {
          $queue->createItem([
            'action' => 'delete_community_folder',
            'term_id'  =>  $tid,
            'type' => 'delete_community_folder',
          ]);
        }
      }
    }
  }


  function get_all_child_terms($parent_tid) {
    $termStorage = \Drupal::entityTypeManager()->getStorage('taxonomy_term');

    // Get direct child terms.
    $childTerms = $termStorage->loadByProperties([
      'parent' => $parent_tid,
      'vid' => 'community_folders',
    ]);

    $allChildren = [];
    foreach ($childTerms as $childTerm) {
      $allChildren[$childTerm->id()] = $childTerm;

      // Recursively get sub-child terms.
      $subChildren = $this->get_all_child_terms($childTerm->id());
      if (!empty($subChildren)) {
        $allChildren += $subChildren;
      }
    }

    return $allChildren;
    }
}

