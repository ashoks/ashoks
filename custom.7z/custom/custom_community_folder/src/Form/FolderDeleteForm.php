<?php

namespace Drupal\custom_community_folder\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Formbase.
 */
class FolderDeleteForm extends FormBase {

  /**
   * Returns a unique string identifying the list.
   *
   * The returned ID should be a unique string that can be a valid PHP function
   * name, since it's used in hook implementation names such as
   * hook_form_FORM_ID_alter().
   *
   * @return string
   *   The unique string identifying the form.
   */
  public function getFormId() {
    return 'custom_community_folder_delete_confirmation';
  }

  /**
   * Form constructor.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $gid = \Drupal::request()->query->get('community_id');
    $tid = \Drupal::request()->query->get('folderterm');
    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($tid);
    $form['description'] = [
      '#type' => 'item',
      '#markup' => $this->t('Warning! The Community Folder "' . $term->getName() . '" will be permanently deleted. Deletion cannot be undone.'),
    ];
    $form['tid'] = [
      '#type' => 'hidden',
      '#value' => $tid,
    ];
    $form['actions'] = [
      '#type' => 'actions',
    ];
    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Delete'),
    ];
    $form['actions']['cancel'] = [
      '#type' => 'button',
      '#value' => $this->t('Cancel'),
      '#attributes' => [
        'onclick' => 'window.location.replace("/folderlist?community_id=' . $gid . '");return false;',
      ],
    ];
    return $form;
  }

  /**
   * FormStateInterface.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $gid = \Drupal::request()->query->get('community_id');
    $values = $form_state->cleanValues()->getValues();
    $term_id = $values['tid'];
    // $new_term_name = $values['new_term_name'];
    $term = Term::load($term_id);
    // $term->name->setValue($new_term_name);
    $term->delete();
    $redirect_to_folderList = new RedirectResponse(URL::fromUserInput('/folderlist?community_id=' . $gid)->toString());
    $redirect_to_folderList->send();
    \Drupal::messenger()->addStatus(t($new_term_name . 'Deleted successfully.'));
  }

}
