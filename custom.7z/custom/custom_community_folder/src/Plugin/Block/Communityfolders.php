<?php

namespace Drupal\custom_community_folder\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Entity;

/**
 * Community folders block.
 *
 * @Block(
 *   id = "community_folders_block",
 *   admin_label = "Custom community folders Block"
 * )
 */
class Communityfolders extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $foldertree = '';
    $group = $this->custom_get_group();
    $group_type = '';
    $gid = '';

    if($group instanceof GroupInterface) {
      $gid = !empty($group) ? $group->id() : '';
      if ($group && isset($group) && $group != NULL) {
        $group_type = $group->get('field_community_type')->value;
      }
      else {
        $group_type = '';
      }
    }
    $term_name = 'cap_com_folder_' . $gid;
    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
      ->loadByProperties(['name' => $term_name, 'vid' => 'community_folders']);
    if (!empty($term) && isset($term)) {
      $term = reset($term);
      $term_id = $term->id();

      $vid = 'community_folders';
      // The parent term id.
      $parent_tid = $term_id;
      // 1 to get only immediate children, NULL to load entire tree
      $depth = NULL;
      // True will return loaded entities rather than ids.
      $load_entities = FALSE;
      $child_terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid, $parent_tid, $depth, $load_entities);

      $tree = $this->buildTreecommunityfolder($child_terms, $term_id, $group_type, $gid);
      $community_folder_tree = $this->arrayTofolderList($tree);
      if ($community_folder_tree == '<ul></ul>') {
        $foldertree = '<left>(None)</left>';
      }
      else {
        $foldertree = $community_folder_tree;
      }

    }
    else {
      $foldertree = '<left>(None)</left>';
    }

    return [
      '#theme' => 'custom_community_folder_block_theme',
      '#data' => $foldertree,
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }

  /**
   *
   */
  public function arrayTofolderList($in, $p = 0) {
    $CurPageURL = $_SERVER['REQUEST_URI'];
    $a = '';
    $a .= "<ul>";
    foreach ($in as $x => $v) {
      if ($p == 0) {
        // Parent li.
        if ($CurPageURL == $v['url']) {
          if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
            $a .= '<li class="py-1 border-bottom-subtel"><input type="checkbox" id="dropdown-toggle-' . $x . '" class="dropdown-toggle-checkbox"><label for="dropdown-toggle-' . $x . '"><i class="material-icons md-4">play_arrow</i></label><a class="active link-primary" href="'.$v['url'].'">'.$v['title'].'</a>'; // parent li
          } else {
            $a .= '<li class="py-1 border-bottom-subtel"><a class="active link-primary" href="'.$v['url'].'">'.$v['title'].'</a>'; // parent li
          }
        }
        else {
          if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
            $a .= '<li class="py-1 border-bottom-subtel"><input type="checkbox" id="dropdown-toggle-' . $x . '" class="dropdown-toggle-checkbox"><label for="dropdown-toggle-' . $x . '"><i class="material-icons md-4">play_arrow</i></label><a class="link-primary" href="'.$v['url'].'">'.$v['title'].'</a>'; // parent li
          }
          else {
            $a .= '<li class="py-1 border-bottom-subtel"><a class="link-primary" href="'.$v['url'].'">'.$v['title'].'</a>'; // parent li
          }
        }
      }
      if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
        $a .= $this->arrayTofolderList($v['children'], 0);
      }
    }
    $a .= "</ul>";
    return $a;
  }

  /**
   *
   */
  public function buildTreecommunityfolder($ar, $pid, $type, $gid) {
    $variables = [];
    foreach ($ar as $folder) {
      if ($folder->parents[0] == $pid) {
        $variables[$folder->tid]['title'] = $folder->name;
        $variables[$folder->tid]['url'] = '/community_folder/' . $folder->tid . '/' . $gid;
        // Using recursion.
        $children = $this->buildTreecommunityfolder($ar, $folder->tid, $type, $gid);
        if ($children) {
          $variables[$folder->tid]['children'] = $children;
        }
      }
    }
    return $variables;
  }

  /**
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   *
   */
  public function custom_get_group() {
    $group = "";
    $matches = [];
    $gid="";
    $parameters = \Drupal::routeMatch()->getParameters()->all();
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
    }
    else {
      $group_from_route = \Drupal::routeMatch()->getParameter('group');
      $group = isset($group_from_route) ? $group_from_route : "";
    }
    if (empty($group)) {
      $nid = \Drupal::routeMatch()->getRawParameter('node');
      $node = !empty($nid) ? Node::load($nid) : NULL;

      if (!empty($node) and $node->hasField('field_community')) {
        $gid = !empty($node) && !empty($node->get('field_community')) && !empty($node->get('field_community')->getValue()[0]['target_id']) ? $node->get('field_community')->getValue()[0]['target_id']: "";
      }
      //$gid = ($node) && !empty($node->get('field_community')->getValue()[0]['target_id']) ? $node->get('field_community')->getValue()[0]['target_id']: "";
      $route_name = \Drupal::routeMatch()->getRouteName();       
      if(empty($gid) && $route_name = "views_bulk_operations.execute_configurable")
      {
        $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');     
        $gid= $store->get('group_key');
      } 
      if (empty($gid)) {
        $key = \Drupal::request()->query->get('community_id');
        if (isset($key)) {
          $gid = $key;
        }
        else {
          $current_uri = \Drupal::request()->getRequestUri();
          preg_match_all('!\d+!', $current_uri, $matches);
          $gid = (isset($matches) && is_array($matches) && (array_key_exists(0,$matches[0])))? $matches[0][0]:null;
        }
      }
      if (isset($gid) && !empty($gid)) {
        $group = Group::load($gid);
      }
    }
    return $group;
  }
}
