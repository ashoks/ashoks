<?php

namespace Drupal\custom_community_folder\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Notifications controller.
 */
class CustomFolderController extends ControllerBase {

  /**
   * Handler for autocomplete request.
   */
  public function handledeluxeAutocomplete(Request $request, $gid) {
    $results = [];
    $child_tid = [];
    $term_name = 'cap_com_folder_' . $gid;

    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
      ->loadByProperties(['name' => $term_name, 'vid' => 'community_folders']);
    if (!empty($term) && isset($term)) {
      $term = reset($term);
      $term_id = $term->id();

      $vid = 'community_folders';
      // The parent term id.
      $parent_tid = $term_id;
      // 1 to get only immediate children, NULL to load entire tree
      $depth = NULL;
      // True will return loaded entities rather than ids.
      $load_entities = FALSE;
      $child_terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid, $parent_tid, $depth, $load_entities);
    }
    foreach ($child_terms as $child) {
      $child_tid[] = $child->tid;
    }
    $input = $request->query->get('q');
    // Get the typed string from the URL, if it exists.
    if (!$input) {
      return new JsonResponse($results);
    }

    $input = Xss::filter($input);
    $input = trim($input);
    if ($child_tid) {
      $query = \Drupal::database()->select('taxonomy_term_field_data', 't');
      $query->addField('t', 'tid', 'tid');
      $query->addField('t', 'name', 'name');
      $query->condition("t.name", '%' . $input . '%', 'LIKE');
      $query->condition('t.tid', $child_tid, 'IN');
      $results = $query->execute()->fetchAll();
    }
    $valuesdelux = [];
    foreach ($results as $result) {
      $val = $result->name;
      // $lable = $val . ' [' . $result->email . '] [' . $result->id . ']';
      $valuesdelux[$val . ' (' . $result->tid . ')'] = $val;
    }
    return new JsonResponse($valuesdelux);
  }

}
