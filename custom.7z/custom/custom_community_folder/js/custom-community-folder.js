(function ($, Drupal, drupalSettings) {
  $(document).ready(function () {

    $('.communityFolders.treeview li').has('ul').each(function () {
      $(this).addClass('branch');
    })

    $('.communityFolders.treeview ul').first().addClass( "d-flex flex-column gap-1" );

    $(".communityFolders .branch > ul").addClass("nested-ul ps-3");
    $(".communityFolders .branch > ul.nested-ul li").removeClass("border-bottom-subtel");
    $(".communityFolders.treeview li:not(:has(ul))").each(function () {
        $(this).addClass('no-nested py-1');
    });

    $('#block-capgemini-b5-customcommunityfoldersblock .treeview li.no-nested').on('click', function (e) {
        e.stopPropagation();
    })

    /* Hide Expand/Collapse if no Child data available */
    if ($('#communityFolders .communityFolders.treeview ul li').length != 0) {
      if ($('#communityFolders .communityFolders.treeview ul li').hasClass('branch')) {
        if ($('#communityFoldersCollapse .treeview-trigger').hasClass('hide-collapse')) {
          $('#communityFoldersCollapse .treeview-trigger').removeClass('hide-collapse');
        }
      }
      else {
        $('#communityFoldersCollapse .treeview-trigger').addClass('hide-collapse');
      }
    }

    // Adding Expand/Collapse All functionality for Community Folders Block
    $(document).on('click', '.communityFoldersButton.treeview-trigger button', function () {
      if($(this).index() == 0){
          $(this).closest('.accordion-body').find('.communityFolders.treeview input[type=checkbox]').prop('checked', true);
      }else{
          $(this).closest('.accordion-body').find('.communityFolders.treeview input[type=checkbox]').prop('checked', false);
      }
    });
    // End of Expand/Collapse All functionality for Community Folders Block
  });
})(jQuery, Drupal, drupalSettings);
