<?php
namespace Drupal\follow_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "follow_users"
 * )
 */
class D7FollowUsers extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('flag_content', 'f')
      ->fields('f', array(
      'fcid',  
      'fid',
      'content_type',
      'content_id',
      'uid',
      'sid',
      'timestamp'
      ));
	  $query->leftJoin('users', 'n', 'n.uid = f.uid');
      $query->addField('n', 'name');
      $query->addField('n', 'theme');
      $query->addField('n', 'access');
      $query->condition('f.fid', '16');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'fcid' => $this->t('FCID'),
      'Fid' => $this->t('FID'),
      'content_type' => $this->t('content_type'),
      'content_id' => $this->t('content_id'),
      'uid' => $this->t('uid'),
      'sid' => $this->t('sid'),
      'timestamp' => $this->t('timestamp')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) { 	
	  // Generate UUID 
    $uuid_service = \Drupal::service('uuid');
    $uuid = $uuid_service->generate();
    $row->setSourceProperty('name', $uuid);
    
    $row->setSourceProperty('theme', 'follow_user');
    $row->setSourceProperty('access', '0');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['fcid' => ['type' => 'integer']];
  }

}