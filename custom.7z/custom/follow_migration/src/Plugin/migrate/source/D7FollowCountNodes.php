<?php
namespace Drupal\follow_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "follow_count_nodes"
 * )
 */
class D7FollowCountNodes extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('flag_counts', 'f')
      ->fields('f', array(  
      'fid',
      'content_type',
      'content_id',
      'count',
      'last_updated'
      ));
	  $query->innerJoin('flags', 'n', 'n.fid = f.fid');
      $query->addField('n', 'name');
      $query->condition('f.fid', '4');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'Fid' => $this->t('FID'),
      'content_type' => $this->t('content_type'),
      'content_id' => $this->t('content_id'),
      'count' => $this->t('Count'),
      'last_updated' => $this->t('last_updated')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) { 	   
    $row->setSourceProperty('name', 'follow_content');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['content_id' => ['type' => 'integer']];
  }

}