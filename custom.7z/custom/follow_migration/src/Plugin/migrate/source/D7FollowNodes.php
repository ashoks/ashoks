<?php
namespace Drupal\follow_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "follow_nodes"
 * )
 */
class D7FollowNodes extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('flag_content', 'f')
      ->fields('f', array(
      'fcid',  
      'fid',
      'content_type',
      'content_id',
      'uid',
      'sid',
      'timestamp'
      ));
	    $query->innerJoin('node', 'n', 'n.nid = f.content_id');
      $query->addField('n', 'type');
      $query->addField('n', 'title');
      $query->addField('n', 'vid');
      $query->condition('fid', '4');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'fcid' => $this->t('FCID'),
      'Fid' => $this->t('FID'),
      'content_type' => $this->t('content_type'),
      'content_id' => $this->t('content_id'),
      'uid' => $this->t('uid'),
      'sid' => $this->t('sid'),
      'timestamp' => $this->t('timestamp')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) { 	
	  // Generate UUID 
    $uuid_service = \Drupal::service('uuid');
    $uuid = $uuid_service->generate();
    $row->setSourceProperty('type', $uuid);
    
    $row->setSourceProperty('title', 'follow_content');
    $row->setSourceProperty('vid', '0');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['fcid' => ['type' => 'integer']];
  }

}