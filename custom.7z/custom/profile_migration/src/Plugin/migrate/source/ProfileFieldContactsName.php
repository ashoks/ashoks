<?php
namespace Drupal\profile_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "profile_field_contacts_name"
 * )
 */
class ProfileFieldContactsName extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'id',
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_contact_name_uid'
    ];

   
    return $this->select('field_data_field_contact_name', 'a')
      ->fields('a', $fields)
      ->condition('bundle', 'field_contacts');
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'id' => $this->t('Row ID'),
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'field_contact_name_uid' => $this->t('field_contact_name_uid')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     $row->setSourceProperty('bundle', 'contacts');
     $row->setSourceProperty('language', 'en');
     return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {

    return ['id' => ['type' => 'integer']];

  }

}