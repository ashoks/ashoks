<?php
namespace Drupal\profile_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "profile_field_base_location"
 * )
 */
class ProfileFieldBaseLocation extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_base_location_value'
    ];

   
    return $this->select('field_data_field_base_location', 'a')
      ->fields('a', $fields)
      ->condition('bundle', 'user');
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'field_base_location_value' => $this->t('field_base_location_value')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     $row->setSourceProperty('language', 'en');
     return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {

    return ['entity_id' => ['type' => 'integer']];

  }

}