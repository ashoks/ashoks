<?php
namespace Drupal\profile_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "profile_field_contacts"
 * )
 */
class ProfileFieldContacts extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'id',
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_contacts_value',
      'field_contacts_revision_id'
    ];

   
    return $this->select('field_data_field_contacts', 'a')
      ->fields('a', $fields)
      ->condition('bundle', 'asset');
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'id' => $this->t('Row ID'),
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'field_contacts_value' => $this->t('field_contacts_value'),
      'field_contacts_revision_id' => $this->t('field_contacts_revision_id')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     $row->setSourceProperty('language', 'en');
     return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {

    return ['id' => ['type' => 'integer']];

  }

}