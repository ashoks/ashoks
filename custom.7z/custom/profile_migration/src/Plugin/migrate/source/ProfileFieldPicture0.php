<?php
namespace Drupal\profile_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "profile_field_picture_0"
 * )
 */
class ProfileFieldPicture0 extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'uid',
      'name',
      'created',
      'language',
      'picture'
    ];

   
    return $this->select('users', 'a')
      ->fields('a', $fields);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'uid' => $this->t('The user id this is associated with'),
      'name' => $this->t('The bundle this is associated with'),
      'created' => $this->t('Deleted'),
      'language' => $this->t('Language'),
      'picture' => $this->t('field_skills_tid')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    
     $row->setSourceProperty('created', 0);
     $row->setSourceProperty('name', 'user');
     $row->setSourceProperty('language', 'en');
     return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {

    return ['uid' => ['type' => 'integer']];

  }

}