<?php

namespace Drupal\custom_taxonomy_management\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Url;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Render\Markup;
use Drupal\taxonomy\Entity\Term;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class ListForm.
 *
 * @package Drupal\custom_taxonomy_management\Form
 */
class CustomTaxonomyListForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'community_taxonomy_list_form';
  }

  /**
   * Form constructor.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $current_uri = \Drupal::request()->getRequestUri();
    preg_match_all('!\d+!', $current_uri, $matches);
    $gid = $matches[0][0];
    $taxonomy_tree = [];
    if ($gid) {
      $term_name = 'cap_com_tax_' . $gid;
      $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
        ->loadByProperties(['name' => $term_name, 'vid' => 'community_taxonomy']);
      $community_taxonomy_id = isset(array_keys($term)[0]) ? array_keys($term)[0] : '';
      $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
      $taxonomy_tree = $manager->loadTree(
      // The taxonomy term vocabulary machine name.
      'community_taxonomy',
      // The "tid" of parent using "0" to get all.
      $community_taxonomy_id,
      // Get all available levels.
      1,
      // Get full load of taxonomy term entity.
      FALSE
      );
    }

    $form['title']['#prefix'] = '<div><h2 class="h4">Manage Community Taxonomy</h2>';
    $form['title']['#suffix'] = '</div>';

    if ($taxonomy_tree && !empty($taxonomy_tree)) {
      $form['table'] = array(
        '#type' => 'table',
        '#header' => array(t('Name'), array('data' => t('Operations')), t('Weight')),
        '#attributes' => array(
          'id' => 'community-taxonomy-table',
        ),
        '#tabledrag' => [
          [
            'action' => 'match',
            'relationship' => 'parent',
            'group' => 'taxo-parent',
            'subgroup' => 'taxo-parent',
            'source' => 'taxo-id',
            'hidden' => FALSE,
            'limit' => 3,
          ],
          [
            'action' => 'order',
            'relationship' => 'sibling',
            'group' => 'taxo-weight',
          ],
        ],
      );

      foreach ($taxonomy_tree as $row => $child) {
        $form['table'][$row]['#weight'] = $child->weight;
        $form['table'][$row]['#tid'] = $child->tid;
        $form['table'][$row]['title'] = array(
          '#type' => 'item',
          '#markup' => $child->name,
        );
        $form['table'][$row]['edit'] = array(
          '#type' => 'link',
          '#title' => t('Edit'),
          '#url' => Url::fromUserInput('/community/' . $gid . '/admin/taxonomy/community_taxonomy/edit/' . $child->tid),
          '#attributes' => ['class' => 'community-taxo-edit'],
        );
        $form['table'][$row]['#attributes']['class'][] = 'draggable';
        $form['table'][$row]['weight'] = array(
          '#type' => 'textfield',
          '#title' => t('Weight for @title', array('@title' => $child->name)),
          '#title_display' => 'invisible',
          '#size' => 4,
          '#default_value' => $child->weight,
          '#attributes' => array('class' => array('taxo-weight')),
        );
        $form['table'][$row]['id'] = [
          '#type' => 'hidden',
          '#value' => $child->tid,
          '#attributes' => ['class' => ['taxo-id']],
        ];
        $form['table'][$row]['parent'] = [
          '#type' => 'hidden',
          '#default_value' => $child->parents['0'],
          '#attributes' => ['class' => ['taxo-parent']],
        ];
      }
      $form['actions'] = [
        '#type' => 'actions',
      ];
      $form['actions']['test_link'] = [
        '#type' => 'link',
        '#title' => $this->t('Add Taxonomy Field'),
        '#url' => Url::fromUserInput('/community/' . $gid . '/admin/taxonomy/community_taxonomy/add'),
      ];

      if (count($taxonomy_tree) > 1) {
        // Add a submit button that handles the submission of the form.
        $form['actions']['submit'] = [
          '#type' => 'submit',
          '#value' => $this->t('Save'),
        ];
      }
    }
    else {
      $form['break_tag'] = [
        '#type' => 'markup',
        '#markup' => '<br/><br/>',
      ];
      $form['empty'] = [
        '#type' => 'label',
        '#title' => Markup::create('<h5>No terms available.</h5>'),
      ];
      $form['actions'] = [
        '#type' => 'actions',
      ];
      $form['actions']['test_link'] = [
        '#type' => 'link',
        '#title' => $this->t('Add Taxonomy Field'),
        '#url' => Url::fromUserInput('/community/' . $gid . '/admin/taxonomy/community_taxonomy/add'),
      ];
    }
    // return (\Drupal::routeMatch()->getRouteName() == 'custom_taxonomy_management.ctm_list_form')?$form:[];
    return $form;
  }

  /**
   * Function for Form Submit.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Here we process the form and do what needs to be done.
    // Show all form values as status message.
    $db = \Drupal::service('database');
    $complete_form = &$form_state->getCompleteForm();
    foreach ($complete_form['table'] as $table) {
      if (is_array($table) && array_key_exists('#tid', $table)) {
        $num_updated = $db->update('taxonomy_term_field_data')
          ->fields([
            'weight' => $table['weight']['#value'],
          ])
          ->condition('tid', $table['#tid'])
          ->execute();
        \Drupal::messenger()->addStatus(t('Community Taxonomy have been updated successfully.'));
      }
    }
    // $gid = $form['actions']['submit']['#gid'];
    $current_uri = \Drupal::request()->getRequestUri();
    $path_args = explode('/', $current_uri);
    $gid = $path_args[2];
    $response = new RedirectResponse("/community/" . $gid . "/admin/taxonomy/community_taxonomy");
    $response->send();
  }

}
