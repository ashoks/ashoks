<?php
namespace Drupal\custom_taxonomy_management\Form;

use Drupal\node\NodeInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\group\Entity\GroupInterface;
use Drupal\Core\Render\Markup;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\MessageCommand;
use Drupal\Core\Ajax\ReplaceCommand;

/**
 * Class CustomTaxonomyManagementForm.
 *
 * @package Drupal\custom_taxonomy_management\Form
 */
class CustomTaxonomyManagementForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'taxonomy_term_community_taxonomy_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    /**
     * @file
     * The block for group, which controls the output of Drupal 7.
     */

    define("TAGS_VID", 6);
    define("ENGLISH_TID", 29);
    define("CATEGORY_TID", 5);
    define("STRATEGIC_BUSINESS_UNIT_TID", 19);
    define("COUNTRY_TID", 2);
    define("SERVICE_OFFER_TID", 20);
    define("SECTOR_TID", 8);
    define("TLI_PRACTICE_TID", 277);
    define("TECHNOLOGY_TID", 278);
    // System Tag.
    define("SYSTEM_TAG_VID", 6);
    // Community Folder.
    define("COMMUNITY_FOLDER_TID", 275);
    // Community Folder.
    define("COMMUNITY_FOLDER_NAME", 'community_folders');
    // Community Taxonomy.
    define("COMMUNITY_TAXONOMY_TID", 276);
    // Community Taxonomy.
    define("COMMUNITY_TAXONOMY_NAME", 'community_taxonomy');
    // Max number of community taxonomy for each community.
    define("COMMUNITY_TAXONOMY_MAX", 6);
    $nid = $term_edit_id = $optionval = '';
    $flag = 0;
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $entity_type = $path_args[1];
    $gid = $path_args[2];
    $vob = $path_args[5];

    if ($gid == "edit" || $gid == "add") {
      $gid = "";
    }

    $group = \Drupal::routeMatch()->getParameter('gid');
    if ($group instanceof GroupInterface) {
      /** @var \Drupal\group\Entity\GroupTypeInterface $group_type */
      $group_type = $group->getGroupType()->id();
      $gid = $group->id();
      $field_community_type = $group->get('field_community_type')->value;
    }

    if (empty($gid)) {
      $gid = \Drupal::request()->get('og_group_ref');
    }

    if (empty($gid)) {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node instanceof NodeInterface) {
        $group = $node->get('field_community')->getValue();
        $gid = $group[0]['target_id'];
      }
    }

    if ($vob === 'community_taxonomy') {
      $root = taxonomy_term_load_multiple_by_name('cap_com_tax_' . $gid, COMMUNITY_TAXONOMY_NAME);
      $parent = "";

      foreach ($root as $term) {
        $parent = $term->getName();
        $parent_id = $term->id();
      }

      if ($parent == "") {
        // Create the taxonomy term.
        $root_term = Term::create([
          'name' => 'cap_com_tax_' . $gid,
          'vid' => $vob,
          'parent' => [],
          'field_gid' => $gid,
        ]);

        // Save the taxonomy term.
        $root_term->save();
        $parent = $root_term->id();
      }
    }

    $community_taxonomy_id = getTidByName('cap_com_tax_' . $gid, "community_taxonomy");
    $community_taxonomy_id = $community_taxonomy_id ?? NULL;

    if (in_array("edit", $path_args)) {
      $label_form = "Edit";

      $term_edit_id = ($path_args[7]) ? $path_args[7] : "";

      $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
      $taxonomy_tree = $manager->loadTree(
      // The taxonomy term vocabulary machine name.
        'community_taxonomy',
        // The "tid" of parent using "0" to get all.
        $community_taxonomy_id,
        // Get all available levels.
        NULL,
        // Get full load of taxonomy term entity.
        TRUE
      );
      $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term_edit_id);
      if ($term) {
        $optionval = ($term->hasField('field_option_value')) ? $term->get('field_option_value')->value[0] : 0;
      }
      $results = [];
      $resultDetails = [];
      $name = "";
      $tid = "";

      foreach ($taxonomy_tree as $term) {
        $existing_tid = $term->id();

        if ($term_edit_id == $existing_tid) {
          // $vid_rf = $vid_rf->id();
          $name = $term->getName();
          $tid = $term->id();

          $vid_rf = Vocabulary::load('community_taxonomy');
          $vid_rf = $vid_rf->id();
          $portfolio_parents = \Drupal::service('entity_type.manager')
            ->getStorage("taxonomy_term")
            ->loadTree($vid_rf, $tid, $max_depth = 1, $load_entities = FALSE);
          $parents_rf = [];
          $parent_terms_rf = [];
          $parent_term_val = [];

          foreach ($portfolio_parents as $key => $term) {
            $term_node = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term->tid);
            // Remove PHP warning Undefined property: stdClass::$field_exclude.
            $exclude = $term_node->field_exclude ?? "";

            if ($flag == 0) {
              $parents_rf[$term->tid]['name'] = $term->name;
              $parents_rf[$term->tid]['weight'] = $term->weight;
              $parent_terms_rf[] = $term->tid;
              $parent_term_val[] = $term->name;
            }
          }

          $term_value = implode(",", $parent_term_val);
        }
      }
    }
    else {
      $label_form = "Add";
    }
    $options = array(0 => "Single Value", 1 => "Multiple Values");
    $form['title'] = [
      '#type' => 'label',
      '#title' => Markup::create('<h4 class="title">' . $label_form . ' Taxonomy Field</h4>'),
    ];

    $form['name'] = [
      '#type' => 'textfield',
      '#title' => t('Name'),
      '#size' => 60,
      '#maxlength' => 128,
      '#required' => TRUE,
      '#default_value' => ($label_form == "Edit") ? $name : '',
      '#attributes' => ['placeholder' => ''],
    ];

    if ($vob == COMMUNITY_TAXONOMY_NAME) {
      $form['field_type'] = [
        '#type' => 'radios',
        '#title' => t('Type'),
        '#options' => $options,
        '#default_value' => ($optionval != NULL) ? $optionval : 0,
        '#required' => TRUE,
      ];
      $form['field_values'] = [
        '#type' => 'textarea',
        '#title' => t('Values'),
        '#required' => ($label_form == "Edit") ? FALSE : TRUE,
        '#rows' => 3,
        '#description' => t('Use comma as a separator between values.'),
        '#default_value' => '',
      ];
    }

    if (isset($parents_rf)) {
      $form["name_tax"]["#tree"] = TRUE;
      foreach ($parents_rf as $k => $term) {
        $form['name_tax' . $k][$k]['name_' . $k] = [
          '#type' => 'textfield',
          '#title' => t(''),
          '#size' => 60,
          '#maxlength' => 128,
          '#required' => FALSE,
          '#default_value' => ($term) ? $term['name'] : '',
          '#prefix' => '<div class="community-taxonomy d-flex gap-3">',
        ];
        $form['name_tax'][] = [
          '#type' => 'hidden',
          '#value' => $k,
        ];

        $form['name_tax' . $k][$k]['weight_' . $k] = [
          '#type' => 'weight',
          '#title' => t(''),
          '#default_value' => $term['weight'],
          '#delta' => 10,
        ];

        /*
        $form['table'][$row]['weight'] = array(
        '#type' => 'textfield',
        '#title' => t('Weight for @title', array('@title' => $child->name)),
        '#title_display' => 'invisible',
        '#size' => 4,
        '#default_value' => $child->weight,
        '#attributes' => array('class' => array('taxo-weight')),
        );
         */

        $form['comunity_tax_delete' . $k][$k] = [
          '#type' => 'button',
          '#value' => $this->t('Delete'),
          '#name' => $k,
          '#attributes' => array(
            'class' => 'delete-community-taxonomy-button',
          ),
          '#ajax' => [
            'callback' => [$this, 'delete_taxonomy_term_by_id'],
            'event' => 'click',
            'progress' => [
              'type' => 'throbber',
            ],
          ],
          '#suffix' => '</div>',
        ];
      }
    }

    $form['vid'] = [
      '#type' => 'hidden',
      '#value' => $vob,
    ];
    $form['pid'] = [
      '#type' => 'hidden',
      '#value' => $parent,
    ];

    $form['gid'] = [
      '#type' => 'hidden',
      '#value' => $gid,
    ];

    $form['tax_options'] = [
      '#type' => 'hidden',
      '#value' => $nid,
    ];

    $form['tid'] = [
      '#type' => 'hidden',
      '#value' => $community_taxonomy_id,
    ];

    $form['term_edit_id'] = [
      '#type' => 'hidden',
      '#value' => $term_edit_id,
    ];

    $form['label_form'] = [
      '#type' => 'hidden',
      '#value' => $label_form,
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => t('Save'),
      '#vid' => $vob,
      '#gid' => $gid,
      '#tid' => $community_taxonomy_id,
      '#label_form' => $label_form,
      '#term_edit_id' => $term_edit_id,
      '#field_type' => $options,
      '#attributes' => array(
        'class' => 'pull-left',
      ),
    ];

    if ($term_edit_id) {
      $form['actions']['delete_ct'] = array(
        '#markup' => '<a href="/community/' . $gid . '/admin/taxonomy/community_taxonomy/delete/' . $term_edit_id . '" class="secondary-btn small pull-left mr-2 btn-primary">Delete</a>',
      );
    }

    $form['actions']['cancel'] = [
      '#type' => 'button',
      '#value' => $this->t('Cancel'),
      '#attributes' => array(
        'onclick' => 'window.location.replace("/community/' . $gid . '/admin/taxonomy/community_taxonomy");return false;',
        'class' => 'pull-left',
      ),
    ];
    return $form;
  }

  /**
   * Utility: find term by name and vid.
   *
   * @param string $name
   *   Term name.
   * @param string $vid
   *   Term vid.
   *
   * @return int
   *   Term id, or 0 if none.
   */
  public function getTidByName($name = NULL, $vid = NULL) {
    if (empty($name) || empty($vid)) {
      return 0;
    }
    $properties = [
      'name' => $name,
      'vid' => $vid,
    ];
    $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
    $term = array_shift($terms);
    return !empty($term) ? $term->id() : 0;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function deleteTaxonomyTerm($delete_tid, $tableName) {
    $query = \Drupal::database()->delete($tableName);
    $query->condition('tid', $delete_tid);
    $query->execute();

    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function updateTaxonomyTerm($update_tid, $update_val, $field_type) {
    $term = Term::load($update_tid);
    if ($term) {
      $term->name->setValue($update_val);
      $term->field_option_value->setValue($field_type);
      $term->Save();
      return TRUE;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function updateCustomTaxonomyTerm($update_tid, $update_val, $field_type, $field_weight) {
    $term = Term::load($update_tid);
    if ($term) {
      $term->name->setValue($update_val);
      $term->field_option_value->setValue($field_type);
      $term->weight->setValue($field_weight);
      $term->Save();
      return TRUE;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $vocabulary = $form_state->getValue('vid');
    $parent = $form_state->getValue('pid');
    $gid = $form_state->getValue('gid');
    // First lavel term id part of url.
    $term_edit_id = $form_state->getValue('term_edit_id');
    $tid = $form_state->getValue('tid');
    $label_form = $form_state->getValue('label_form');

    if ($form['actions']['submit']['#vid'] === 'community_taxonomy') {
      $field_values = $form_state->getValue('field_values');
      $field_type = $form_state->getValue('field_type');
      $tid = $form_state->getValue('tid');

      if (isset($label_form) && ($label_form == "Edit")) {
        $vid_rf = Vocabulary::load('community_taxonomy');
        $vid_rf = $vid_rf->id();
        $portfolio_parents = \Drupal::service('entity_type.manager')
          ->getStorage("taxonomy_term")
          ->loadTree($vid_rf, $tid, $max_depth = 1, $load_entities = FALSE);
        $parents_rf = [];
        $parent_terms_rf = [];
        $parent_term_val = [];
        $outside_tid = "";
        foreach ($portfolio_parents as $key => $term) {
          // Since this will be always single value so use it outside the loop to add values as well as parent.
          if (isset($term_edit_id) && ($term_edit_id == $term->tid)) {
            $update_tid = $term->tid;
            $outside_tid = $term->tid;
            $update_val = $name;

            $this->updateTaxonomyTerm($update_tid, $update_val, $field_type);
          }
        }

        $term_id = $form_state->getValue('name_tax');
        $update_val = [];

        foreach ($term_id as $tid) {
          $update_val[] = $form_state->getValue($tid);
          $this->updateCustomTaxonomyTerm($tid, $form_state->getValue('name_' . $tid), $field_type, $form_state->getValue('weight_' . $tid));
        }

        // foreach ($update_val as $v => $val) {.
        //     $update_tid = $v;
        //     $update_val = $val;
        //     $this->updateTaxonomyTerm($update_tid, $update_val, $field_type);
        // }.
        // Here handling the add condition while editing.
        $term_child_arr = ($field_values) ? explode(',', $field_values) : [];
        if (count($term_child_arr) > 0) {
          $i = 0;
          foreach ($term_child_arr as $child_name) {
            // Create the taxonomy term.
            $child = Term::create([
              'name' => $child_name,
              'vid' => $vocabulary,
              'parent' => $outside_tid,
              'field_gid' => $gid,
              'field_option_value' => $field_type,
              'weight' => $i++,
            ]);

            // Save the taxonomy term.
            $child->save();
          }
        }

        \Drupal::messenger()->addMessage('Taxonomy Term "' . $name . '"' . ' has been updated successfully.');
      }
      else {
        // Add condition for taxonomy term
        // Create the taxonomy term.
        $term = Term::create([
          'name' => $name,
          'vid' => $vocabulary,
          'parent' => $tid,
          'field_gid' => $gid,
          'field_values' => $field_values,
          'field_option_value' => $field_type,
          'field_type' => $field_type,
        ]);

        // Save the taxonomy term.
        $term->save();

        $term_child_arr = ($field_values) ? explode(',', $field_values) : [];
        if (count($term_child_arr) > 0) {
          $i = 0;
          foreach ($term_child_arr as $child_name) {
            // Create the taxonomy term.
            $child = Term::create([
              'name' => trim($child_name),
              'vid' => $vocabulary,
              'parent' => $term->id(),
              'field_gid' => $gid,
              'field_option_value' => $field_type,
              'weight' => $i++,
            ]);

            // Save the taxonomy term.
            $child->save();
          }
        }

        \Drupal::messenger()->addMessage('Taxonomy Term "' . $name . '"' . ' has been created successfully.');
      }
    }

    $gid = $form['actions']['submit']['#gid'];

    $response = new RedirectResponse("/community/" . $gid . "/admin/taxonomy/community_taxonomy");
    $response->send();
  }

  /**
   * {@inheritdoc}
   */
  public function delete_taxonomy_term_by_id(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $term_id = $form_state->getTriggeringElement()['#name'];
    $term = Term::load($term_id);
    $term->delete();
    unset($form['name_tax' . $term_id][$term_id]);
    unset($form['comunity_tax_delete' . $term_id][$term_id]);
    $response->addCommand(new ReplaceCommand('.taxonomy-term-community-taxonomy-form', $form));
    $response->addCommand(new MessageCommand('Community Taxonomy ' . $term->getName() . ' is deleted successfully.'));
    return $response;
  }

}
