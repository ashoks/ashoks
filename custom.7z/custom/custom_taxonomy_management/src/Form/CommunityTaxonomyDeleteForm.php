<?php

namespace Drupal\custom_taxonomy_management\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class DeleteForm.
 *
 * @package Drupal\custom_taxonomy_management\Form
 */
class CommunityTaxonomyDeleteForm extends ConfirmFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'community_taxonomy_delete_form';
  }

  public $group;
  public $tid;

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {
    return new Url('custom_taxonomy_management.ctm_list_form', ['gid' => $this->group]);
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $group = NULL, $tid = NULL) {
    $this->group = $group;
    $this->tid = $tid;
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // $form_state->setRedirect('custom_taxonomy_management.ctm_controller_display');
    $community_taxonomy_id = getTidByName('cap_com_tax_' . $this->group, "community_taxonomy");
    $community_taxonomy_id = $community_taxonomy_id ?? NULL;
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $taxonomy_tree = $manager->loadTree(
      // The taxonomy term vocabulary machine name.
      'community_taxonomy',
      // The "tid" of parent using "0" to get all.
      $community_taxonomy_id,
      // Get all available levels.
      NULL,
      // Get full load of taxonomy term entity.
      TRUE
    );
    $name = "";
    foreach ($taxonomy_tree as $term) {
      if ($term->id() == $this->tid) {
        $name = $term->getName();
      }
    }

    $term = \Drupal\taxonomy\Entity\Term::load($this->tid);
    $term->delete();

    \Drupal::messenger()->addStatus(t('Term "@title" has been deleted.', ['@title' => $name]));
    (new RedirectResponse('/community/' . $this->group . '/admin/taxonomy/community_taxonomy'))->send();
    exit();
  }

  /**
   * Function for getQuestion.
   */
  public function getQuestion() {
    // $form_state->setRedirect('custom_taxonomy_management.ctm_controller_display');
    $community_taxonomy_id = getTidByName('cap_com_tax_' . $this->group, "community_taxonomy");
    $community_taxonomy_id = $community_taxonomy_id ?? NULL;
    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    $taxonomy_tree = $manager->loadTree(
      // The taxonomy term vocabulary machine name.
      'community_taxonomy',
      // The "tid" of parent using "0" to get all.
      $community_taxonomy_id,
      // Get all available levels.
      NULL,
      // Get full load of taxonomy term entity.
      TRUE
    );

    $name = $taxonomy_tree[0]->getName();
    return $this->t('Are you sure you want to delete the term @name?', ['@name' => $name]);
  }

}
