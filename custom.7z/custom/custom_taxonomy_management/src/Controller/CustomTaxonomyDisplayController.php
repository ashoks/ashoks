<?php

namespace Drupal\custom_taxonomy_management\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\Core\Render\Markup;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\custom_taxonomy_management\Controller
 */
class CustomTaxonomyDisplayController extends ControllerBase {

  /**
   *
   */
  public function getContent() {
    // First we'll tell the user what's going on. This content can be found
    // in the twig template file: templates/description.html.twig.
    // @todo Set up links to create nodes and point to devel module.
    $build = [
      'description' => [
        '#theme' => 'custom_taxonomy_management_description',
        '#description' => 'foo',
        '#attributes' => [],
      ],
    ];
    return $build;
  }

  /**
   * Method to get the sector taxonomy.
   */
  public function custom_taxonomy($community_taxonomy) {
    $options = '';
    foreach ($community_taxonomy as $sector) {
      if ($sector->depth == 0) {
        $parent_terms_list['parent'][$sector->tid] = $sector->name;
      }
      elseif ($sector->depth == 1) {
        $parent_terms_list['child'][$sector->tid] = $sector->name;
      }
      elseif ($sector->depth == 2) {
        $parent_terms_list['subchild'][$sector->tid] = $sector->name;
      }
    }
    return $parent_terms_list;
  }

  /**
   * Utility: find term by name and vid.
   *
   * @param string $name
   *   Term name.
   * @param string $vid
   *   Term vid.
   *
   * @return int
   *   Term id, or 0 if none.
   */
  public function getTidByName($name = NULL, $vid = NULL) {
    if (empty($name) || empty($vid)) {
      return 0;
    }
    $properties = [
      'name' => $name,
      'vid' => $vid,
    ];
    $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
    $term = array_shift($terms);
    return !empty($term) ? $term->id() : 0;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display($gid) {
    $community_taxonomy_id = getTidByName('cap_com_tax_' . $gid, "community_taxonomy");
    $community_taxonomy_id = $community_taxonomy_id ?? NULL;

    $manager = \Drupal::entityTypeManager()->getStorage('taxonomy_term');

    $taxonomy_tree = [];
    if ($community_taxonomy_id > 0) {
      $taxonomy_tree = $manager->loadTree(
        // The taxonomy term vocabulary machine name.
        'community_taxonomy',
        // The "tid" of parent using "0" to get all.
        $community_taxonomy_id,
        // Get all available levels.
        NULL,
        // Get full load of taxonomy term entity.
        TRUE
      );
    }

    $results_terms = [];
    $results = [];

    foreach ($taxonomy_tree as $term) {
      // Check if has children or not to validate if is at last level.
      if (!empty($manager->loadChildren($term->id()))) {
        $results[$term->id()] = $term->getName();
      }
    }

    // Create table header.
    $header_table = [
      'name' => t('Name'),
      'opt' => t('Operations'),
    ];

    $rows = [];

    foreach ($results as $key => $data) {
      // custom_taxonomy_management.ctm_edit_form.
      $edit = Url::fromUserInput('/community/' . $gid . '/admin/taxonomy/community_taxonomy/edit/' . $key);
      // $url = Url::fromRoute('custom_taxonomy_management.ctm_edit_form');
      $link = Link::fromTextAndUrl(t('Edit'), $edit);
      // Get the link string:
      $link_string = $link->toString();
      $rows[] = [
        'name' => $data,
        $link_string,
      ];
    }

    $form['title'] = [
      '#type' => 'label',
      '#title' => Markup::create('<h4 class="title">Manage Community Taxonomy</h4>'),
    ];

    $form['table'] = [
      '#type' => 'table',
      '#header' => $header_table,
      '#rows' => $rows,
      '#empty' => t('No Community Taxonomy Added'),
    ];

    $form['test_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Add Taxonomy Field'),
      '#url' => Url::fromUserInput('/community/' . $gid . '/admin/taxonomy/community_taxonomy/add'),
      '#attributes' => ['class' => 'secondary-btn small add pull-right'],
    ];

    return $form;
  }

}
