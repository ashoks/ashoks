<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * d7_node_field_data_reference source.
 *
 * @MigrateSource(
 *   id = "d7_node_field_data_reference"
 * )
 */
class D7NodeFieldDataReference extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    
      $query = $this->select('node', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'type',
      'language',
      'title',
      'uid',
      'status',
      'created',
      'changed',
      'comment',
      'promote',
      'sticky',
      'tnid',
      'translate'
      ))
      ->condition('n.type', 'reference');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
 
    
    $row->setSourceProperty('language', 'en');
    $row->setSourceProperty('tnid', 1);
    $row->setSourceProperty('translate', 1);
 
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(

      'nid' => $this->t('nid'),
      'vid' => $this->t('vid'),
      'type' => $this->t('type'),
      'language' => $this->t('language'),
      'title' => $this->t('title'),
      'uid' => $this->t('uid'),
      'status' => $this->t('status'),
      'created' => $this->t('created'),
      'changed' => $this->t('changed'),
      'comment' => $this->t('comment'),
      'promote' => $this->t('promote'),
      'sticky' => $this->t('sticky'),
      'tnid' => $this->t('tnid'),
      'translate' => $this->t('translate')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}