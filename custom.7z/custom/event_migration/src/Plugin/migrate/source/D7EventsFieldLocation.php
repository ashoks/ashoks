<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_location source.
 *
 * @MigrateSource(
 *   id = "event_1_field_location"
 * )
 */
class D7EventsFieldLocation extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('field_data_field_location', 'n')
      ->fields('n', array(
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_location_value'
      ));
      
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'field_location_value' => $this->t('Field location value')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['entity_id']['type'] = 'integer';
    return $ids;
  }
   
}