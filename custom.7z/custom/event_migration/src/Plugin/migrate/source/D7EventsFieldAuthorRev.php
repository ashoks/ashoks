<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_author_revision source.
 *
 * @MigrateSource(
 *   id = "event_1_field_author_revision"
 * )
 */
class D7EventsFieldAuthorRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node_revision', 'n')
      ->fields('n', array(
      'status',
      'nid',
      'vid',
      'log',
      'uid',
      'comment'
      ));
      $query->innerJoin('users', 'u', 'u.uid = n.uid');
      $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      $query->addField('fdfn', 'field_name_first_value');
      $query->addField('fdln', 'field_name_last_value');
      $query->addField('u', 'mail');
      $query->addField('u', 'name');
      $query->addField('u', 'uid');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     $full_name = $row->getSourceProperty('field_name_first_value')." ".$row->getSourceProperty('field_name_last_value');
     $mail = $row->getSourceProperty('mail');
     $uid = $row->getSourceProperty('uid');

     $nid = $row->getSourceProperty('nid');


      // Get the group type from field_data_field_og_subscribe_settings

      $query_node = $this->select('node', 'nd')
      ->fields('nd', array(
      'type'
      ))
      ->condition('nd.nid', $nid);

      $result_node = $query_node->execute()->fetchObject();

      $node_type = $result_node->type;

      if($node_type == "group" || $node_type == "notification" || $node_type == "engagement" || $node_type == "node_gallery_gallery" || $node_type == "node_gallery_item" || $node_type == "poll" || $node_type == "webform" || $node_type == "wiki")
      {
      return false;
      }


     

     $formatted_submitter = $full_name."[".$mail."][".$uid."]";

     $field_dummy_submitter_value = $row->getSourceProperty('uid');
     $row->setSourceProperty('uid', $field_dummy_submitter_value);

      // Adding changes for handling the book case for comm. pages
      if($node_type == "book"){
       $row->setSourceProperty('comment', "pages");
      } else {
       $row->setSourceProperty('comment', $node_type);
      }


     $status = $row->getSourceProperty('status');
     $row->setSourceProperty('status', 0);
     $row->setSourceProperty('log', 'en');


   
    $row->setSourceProperty('comment', $node_type);

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity revision'),
      'log' => $this->t('language'),
      'delta' => $this->t('delta'),
      'uid' => $this->t('uid'),
      'status' => $this->t('status'),
      'comment' => $this->t('comment')

    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['vid']['type'] = 'integer';
    return $ids;
  }
   
}