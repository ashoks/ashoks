<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_offset_url_revision source.
 *
 * @MigrateSource(
 *   id = "event_1_field_offset_url_revision"
 * )
 */
class D7EventsFieldOffsetUrlRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('field_revision_field_offsite_url', 'n')
      ->fields('n', array(
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_offsite_url_value',
      'field_offsite_url_format'
      ))
      ->condition('bundle', 'event');
      
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

   
    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'field_offsite_url_value' => $this->t('Field offsite url value'),
      'field_offsite_url_format' => $this->t('Field offsite url format')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['revision_id']['type'] = 'integer';
    return $ids;
  }
   
}