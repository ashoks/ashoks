<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_content_files_managed source.
 *
 * @MigrateSource(
 *   id = "event_1_field_content_files_managed"
 * )
 */
class D7EventsFiles extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('file_managed', 'f')
      ->fields('f')
      ->orderBy('f.fid');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Generate UUID 
    $uuid_service = \Drupal::service('uuid');
    $uuid = $uuid_service->generate();
    $row->setSourceProperty('origname', $uuid);
    
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'fid' => $this->t('FID from File Managed'),
      'uid' => $this->t('uid'),
      'filename' => $this->t('filename'),
      'uri' => $this->t('uri'),
      'filemime' => $this->t('filemime'),
      'filesize' => $this->t('filesize'),
      'status' => $this->t('status'),
      'timestamp' => $this->t('timestamp'),
      'type' => $this->t('type'),
      'origname' => $this->t('origname'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['fid']['type'] = 'integer';
    return $ids;
  }
   
}