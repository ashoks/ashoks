<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_node_counter_cap source.
 *
 * @MigrateSource(
 *   id = "event_1_node_counter_cap"
 * )
 */
class D7NodeCounterCap extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {

    // SELECT visitors_nid, COUNT(visitors_id) as count_id FROM `visitors` WHERE visitors_type = 'reference' or visitors_type = 'asset' or visitors_type = 'book' or visitors_type = 'news' or visitors_type = 'event' GROUP BY visitors_nid;
      $query = $this->select('cap_node_counter', 'n')
      ->fields('n', array(
      'nid',
      'totalcount',
      'timestamp'
      ));


      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $nid = $row->getSourceProperty('nid');
    $query_node = $this->select('visitors', 'nd')
      ->fields('nd', array(
        'visitors_date_time',
      ))
      ->condition('nd.visitors_nid', $nid);
      $result_node = $query_node->execute()->fetchObject();

      $timestamp = $result_node->visitors_date_time;
      
    $row->setSourceProperty('timestamp', $timestamp);
 
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'totalcount' => $this->t('totalcount'),
      'timestamp' => $this->t('unix timestamp')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}