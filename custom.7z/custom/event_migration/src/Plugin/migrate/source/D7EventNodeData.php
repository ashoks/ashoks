<?php
namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate\Plugin\migrate\source\SqlBase;


/**
 * Drupal 7 news articles from database.
 *
 * Example:
 *
 * @code
 * source:
 *   plugin: event_1_node_data
 *
 * @MigrateSource(
 *   id = "event_1_node_data",
 * )
 */
class D7EventNodeData extends SqlBase {
 
  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('node', 'n');
    $query->fields('n', ['nid', 'title', 'vid', 'type', 'language', 'uid', 'created', 'changed']);
    $query->condition('n.type', "event");
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
        'nid' => t('Node Id'),
        'title' => t('Article Title'),
        'vid' => t("Revision ID"), 
        'type' => t("Bundle Type"),
        'language' => t('Language Code'), 
        'uid' => t('User ID'),
        'created' => t('Created'),
        'changed' => t('Changed'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }

   

}
