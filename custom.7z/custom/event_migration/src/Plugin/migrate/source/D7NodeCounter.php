<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_node_counter source.
 *
 * @MigrateSource(
 *   id = "event_1_node_counter"
 * )
 */
class D7NodeCounter extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {

    // SELECT visitors_nid, COUNT(visitors_id) as count_id FROM `visitors` WHERE visitors_type = 'reference' or visitors_type = 'asset' or visitors_type = 'book' or visitors_type = 'news' or visitors_type = 'event' GROUP BY visitors_nid;
      $query = $this->select('visitors', 'n')
      ->fields('n', array(
      'visitors_nid',
      'visitors_id',
      'visitors_date_time'
      ));
      $query->addExpression('COUNT(n.visitors_id)', 'visitors_id_count');
      $query->groupBy('n.visitors_nid');

      $orGroup1 = $query->orConditionGroup()
      ->condition('n.visitors_type', 'asset')
      ->condition('n.visitors_type', 'reference')
      ->condition('n.visitors_type', 'news')
      ->condition('n.visitors_type', 'book')
      ->condition('n.visitors_type', 'event');

      $query->condition($orGroup1);


      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'visitors_nid' => $this->t('Entity ID'),
      'visitors_id_count' => $this->t('totalcount'),
      'visitors_date_time' => $this->t('unix timestamp')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['visitors_nid']['type'] = 'integer';
    return $ids;
  }
   
}