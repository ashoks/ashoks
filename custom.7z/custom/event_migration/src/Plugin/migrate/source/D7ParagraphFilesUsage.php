<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * d7_events_field_content_files_usage source.
 *
 * @MigrateSource(
 *   id = "d7_events_field_content_files_usage"
 * )
 */
class D7ParagraphFilesUsage extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('file_usage', 'f')
      ->fields('f')
      ->orderBy('f.fid');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $row->setSourceProperty('type', 'paragraph');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'fid' => $this->t('FID from File Managed'),
      'module' => $this->t('File'),
      'type' => $this->t('Paragraph'),
      'id' => $this->t('Paragraph Item Table ID'),
      'count' => $this->t('No of Files Usage'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['fid']['type'] = 'integer';
    return $ids;
  }
   
}