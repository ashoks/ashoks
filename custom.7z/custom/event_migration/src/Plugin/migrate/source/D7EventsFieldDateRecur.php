<?php
namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "event_1_field_date_recur"
 * )
 */
class D7EventsFieldDateRecur extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_date_value',
      'field_date_value2',
      'field_date_timezone',
      'field_date_rrule'
    ];
    return $this->select('field_data_field_date', 'a')
      ->fields('a', $fields)
      ->condition('deleted', 0);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'field_date_value' => $this->t('Field Date Start Date'),
      'field_date_value2' => $this->t('Field Date End Date'),
      'field_date_timezone' => $this->t('Field Date Timezone'),
      'field_date_rrule' => $this->t('Field Date Rule')
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $field_date_value = $row->getSourceProperty('field_date_value');
    if (empty($field_date_value)) {
      return FALSE;
    }
    $field_date_value_1 = str_replace('+00:00', '', gmdate('c', strtotime($field_date_value)));
    $row->setSourceProperty('field_date_value', $field_date_value_1);
    


    $field_date_value2 = $row->getSourceProperty('field_date_value2');
    if (empty($field_date_value)) {
      return FALSE;
    }
    $field_date_value_2 = str_replace('+00:00', '', gmdate('c', strtotime($field_date_value2)));
    $row->setSourceProperty('field_date_value2', $field_date_value_2);

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['entity_id' => ['type' => 'integer']];
  }

}