<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * d7_node_access_1_reference source.
 *
 * @MigrateSource(
 *   id = "d7_node_access_1_reference"
 * )
 */
class D7NodeAccess1Reference extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    
      $query = $this->select('node', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'type',
      'language',
      'title',
      'uid',
      'status',
      'created',
      'changed',
      'comment',
      'promote',
      'sticky',
      'tnid',
      'translate'
      ))
      ->condition('n.type', 'reference');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $nid = $row->getSourceProperty('nid');
    $uid = $row->getSourceProperty('uid');
    $query_node = $this->select('node_access', 'nd')
      ->fields('nd', array(
      'grant_view',
      'grant_update',
      'grant_delete'
      ))
      ->condition('nd.nid', $nid)
      ->range(0,1);

      $result_node = $query_node->execute()->fetchObject();

      $grant_view = $result_node->grant_view;
      $grant_update = $result_node->grant_update;
      $grant_delete = $result_node->grant_delete;

    
    $row->setSourceProperty('uid', $uid);
    $row->setSourceProperty('title', 'view_node_reference_field_content_visibility_community_author');
    $row->setSourceProperty('language', 'en');

    $row->setSourceProperty('comment', $grant_view);
    $row->setSourceProperty('promote', $grant_update);
    $row->setSourceProperty('sticky', $grant_delete);
 
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(

      'nid' => $this->t('nid'),
      'vid' => $this->t('vid'),
      'type' => $this->t('type'),
      'language' => $this->t('language'),
      'title' => $this->t('title'),
      'uid' => $this->t('uid'),
      'status' => $this->t('status'),
      'created' => $this->t('created'),
      'changed' => $this->t('changed'),
      'comment' => $this->t('comment'),
      'promote' => $this->t('promote'),
      'sticky' => $this->t('sticky'),
      'tnid' => $this->t('tnid'),
      'translate' => $this->t('translate')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}