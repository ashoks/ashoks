<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_content_files_revision source.
 *
 * @MigrateSource(
 *   id = "event_1_field_content_files_revision"
 * )
 */
class D7ParagraphFilesContentFieldRev extends FieldableEntity {
 

 /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('field_revision_field_files', 'f')
      ->fields('f')
      ->orderBy('f.entity_id')
      ->condition('f.bundle', 'event');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'id' => $this->t('Row ID'),
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'delta' => $this->t('The delta'),
      'language' => $this->t('The language'),
      'field_files_value' => $this->t('field files value'),
      'field_files_revision_id' => $this->t('field files revision id')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    return $ids;
  }
   
}