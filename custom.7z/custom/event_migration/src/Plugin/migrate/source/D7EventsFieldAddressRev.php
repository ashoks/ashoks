<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_address_revision source.
 *
 * @MigrateSource(
 *   id = "event_1_field_address_revision"
 * )
 */
class D7EventsFieldAddressRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('field_revision_field_address', 'n')
      ->fields('n', array(
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_address_country',
      'field_address_locality',
      'field_address_postal_code',
      'field_address_thoroughfare'
      
      ));
      
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // $language = $row->getSourceProperty('language');
    // if (empty($language)) {
    //   return FALSE;
    // }
    // $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'field_address_country' => $this->t('Country Code'),
      'field_address_locality' => $this->t('City'),
      'field_address_postal_code' => $this->t('Zip Code'),
      'field_address_thoroughfare' => $this->t('Address Line 1 & 2')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['entity_id']['type'] = 'integer';
    return $ids;
  }
   
}