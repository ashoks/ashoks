<?php

namespace Drupal\event_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * event_1_field_author source.
 *
 * @MigrateSource(
 *   id = "event_1_field_author"
 * )
 */
class D7EventsFieldAuthor extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node', 'n')
      ->fields('n', array(
      'type',
      'status',
      'nid',
      'vid',
      'language',
      'uid'
      ))
      ->condition('n.type', 'group', '<>')
      ->condition('n.type', 'notification', '<>')
      ->condition('n.type', 'engagement', '<>')
      ->condition('n.type', 'node_gallery_gallery', '<>')
      ->condition('n.type', 'node_gallery_item', '<>')
      ->condition('n.type', 'poll', '<>')
      ->condition('n.type', 'webform', '<>')
      ->condition('n.type', 'wiki', '<>');

      $query->innerJoin('users', 'u', 'u.uid = n.uid');
      $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      $query->addField('fdfn', 'field_name_first_value');
      $query->addField('fdln', 'field_name_last_value');
      $query->addField('u', 'mail');
      $query->addField('u', 'name');
      $query->addField('u', 'uid');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    
     $full_name = $row->getSourceProperty('field_name_first_value')." ".$row->getSourceProperty('field_name_last_value');
     $mail = $row->getSourceProperty('mail');
     $uid = $row->getSourceProperty('uid');

     $formatted_submitter = $full_name."[".$mail."][".$uid."]";

     $field_dummy_submitter_value = $row->getSourceProperty('uid');
     $row->setSourceProperty('uid', $field_dummy_submitter_value);

    // Adding changes for handling the book case for comm. pages
     $field_type = $row->getSourceProperty('type');
     if($field_type == "book"){
      $row->setSourceProperty('type', "pages");
     } else {
      $row->setSourceProperty('type', $field_type);
     }
     
     

     $status = $row->getSourceProperty('status');
     $row->setSourceProperty('status', 0);
     $row->setSourceProperty('language', 'en');


    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'type' => $this->t('The bundle this is associated with'),
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity revision'),
      'language' => $this->t('language'),
      'delta' => $this->t('delta'),
      'uid' => $this->t('uid'),
      'status' => $this->t('status')

    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}