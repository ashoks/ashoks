<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * Asset_field_community_folder source.
 *
 * @MigrateSource(
 *   id = "asset_field_community_folder"
 * )
 */
class D7AssetFieldCommunityFolders extends FieldableEntity {

  /**
   * {@inheritdoc}
   */
  public function query() {
    // Add id column with unique key and Auto Increment in both old and new table, to map each row uniquely.
    $query = $this->select('field_data_field_community_folders_value', 'c')
      ->fields('c', [
        'id',
        'bundle',
        'deleted',
        'entity_id',
        'revision_id',
        'language',
        'delta',
        'field_community_folders_value_tid',
        'entity_type',
      ]);
    $query->innerJoin('taxonomy_term_data', 't', 't.tid = c.field_community_folders_value_tid');
    $query->addField('t', 'name');
    $query->condition('bundle', 'asset');

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');
    $row->setSourceProperty('entity_type', 'taxonomy_term');
    $tname = $row->getSourceProperty('name');

    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
      ->loadByProperties(['name' => $tname, 'vid' => 'community_folders']);
    if ($term != FALSE && !empty($tname)) {
      $term = reset($term);
      $term_id = $term->id();
      $row->setSourceProperty('field_community_folders_value_tid', $term_id);
    }

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
      'id' => $this->t('Row ID'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'field_community_folders_value_tid' => $this->t('Field Community Folder Tid'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    // $ids['delta']['type'] = 'integer';
    return $ids;
  }

}
