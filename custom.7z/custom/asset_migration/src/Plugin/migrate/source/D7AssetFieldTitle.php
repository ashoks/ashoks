<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * Asset_title_field source.
 *
 * @MigrateSource(
 *   id = "asset_title_field"
 * )
 */
class D7AssetFieldTitle extends FieldableEntity {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('field_data_title_field', 'n')
      ->fields('n', [
        'bundle',
        'deleted',
        'entity_id',
        'revision_id',
        'language',
        'delta',
        'title_field_value',
        'title_field_format',
      ]);
    $query->condition('bundle', 'asset');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return [
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Revision id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('Delta'),
      'title_field_value' => $this->t('Field title value'),
      'title_field_format' => $this->t('Field title format'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['entity_id']['type'] = 'integer';
    return $ids;
  }

}
