<?php

namespace Drupal\asset_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "asset_field_archive_date_revision"
 * )
 */
class D7AssetFieldArchiveDateRev extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $fields = [
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_archive_date_value',
    ];
    return $this->select('field_revision_field_archive_date', 'a')
      ->fields('a', $fields)
      ->condition('deleted', 0)
      ->condition('bundle', 'asset');
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'entity_type' => $this->t('The entity type.'),
      'bundle' => $this->t('The bundle this is associated with'),
      'deleted' => $this->t('Deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('Entity revision'),
      'language' => $this->t('Language'),
      'delta' => $this->t('The delta'),
      'field_archive_date_value' => $this->t('Field Date Start Date'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $field_archive_date_value = $row->getSourceProperty('field_archive_date_value');

    $field_enddate_value = date('Y-m-d', $field_archive_date_value);
    ;
    $row->setSourceProperty('field_archive_date_value', $field_enddate_value);
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['revision_id' => ['type' => 'integer']];
  }

}
