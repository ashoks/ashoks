<?php

namespace Drupal\comments_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "comments_node_communitypages"
 * )
 */
class D7Comments_node_communitypages extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('field_data_comment_body', 'n')
      ->fields('n', [
        'bundle',
        'deleted',
        'entity_id',
        'revision_id',
        'language',
        'delta',
      ]);
    $query->innerJoin('comment', 'c', 'c.cid = n.entity_id');
    $query->addField('c', 'nid');
    $query->addField('c', 'pid');
    $query->condition('bundle', 'comment_node_book');
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'bundle' => $this->t('bundle'),
      'deleted' => $this->t('deleted'),
      'entity_id' => $thsi->t('entity_id'),
      'revision_id' => $this->t('revision_id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('delta'),
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $row->setSourceProperty('bundle', 'pages');
    $row->setSourceProperty('language', 'en');
    $row->setSourceProperty('pid', '2');
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['entity_id' => ['type' => 'integer']];
  }

}
