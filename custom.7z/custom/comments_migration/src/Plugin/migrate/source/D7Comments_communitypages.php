<?php

namespace Drupal\comments_migration\Plugin\migrate\source;

use Drupal\migrate\Plugin\migrate\source\SqlBase;
use Drupal\migrate\Row;

/**
 * Obtains the authmap rows for OneAll.
 *
 * @MigrateSource(
 *   id = "comments_communitypages"
 * )
 */
class D7Comments_communitypages extends SqlBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('field_data_comment_body', 'n')
      ->fields('n', [
        'bundle',
        'deleted',
        'entity_id',
        'revision_id',
        'language',
        'delta',
        'comment_body_value',
        'comment_body_format',
      ]);
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'bundle' => $this->t('bundle'),
      'deleted' => $this->t('deleted'),
      'entity_id' => $thsi->t('entity_id'),
      'revision_id' => $this->t('revision_id'),
      'language' => $this->t('Language'),
      'delta' => $this->t('delta'),
      'comment_body_value' => $this->t('comment_body_value'),
      'comment_body_format' => $this->t('comment_body_format'),

    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    $comment_type = $row->getSourceProperty('bundle');

    if ($comment_type == 'comment_node_book') {
      $row->setSourceProperty('bundle', 'comment');
    }
    else {
      return FALSE;
    }

    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return ['entity_id' => ['type' => 'integer']];
  }

}
