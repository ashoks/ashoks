<?php

namespace Drupal\custom_community_page\Plugin\Block;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Url;
use Drupal\group\Entity\Group;
use Drupal\group\Entity\GroupInterface;
use Drupal\node\Entity\Node;



/**
 * Community pages block.
 *
 * @Block(
 *   id = "community_pages_block",
 *   admin_label = "Custom community pages Block"
 * )
 */
class Communitypages extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
		$isFront = \Drupal::service('path.matcher')->isFrontPage();
		if($isFront != true){
      $node_books = $this->getGroupBooks();
      if(!empty($node_books)) {
        $tree = $this->buildTreecommunitypage($node_books);
        $community_page_tree = $this->arrayToList($tree);
        $variables['community_page_tree'] = $community_page_tree;
      }
      else {
        $variables['community_page_tree'] = '(None)';
      }	
      return [
        '#theme' => 'custom_community_page',
        '#data' => $variables['community_page_tree'],
        '#cache' => ['max-age' => 0],
      ];
		}
  }

  public function getCurrentNodeNid() {
    $nodeID = NULL;
    $current_route_match = \Drupal::service('current_route_match');
    if ($node = $current_route_match->getParameter('node')) {
      if ($node instanceof NodeInterface) {
        $nodeID = $node->id();
      }
    }
    return $nodeID;
  }

  /**
   * {@inheritdoc}
   */
  public function arrayToList($in, $p = 0) {

    $nid = $this->getCurrentNodeNid();
    $a = '';
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $curPageURL = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
   
    $a .= "<ul>";
    foreach ($in as $x => $v) {
      if ($p == 0) {
        if ($x == $nid) {
          if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
            $a .= '<li class="py-1 border-bottom-subtel"><input type="checkbox" id="dropdown-toggle-' . $x . '" class="dropdown-toggle-checkbox"><label for="dropdown-toggle-' . $x . '"><i class="material-icons md-4">play_arrow</i></label><a class="active link-primary" href="'.$v['url'].'">' . $v['title'] . '</a>';
          }
          else {
            $a .= '<li class="py-1 border-bottom-subtel"><a class="active link-primary" href="'.$v['url'].'">' . $v['title'] . '</a>';
          }
        }
        else {
          if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
            $a .= '<li class="py-1 border-bottom-subtel"><input type="checkbox" id="dropdown-toggle-' . $x . '" class="dropdown-toggle-checkbox"><label for="dropdown-toggle-' . $x . '"><i class="material-icons md-4">play_arrow</i></label><a class="link-primary" href="'.$v['url'].'">' . $v['title'] . '</a>';
          }
          else {
            $a .= '<li class="py-1 border-bottom-subtel"><a class="link-primary" href="'.$v['url'].'">' . $v['title'] . '</a>';
          }
        }
      }
      if (isset($v['children']) && is_array($v['children']) && $v['children'] != 'null') {
        $a .= $this->arrayToList($v['children'], 0);
      }
    }
    $a .= "</ul>";
    return $a;
  }

  /**
   * {@inheritdoc}
   */
  public function buildTreecommunitypage($ar, $pid = 0) {
    $variables = [];
    foreach ($ar as $book) {
      if ($book->pid == $pid) {
        $variables[$book->nid]['title'] = $book->title;
        $options = ['absolute' => TRUE];
        $url = URL::fromRoute('entity.node.canonical', ['node' => $book->nid], $options);
        $nodeurl = $url->toString();
        $variables[$book->nid]['url'] = $nodeurl;
        // Using recursion.
        $children = $this->buildTreecommunitypage($ar, $book->nid);
        if ($children) {
          $variables[$book->nid]['children'] = $children;
        }
      }
    }
    return $variables;
  }

  /**
   * {@inheritdoc}
   */
  public function getGroupBooks() {
    $group_books = [];
    $groupSocialId = "";
    $parameters = \Drupal::routeMatch()->getParameters()->all();
    $current_path = \Drupal::service('path.current')->getPath();
    $store = \Drupal::service('tempstore.private')->get('views_bulk_operations_mass_operation_page_1');
    $store->get('old_gid');
    if (!empty($parameters['group']) && is_numeric($parameters['group'])) {
      $group = Group::load($parameters['group']);
      if ($group instanceof GroupInterface) {
        $gid = $group->id();
      }
    } elseif ($group = \Drupal::routeMatch()->getParameter('group')) {
      if ($group instanceof GroupInterface) {
        $group_type = $group->getGroupType()->id();
        $gid = $group->id();
      }
 
    } elseif ( $store->get('old_gid') > 0 && ($current_path == '/group/views-bulk-operations/configure/mass_operation/page_1')) {
      $group = Group::load($store->get('old_gid'));
      if ($group instanceof GroupInterface) {
        $gid = $group->id();
      }
    }
    elseif ( $store->get('old_gid') > 0 && ($current_path == '/group/views-bulk-operations/confirm/mass_operation/page_1')) {
      $group = Group::load($store->get('old_gid'));
      if ($group instanceof GroupInterface) {
        $gid = $group->id();
      }
    }
    if (empty($gid)) {
      $nid = \Drupal::routeMatch()->getRawParameter('node');
      $node = ($nid)?Node::load($nid): null;
      if (!empty($node) and $node->hasField('field_community')) {
        $groupSocialId = ($node) ? $node->get('field_community')->getValue()[0]['target_id'] : "";
      }
      if ($groupSocialId) {
        $group = Group::load($groupSocialId);
        $gid = $group->id();
      }
      else {
        $key = \Drupal::request()->query->get('field_community');
        if (isset($key)) {
          $gid = $key;
        }
        else {
          $current_uri = \Drupal::request()->getRequestUri();
          preg_match_all('!\d+!', $current_uri, $matches);
          $gid = (is_array($matches) && (array_key_exists(0,$matches[0])))? $matches[0][0]:null;
        }
      }
    }
    $query = \Drupal::database()->select('book', 'b');
    $query->join('node_field_data', 'n', 'b.nid = n.nid');
    $query->join('group_relationship_field_data', 'nc', 'n.nid = nc.entity_id');
    $query->addField('n', 'type', 'type');
    $query->addField('n', 'title', 'title');
    $query->fields('b');
    $query->condition('n.status', 1);
    $query->condition('nc.gid', $gid);
    $query->condition('nc.plugin_id', 'group_node:pages');
    $query->orderby('b.weight', 'ASC');
    $query->orderby('n.title', 'ASC');
    $query->addTag('node_access');
    $results = $query->execute()->fetchAll();
    
    return $results;
  }

  /**
   * Clears cache.
   *
   * @return int
   *   Integer containing return value.
   */
  public function getCacheMaxAge() {
    return 0;
  }

}
