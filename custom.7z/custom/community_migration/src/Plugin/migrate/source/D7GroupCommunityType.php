<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_community_type source.
 *
 * @MigrateSource(
 *   id = "group_community_type"
 * )
 */
class D7GroupCommunityType extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    
      $query = $this->select('field_data_field_community_type', 'fdf')
      ->fields('fdf', array(
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_community_type_value'
      ))
      ->condition('fdf.bundle', 'group');
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $entity_id = $row->getSourceProperty('entity_id');

    $query_node = $this->select('field_data_field_og_subscribe_settings', 'fds')
     ->fields('fds', array(
     'field_og_subscribe_settings_value'
     ))
     ->condition('fds.entity_id', $entity_id);

     $result_node = $query_node->execute()->fetchObject();

     $field_og_subscribe_settings_value = $result_node->field_og_subscribe_settings_value;

     

    //$field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('bundle', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('bundle', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('bundle', 'secret_group');
     }


    // Group Language changed from und to en 

   
    $row->setSourceProperty('language', 'en');

    $field_community_type_value = $row->getSourceProperty('field_community_type_value');

    if($field_community_type_value == 0 || $field_community_type_value == 1 || $field_community_type_value == 2){
      $row->setSourceProperty('field_community_type_value', 0);
    }
 
    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
    'bundle' => $this->t('bundle'),
    'deleted' => $this->t('deleted'),
    'entity_id' => $this->t('entity_id'),
    'revision_id' => $this->t('revision_id'),
    'delta' => $this->t('delta'),
    'field_community_type_value' => $this->t('field_community_type_value')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['entity_id']['type'] = 'integer';
    return $ids;
  }
   
}