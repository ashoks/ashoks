<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;
use Drupal\Core\Database\Database;

/**
 * community_1_field_group_description_rev source.
 *
 * @MigrateSource(
 *   id = "community_1_field_group_description_rev"
 * )
 */
class D7GroupsFieldDescriptionRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
   
      $query = $this->select('field_revision_body', 'n')
      ->fields('n', array(
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'body_value'
      ))
      ->condition('n.bundle', 'group');

      $query->leftJoin('node', 'fdf', 'fdf.nid = n.entity_id');
      // $query->innerJoin('field_data_field_og_subscribe_settings', 'fds', 'fdf.nid = fds.entity_id');
      // $query->addField('fds', 'field_og_subscribe_settings_value');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $entity_id = $row->getSourceProperty('entity_id');

    Database::setActiveConnection('migrate');
    $active = Database::getConnection();
    $field_og_subscribe_settings_value = $active->select('field_data_field_og_subscribe_settings', 'fds')->fields('fds',['field_og_subscribe_settings_value'])->condition('fds.entity_id',$entity_id)->execute()->fetchAll();
    
    foreach($field_og_subscribe_settings_value as $key => $object) {
      if (!empty($object->field_og_subscribe_settings_value) && $object->field_og_subscribe_settings_value == "anyone") {
        $row->setSourceProperty('bundle', 'public_group');
      }
  
      if (!empty($object->field_og_subscribe_settings_value) && $object->field_og_subscribe_settings_value == "invitation") {
        $row->setSourceProperty('bundle', 'closed_group');
      }
  
      if (!empty($object->field_og_subscribe_settings_value) && $object->field_og_subscribe_settings_value == "approval") {
        $row->setSourceProperty('bundle', 'secret_group');
      }
    }

    Database::setActiveConnection('default');

    // Group Language changed from und to en 

    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');

    

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
    'entity_id' => $this->t('Entity ID'),
    'revision_id' => $this->t('Entity Revision'),
    'bundle' => $this->t('bundle'),
    'language' => $this->t('Language'),
    'delta' => $this->t('delta'),
    'deleted' => $this->t('deleted'),
    'body_value' => $this->t('body_value')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['revision_id']['type'] = 'integer';
    return $ids;
  }
   
}