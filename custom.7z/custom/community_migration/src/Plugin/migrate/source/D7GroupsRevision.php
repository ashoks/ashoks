<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * master_groups_revision source.
 *
 * @MigrateSource(
 *   id = "master_groups_revision"
 * )
 */
class D7GroupsRevision extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node_revision', 'nr')
      ->fields('nr', array(
      'nid',
      'vid',
      'uid',
      'log',
      'timestamp',
      'status'
      ));
      // $query->leftJoin('node', 'nd', 'nr.nid = nd.nid');
      // $query->condition('nd.type', 'group');


      $query->join('field_data_field_og_subscribe_settings', 'nd', 'nr.nid = nd.entity_id');


      // SELECT nr.* FROM `node` nr LEFT JOIN node_revision nd ON nr.nid = nd.nid WHERE nr.type = 'group';

     
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    // $nid = $row->getSourceProperty('nid');
 
    // $query_node = $this->select('node', 'nd')
    // ->fields('nd', array(
    // 'type'
    // ))
    // ->condition('nd.nid', $nid);

    // $result_node = $query_node->execute()->fetchObject();

    // $node_type = $result_node->type;

    // if($node_type != "group")
    // {
    // return false;
    // }
    
    // Group revision_default value set to 1 
    $row->setSourceProperty('status', 1);

    // Group Language changed from und to en 
    $row->setSourceProperty('log', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity Revision'),
      'uid' => $this->t('User created group'),
      'log' => $this->t('Language'),
      'timestamp' => $this->t('Timestamp'),
      'status' => $this->t('Status')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['vid']['type'] = 'integer';
    return $ids;
  }
   
}