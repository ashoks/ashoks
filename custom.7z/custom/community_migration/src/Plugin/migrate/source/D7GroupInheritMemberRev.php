<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_inherit_member_rev source.
 *
 * @MigrateSource(
 *   id = "group_inherit_member_rev"
 * )
 */
class D7GroupInheritMemberRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {

    $query = $this->select('field_revision_field_inherit_members', 'n')
      ->fields('n', array(
      'entity_type',
      'bundle',
      'deleted',
      'entity_id',
      'revision_id',
      'language',
      'delta',
      'field_inherit_members_value'
      ))
      ->condition('n.bundle', 'group');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

      // Fetch the value of matching entity_id on field_data_field_og_subscribe_settings
      $entity_id = $row->getSourceProperty('entity_id');

      $queryInheritMember = $this->select('field_data_field_og_subscribe_settings', 'f')
        ->fields('f', array(
        'field_og_subscribe_settings_value'
        ))
        ->condition('f.entity_id', $entity_id);
  
      $resultInheritMember = $queryInheritMember->execute()->fetchObject();
      $field_og_subscribe_settings_value = $resultInheritMember->field_og_subscribe_settings_value;
  
   
       if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
        $row->setSourceProperty('bundle', 'public_group');
       }
  
       if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
        $row->setSourceProperty('bundle', 'closed_group');
       }
  
       if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
        $row->setSourceProperty('bundle', 'secret_group');
       }
  
  
      // Group Language changed from und to en 
      $row->setSourceProperty('language', 'en');
    
      return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'entity_type' => $this->t('entity_type'),
      'bundle' => $this->t('bundle'),
      'deleted' => $this->t('deleted'),
      'entity_id' => $this->t('Entity ID'),
      'revision_id' => $this->t('revision_id'),
      'language' => $this->t('language'),
      'delta' => $this->t('delta'),
      'field_inherit_members_value' => $this->t('field inherit members value')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['revision_id']['type'] = 'integer';
    return $ids;
  }
   
}