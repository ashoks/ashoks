<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * community_1_field_group_description source.
 *
 * @MigrateSource(
 *   id = "community_1_field_group_description"
 * )
 */
class D7GroupsFieldDescription extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    //   $query = $this->select('field_data_body', 'n')
    //   ->fields('n', array(
    //   'bundle',
    //   'deleted',
    //   'entity_id',
    //   'revision_id',
    //   'language',
    //   'delta',
    //   'body_value',
    //   'body_summary',
    //   'body_format'
    //   ))
    //   ->condition('n.bundle', 'group');
    // //   $query->innerJoin('node', 'nd', 'nd.nid = n.entity_id');
    // //   $query->innerJoin('field_data_field_og_subscribe_settings', 'fds', 'fds.entity_id = nd.nid');
    // //   $query->addField('fds', 'field_og_subscribe_settings_value');
      
    //   return $query;



      $query = $this->select('node', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'type',
      'language',
      'title',
      'uid',
      'status',
      'created',
      'changed',
      'promote'
      ))
      ->condition('n.type', 'group');

      // ->condition('n.type', 'event', '=')
      // ->condition('n.type', 'pages', '=')
      // ->condition('n.type', 'reference', '=')
      // ->condition('n.type', 'news', '=');

      $query->innerJoin('field_data_body', 'fdf', 'fdf.entity_id = n.nid');
      $query->innerJoin('field_data_field_og_subscribe_settings', 'fds', 'fds.entity_id = n.nid');

      // $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      // $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      // $query->condition('fdf.field_data_field_default_display', 'asset');
      // $query->addField('fdln', 'field_name_last_value');
      // $query->addField('u', 'mail');
      // $query->addField('u', 'name');
      $query->addField('fdf', 'delta');
      $query->addField('fdf', 'deleted');
      $query->addField('fdf', 'body_value');
      $query->addField('fdf', 'body_format');
      $query->addField('fds', 'field_og_subscribe_settings_value');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

    $field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('type', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('type', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('type', 'secret_group');
     }


    // Group Language changed from und to en 

    $language = $row->getSourceProperty('language');
    if (empty($language)) {
      return FALSE;
    }
    $row->setSourceProperty('language', 'en');

    

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
    //   'bundle' => $this->t('Bundle'),
    //   'deleted' => $this->t('Deleted'),
    //   'entity_id' => $this->t('Entity ID'),
    //   'revision_id' => $this->t('Entity Revision'),
    //   'language' => $this->t('Language'),
    //   'delta' => $this->t('Delta'),
    //   'body_value' => $this->t('body value'),
    //   'body_summary' => $this->t('body summary'),
    //   'body_format' => $this->t('body format')

    'nid' => $this->t('Entity ID'),
    'vid' => $this->t('Entity Revision'),
    'type' => $this->t('Type'),
    'language' => $this->t('Language'),
    'delta' => $this->t('delta'),
    'deleted' => $this->t('deleted'),
    'body_value' => $this->t('body_value'),
    'body_format' => $this->t('body_format'),

    // $query->addField('fdf', 'delta');
    // $query->addField('fdf', 'deleted');
    // $query->addField('fdf', 'body_value');
    // $query->addField('fdf', 'body_format');

    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}