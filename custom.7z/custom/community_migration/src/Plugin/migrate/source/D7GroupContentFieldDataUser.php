<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * group_content_field_data_user source.
 *
 * @MigrateSource(
 *   id = "group_content_field_data_user"
 * )
 */
class D7GroupContentFieldDataUser extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
    #Change 2 : Adding filter for data which actually has been removed from new Prism like wiki, poll etc.
      $query = $this->select('og_membership', 'n')
      ->fields('n', array(
      'id',
      'type',
      'etid',
      'entity_type',
      'gid',
      'group_type',
      'state',
      'created',
      'field_name',
      'language',
      'grp_type',
      'plugin_id'
      ))
      ->condition('n.entity_type', 'user');
     
      // ->condition('nd.type', 'group', '<>')
      // ->condition('nd.type', 'notification', '<>')
      // ->condition('nd.type', 'engagement', '<>')
      // ->condition('nd.type', 'node_gallery_gallery', '<>')
      // ->condition('nd.type', 'node_gallery_item', '<>')
      // ->condition('nd.type', 'poll', '<>')
      // ->condition('nd.type', 'webform', '<>')
      // ->condition('nd.type', 'wiki', '<>');

      // $query->leftJoin('node', 'nd', 'nd.nid = n.etid');
      // $query->addField('nd', 'nid');
      // $query->addField('nd', 'type');
    
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {

   

    $type = $row->getSourceProperty('entity_type');
    $gid = $row->getSourceProperty('gid');
    $etid = $row->getSourceProperty('etid');
   
    $row->setSourceProperty('group_type', 1);


    // get the type of uid using $etid from table node
    $query_uid = $this->select('users', 'nd')
    ->fields('nd', array(
    'uid',
    'name',
    'created'
    ))
    ->condition('nd.uid', $etid);
    $result_uid = $query_uid->execute()->fetchObject();

    $uid = $result_uid->uid;
    if (empty($uid)) {
        return FALSE;
    }
    
    $label = $result_uid->name;
    $changed = $result_uid->created;
    $row->setSourceProperty('field_name', $label);
    $row->setSourceProperty('entity_type', $changed);
    $row->setSourceProperty('state', $uid);
     

    // Get the group type from field_data_field_og_subscribe_settings

    $query_group = $this->select('field_data_field_og_subscribe_settings', 'fds')
    ->fields('fds', array(
    'field_og_subscribe_settings_value'
    ))
    ->condition('fds.entity_id', $gid);
    $result_group = $query_group->execute()->fetchObject();
    $group_type = $result_group->field_og_subscribe_settings_value;

    if (!empty($group_type) && $group_type == "anyone") {
        $custom_gtype = 'public_group';
    }

    if (!empty($group_type) && $group_type == "invitation") {
        $custom_gtype = 'closed_group';
    }

    if (!empty($group_type) && $group_type == "approval") {
        $custom_gtype = 'secret_group';
    }
 
    
    $cg_type = $custom_gtype.'-group_membership';

    $row->setSourceProperty('type', $cg_type);

    $row->setSourceProperty('language', 'en');

    // Here we will be creating 2 new field for group_type & plugin_id in og_membership table so that we can map 2 extra fields added in d10
    // ALTER TABLE `og_membership` ADD `grp_type` VARCHAR(250) NULL AFTER `language`, ADD `plugin_id` VARCHAR(250) NULL AFTER `grp_type`;
    $row->setSourceProperty('grp_type', $custom_gtype);
    $row->setSourceProperty('plugin_id', 'group_membership');

    return parent::prepareRow($row);

  }

  /**
   * {@inheritdoc}
   */
  public function fields() {


    return array(

    'id' => $this->t('id'),
    'type' => $this->t('type'),
    'etid' => $this->t('etid'),
    'entity_type' => $this->t('entity_type'),
    'gid' => $this->t('gid'),
    'group_type' => $this->t('group_type'),
    'state' => $this->t('state'),
    'created' => $this->t('created'),
    'field_name' => $this->t('field_name'),
    'language' => $this->t('langcode'),
    'grp_type' => $this->t('group type will be added'),
    'plugin_id' => $this->t('Plugin ID')
    
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['id']['type'] = 'integer';
    return $ids;
  }
   
}