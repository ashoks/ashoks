<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * groups_author_rev source.
 *
 * @MigrateSource(
 *   id = "groups_author_rev"
 * )
 */
class D7GroupsAuthorRev extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node_revision', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'uid',
      'log',
      'comment',
      'status',
      'promote'
      ));
      // ->condition('n.type', 'group');

      // ->condition('n.type', 'event', '=')
      // ->condition('n.type', 'pages', '=')
      // ->condition('n.type', 'reference', '=')
      // ->condition('n.type', 'news', '=');
      $query->leftJoin('field_data_field_og_subscribe_settings', 'fds', 'fds.entity_id = n.nid');

      // $query->innerJoin('field_data_field_name_first', 'fdfn', 'fdfn.entity_id = u.uid');
      // $query->innerJoin('field_data_field_name_last', 'fdln', 'fdln.entity_id = u.uid');
      // $query->condition('fdf.field_data_field_default_display', 'asset');
      // $query->addField('fdln', 'field_name_last_value');
      // $query->addField('u', 'mail');
      // $query->addField('u', 'name');

      $query->addField('fds', 'field_og_subscribe_settings_value');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     
     $field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('log', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('log', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('log', 'secret_group');
     }
 
    // Group Language changed from und to en 
    $row->setSourceProperty('status', 0);
    $row->setSourceProperty('promote', 0);
    $row->setSourceProperty('comment', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity Revision'),
      'uid' => $this->t('User ID'),
      'log' => $this->t('log'),
      'comment' => $this->t('Language'),
      'status' => $this->t('Status'),
      'promote' => $this->t('Promote')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['vid']['type'] = 'integer';
    return $ids;
  }
   
}