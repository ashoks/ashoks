<?php

namespace Drupal\community_migration\Plugin\migrate\source;

use Drupal\migrate\Row;
use Drupal\migrate_drupal\Plugin\migrate\source\d7\FieldableEntity;

/**
 * community_1_field_group_data source.
 *
 * @MigrateSource(
 *   id = "community_1_field_group_data"
 * )
 */
class D7GroupsFieldData extends FieldableEntity {
 
 /**
   * {@inheritdoc}
   */
  public function query() {
      $query = $this->select('node', 'n')
      ->fields('n', array(
      'nid',
      'vid',
      'type',
      'language',
      'title',
      'uid',
      'status',
      'created',
      'changed',
      'promote'
      ))
      ->condition('n.type', 'group');

      $query->leftJoin('field_data_field_default_display', 'fdf', 'fdf.entity_id = n.nid');
      $query->leftJoin('field_data_field_og_subscribe_settings', 'fds', 'fds.entity_id = n.nid');

      $query->addField('fdf', 'field_default_display_value');
      $query->addField('fds', 'field_og_subscribe_settings_value');
      
      return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
     
     $field_og_subscribe_settings_value = $row->getSourceProperty('field_og_subscribe_settings_value');
 
     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "anyone") {
      $row->setSourceProperty('type', 'public_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "invitation") {
      $row->setSourceProperty('type', 'closed_group');
     }

     if (!empty($field_og_subscribe_settings_value) && $field_og_subscribe_settings_value == "approval") {
      $row->setSourceProperty('type', 'secret_group');
     }

     $field_default_display_value = $row->getSourceProperty('field_default_display_value');
 
     if (!empty($field_default_display_value) && $field_default_display_value == "asset") {
        $row->setSourceProperty('promote', 'view.group_assets.page_group_assets');
     }  else if (!empty($field_default_display_value) && $field_default_display_value == "reference") {
        $row->setSourceProperty('promote', 'view.group_references.page_group_references');
     }  else if (!empty($field_default_display_value) && $field_default_display_value == "event") {
        $row->setSourceProperty('promote', 'view.group_events.page_group_events');
     }  else if (!empty($field_default_display_value) && $field_default_display_value == "news") {
        $row->setSourceProperty('promote', 'view.group_news.page_group_news');
     } else {
        $row->setSourceProperty('promote', 'node:'.$field_default_display_value);
     }



    // Group Language changed from und to en 
    $row->setSourceProperty('language', 'en');

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    return array(
      'nid' => $this->t('Entity ID'),
      'vid' => $this->t('Entity Revision'),
      'type' => $this->t('Type'),
      'language' => $this->t('Language'),
      'title' => $this->t('Title'),
      'uid' => $this->t('User ID'),
      'status' => $this->t('Status'),
      'created' => $this->t('Created'),
      'changed'  => $this->t('Changed'),
      'promote' => $this->t('Promote')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    $ids['nid']['type'] = 'integer';
    return $ids;
  }
   
}