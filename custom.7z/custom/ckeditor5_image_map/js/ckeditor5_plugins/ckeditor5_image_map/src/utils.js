export const createImagemapElement = (attrs, model) => {
  // Use the model's writer within a change transaction
  return model.change(writer => {
      // Create the imagemap element with the attributes
      return writer.createElement('imagemap', attrs);
  });
}

export const updateImagemapElement = (modelElement, attrs, writer) => {
const {x,y} = attrs
  writer.setAttribute( 'x', x, modelElement )
  writer.setAttribute( 'y', y, modelElement )
}
export function isSupported(option) {
  return /^\d(.\d+)?$/mg.test(String(option));
}

export function normalizeOptions(configuredOptions) {
  return configuredOptions.map(optionDefinition).filter(option => !!option);
}

export function buildDefinition(options) {
  const definition = {
    model: {
      key: 'lineHeight',
      values: options.slice(),
    },
    view: {},
  };

  for (const option of options) {
    definition.view[option] = {
      key: 'style',
      value: {
        'line-height': option,
      },
    };
  }

  return definition;
}

function optionDefinition(option) {
  if (typeof option === 'object') {
    return option;
  }

  if (option === 'default') {
    return {
      model: undefined,
      title: 'Default',
    };
  }

  const sizePreset = parseFloat(option);

  if (isNaN(sizePreset)) {
    return;
  }

  return generatePixelPreset(sizePreset);
}

function generatePixelPreset(size) {
  const sizeName = String(size);

  return {
    title: sizeName,
    model: size,
    view: {
      name: 'span',
      styles: {
        'line-height': sizeName,
      },
      priority: 5,
    },
  };
}
