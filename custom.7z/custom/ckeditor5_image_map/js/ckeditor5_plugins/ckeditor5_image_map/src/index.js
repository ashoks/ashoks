import ImageMap from './imagemap';

export default {
  ImageMap,
};
