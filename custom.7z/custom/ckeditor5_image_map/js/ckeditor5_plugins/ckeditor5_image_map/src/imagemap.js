import { Plugin } from 'ckeditor5/src/core';
import ImageMapEditing from './imagemapediting';
import ImageMapUI from './imagemapui';

export default class ImageMap extends Plugin {
  static get requires() {
    return [
      ImageMapEditing,
      ImageMapUI,
    ];
  }

  static get pluginName() {
    return 'ImageMap';
  }
}
