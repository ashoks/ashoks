import { View  } from 'ckeditor5/src/ui';

export default class ImageMapModal {
  constructor(editor, existingData, mapId, imageElement) {
      this.editor = editor;
      this.imageElement = imageElement;
      this.existingData = existingData || '{}';
      this.mapId = mapId;
      this.modal = new View(editor.locale);
      this.areas = [];
      this.drawing = false;
      this.selectedArea = null;
      this.currentShape = 'rect';
      this.tempCoords = [];
      this.lastCoords = []
      this.imgSrc = '';
      this._setupModal();
      //this.modal.render();
  }
  show(){
 //     this.modal.show();
  }
   createViewForForm() {
    const form = document.createElement('form');
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Enter something';
    form.appendChild(input);

    return form;
}
  _setupModal() {
    $ = jQuery;
    const editor = this.editor;
    var arr = Array.from(this.imageElement.getAttributes());
    let obj = {};
    $.map(arr, function(item) {
        obj[item[0]] = item[1];
    });
    const imgSrc = obj.src;
    const data_entity_uuid = obj.dataEntityUuid;
    const data_entity_type = obj.dataEntityType;
    const imgWidth = obj.resizedWidth;
    const imgHeight = obj.resizedHeight;
    const imageElement = this.imageElement;
    let existing_map = '';
    if(imageElement.nextSibling) {
       existing_map = imageElement.nextSibling._attrs.get('htmlContent');
    }
    $('.dialog-content').remove();
    var dialog = $('<div></div>')
    .attr('id', 'dynamicDialog')
    .addClass('dialog-content')
    .html(`

    <button id="addRectangle">➕ Add Rectangle</button>
    <button id="generateMap">📌 Apply</button>
    <button id="clearMap">❌ Clear All</button>
    <div id="image-container">
        <img src="`+imgSrc+`" id="image-map" width="`+imgWidth+`" height="`+imgWidth+`" usemap="#`+data_entity_uuid+`">
        <img src="`+imgSrc+`" id="image-map" width="`+imgWidth+`" height="`+imgWidth+`">
        <map name="`+data_entity_uuid+`">`+existing_map+`</map>
    </div>
    <textarea id="output" class="output_map" rows="5" cols="80" readonly></textarea>

    <div id="editForm" class="controls">

        <label>Title:</label>
        <input type="text" id="rectTitle">
        <label>Link:</label>
        <input type="text" id="rectLink">
        <label>Target:</label>
        <select id="rectTarget">
            <option value="_self">Same Tab (_self)</option>
            <option value="_blank">New Tab (_blank)</option>
            <option value="_parent">Parent Frame (_parent)</option>
            <option value="_top">Top Frame (_top)</option>
        </select>

        <button id="saveData">Save</button>
        <button id="cancelBtn">Close</button>
    </div>

    `)
    .dialog({
        autoOpen: false,
        title: 'Image Map',
        modal: true,

        width: 800,
        buttons: {
            Close: function() {
                $(this).dialog('close');
            }
        },
        open: function() {
        }
    });

    dialog.dialog('open');
    let rectCount = 0;
    let selectedRect = null;

    if (!imageElement) {
      console.warn("No image selected.");
      return;
  }
    $(document).ready(function () {

      ///////////////////// Existing Load Imagemap Start .////////
      loadExistingMap();
      function loadExistingMap() {
        $("area").each(function () {
            let coords = $(this).attr("coords").split(",");
            let x1 = parseInt(coords[0]);
            let y1 = parseInt(coords[1]);
            let x2 = parseInt(coords[2]);
            let y2 = parseInt(coords[3]);
            let width = x2 - x1;
            let height = y2 - y1;
            let link = $(this).attr("href") || "#";
            let title = $(this).attr("title") || "";
            let target = $(this).attr("target") || "_self";

            addRectangle(x1, y1, width, height, title, link, target);
        });
      }

      function addRectangle(left, top, width, height, title = "", link = "#", target = "_self") {
        rectCount++;
        let rect = $("<div>", {
            "class": "drawn-rectangle",
            "id": "rect" + rectCount,
            "data-title": title,
            "data-link": link,
            "data-target": target
        }).css({
            width: width + "px",
            height: height + "px",
            left: left + "px",
            top: top + "px"
        }).appendTo("#image-container");

        let removeBtn = $("<div>", {
            "class": "remove-btn",
            "text": "×"
        }).appendTo(rect);

        rect.draggable({ containment: "#image-container" }).resizable({
            stop: function () {
                showEditForm($(this));
            }
        });

        rect.click(function () {
            $(".drawn-rectangle").removeClass("selected");
            $(this).addClass("selected");
            // $(".remove-btn").hide();
            $(this).find(".remove-btn").show();
            showEditForm($(this));
        });

        removeBtn.click(function (e) {
            e.stopPropagation();
            rect.remove();
            $("#editForm").hide();
        });
      }
      ///////////////////// Existing Load Imagemap End .////////
      $("#addRectangle").click(function () {
          rectCount++;
          let rect = $("<div>", {
              "class": "drawn-rectangle",
              "id": "rect" + rectCount,
              "data-title": "",
              "data-link": "",
              "data-target": "_self"
          }).css({
              width: "100px",
              height: "50px",
              left: "50px",
              top: "50px"
          }).appendTo("#image-container");

          let removeBtn = $("<div>", {
              "class": "remove-btn",
              "text": "×"
          }).appendTo(rect);

          rect.draggable({ containment: "#image-container" }).resizable({
              stop: function () {
                  showEditForm($(this));
              }
          });

          rect.click(function () {
              $(".drawn-rectangle").removeClass("selected");
              $(this).addClass("selected");
              $(".remove-btn").hide();
              $(this).find(".remove-btn").show();
              showEditForm($(this));
          });

          removeBtn.click(function (e) {
              e.stopPropagation();
              rect.remove();
              $("#editForm").hide();
          });
      });
      function showEditForm(rect) {
        selectedRect = rect;
        let pos = rect.position();
        $("#rectTitle").val(rect.attr("data-title"));
        $("#rectLink").val(rect.attr("data-link"));
        $("#rectTarget").val(rect.attr("data-target"));
        $("#editForm").css({ top: pos.top - 0, left: pos.left }).show();
      }

      $("#saveData").click(function () {
        if (selectedRect) {
          selectedRect.attr("data-title", $("#rectTitle").val());
          selectedRect.attr("data-link", $("#rectLink").val());
          selectedRect.attr("data-target", $("#rectTarget").val());
          $("#editForm").hide();
        }
      });
      $("#cancelBtn").click(function () {
        $("#editForm").hide();
      })
      $("#generateMap").click(function () {
        let mapHTML = `<map name="`+data_entity_uuid+`">\n`;
        let areas = [];
        $(".drawn-rectangle").each(function () {
            let pos = $(this).position();
            let width = $(this).width();
            let height = $(this).height();

            let x1 = Math.round(pos.left);
            let y1 = Math.round(pos.top);
            let x2 = x1 + Math.round(width);
            let y2 = y1 + Math.round(height);

            let link = $(this).attr("data-link") || "#";
            let title = $(this).attr("data-title") || "Untitled";
            let target = $(this).attr("data-target") || "_self";
            areas.push(`<area shape="rect" coords="${x1},${y1},${x2},${y2}" href="${link}" target="${target}" title="${title}">`);
          });
        mapHTML += areas.join("\n") + `\n</map>`;
        $("#output").val(mapHTML);
        $("#image-map").attr("usemap", "#"+data_entity_uuid+"");
        $("#image-map-map").html(areas.join("\n"));
        // Editor changes
        editor.model.change(writer => {
          if (!imageElement) {
              console.warn("No image selected.");
              return;
          }
          var imgHTML = '';
          imgHTML = '<img src="'+imgSrc+'" usemap="#'+data_entity_uuid+'" data-entity-uuid="'+data_entity_uuid+'" data-entity-type="'+data_entity_type+'" width="'+imgWidth+'" height="'+imgHeight+'">';
          imgHTML = '<img src="'+imgSrc+'" usemap="#'+data_entity_uuid+'" data-entity-uuid="'+data_entity_uuid+'" data-entity-type="'+data_entity_type+'" width="'+imgWidth+'" height="'+imgHeight+' usemap="#'+data_entity_uuid+'>';
          // Define raw HTML for the imagemap
          const rawHtml = imgHTML+mapHTML;

          // Convert the raw HTML into a CKEditor 5 model element
          const viewFragment = editor.data.processor.toView(rawHtml);
          const modelFragment = editor.data.toModel(viewFragment);
          // Insert the HTML into the editor at the current selection
          editor.model.insertContent(modelFragment, editor.model.document.selection.getFirstPosition())
          if(imageElement.nextSibling) {
            writer.remove(imageElement.nextSibling);
          }
          // Remove the selected image
          writer.remove(imageElement);
          console.log("Image replaced with imagemap.");
        });
        $('.ui-button').click();
        $('.ui-dialog-buttonset > button').click();
      });

      $("#clearMap").click(function () {
          $(".drawn-rectangle").remove();
          $("#editForm").hide();
          $("#output").val("");
          $("#image-map-map").html("");
      });
  });
}
}

